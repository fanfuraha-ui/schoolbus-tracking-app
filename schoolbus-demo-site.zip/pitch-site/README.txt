School bus tracking: demo site (static files, no server needed)

Folder layout
  index.html        showcase page (screenshots + links to both demos)
  admin-demo/       clickable office dashboard demo   (password: demo)
  parent-demo/      clickable parent app demo         (sign-in code: 123456)
  img/              screenshots

Publish it free in about 5 minutes (pick one)

A) Netlify (easiest): go to app.netlify.com/drop, drag this whole folder onto the page.
   You get a link like https://something.netlify.app . Rename it in Site settings.

B) GitHub Pages: create a new repo, upload these files to the root, then
   Settings > Pages > Deploy from branch > main / (root).
   Link: https://<your-username>.github.io/<repo-name>/

Optional: attach your own domain (e.g. demo.yourname.co.ke) in either service's domain settings.
The demos use made-up data for a pretend school and need an internet connection for the map tiles and fonts.
