'use strict';
/**
 * Bundles an app module for Node with React Native swapped for the DOM shim (demo/rnWeb.js),
 * so screens can be server-rendered in tests. React comes from the tool cache.
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const Module = require('module');

// Packages used only by the tests (react, react-dom/server, esbuild): the workspace's node_modules
// after `npm install`, or a shared tool folder (NODE_PATH) where nothing is installed.
const MODS = (() => {
  try { return path.dirname(path.dirname(require.resolve('react-dom/package.json'))); } catch { return process.env.NODE_PATH || '/opt/npm-tools/node_modules'; }
})();
const esbuild = require(path.join(MODS, 'esbuild'));
const ROOT = path.join(__dirname, '../..');
const SHIM = path.join(ROOT, 'demo/rnWeb.js');
const OUT = fs.mkdtempSync(path.join(os.tmpdir(), 'parent-render-'));

function load(file) {
  const outfile = path.join(OUT, `${path.basename(file)}.cjs`);
  esbuild.buildSync({
    entryPoints: [path.join(ROOT, file)], bundle: true, outfile, platform: 'node', format: 'cjs',
    loader: { '.js': 'jsx' }, jsx: 'automatic', logLevel: 'silent',
    alias: { 'react-native': SHIM, 'react-native-safe-area-context': SHIM, 'react-native-webview': SHIM },
    external: ['react', 'react/jsx-runtime', 'react-dom'],
  });
  const m = new Module(outfile);
  m.paths = [MODS];
  m._compile(fs.readFileSync(outfile, 'utf8'), outfile);
  return m.exports;
}

module.exports = { load, MODS };
