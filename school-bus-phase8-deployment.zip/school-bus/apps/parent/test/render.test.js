'use strict';
/**
 * Server-renders every parent screen (React 19, React Native swapped for the DOM shim) in English
 * and Kiswahili. Catches render-time crashes and checks what the parent actually reads.
 */
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('path');
const { load, MODS } = require('./support/load');

const React = require(path.join(MODS, 'react'));
const { renderToStaticMarkup } = require(path.join(MODS, 'react-dom/server'));
const { translate, plural } = require('../src/i18n/strings');
const time = require('../src/lib/time');
const { summarize } = require('../src/live/tripModel');

const { TodayScreen } = load('src/screens/TodayScreen.js');
const { TripScreen } = load('src/screens/TripScreen.js');
const { AbsencesScreen, AbsenceSheet } = load('src/screens/AbsencesScreen.js');
const { AlertsScreen } = load('src/screens/AlertsScreen.js');
const { SettingsScreen } = load('src/screens/SettingsScreen.js');
const { SignInScreen } = load('src/screens/SignInScreen.js');
const { ConsentScreen } = load('src/screens/ConsentScreen.js');

const h = React.createElement;
const text = (html) => html.replace(/<[^>]+>/g, ' ').replace(/&#x27;/g, "'").replace(/&amp;/g, '&').replace(/\s+/g, ' ');
const I = (lang) => ({ t: (k, v) => translate(lang, k, v), tp: (k, n, v) => translate(lang, plural(k, n), { n, ...v }), lang });
const D = '2026-11-17';
const at = (x) => time.localToMs(D, x);
const iso = (ms) => new Date(ms).toISOString();
const noop = () => {};

const overview = () => ({
  profile: { id: 'g1', fullName: 'Wanjiru Kamau', phone: '+254711000004', channelMode: 'push_then_sms', preferredLanguage: 'en', quietHoursStart: null, quietHoursEnd: null, consentAt: iso(at('06:00')) },
  school: { name: 'Greenfield Academy', phone: '+254720000111' },
  serviceDate: D,
  children: [
    { id: 'c1', fullName: 'Amina Wairimu', className: 'Grade 3', today: [
      { studentId: 'c1', scheduleId: 'am', scheduleName: 'Morning pickup', direction: 'to_school', startTime: '06:40:00', routeName: 'Route 2 - Gikambura', stopId: 's5', stopName: 'Gikambura Stage 9', landmark: null, scheduledTime: '07:10:00', lat: -1.25, lng: 36.66, tripId: 't1', tripStatus: 'active', cancelledReason: null, plateNumber: 'KDA 102B', stopStatus: 'pending', etaAt: iso(at('07:08')), arrivedAt: null, absenceId: null, absentAllDay: null, absent: false, stopsAway: 3, busSeenAt: iso(at('07:00') - 8000), childEvent: null, childEventAt: null },
      { studentId: 'c1', scheduleId: 'pm', scheduleName: 'Afternoon drop-off', direction: 'from_school', startTime: '15:40:00', routeName: 'Route 2 - Gikambura', stopId: 's5', stopName: 'Gikambura Stage 9', landmark: null, scheduledTime: '16:35:00', lat: -1.25, lng: 36.66, tripId: null, tripStatus: 'not_started', cancelledReason: null, plateNumber: 'KDA 102B', stopStatus: null, etaAt: null, arrivedAt: null, absenceId: null, absentAllDay: null, absent: false, stopsAway: null, busSeenAt: null, childEvent: null, childEventAt: null },
    ] },
    { id: 'c2', fullName: 'Baraka Kamau', className: 'Grade 6', today: [
      { studentId: 'c2', scheduleId: 'am5', scheduleName: 'Morning pickup', direction: 'to_school', startTime: '06:35:00', routeName: 'Route 5 - Thogoto', stopId: 'x', stopName: 'Thogoto Gate', landmark: null, scheduledTime: '07:05:00', lat: -1.26, lng: 36.65, tripId: 't5', tripStatus: 'active', cancelledReason: null, plateNumber: 'KDB 505E', stopStatus: 'pending', etaAt: null, arrivedAt: null, absenceId: 'ab1', absentAllDay: false, absent: true, stopsAway: 2, busSeenAt: null, childEvent: null, childEventAt: null },
    ] },
  ],
});

test('Today: countdown, stops, when to be at the stop, quiet afternoon ride, absent child with undo', () => {
  for (const lang of ['en', 'sw']) {
    const html = renderToStaticMarkup(h(TodayScreen, { overview: overview(), now: at('07:00'), ...I(lang), pushState: 'granted', onTrack: noop, onMarkAbsent: noop, onUndoAbsent: noop }));
    const tx = text(html);
    if (lang === 'en') {
      assert.match(tx, /Good morning, Wanjiru/);
      assert.match(tx, /Tuesday 17 Nov/);
      assert.match(tx, /8 min 3 stops before yours/);
      assert.match(tx, /Be at Gikambura Stage 9 by 7:06 am/);
      assert.match(tx, /Track the bus/);
      assert.match(tx, /Leaves at 3:40 pm/);
      assert.match(tx, /Baraka Kamau.*Not riding.*Undo/);
      assert.ok(!/App alerts are off/.test(tx));
    } else {
      assert.match(tx, /Habari ya asubuhi, Wanjiru/);
      assert.match(tx, /Vimebaki vituo 3 kabla ya chako/);
      assert.match(tx, /Fika Gikambura Stage 9 kabla ya 7:06 am/);
      assert.match(tx, /Fuatilia basi/);
    }
    assert.ok(html.includes('data-testid="dots"'));
  }
  const off = text(renderToStaticMarkup(h(TodayScreen, { overview: overview(), now: at('07:00'), ...I('en'), pushState: 'denied', offlineSince: at('06:58'), onTrack: noop })));
  assert.match(off, /No connection\. Showing what we had at 6:58 am/);
  assert.match(off, /App alerts are off\. You'll get SMS only\. Turn on/);
});

test('Today: no children linked', () => {
  const o = { ...overview(), children: [] };
  assert.match(text(renderToStaticMarkup(h(TodayScreen, { overview: o, now: at('07:00'), ...I('en') }))), /No children are linked to your number yet/);
});

const tripView = () => ({
  trip: { id: 't1', status: 'active', serviceDate: D, startedAt: iso(at('06:41')), endedAt: null, cancelledReason: null, scheduleName: 'Morning pickup', direction: 'to_school', routeName: 'Route 2 - Gikambura', plateNumber: 'KDA 102B' },
  bus: { lat: -1.25, lng: 36.66, speedMps: 8, headingDeg: 90, recordedAt: iso(at('07:00') - 12000) },
  stops: [1, 2, 3, 4, 5, 6].map((n) => ({
    stopId: `s${n}`, sequence: n, name: n === 6 ? 'Greenfield Academy' : `Gikambura Stage ${n + 4}`, lat: -1.25 + n / 1000, lng: 36.66, isSchool: n === 6,
    scheduledTime: `07:${String(n * 2).padStart(2, '0')}:00`, status: n <= 2 ? 'departed' : 'pending', etaAt: n > 2 ? iso(at(`07:${String(n * 2 + 1).padStart(2, '0')}`)) : null, arrivedAt: null, departedAt: null,
  })),
  myStops: [{ stopId: 's5', children: [{ studentId: 'c1', fullName: 'Amina Wairimu', event: null }] }],
});

test('Trip: hero countdown, ladder from the bus to your stop, live status, freshness', () => {
  const v = tripView();
  const now = at('07:00');
  const html = renderToStaticMarkup(h(TripScreen, { view: v, summary: summarize(v, now), connection: 'live', now, ...I('en'), onBack: noop, map: null }));
  const tx = text(html);
  assert.match(tx, /Bus KDA 102B/);
  assert.match(tx, /Live/);
  assert.match(tx, /11 min 2 stops before yours/);
  assert.match(tx, /2 stops done/);
  assert.match(tx, /Gikambura Stage 7.*Next.*Gikambura Stage 9.*Your stop · Amina/);
  assert.match(tx, /Updated 12 s ago/);
  assert.ok(html.includes('data-testid="ladder-mine"'));

  const stale = text(renderToStaticMarkup(h(TripScreen, { view: v, summary: summarize(v, at('07:05')), connection: 'polling', now: at('07:05'), ...I('sw'), onBack: noop })));
  assert.match(stale, /Hakuna ishara kutoka kwa basi tangu 6:59 am/);
  assert.match(stale, /Inasasishwa kila sekunde 15/);
  assert.ok(!/trip-countdown/.test(stale), 'no countdown on stale GPS');

  const ended = { ...v, trip: { ...v.trip, status: 'cancelled', cancelledReason: 'Bus breakdown at Kikuyu' }, bus: null };
  const ct = text(renderToStaticMarkup(h(TripScreen, { view: ended, summary: summarize(ended, now), connection: 'live', now, ...I('en'), onBack: noop })));
  assert.match(ct, /This trip was cancelled/);
  assert.match(ct, /Reason: Bus breakdown at Kikuyu/);
  assert.match(ct, /Back to today/);

  const notFound = text(renderToStaticMarkup(h(TripScreen, { view: null, error: { status: 404 }, ...I('en'), onBack: noop })));
  assert.match(notFound, /This trip isn't available/);
});

test('Not riding: list grouped by day, sheet with children, days and trips', () => {
  const items = [
    { id: 'a1', studentId: 'c2', fullName: 'Baraka Kamau', serviceDate: D, scheduleId: 'am5', reason: 'Clinic visit' },
    { id: 'a2', studentId: 'c1', fullName: 'Amina Wairimu', serviceDate: '2026-11-18', scheduleId: null, reason: null },
  ];
  const tx = text(renderToStaticMarkup(h(AbsencesScreen, { items, ...I('en'), serviceDate: D, rideNames: { am5: 'To school' }, onOpenAdd: noop, onRemove: noop })));
  assert.match(tx, /Today Baraka Kamau To school · Clinic visit Remove/);
  assert.match(tx, /Tomorrow Amina Wairimu All trips/);
  const sheet = text(renderToStaticMarkup(h(AbsenceSheet, { visible: true, children: overview().children, serviceDate: D, ...I('en'), preset: { studentId: 'c1', date: D, scheduleId: 'am' }, onSubmit: noop, onClose: noop })));
  assert.match(sheet, /Who won't ride\?.*Amina.*Baraka.*Today.*Tomorrow.*Thu 19 Nov.*All trips.*To school.*Home.*Tell the driver/);
  assert.match(text(renderToStaticMarkup(h(AbsencesScreen, { items: [], ...I('sw'), serviceDate: D, rideNames: {} }))), /Hakuna kilichoripotiwa/);
});

test('Alerts: grouped by day, shows how each arrived and failures', () => {
  const items = [
    { id: 'n1', eventType: 'approaching', isCritical: false, title: 'Bus approaching', body: 'Bus KDA 102B is ~5 min from Gikambura Stage 9. -Greenfield', tripId: 't1', studentName: 'Amina', createdAt: iso(at('07:03')), channels: ['push'], status: 'sent' },
    { id: 'n2', eventType: 'delay', isCritical: false, title: 'Running late', body: 'Bus KDA 102B is running ~15 min late.', tripId: 't0', studentName: null, createdAt: iso(at('07:03') - 86400000), channels: ['sms'], status: 'sent' },
    { id: 'n3', eventType: 'trip_cancelled', isCritical: true, title: 'Cancelled', body: 'Afternoon trip cancelled.', tripId: 't9', studentName: null, createdAt: iso(at('07:03') - 2 * 86400000), channels: [], status: 'failed' },
  ];
  const tx = text(renderToStaticMarkup(h(AlertsScreen, { items, ...I('en'), now: at('07:10') })));
  assert.match(tx, /Today 7:03 am Bus KDA 102B is ~5 min from Gikambura Stage 9\. -Greenfield App/);
  assert.match(tx, /Yesterday 7:03 am .* SMS/);
  assert.match(tx, /Sunday 15 Nov .* Not delivered/);
});

test('Settings: channel, push states, language, quiet hours, account', () => {
  const p = overview().profile;
  const base = { profile: { ...p, quietHoursStart: '21:00:00', quietHoursEnd: '05:30:00' }, school: overview().school, platform: 'android', appVersion: '0.7.0', ...I('en'), onChannel: noop };
  const tx = text(renderToStaticMarkup(h(SettingsScreen, { ...base, pushState: 'granted' })));
  assert.match(tx, /App, then SMS if it doesn't arrive Recommended/);
  assert.match(tx, /9:00 pm to 5:30 am/);
  assert.match(tx, /Signed in as 0711 000 004/);
  assert.match(tx, /Call the school office/);
  assert.match(tx, /Version 0\.7\.0/);
  assert.match(text(renderToStaticMarkup(h(SettingsScreen, { ...base, pushState: 'blocked' }))), /Blocked in your phone settings\. Open phone settings/);
  assert.match(text(renderToStaticMarkup(h(SettingsScreen, { ...base, pushState: 'unsupported', platform: 'ios' }))), /On iPhone, alerts come by SMS for now/);
  const noPhone = text(renderToStaticMarkup(h(SettingsScreen, { ...base, school: { name: 'X', phone: null }, pushState: 'granted' })));
  assert.ok(!/Call the school office/.test(noPhone), 'no number configured: no call button');
});

test('Sign in and consent', () => {
  const en = text(renderToStaticMarkup(h(SignInScreen, { ...I('en'), onLanguage: noop, requestCode: noop, verify: noop })));
  assert.match(en, /English Kiswahili Know where the school bus is/);
  assert.match(en, /Phone number.*Send code/);
  const sw = text(renderToStaticMarkup(h(SignInScreen, { ...I('sw'), onLanguage: noop, notice: 'expired' })));
  assert.match(sw, /Jua basi la shule liko wapi/);
  assert.match(sw, /Umetolewa kwenye akaunti/);
  const c = text(renderToStaticMarkup(h(ConsentScreen, { ...I('en'), schoolName: 'Greenfield Academy', onAccept: noop, onDecline: noop })));
  assert.match(c, /Greenfield Academy uses this app/);
  assert.match(c, /never uses your phone's location/);
  assert.match(c, /Data Protection Act 2019/);
  assert.match(c, /I agree.*Not now/);
});
