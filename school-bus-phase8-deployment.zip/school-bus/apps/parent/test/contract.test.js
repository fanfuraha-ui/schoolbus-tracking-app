'use strict';
/**
 * Contract test: the parent app's logic and screens against the REAL backend services on a real
 * database (no mocks of the API's behaviour).
 *
 *  1. Real overview -> ride status -> Today screen renders.
 *  2. Real trip view + the socket events the backend broadcasts while a bus really moves ->
 *     the app's reducer -> must match a fresh GET of the same trip. (If the reducer and the server
 *     ever disagree, a parent would see a different bus position than an app restart shows.)
 *  3. Every request body the app sends passes the backend's own validation schemas.
 */
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('path');
const crypto = require('crypto');

const API = path.join(__dirname, '../../api');
const { freshDatabase, fakeBroadcaster, quietLogger } = require(path.join(API, 'test/support/context'));
const { createSettingsService } = require(path.join(API, 'src/services/settingsService'));
const { createTripService } = require(path.join(API, 'src/services/tripService'));
const { createParentService } = require(path.join(API, 'src/services/parentService'));
const S = require(path.join(API, 'src/http/schemas'));

const { describeRide } = require('../src/live/rideStatus');
const { applyEvent, summarize } = require('../src/live/tripModel');
const { mapData } = require('../src/map/mapHtml');
const { translate, plural } = require('../src/i18n/strings');
const { load, MODS } = require('./support/load');

const React = require(path.join(MODS, 'react'));
const { renderToStaticMarkup } = require(path.join(MODS, 'react-dom/server'));
const { TodayScreen } = load('src/screens/TodayScreen.js');
const { TripScreen } = load('src/screens/TripScreen.js');

const json = (x) => JSON.parse(JSON.stringify(x)); // what actually crosses HTTP / Socket.IO
const I = { t: (k, v) => translate('en', k, v), tp: (k, n, v) => translate('en', plural(k, n), { n, ...v }), lang: 'en' };
const text = (html) => html.replace(/<[^>]+>/g, ' ').replace(/&#x27;/g, "'").replace(/\s+/g, ' ');

let pool; let db; let parents; let trips; let bc; let guardianId; let tripId; let driverId;

test.before(async () => {
  ({ pool, db } = await freshDatabase('schoolbus_test_parent_contract'));
  const settings = createSettingsService({ db });
  bc = fakeBroadcaster();
  trips = createTripService({ db, settings, broadcaster: bc, logger: quietLogger });
  parents = createParentService({ db, settings });
  guardianId = (await db.one("SELECT id FROM users WHERE phone = '+254711000004'")).id;
  ({ id: tripId, driverId } = await db.one("SELECT id, driver_id FROM trips WHERE status = 'active'"));
});
test.after(() => pool.end());

test('real overview -> Today screen', async () => {
  const o = json(await parents.getOverview(guardianId));
  const now = Date.now();
  const child = o.children[0];
  for (const r of child.today) {
    const st = describeRide(r, { now, serviceDate: o.serviceDate, childName: 'Student' });
    assert.ok(st.headline && translate('en', st.headline.key, st.headline.vars) !== st.headline.key, `untranslated ${st.headline.key}`);
  }
  const am = child.today.find((r) => r.tripStatus === 'active');
  assert.equal(describeRide(am, { now, serviceDate: o.serviceDate, childName: 'S' }).canTrack, true);
  const html = renderToStaticMarkup(React.createElement(TodayScreen, { overview: o, now, ...I, pushState: 'granted', onTrack() {}, onMarkAbsent() {}, onUndoAbsent() {} }));
  assert.match(text(html), /Student 4/);
  assert.match(text(html), /Track the bus/);
  assert.match(text(html), new RegExp(am.plateNumber));
});

test('"Not riding" round trip: the app\'s body is valid; the card offers Undo with the real absence id', async () => {
  const o = json(await parents.getOverview(guardianId));
  const pm = o.children[0].today.find((r) => r.direction === 'from_school');
  // Exactly what AbsenceSheet submits (scheduleId set, empty reason dropped), after JSON.
  const body = S.parent.absence.parse(json({ studentId: o.children[0].id, date: o.serviceDate, scheduleId: pm.scheduleId, reason: undefined }));
  const a = await parents.createAbsence(guardianId, body);
  const after = json(await parents.getOverview(guardianId)).children[0].today.find((r) => r.scheduleId === pm.scheduleId);
  const st = describeRide(after, { now: Date.now(), serviceDate: o.serviceDate, childName: 'S' });
  assert.equal(st.headline.key, 'ride.absent');
  assert.equal(st.canUndoAbsent, true);
  assert.equal(after.absenceId, a.id);
  await parents.deleteAbsence(guardianId, after.absenceId);
  // "All trips" variant: no scheduleId at all.
  assert.equal(S.parent.absence.safeParse(json({ studentId: o.children[0].id, date: o.serviceDate })).success, true);
});

test('live: reducer + real broadcast events == a fresh GET of the trip', async () => {
  let view = json(await parents.getTripView(guardianId, tripId));
  const sorted = [...view.stops].sort((a, b) => a.sequence - b.sequence);
  const [s1, s2] = sorted;
  const mine = view.myStops[0].stopId;
  assert.ok(sorted.some((s) => s.stopId === mine));

  // Drive the bus: arrive at stop 1, leave toward stop 2, arrive at stop 2.
  const t0 = Date.now() + 1000;
  const lerp = (f) => ({ lat: s1.lat + (s2.lat - s1.lat) * f, lng: s1.lng + (s2.lng - s1.lng) * f });
  const path1 = [[0, 0.4], [0, 0.3], [0.35, 8], [0.6, 8], [0.85, 8], [1, 0.4], [1, 0.3]];
  const points = path1.map(([f, speed], i) => ({ ...lerp(f), recordedAt: new Date(t0 + i * 5000).toISOString(), speedMps: speed, headingDeg: 200, accuracyM: 6 }));
  bc.calls.length = 0;
  for (const p of points) {
    const payload = S.driver.socketLocations.parse(json({ tripId, points: [p] }));
    await trips.ingestPoints({ tripId, driverId, points: payload.points, source: 'live' });
  }
  const roomEvents = bc.calls.filter((c) => c.to === `trip:${tripId}` && c.event !== '__close__');
  assert.ok(roomEvents.some((e) => e.event === 'bus:location'));
  assert.ok(roomEvents.some((e) => e.event === 'trip:stops'), 'stop progress was broadcast to the trip room');
  for (const e of roomEvents) view = applyEvent(view, e.event, json(e.data));

  const fresh = json(await parents.getTripView(guardianId, tripId));
  const pick = (v) => [...v.stops].sort((a, b) => a.sequence - b.sequence).map((s) => [s.stopId, s.status, s.etaAt, s.arrivedAt]);
  assert.deepEqual(pick(view), pick(fresh), 'stop statuses, ETAs and arrival times match');
  assert.deepEqual([view.bus.lat, view.bus.lng, Date.parse(view.bus.recordedAt)], [fresh.bus.lat, fresh.bus.lng, Date.parse(fresh.bus.recordedAt)]);
  assert.equal(fresh.stops.find((s) => s.stopId === s1.stopId).status, 'departed');
  assert.equal(fresh.stops.find((s) => s.stopId === s2.stopId).status, 'arrived');

  const now = Date.parse(view.bus.recordedAt) + 5000;
  const sm = summarize(view, now);
  assert.equal(sm.bus.fresh, true);
  const data = mapData(view, sm);
  assert.equal(data.stops.length, view.stops.length, 'every stop has coordinates for the map');
  const html = text(renderToStaticMarkup(React.createElement(TripScreen, { view, summary: sm, connection: 'live', now, ...I, onBack() {} })));
  assert.match(html, /Bus K[A-Z]{2} \d{3}[A-Z]/);
  assert.match(html, /Your stop/);

  // Driver ends the trip: the room hears it, and the app's copy matches the server's.
  bc.calls.length = 0;
  await trips.endTrip({ tripId, driverId });
  const ended = bc.calls.find((c) => c.event === 'trip:ended');
  view = applyEvent(view, 'trip:ended', json(ended.data));
  const after = json(await parents.getTripView(guardianId, tripId));
  assert.equal(view.trip.status, after.trip.status);
  assert.equal(view.bus, after.bus, 'no bus position once the trip is over');
  assert.equal(await parents.canWatchTrip(guardianId, tripId), false, 'socket watch refused after the end; the app falls back to GET');
});

test('every request body the app sends is accepted by the backend schemas', () => {
  const uid = crypto.randomUUID();
  assert.ok(S.auth.otpRequest.safeParse({ phone: '+254711000004' }).success);
  assert.ok(S.auth.otpVerify.safeParse({ phone: '+254711000004', code: '123456', device: { deviceUid: uid, platform: 'android', appVersion: '0.7.0' } }).success);
  // push sync: off, then on with a token (src/push/push.js)
  assert.ok(S.parent.device.safeParse({ deviceUid: uid, platform: 'android', appVersion: '0.7.0', pushEnabled: false }).success);
  assert.ok(S.parent.device.safeParse({ deviceUid: uid, platform: 'android', appVersion: '0.7.0', pushEnabled: true, fcmToken: 'f'.repeat(152) }).success);
  // settings screen
  for (const b of [{ channelMode: 'push_then_sms' }, { preferredLanguage: 'sw' }, { quietHours: { start: '21:00', end: '05:30' } }, { quietHours: null }]) {
    assert.ok(S.parent.preferences.safeParse(json(b)).success, JSON.stringify(b));
  }
  assert.ok(S.parent.consent.safeParse({ version: '2026-11' }).success);
  assert.ok(S.parent.notificationsQuery.safeParse({ limit: '100' }).success);
});

test('alert history rows carry what the Alerts screen reads', async () => {
  await db.query(
    `INSERT INTO notifications (dedupe_key, channel, guardian_id, trip_id, event_type, to_address, title, body, status)
     VALUES ('c1', 'sms', $1, $2, 'delay', '+254711000004', 'Running late', 'Bus is running ~15 min late.', 'delivered')`,
    [guardianId, tripId],
  );
  const [row] = json(await parents.listNotifications(guardianId, { limit: 100 }));
  for (const k of ['id', 'body', 'createdAt', 'channels', 'status', 'isCritical', 'eventType']) assert.ok(k in row, k);
  assert.deepEqual(row.channels, ['sms']);
});
