'use strict';
/** Pure logic: time, phone, ride status (Today), live trip model, strings, map data, socket. */
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('path');

const time = require('../src/lib/time');
const { normalizeKenyanPhone, displayPhone } = require('../src/lib/phone');
const { describeRide, rideRank } = require('../src/live/rideStatus');
const { applyEvent, summarize } = require('../src/live/tripModel');
const { strings, translate, plural } = require('../src/i18n/strings');
const { mapHtml, mapData } = require('../src/map/mapHtml');
const { createParentSocket } = require('../src/realtime/parentSocket');
const apiPhone = require(path.join(__dirname, '../../api/src/domain/phone'));

const D = '2026-11-17'; // a Tuesday
const at = (hhmm) => time.localToMs(D, hhmm);
const iso = (ms) => new Date(ms).toISOString();

// ---------- time ----------
test('Nairobi times: fixed +3, 12-hour clock, school days skip weekends', () => {
  assert.equal(new Date(at('07:00')).toISOString(), '2026-11-17T04:00:00.000Z');
  assert.equal(time.fmtTime(at('07:05')), '7:05 am');
  assert.equal(time.fmtTime(at('12:30')), '12:30 pm');
  assert.equal(time.fmtTime(at('00:10')), '12:10 am');
  assert.equal(time.fmtClock('16:35:00'), '4:35 pm');
  assert.equal(time.fmtDay(D, 'en'), 'Tuesday 17 Nov');
  assert.equal(time.fmtDay(D, 'sw'), 'Jumanne 17 Nov');
  assert.deepEqual(time.schoolDays('2026-11-20', 3), ['2026-11-20', '2026-11-23', '2026-11-24'], 'Fri, then Mon, Tue');
  assert.equal(time.partOfDay(at('06:30')), 'morning');
  assert.equal(time.partOfDay(at('15:00')), 'afternoon');
  assert.equal(time.minutesUntil(at('07:10'), at('07:01')), 9);
  assert.equal(time.minutesUntil(at('07:00'), at('07:05')), 0, 'never negative');
});

// ---------- phone ----------
test('phone normaliser agrees with the API on every format', () => {
  const cases = ['0712345678', '712345678', '+254712345678', '254712345678', '0712 345 678', '0110 123 456', '0812345678', '12345', '+255712345678', '07123456789'];
  for (const c of cases) assert.equal(normalizeKenyanPhone(c), apiPhone.normalizeKenyanPhone(c), c);
  assert.equal(displayPhone('+254712345678'), '0712 345 678');
});

// ---------- ride status (Today card) ----------
const ride = (over = {}) => ({
  scheduleId: 'sc1', direction: 'to_school', startTime: '06:40:00', routeName: 'Route 2', stopName: 'Stage 9',
  scheduledTime: '07:10:00', tripId: 't1', tripStatus: 'active', plateNumber: 'KDA 102B', stopStatus: 'pending',
  etaAt: null, arrivedAt: null, absent: false, absenceId: null, absentAllDay: null, stopsAway: 3,
  busSeenAt: null, childEvent: null, childEventAt: null, cancelledReason: null, ...over,
});
const d = (r, now) => describeRide(r, { now, serviceDate: D, childName: 'Amina' });

test('coming: countdown, stops before yours, and when to be at the stop', () => {
  const now = at('07:00');
  const st = d(ride({ etaAt: iso(at('07:08')), busSeenAt: iso(now - 10000) }), now);
  assert.equal(st.tone, 'live');
  assert.deepEqual(st.big.minutes, 8);
  assert.equal(st.big.side.key, 'ride.stopsAway.other');
  assert.equal(st.big.side.vars.n, 3);
  assert.equal(st.detail.key, 'ride.beAtStopBy');
  assert.equal(st.detail.vars.time, '7:06 am', 'ETA minus 2 minutes');
  assert.equal(st.canTrack, true);
  assert.equal(st.canMarkAbsent, true);
});

test('near: "your stop is next" beside the countdown', () => {
  const now = at('07:05');
  const st = d(ride({ stopStatus: 'approaching', stopsAway: 0, etaAt: iso(at('07:08')), busSeenAt: iso(now) }), now);
  assert.equal(st.headline.key, 'ride.nearMinutes');
  assert.equal(st.big.side.key, 'ride.nextIsYours');
});

test('under a minute: no "0 min", the headline says the bus is almost there', () => {
  const now = at('07:05');
  const st = d(ride({ stopStatus: 'approaching', stopsAway: 0, etaAt: iso(now + 20000), busSeenAt: iso(now) }), now);
  assert.equal(st.big, null);
  assert.equal(st.headline.key, 'ride.nearNow');
});

test('stale GPS with no stops left before theirs: "your stop is next", never "0 stops"', () => {
  const now = at('07:10');
  const st = d(ride({ stopsAway: 0, etaAt: null, busSeenAt: iso(at('07:02')) }), now);
  assert.equal(st.headline.key, 'ride.nextIsYours');
});

test('late: amber tone and how late, measured against the stop\'s scheduled time', () => {
  const now = at('07:10');
  const st = d(ride({ etaAt: iso(at('07:25')), busSeenAt: iso(now) }), now);
  assert.equal(st.tone, 'late');
  assert.deepEqual(st.lateNote, { key: 'ride.runningLate', vars: { min: 15 } });
});

test('stale GPS: no countdown (it would be a guess), and say since when', () => {
  const now = at('07:10');
  const st = d(ride({ etaAt: iso(at('07:15')), busSeenAt: iso(at('07:05')) }), now);
  assert.equal(st.big, null);
  assert.equal(st.tone, 'late');
  assert.equal(st.detail.key, 'ride.staleSince');
  assert.equal(st.detail.vars.time, '7:05 am');
});

test('child events from the driver override the bus position', () => {
  const now = at('07:20');
  assert.equal(d(ride({ childEvent: 'boarded', childEventAt: iso(at('07:12')) }), now).headline.key, 'ride.onBoard');
  const ns = d(ride({ childEvent: 'no_show', childEventAt: iso(at('07:12')) }), now);
  assert.equal(ns.tone, 'alert');
  assert.equal(ns.headline.vars.name, 'Amina');
  const pm = d(ride({ direction: 'from_school', childEvent: 'dropped_off', childEventAt: iso(at('16:30')) }), now);
  assert.equal(pm.headline.key, 'ride.droppedOff');
  assert.equal(pm.tone, 'ok');
});

test('not started: departure time; 10 minutes past it, say so; an old run that never happened stays calm', () => {
  const notYet = d(ride({ tripStatus: 'not_started', stopsAway: null }), at('06:00'));
  assert.equal(notYet.headline.key, 'ride.startsAt');
  assert.equal(notYet.headline.vars.time, '6:40 am');
  assert.equal(notYet.detail.vars.time, '7:10 am');
  assert.equal(notYet.canTrack, false);
  assert.equal(notYet.canMarkAbsent, true);
  assert.equal(d(ride({ tripStatus: 'not_started' }), at('06:55')).tone, 'late');
  assert.equal(d(ride({ tripStatus: 'not_started' }), at('11:00')).headline.key, 'ride.didNotRun');
});

test('absent, cancelled, skipped, finished', () => {
  const ab = d(ride({ absent: true, absenceId: 'a1', absentAllDay: false }), at('07:00'));
  assert.equal(ab.headline.key, 'ride.absent');
  assert.equal(ab.canUndoAbsent, true);
  assert.equal(d(ride({ absent: true, absenceId: 'a1', absentAllDay: true }), at('07:00')).canUndoAbsent, false, 'all-day absences are undone from the Not riding tab');
  const c = d(ride({ tripStatus: 'cancelled', cancelledReason: 'Bus breakdown' }), at('07:00'));
  assert.equal(c.tone, 'alert');
  assert.equal(c.detail.vars.reason, 'Bus breakdown');
  assert.equal(d(ride({ stopStatus: 'skipped' }), at('07:30')).tone, 'alert');
  assert.equal(d(ride({ tripStatus: 'completed', childEvent: 'boarded', childEventAt: iso(at('07:12')) }), at('08:00')).headline.key, 'ride.reachedSchool');
});

test('rides sort: live first, then upcoming, then done', () => {
  const rs = [ride({ tripStatus: 'completed' }), ride({ tripStatus: 'not_started' }), ride({ tripStatus: 'active' })];
  assert.deepEqual(rs.sort((a, b) => rideRank(a) - rideRank(b)).map((r) => r.tripStatus), ['active', 'not_started', 'completed']);
});

// ---------- live trip model ----------
const view = () => ({
  trip: { id: 't1', status: 'active', serviceDate: D, direction: 'to_school', routeName: 'Route 2', scheduleName: 'Morning', plateNumber: 'KDA 102B' },
  bus: { lat: -1.25, lng: 36.66, recordedAt: iso(at('07:00')) },
  stops: [1, 2, 3, 4, 5, 6].map((n) => ({
    stopId: `s${n}`, sequence: n, name: n === 6 ? 'School' : `Stage ${n}`, lat: -1.25 + n / 1000, lng: 36.66, isSchool: n === 6,
    scheduledTime: `07:${String(n * 5).padStart(2, '0')}:00`, status: n <= 2 ? 'departed' : 'pending', etaAt: n > 2 ? iso(at(`07:${String(n * 5 + 2).padStart(2, '0')}`)) : null,
  })),
  myStops: [{ stopId: 's5', children: [{ studentId: 'k1', fullName: 'Amina Wairimu' }] }],
});

test('summary: target stop, stops to go, the ladder from the bus to the child', () => {
  const sm = summarize(view(), at('07:00') + 20000);
  assert.equal(sm.phase, 'coming');
  assert.equal(sm.target.stopId, 's5');
  assert.equal(sm.stopsAway, 2);
  assert.equal(sm.stopsBehind, 2);
  assert.deepEqual(sm.ladder.map((l) => [l.stopId, l.state, l.isMine]), [['s3', 'next', false], ['s4', 'upcoming', false], ['s5', 'upcoming', true]]);
  assert.equal(sm.bus.fresh, true);
  assert.equal(summarize(view(), at('07:04')).bus.fresh, false, 'over 3 minutes old');
});

test('events: bus moves, stops update, trip ends; old and foreign events are ignored', () => {
  let v = view();
  v = applyEvent(v, 'bus:location', { tripId: 't1', lat: -1.2, lng: 36.7, recordedAt: iso(at('07:01')) });
  assert.equal(v.bus.lat, -1.2);
  const same = applyEvent(v, 'bus:location', { tripId: 't1', lat: 0, lng: 0, recordedAt: iso(at('07:00')) });
  assert.equal(same, v, 'out-of-order point dropped');
  assert.equal(applyEvent(v, 'bus:location', { tripId: 'other', lat: 0, lng: 0, recordedAt: iso(at('07:02')) }), v);

  v = applyEvent(v, 'trip:stops', { tripId: 't1', stops: [{ stopId: 's3', status: 'departed', arrivedAt: iso(at('07:02')), departedAt: iso(at('07:03')) }, { stopId: 's4', status: 'arrived', arrivedAt: iso(at('07:06')) }] });
  let sm = summarize(v, at('07:06'));
  assert.equal(sm.stopsAway, 0);
  assert.equal(sm.ladder[0].state, 'here');
  v = applyEvent(v, 'trip:stops', { tripId: 't1', stops: [{ stopId: 's4', status: 'departed' }, { stopId: 's5', status: 'arrived', arrivedAt: iso(at('07:09')) }] });
  assert.equal(summarize(v, at('07:09')).phase, 'atStop');
  v = applyEvent(v, 'trip:stops', { tripId: 't1', stops: [{ stopId: 's5', status: 'departed' }] });
  assert.equal(summarize(v, at('07:10')).phase, 'passed');
  v = applyEvent(v, 'trip:ended', { tripId: 't1', status: 'cancelled', reason: 'Breakdown' });
  assert.equal(v.trip.status, 'cancelled');
  assert.equal(v.trip.cancelledReason, 'Breakdown');
  assert.equal(v.bus, null);
});

// ---------- strings ----------
test('strings: same keys in both languages, same placeholders, plural pairs complete', () => {
  const en = strings.en; const sw = strings.sw;
  assert.deepEqual(Object.keys(sw).sort(), Object.keys(en).sort());
  const ph = (s) => (s.match(/\{(\w+)\}/g) || []).sort().join();
  for (const k of Object.keys(en)) assert.equal(ph(sw[k]), ph(en[k]), `placeholders differ for ${k}`);
  for (const k of Object.keys(en).filter((x) => x.endsWith('.one'))) assert.ok(en[k.replace(/\.one$/, '.other')], k);
  assert.equal(translate('sw', plural('ride.stopsAway', 3), { n: 3 }), 'Vimebaki vituo 3 kabla ya chako');
  assert.equal(translate('en', plural('ride.stopsAway', 1), { n: 1 }), '1 stop before yours');
});

// ---------- map ----------
test('map page: Leaflet with a schematic fallback; data carries only what the page needs', () => {
  const html = mapHtml({});
  assert.match(html, /leaflet@1\.9\.4/);
  assert.match(html, /function drawSvg/);
  assert.match(html, /window\.__update/);
  const v = view();
  const data = mapData(v, summarize(v, at('07:00')));
  assert.equal(data.stops.length, 6);
  assert.deepEqual(data.stops.filter((s) => s.mine).length, 1);
  assert.equal(data.stops[0].done, true);
  assert.equal(data.bus.fresh, true);
  assert.equal(mapHtml({ tiles: 'https://tiles.example/{z}/{x}/{y}.png' }).includes('tiles.example'), true);
});

// ---------- socket ----------
function fakeIo() {
  const sockets = [];
  const factory = (url, opts) => {
    const handlers = {};
    const emitted = [];
    const s = {
      url, opts, connected: false, handlers, emitted,
      on: (e, fn) => { (handlers[e] ||= []).push(fn); },
      fire: (e, ...a) => (handlers[e] || []).forEach((fn) => fn(...a)),
      connect: () => { s.connected = true; s.fire('connect'); },
      disconnect: () => { s.connected = false; s.disconnected = true; },
      removeAllListeners: () => { Object.keys(handlers).forEach((k) => delete handlers[k]); },
      emit: (e, p) => emitted.push([e, p]),
      ackFor: null,
      timeout: () => ({ emitWithAck: async (e, p) => { emitted.push([e, p]); return s.ackFor ? s.ackFor(p) : { ok: true, view: { trip: { id: p.tripId } } }; } }),
    };
    sockets.push(s);
    return s;
  };
  return { factory, sockets };
}
const flush = () => new Promise((r) => setImmediate(r));

test('socket: opens on first watch, re-watches after reconnect, routes events by trip, closes when unused', async () => {
  const io = fakeIo();
  const sock = createParentSocket({ url: 'http://api', getToken: async () => 'tok', refresh: async () => {}, ioFactory: io.factory });
  const got = { views: [], events: [], status: [] };
  const off = sock.watch('t1', { onView: (v) => got.views.push(v), onEvent: (n, p) => got.events.push([n, p.lat]), onStatus: (s) => got.status.push(s) });
  const s = io.sockets[0];
  assert.equal(io.sockets.length, 1);
  s.connect(); await flush();
  assert.deepEqual(s.emitted[0], ['trip:watch', { tripId: 't1' }]);
  assert.equal(got.views.length, 1);
  s.fire('bus:location', { tripId: 't1', lat: 1 });
  s.fire('bus:location', { tripId: 'zzz', lat: 2 });
  assert.deepEqual(got.events, [['bus:location', 1]]);
  s.fire('disconnect'); s.connect(); await flush();
  assert.equal(got.views.length, 2, 'catch-up view after reconnect');
  assert.deepEqual(got.status.slice(-2), ['offline', 'live']);
  off();
  assert.deepEqual(s.emitted.at(-1), ['trip:unwatch', { tripId: 't1' }]);
  assert.equal(s.disconnected, true);
  assert.equal(sock.isOpen(), false);
});

test('socket: refused watch is reported; auth rejection refreshes the token and reconnects', async () => {
  const io = fakeIo();
  let refreshed = 0;
  const sock = createParentSocket({ url: 'x', getToken: async () => 't', refresh: async () => { refreshed += 1; }, ioFactory: io.factory });
  let rejected = null;
  sock.watch('t9', { onRejected: (e) => { rejected = e; } });
  const s = io.sockets[0];
  s.ackFor = () => ({ ok: false, error: { code: 'forbidden' } });
  s.connect(); await flush();
  assert.deepEqual(rejected, { code: 'forbidden' });
  s.connected = false;
  s.fire('connect_error', new Error('unauthorized')); await flush();
  assert.equal(refreshed, 1);
  assert.equal(s.connected, true);
});
