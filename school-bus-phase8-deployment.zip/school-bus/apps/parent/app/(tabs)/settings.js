import React from 'react';
import { router } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { SettingsContainer } from '../../src/features/containers';
import { colors } from '../../src/ui/theme';

export default function Settings() {
  return (
    <SafeAreaView edges={['top']} style={{ flex: 1, backgroundColor: colors.paper }}>
      <SettingsContainer nav={{ openPrivacy: () => router.push('/privacy') }} />
    </SafeAreaView>
  );
}
