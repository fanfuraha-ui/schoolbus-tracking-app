import React from 'react';
import { useIsFocused } from '@react-navigation/native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { AlertsContainer } from '../../src/features/containers';
import { colors } from '../../src/ui/theme';

export default function Alerts() {
  const focused = useIsFocused();
  return (
    <SafeAreaView edges={['top']} style={{ flex: 1, backgroundColor: colors.paper }}>
      <AlertsContainer focused={focused} />
    </SafeAreaView>
  );
}
