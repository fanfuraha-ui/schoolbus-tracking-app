import React, { useEffect } from 'react';
import { Redirect, Tabs, router } from 'expo-router';
import * as Notifications from 'expo-notifications';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '../../src/auth/AuthContext';
import { useI18n } from '../../src/i18n/I18nContext';
import { OverviewProvider } from '../../src/features/OverviewContext';
import { PushSync } from '../../src/features/containers';
import { TabBar } from '../../src/ui/TabBar';

const ORDER = ['today', 'alerts', 'absences', 'settings'];

/** Tapping a bus alert opens that trip (or Alerts if the trip has finished, which the trip screen handles). */
// The hook keeps returning the LAST tap, so remember which one was handled: otherwise signing out
// and back in (which remounts these tabs) would jump to an old trip again.
let handledId = null;

function NotificationRouter() {
  const response = Notifications.useLastNotificationResponse();
  useEffect(() => {
    if (!response) return;
    const id = response.notification.request.identifier;
    if (id === handledId) return;
    handledId = id;
    const data = response.notification.request.content.data;
    if (data && data.tripId) router.push(`/trip/${data.tripId}`);
    else if (response) router.navigate('/alerts');
  }, [response]);
  return null;
}

export default function TabsLayout() {
  const { status, needsConsent } = useAuth();
  const { t } = useI18n();
  const insets = useSafeAreaInsets();
  if (status !== 'signedIn') return <Redirect href="/" />;
  if (needsConsent) return <Redirect href="/consent" />;
  return (
    <OverviewProvider>
      <PushSync />
      <NotificationRouter />
      <Tabs
        screenOptions={{ headerShown: false, sceneStyle: { paddingTop: 0 } }}
        tabBar={({ state, navigation }) => (
          <TabBar
            tabs={ORDER.map((key) => ({ key, label: t(`tabs.${key}`) }))}
            active={state.routes[state.index].name}
            onPress={(key) => navigation.navigate(key)}
            insetBottom={insets.bottom}
          />
        )}
      >
        {ORDER.map((name) => <Tabs.Screen key={name} name={name} />)}
      </Tabs>
    </OverviewProvider>
  );
}
