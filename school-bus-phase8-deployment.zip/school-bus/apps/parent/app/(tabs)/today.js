import React from 'react';
import { router } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { TodayContainer } from '../../src/features/containers';
import { colors } from '../../src/ui/theme';

export default function Today() {
  return (
    <SafeAreaView edges={['top']} style={{ flex: 1, backgroundColor: colors.ink }}>
      <TodayContainer nav={{ openTrip: (id) => router.push(`/trip/${id}`) }} />
    </SafeAreaView>
  );
}
