import React, { useEffect, useMemo } from 'react';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import * as SplashScreen from 'expo-splash-screen';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { useFonts, Barlow_400Regular, Barlow_500Medium, Barlow_600SemiBold } from '@expo-google-fonts/barlow';
import { BarlowCondensed_600SemiBold, BarlowCondensed_700Bold } from '@expo-google-fonts/barlow-condensed';
import { ServicesContext } from '../src/services/ServicesContext';
import { createRealServices } from '../src/services/realServices';
import { I18nProvider } from '../src/i18n/I18nContext';
import { AuthProvider } from '../src/auth/AuthContext';
import { ToastProvider } from '../src/ui/components';
import { colors } from '../src/ui/theme';

SplashScreen.preventAutoHideAsync().catch(() => {});

export default function RootLayout() {
  const services = useMemo(() => createRealServices(), []);
  const [fontsLoaded, fontError] = useFonts({
    Barlow_400Regular, Barlow_500Medium, Barlow_600SemiBold, BarlowCondensed_600SemiBold, BarlowCondensed_700Bold,
  });
  useEffect(() => { if (fontsLoaded || fontError) SplashScreen.hideAsync().catch(() => {}); }, [fontsLoaded, fontError]);
  if (!fontsLoaded && !fontError) return null; // splash stays up; fonts are bundled, so this is a few ms

  return (
    <SafeAreaProvider>
      <ServicesContext.Provider value={services}>
        <I18nProvider>
          <AuthProvider>
            <ToastProvider>
              <StatusBar style="light" backgroundColor={colors.ink} />
              <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: colors.paper } }}>
                <Stack.Screen name="index" />
                <Stack.Screen name="sign-in" />
                <Stack.Screen name="consent" />
                <Stack.Screen name="(tabs)" />
                <Stack.Screen name="trip/[id]" options={{ animation: 'slide_from_right' }} />
                <Stack.Screen name="privacy" options={{ presentation: 'modal' }} />
              </Stack>
            </ToastProvider>
          </AuthProvider>
        </I18nProvider>
      </ServicesContext.Provider>
    </SafeAreaProvider>
  );
}
