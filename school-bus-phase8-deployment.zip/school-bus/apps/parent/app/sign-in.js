import React from 'react';
import { Redirect } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '../src/auth/AuthContext';
import { SignInContainer } from '../src/features/containers';

export default function SignIn() {
  const insets = useSafeAreaInsets();
  const { status } = useAuth();
  if (status === 'signedIn') return <Redirect href="/" />;
  return <SignInContainer insetTop={insets.top} />;
}
