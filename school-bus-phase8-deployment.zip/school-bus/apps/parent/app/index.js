import React from 'react';
import { Redirect } from 'expo-router';
import { useAuth } from '../src/auth/AuthContext';
import { Loading } from '../src/ui/components';

/** Decides where the app opens: sign-in, the one-time privacy notice, or Today. */
export default function Index() {
  const { status, needsConsent } = useAuth();
  if (status === 'loading') return <Loading />;
  if (status === 'signedOut') return <Redirect href="/sign-in" />;
  if (needsConsent) return <Redirect href="/consent" />;
  return <Redirect href="/today" />;
}
