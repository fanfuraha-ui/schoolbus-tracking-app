import React from 'react';
import { Redirect } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '../src/auth/AuthContext';
import { ConsentContainer } from '../src/features/containers';

export default function Consent() {
  const insets = useSafeAreaInsets();
  const { status, needsConsent } = useAuth();
  if (status !== 'signedIn' || !needsConsent) return <Redirect href="/" />;
  return <ConsentContainer insetTop={insets.top} />;
}
