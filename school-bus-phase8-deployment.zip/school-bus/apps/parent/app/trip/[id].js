import React from 'react';
import { Redirect, router, useLocalSearchParams } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '../../src/auth/AuthContext';
import { TripContainer } from '../../src/features/containers';

export default function Trip() {
  const { id } = useLocalSearchParams();
  const insets = useSafeAreaInsets();
  const { status } = useAuth();
  if (status !== 'signedIn') return <Redirect href="/" />;
  const back = () => (router.canGoBack() ? router.back() : router.replace('/today'));
  return <TripContainer tripId={String(id)} nav={{ back }} insetTop={insets.top} />;
}
