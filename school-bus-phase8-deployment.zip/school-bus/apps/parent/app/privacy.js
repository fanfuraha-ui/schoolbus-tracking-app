import React from 'react';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useI18n } from '../src/i18n/I18nContext';
import { ConsentScreen } from '../src/screens/ConsentScreen';

export default function Privacy() {
  const { t } = useI18n();
  const insets = useSafeAreaInsets();
  return <ConsentScreen t={t} readOnly onClose={() => router.back()} insetTop={insets.top} />;
}
