// Entry point. Notification handling is registered before the router loads, so a tap on an
// alert that cold-starts the app is not missed.
import './src/push/handler';
import 'expo-router/entry';
