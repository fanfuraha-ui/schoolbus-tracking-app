/** API error -> translated sentence (falls back to a generic one). */
export function errorText(t, e) {
  const code = e && e.code;
  const key = `err.${code}`;
  const text = code ? t(key) : null;
  return text && text !== key ? text : t('err.generic');
}
