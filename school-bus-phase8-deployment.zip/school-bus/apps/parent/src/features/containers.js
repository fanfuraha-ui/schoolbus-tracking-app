import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { View } from 'react-native';
import { useServices } from '../services/ServicesContext';
import { useI18n } from '../i18n/I18nContext';
import { useAuth } from '../auth/AuthContext';
import { useSharedOverview } from './OverviewContext';
import { useList } from '../data/useList';
import { useLiveTrip } from '../data/useLiveTrip';
import { useAppActive, useNow } from '../data/useAppActive';
import { Empty, Loading, Sheet, useToast } from '../ui/components';
import { TodayScreen } from '../screens/TodayScreen';
import { TripScreen } from '../screens/TripScreen';
import { AbsencesScreen, AbsenceSheet } from '../screens/AbsencesScreen';
import { AlertsScreen } from '../screens/AlertsScreen';
import { SettingsScreen } from '../screens/SettingsScreen';
import { SignInScreen } from '../screens/SignInScreen';
import { ConsentScreen, PushPrimer } from '../screens/ConsentScreen';
import { BusMap } from '../map/BusMap';
import { errorText } from './errors';
import { fmtDay, addDays } from '../lib/time';
import { translate } from '../i18n/strings';

/**
 * Containers: hooks + screens. Navigation comes in as plain callbacks (`nav`), so the expo-router
 * routes and the web demo's tiny navigator drive exactly the same code.
 */

// ---------- push permission state, shared by Today and Settings ----------
export function usePushState() {
  const { push } = useServices();
  const appActive = useAppActive();
  const [state, setState] = useState(null);
  const check = useCallback(() => push.status().then(setState).catch(() => setState('unsupported')), [push]);
  useEffect(() => { if (appActive) check(); }, [appActive, check]);
  const enable = useCallback(async () => {
    const st = state === 'blocked' ? (push.openSettings(), 'blocked') : await push.request();
    setState(st);
    push.sync().catch(() => {});
    return st;
  }, [push, state]);
  return { pushState: state, enablePush: enable, recheck: check };
}

/** Keeps the server's copy of this phone's push registration current (start, foreground, token change). */
export function PushSync() {
  const { push } = useServices();
  const appActive = useAppActive();
  useEffect(() => { if (appActive) push.sync().catch(() => {}); }, [appActive, push]);
  useEffect(() => push.onTokenChange(() => push.sync().catch(() => {})), [push]);
  return null;
}

// ---------- shared "not riding" sheet ----------
function useAbsenceFlow({ overview, onSaved }) {
  const { api } = useServices();
  const { t, lang } = useI18n();
  const toast = useToast();
  const [sheet, setSheet] = useState(null); // { preset } | null
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);

  const submit = useCallback(async (body) => {
    setBusy(true); setError(null);
    try {
      await api.addAbsence(body);
      const child = overview.data.children.find((c) => c.id === body.studentId);
      const sd = overview.data.serviceDate;
      const day = body.date === sd ? t('abs.today').toLowerCase() : body.date === addDays(sd, 1) ? t('abs.tomorrow').toLowerCase() : t('abs.onDate', { date: fmtDay(body.date, lang) });
      if (body.date === sd) overview.patchRide(body.studentId, body.scheduleId, { absent: true, absentAllDay: !body.scheduleId });
      setSheet(null);
      toast(t('abs.saved', { name: child ? child.fullName.split(' ')[0] : '', day }));
      overview.refresh();
      onSaved && onSaved();
    } catch (e) {
      setError(errorText(t, e));
    } finally { setBusy(false); }
  }, [api, overview, t, lang, toast, onSaved]);

  const element = overview.data ? (
    <AbsenceSheet
      visible={Boolean(sheet)} onClose={() => { setSheet(null); setError(null); }} onSubmit={submit}
      children={overview.data.children} serviceDate={overview.data.serviceDate} t={t} lang={lang}
      preset={sheet && sheet.preset} busy={busy} error={error}
    />
  ) : null;
  return { open: (preset) => { setError(null); setSheet({ preset }); }, element };
}

// ---------- Today ----------
export function TodayContainer({ nav }) {
  const services = useServices();
  const { api, kv } = services;
  const { t, tp, lang } = useI18n();
  const toast = useToast();
  const overview = useSharedOverview();
  const now = useNow(15000, services.now);
  const { pushState, enablePush } = usePushState();
  const [primer, setPrimer] = useState(false);
  const [busyKey, setBusyKey] = useState(null);
  const absence = useAbsenceFlow({ overview });

  // Ask about notifications once, after the parent has seen their children's rides.
  useEffect(() => {
    if (!overview.data || pushState !== 'undetermined') return;
    kv.get('pushAsked').then((asked) => { if (!asked) setPrimer(true); });
  }, [overview.data, pushState, kv]);
  const closePrimer = () => { setPrimer(false); kv.set('pushAsked', true); };

  const undo = useCallback(async (child, ride) => {
    setBusyKey(`${child.id}:${ride.scheduleId}`);
    try {
      await api.removeAbsence(ride.absenceId);
      overview.patchRide(child.id, ride.scheduleId, { absent: false, absenceId: null });
      toast(t('ride.undone', { name: child.fullName.split(' ')[0] }));
      overview.refresh();
    } catch (e) { toast(errorText(t, e), 'alert'); } finally { setBusyKey(null); }
  }, [api, overview, toast, t]);

  if (!overview.data) {
    return overview.error
      ? <Empty text={errorText(t, overview.error) || t('common.loadFailed')} action={t('common.retry')} onAction={() => overview.refresh()} />
      : <Loading />;
  }
  return (
    <View style={{ flex: 1 }}>
      <TodayScreen
        overview={overview.data} now={now} t={t} tp={tp} lang={lang}
        offlineSince={overview.offline ? overview.fetchedAt : null}
        refreshing={overview.refreshing} onRefresh={() => overview.refresh({ pull: true })}
        pushState={pushState} onEnablePush={enablePush}
        onTrack={(tripId) => nav.openTrip(tripId)}
        onMarkAbsent={(child, ride) => absence.open({ studentId: child.id, date: overview.data.serviceDate, scheduleId: ride.scheduleId })}
        onUndoAbsent={undo} busyKey={busyKey}
      />
      {absence.element}
      <Sheet visible={primer} onClose={closePrimer}>
        <PushPrimer t={t} onAllow={async () => { closePrimer(); await enablePush(); }} onLater={closePrimer} />
      </Sheet>
    </View>
  );
}

// ---------- Trip ----------
export function TripContainer({ tripId, nav, insetTop = 0, MapComponent = BusMap }) {
  const services = useServices();
  const { t, tp } = useI18n();
  const live = useLiveTrip(tripId);
  return (
    <TripScreen
      view={live.view} summary={live.summary} connection={live.connection} now={live.now} error={live.error}
      t={t} tp={tp} onBack={nav.back} insetTop={insetTop}
      map={live.view && live.summary ? <MapComponent view={live.view} summary={live.summary} tiles={services.mapTiles} /> : null}
    />
  );
}

// ---------- Not riding ----------
export function AbsencesContainer({ focused = true }) {
  const { api } = useServices();
  const { t, lang } = useI18n();
  const toast = useToast();
  const overview = useSharedOverview();
  const load = useCallback((a) => a.absences(), []);
  const list = useList(load, { focused });
  const [busyId, setBusyId] = useState(null);
  const absence = useAbsenceFlow({ overview, onSaved: () => list.reload() });

  const rideNames = useMemo(() => {
    const m = {};
    (overview.data ? overview.data.children : []).forEach((c) => c.today.forEach((r) => { m[r.scheduleId] = t(`today.dir.${r.direction}`); }));
    return m;
  }, [overview.data, t]);

  const remove = useCallback(async (a) => {
    setBusyId(a.id);
    try {
      await api.removeAbsence(a.id);
      list.setItems((items) => items.filter((x) => x.id !== a.id));
      toast(t('abs.removed', { name: a.fullName.split(' ')[0] }));
      overview.refresh();
    } catch (e) { toast(errorText(t, e), 'alert'); } finally { setBusyId(null); }
  }, [api, list, toast, t, overview]);

  return (
    <View style={{ flex: 1 }}>
      <AbsencesScreen
        items={list.items} error={list.error} refreshing={list.refreshing} onRefresh={() => list.reload({ pull: true })}
        t={t} lang={lang} serviceDate={overview.data ? overview.data.serviceDate : null} rideNames={rideNames}
        onOpenAdd={() => absence.open(null)} onRemove={remove} busyId={busyId}
      />
      {absence.element}
    </View>
  );
}

// ---------- Alerts ----------
export function AlertsContainer({ focused = true }) {
  const services = useServices();
  const { t, lang } = useI18n();
  const load = useCallback((a) => a.notifications(100), []);
  const list = useList(load, { focused });
  return (
    <AlertsScreen
      items={list.items} error={list.error} refreshing={list.refreshing} onRefresh={() => list.reload({ pull: true })}
      t={t} lang={lang} now={services.now()}
    />
  );
}

// ---------- Settings ----------
export function SettingsContainer({ nav }) {
  const services = useServices();
  const { api } = services;
  const { t, lang, setLang } = useI18n();
  const { signOut } = useAuth();
  const toast = useToast();
  const overview = useSharedOverview();
  const { pushState, enablePush } = usePushState();
  const [profile, setProfile] = useState(null);
  useEffect(() => { if (overview.data) setProfile(overview.data.profile); }, [overview.data]);

  const save = useCallback(async (patch, optimistic) => {
    const before = profile;
    setProfile((p) => ({ ...p, ...optimistic }));
    try {
      await api.updatePreferences(patch);
      // After a language switch, confirm in the NEW language (t still holds the old one here).
      toast(patch.preferredLanguage ? translate(patch.preferredLanguage, 'settings.saved') : t('settings.saved'));
      overview.refresh();
    } catch (e) {
      setProfile(before);
      toast(errorText(t, e), 'alert');
    }
  }, [api, profile, toast, t, overview]);

  if (!profile) return <Loading />;
  return (
    <SettingsScreen
      profile={profile} school={overview.data.school} pushState={pushState} platform={services.platform}
      appVersion={services.appVersion} t={t} lang={lang}
      onChannel={(c) => save({ channelMode: c }, { channelMode: c })}
      onLanguage={(l) => { setLang(l); save({ preferredLanguage: l }, { preferredLanguage: l }); }}
      onQuiet={(q) => save({ quietHours: q }, { quietHoursStart: q ? `${q.start}:00` : null, quietHoursEnd: q ? `${q.end}:00` : null })}
      onEnablePush={enablePush}
      onOpenPhoneSettings={() => services.push.openSettings()}
      onCall={() => services.openUrl(`tel:${overview.data.school.phone}`)}
      onPrivacy={() => nav.openPrivacy()}
      onSignOut={() => signOut()}
    />
  );
}

// ---------- Sign in / consent ----------
export function SignInContainer({ insetTop = 0 }) {
  const auth = useAuth();
  const { t, lang, setLang } = useI18n();
  return (
    <SignInScreen
      t={t} lang={lang} onLanguage={(l) => setLang(l, { picked: true })}
      requestCode={auth.requestCode} verify={auth.verify} notice={auth.notice} insetTop={insetTop}
    />
  );
}

export function ConsentContainer({ insetTop = 0 }) {
  const auth = useAuth();
  const { t } = useI18n();
  const { api } = useServices();
  const [busy, setBusy] = useState(false);
  const [school, setSchool] = useState(null);
  useEffect(() => { api.me().then((o) => setSchool(o.school ? o.school.name : null)).catch(() => {}); }, [api]);
  return (
    <ConsentScreen
      t={t} schoolName={school} busy={busy} insetTop={insetTop}
      onAccept={async () => { setBusy(true); try { await auth.acceptConsent(); } finally { setBusy(false); } }}
      onDecline={() => auth.signOut()}
    />
  );
}

export function PrivacyContainer({ nav, insetTop = 0 }) {
  const { t } = useI18n();
  const overview = useSharedOverview();
  return <ConsentScreen t={t} readOnly onClose={nav.back} insetTop={insetTop} schoolName={overview && overview.data ? overview.data.school.name : null} />;
}
