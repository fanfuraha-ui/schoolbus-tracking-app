import React, { createContext, useContext } from 'react';
import { useOverview } from '../data/useOverview';

/** One shared copy of today's overview for all tabs (Today, Not riding, Settings). */
const OverviewContext = createContext(null);
export function OverviewProvider({ children }) {
  const value = useOverview({ focused: true });
  return <OverviewContext.Provider value={value}>{children}</OverviewContext.Provider>;
}
export const useSharedOverview = () => useContext(OverviewContext);
