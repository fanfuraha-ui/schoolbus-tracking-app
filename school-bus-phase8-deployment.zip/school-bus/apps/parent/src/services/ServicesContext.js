import { createContext, useContext } from 'react';

/**
 * Everything the screens need from the outside world: API, socket, storage, push, clock.
 * The real app provides createRealServices(); the web demo and tests provide fakes, so the same
 * screens and hooks run in all three. (Think of it as the app's wall socket: plug the screens
 * into the mains or into a generator, they work the same.)
 */
export const ServicesContext = createContext(null);
export const useServices = () => {
  const s = useContext(ServicesContext);
  if (!s) throw new Error('ServicesContext missing');
  return s;
};
