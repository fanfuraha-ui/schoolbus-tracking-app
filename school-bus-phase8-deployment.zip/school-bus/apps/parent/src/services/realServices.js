import { Platform, Linking } from 'react-native';
import * as Crypto from 'expo-crypto';
import { io } from 'socket.io-client';
import { createApiClient, getOrCreateDeviceUid } from '@school-bus/core';
import { createParentApi } from '../api/parentApi';
import { createParentSocket } from '../realtime/parentSocket';
import { secureTokenStore, secureKv } from '../storage/secureStore';
import { kv } from '../storage/kv';
import { pushStatus, requestPush, syncPushRegistration, onPushTokenChange, openPhoneSettings } from '../push/push';
import { API_ORIGIN, API_URL, APP_VERSION, MAP_TILES } from '../config';

let services = null;

/** Production wiring. One instance per app process. */
export function createRealServices() {
  if (services) return services;
  const expiredListeners = new Set();
  const core = createApiClient({
    baseUrl: API_URL,
    tokenStore: secureTokenStore,
    onSessionExpired: () => expiredListeners.forEach((fn) => fn()),
  });
  const api = createParentApi(core);
  const socket = createParentSocket({
    url: API_ORIGIN,
    getToken: () => core.accessToken(),
    refresh: () => core.refresh(),
    ioFactory: io,
  });
  let uid = null;
  const deviceUid = async () => { if (!uid) uid = await getOrCreateDeviceUid(secureKv, Crypto.randomUUID); return uid; };

  services = {
    api,
    tokens: secureTokenStore,
    kv,
    deviceUid,
    socket,
    platform: Platform.OS === 'ios' ? 'ios' : 'android',
    appVersion: APP_VERSION,
    mapTiles: MAP_TILES,
    now: () => Date.now(),
    openUrl: (url) => Linking.openURL(url),
    push: {
      status: pushStatus,
      request: requestPush,
      sync: async () => syncPushRegistration({ api, deviceUid: await deviceUid(), appVersion: APP_VERSION }),
      onTokenChange: onPushTokenChange,
      openSettings: openPhoneSettings,
    },
    onSessionExpired(fn) { expiredListeners.add(fn); return () => expiredListeners.delete(fn); },
  };
  return services;
}
