'use strict';
/**
 * Parent socket. Opens only while a trip screen is watching something, and closes when nothing
 * is watched, so the app holds no connection (and uses no battery or data) on other screens.
 *
 *   const unwatch = socket.watch(tripId, { onView, onEvent, onStatus, onRejected })
 *
 *  - onView(view): the trip:watch ack (same shape as GET /parent/trips/:id), sent on every
 *    (re)connect, so a phone that slept or lost signal catches up in one step.
 *  - onEvent(name, payload): bus:location, trip:stops, trip:ended for this trip only.
 *  - onStatus('live' | 'connecting' | 'offline')
 *  - onRejected(error): the server refused to watch (trip not active, not their child).
 *
 * `ioFactory` is socket.io-client's `io`, injected so tests can use a fake.
 */
const EVENTS = ['bus:location', 'trip:stops', 'trip:ended'];

function createParentSocket({ url, getToken, refresh, ioFactory, ackTimeoutMs = 8000 }) {
  let socket = null;
  const watchers = new Map(); // tripId -> Set(handlers)

  const each = (fn) => watchers.forEach((set, tripId) => set.forEach((h) => fn(h, tripId)));
  const status = (s) => each((h) => h.onStatus && h.onStatus(s));

  async function sendWatch(tripId) {
    if (!socket || !socket.connected) return;
    let ack;
    try {
      ack = await socket.timeout(ackTimeoutMs).emitWithAck('trip:watch', { tripId });
    } catch {
      return; // no ack: the hook's polling covers the gap; the next reconnect retries
    }
    const set = watchers.get(tripId);
    if (!set) return;
    set.forEach((h) => {
      if (ack && ack.ok) h.onView && h.onView(ack.view);
      else h.onRejected && h.onRejected(ack ? ack.error : null);
    });
  }

  function open() {
    if (socket) { if (!socket.connected) socket.connect(); return; }
    status('connecting');
    socket = ioFactory(url, {
      transports: ['websocket'],
      auth: (cb) => { getToken().then((token) => cb({ token })).catch(() => cb({})); },
      reconnectionDelay: 1000,
      reconnectionDelayMax: 15000,
    });
    socket.on('connect', () => { status('live'); watchers.forEach((_, tripId) => sendWatch(tripId)); });
    socket.on('disconnect', () => status('offline'));
    socket.on('connect_error', async (err) => {
      status('offline');
      if (err && err.message === 'unauthorized') {
        try { await refresh(); if (socket) socket.connect(); } catch { /* session over; app returns to sign-in */ }
      }
    });
    EVENTS.forEach((name) => socket.on(name, (payload) => {
      const set = payload && watchers.get(payload.tripId);
      if (set) set.forEach((h) => h.onEvent && h.onEvent(name, payload));
    }));
  }

  function close() {
    if (!socket) return;
    socket.removeAllListeners();
    socket.disconnect();
    socket = null;
  }

  function watch(tripId, handlers) {
    let set = watchers.get(tripId);
    if (!set) { set = new Set(); watchers.set(tripId, set); }
    set.add(handlers);
    if (socket && socket.connected) { handlers.onStatus && handlers.onStatus('live'); sendWatch(tripId); } else open();
    return () => {
      set.delete(handlers);
      if (!set.size) {
        watchers.delete(tripId);
        if (socket && socket.connected) socket.emit('trip:unwatch', { tripId });
      }
      if (!watchers.size) close();
    };
  }

  return { watch, close, isOpen: () => Boolean(socket) };
}

module.exports = { createParentSocket };
