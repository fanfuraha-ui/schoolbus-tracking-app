import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { colors, fonts, space, type } from './theme';
import { fmtTime } from '../lib/time';

/**
 * The app's signature: the route seen from your stop. A yellow bus, the stops it still has to
 * serve as dots, and your stop as a ring. Same idea as the admin dashboard's route-line board,
 * cut down to one family's view.
 */
const MAX_DOTS = 8;

export function Bus({ size = 22, stale = false, inverse = false }) {
  return (
    <View
      accessibilityLabel="bus"
      style={{
        width: size, height: size, borderRadius: size / 2, borderWidth: 3, borderColor: inverse ? colors.onInk : colors.ink,
        backgroundColor: stale ? colors.card : colors.bus, borderStyle: stale ? 'dashed' : 'solid',
      }}
    />
  );
}

export function Home({ size = 20, inverse = false }) {
  return <View style={{ width: size, height: size, borderRadius: size / 2, borderWidth: 6, borderColor: inverse ? colors.onInk : colors.ink, backgroundColor: inverse ? colors.ink : colors.card }} />;
}

/** Horizontal strip for the Today card. stopsAway = stops still to serve before yours. */
export function DotStrip({ stopsAway, stale = false, inverse = false, testID }) {
  const n = Math.max(0, Math.min(stopsAway ?? 0, MAX_DOTS));
  const more = (stopsAway ?? 0) > MAX_DOTS;
  return (
    <View style={d.strip} testID={testID} accessibilityLabel={`${stopsAway} stops before yours`}>
      <View style={[d.rail, stale && d.railStale, inverse && { backgroundColor: colors.onInkMuted }]} />
      <Bus stale={stale} inverse={inverse} />
      {Array.from({ length: n }).map((_, i) => <View key={i} style={[d.dot, inverse && d.dotInverse]} />)}
      {more ? <Text style={d.more}>+{stopsAway - MAX_DOTS}</Text> : null}
      <Home inverse={inverse} />
    </View>
  );
}

/**
 * Vertical ladder for the trip screen: from where the bus is down to the child's stop.
 * items: summary.ladder (see live/tripModel.js)
 */
export function StopLadder({ items, stopsBehind, busStale, t, tp }) {
  return (
    <View testID="ladder">
      {stopsBehind ? (
        <View style={l.row}>
          <View style={l.railCol}><View style={[l.seg, l.segDone, { top: 0, bottom: 0 }]} /></View>
          <Text style={[type.small, l.behind]}>{tp('trip.done', stopsBehind)}</Text>
        </View>
      ) : null}
      {items.map((it, i) => {
        const first = i === 0;
        const last = i === items.length - 1;
        const busHere = it.state === 'here';
        const busAbove = first && it.state === 'next';
        let right = null;
        if (busHere) right = t('trip.here');
        else if (it.state === 'departed') right = it.at ? t('trip.at', { time: fmtTime(it.at) }) : null;
        else if (it.etaAt) right = t('trip.expected', { time: fmtTime(it.etaAt) });
        return (
          <View key={it.stopId} style={[l.row, last && { minHeight: 0 }]} testID={it.isMine ? 'ladder-mine' : undefined}>
            <View style={l.railCol}>
              {!first || stopsBehind ? <View style={[l.seg, { top: 0, height: 22 }, (busHere || busAbove) && first && l.segDone]} /> : null}
              {!last ? <View style={[l.seg, { top: 22, bottom: 0 }]} /> : null}
              <View style={l.nodeWrap}>
                {busHere ? <Bus size={26} stale={busStale} /> : it.isMine ? <Home size={22} /> : <View style={l.node} />}
              </View>
              {busAbove ? <View style={l.busAbove}><Bus size={22} stale={busStale} /></View> : null}
            </View>
            <View style={l.body}>
              <View style={l.line1}>
                <Text style={[it.isMine ? type.bodyStrong : type.body, { flex: 1 }]} numberOfLines={2}>
                  {it.isSchool ? `${it.name}` : it.name}
                </Text>
                {right ? <Text style={[l.time, busHere && { color: colors.ink }]}>{right}</Text> : null}
              </View>
              {it.isMine ? (
                <Text style={type.small}>
                  {t('trip.yourStop')}{it.children.length ? ` · ${it.children.map((c) => c.fullName.split(' ')[0]).join(', ')}` : ''}
                </Text>
              ) : it.state === 'next' ? <Text style={type.small}>{t('trip.next')}</Text> : null}
            </View>
          </View>
        );
      })}
    </View>
  );
}

const d = StyleSheet.create({
  strip: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', height: 28, position: 'relative' },
  rail: { position: 'absolute', left: 10, right: 10, top: 12, height: 4, borderRadius: 2, backgroundColor: colors.ink },
  railStale: { backgroundColor: colors.done },
  dot: { width: 10, height: 10, borderRadius: 5, backgroundColor: colors.card, borderWidth: 2.5, borderColor: colors.ink },
  dotInverse: { backgroundColor: colors.ink, borderColor: colors.onInk },
  more: { fontFamily: fonts.cond, fontSize: 14, color: colors.ink, backgroundColor: colors.card, paddingHorizontal: 4 },
});

const RAIL = 36;
const l = StyleSheet.create({
  row: { flexDirection: 'row', minHeight: 64 },
  railCol: { width: RAIL, alignItems: 'center', position: 'relative' },
  seg: { position: 'absolute', width: 4, left: RAIL / 2 - 2, backgroundColor: colors.ink },
  segDone: { backgroundColor: colors.done },
  nodeWrap: { position: 'absolute', top: 22, left: 0, right: 0, alignItems: 'center', transform: [{ translateY: -12 }], height: 26, justifyContent: 'center' },
  node: { width: 14, height: 14, borderRadius: 7, backgroundColor: colors.card, borderWidth: 3, borderColor: colors.ink },
  busAbove: { position: 'absolute', top: -14, left: 0, right: 0, alignItems: 'center' },
  body: { flex: 1, paddingTop: 10, paddingBottom: space.md, paddingLeft: space.sm, gap: 2 },
  line1: { flexDirection: 'row', alignItems: 'baseline', gap: space.sm },
  time: { fontFamily: fonts.cond, fontSize: 17, color: colors.muted },
  behind: { paddingTop: 0, paddingLeft: space.sm, paddingBottom: space.md, alignSelf: 'center' },
});
