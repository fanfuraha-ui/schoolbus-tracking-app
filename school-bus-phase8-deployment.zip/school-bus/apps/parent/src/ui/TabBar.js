import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { colors, fonts, space } from './theme';

/**
 * Text tab bar: four words, the current one marked by a bus-yellow bar. Readable at a glance and
 * in Kiswahili, without relying on icons parents have to decode.
 */
export function TabBar({ tabs, active, onPress, insetBottom = 0 }) {
  return (
    <View style={[s.bar, { paddingBottom: Math.max(insetBottom, space.sm) }]} accessibilityRole="tablist">
      {tabs.map((tab) => {
        const on = tab.key === active;
        return (
          <Pressable
            key={tab.key} testID={`tab-${tab.key}`} accessibilityRole="tab" accessibilityState={{ selected: on }}
            onPress={() => onPress(tab.key)} style={({ pressed }) => [s.tab, pressed && { opacity: 0.7 }]}
          >
            <View style={[s.mark, on && s.markOn]} />
            <Text style={[s.label, on && s.labelOn]} numberOfLines={1}>{tab.label}</Text>
            {tab.badge ? <View style={s.badge} /> : null}
          </Pressable>
        );
      })}
    </View>
  );
}

const s = StyleSheet.create({
  bar: { flexDirection: 'row', backgroundColor: colors.card, borderTopWidth: 1, borderTopColor: colors.line },
  tab: { flex: 1, alignItems: 'center', paddingTop: 0, paddingBottom: space.sm, minHeight: 56, position: 'relative' },
  mark: { height: 4, alignSelf: 'stretch', marginHorizontal: space.lg, borderBottomLeftRadius: 3, borderBottomRightRadius: 3, backgroundColor: 'transparent', marginBottom: space.sm + 2 },
  markOn: { backgroundColor: colors.bus },
  label: { fontFamily: fonts.cond, fontSize: 17, color: colors.muted, letterSpacing: 0.2 },
  labelOn: { color: colors.ink },
  badge: { position: 'absolute', top: 10, right: '24%', width: 8, height: 8, borderRadius: 4, backgroundColor: colors.alert },
});
