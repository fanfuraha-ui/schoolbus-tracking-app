/**
 * Parent app tokens. Same family as the admin dashboard (signage navy + school-bus yellow), so
 * the school's tools read as one system. Yellow is reserved for the bus itself and the one main
 * action ("Track the bus"); status colours are only used for status.
 */
export const colors = {
  ink: '#1A2238',
  inkSoft: '#2B3555',
  bus: '#FFB400',
  busSoft: '#FFF1CC',
  paper: '#F3F5F8',
  card: '#FFFFFF',
  line: '#DDE2EA',
  lineStrong: '#B9C1CF',
  muted: '#5E6779',
  done: '#A9B2C3',
  ok: '#1F7A51',
  okSoft: '#E3F3EA',
  late: '#A85500',
  lateSoft: '#FDF0E1',
  alert: '#C8102E',
  alertSoft: '#FCE8EB',
  onInk: '#FFFFFF',
  onInkMuted: '#B8C0D4',
};

export const tone = {
  live: { fg: colors.ink, bg: colors.busSoft, bar: colors.bus },
  ok: { fg: colors.ok, bg: colors.okSoft, bar: colors.ok },
  late: { fg: colors.late, bg: colors.lateSoft, bar: colors.late },
  alert: { fg: colors.alert, bg: colors.alertSoft, bar: colors.alert },
  quiet: { fg: colors.muted, bg: colors.paper, bar: colors.line },
};

// Loaded in app/_layout.js from @expo-google-fonts. On Android a custom family must not be
// combined with fontWeight, so each weight is its own family.
export const fonts = {
  body: 'Barlow_400Regular',
  medium: 'Barlow_500Medium',
  semi: 'Barlow_600SemiBold',
  cond: 'BarlowCondensed_600SemiBold',
  condBold: 'BarlowCondensed_700Bold',
};

export const space = { xs: 4, sm: 8, md: 12, lg: 16, xl: 24, xxl: 32 };
export const radius = { sm: 8, md: 14, lg: 20, pill: 999 };

// Type scale (Barlow body 16 / 1.4; condensed for numbers and names).
export const type = {
  hero: { fontFamily: fonts.condBold, fontSize: 64, lineHeight: 64, color: colors.ink },
  display: { fontFamily: fonts.condBold, fontSize: 34, lineHeight: 38, color: colors.ink },
  title: { fontFamily: fonts.cond, fontSize: 26, lineHeight: 30, color: colors.ink },
  heading: { fontFamily: fonts.semi, fontSize: 18, lineHeight: 24, color: colors.ink },
  body: { fontFamily: fonts.body, fontSize: 16, lineHeight: 22, color: colors.ink },
  bodyStrong: { fontFamily: fonts.semi, fontSize: 16, lineHeight: 22, color: colors.ink },
  small: { fontFamily: fonts.body, fontSize: 14, lineHeight: 19, color: colors.muted },
  smallStrong: { fontFamily: fonts.medium, fontSize: 14, lineHeight: 19, color: colors.ink },
  label: { fontFamily: fonts.medium, fontSize: 13, lineHeight: 17, color: colors.muted },
  num: { fontFamily: fonts.cond, fontSize: 18, lineHeight: 22, color: colors.ink },
};
