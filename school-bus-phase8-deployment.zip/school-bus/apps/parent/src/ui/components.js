import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { ActivityIndicator, Modal, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { colors, fonts, radius, space, tone as tones, type } from './theme';

export function T({ v = 'body', style, children, ...rest }) {
  return <Text style={[type[v], style]} {...rest}>{children}</Text>;
}

/** Buttons. `bus` (yellow) is used once per screen at most, for the main action. */
export function Button({ title, onPress, variant = 'primary', loading = false, disabled = false, compact = false, testID, style }) {
  const v = BTN[variant];
  return (
    <Pressable
      testID={testID}
      accessibilityRole="button"
      accessibilityState={{ disabled: disabled || loading, busy: loading }}
      onPress={disabled || loading ? undefined : onPress}
      style={({ pressed }) => [
        s.btn, compact && s.btnCompact, { backgroundColor: v.bg, borderColor: v.border },
        (disabled || loading) && s.btnDisabled, pressed && !disabled && { opacity: 0.85 }, style,
      ]}
    >
      {loading ? <ActivityIndicator color={v.fg} /> : <Text style={[s.btnText, compact && s.btnTextCompact, { color: v.fg }]}>{title}</Text>}
    </Pressable>
  );
}
const BTN = {
  bus: { bg: colors.bus, fg: colors.ink, border: colors.bus },
  primary: { bg: colors.ink, fg: colors.onInk, border: colors.ink },
  secondary: { bg: colors.card, fg: colors.ink, border: colors.lineStrong },
  ghost: { bg: 'transparent', fg: colors.ink, border: 'transparent' },
  danger: { bg: colors.card, fg: colors.alert, border: colors.alert },
};

/** Text-only action inside content ("Undo", "Remove"). */
export function LinkButton({ title, onPress, color = colors.ink, testID }) {
  return (
    <Pressable testID={testID} accessibilityRole="button" onPress={onPress} hitSlop={10} style={({ pressed }) => [s.link, pressed && { opacity: 0.6 }]}>
      <Text style={[s.linkText, { color }]}>{title}</Text>
    </Pressable>
  );
}

export function Card({ children, style, accent }) {
  return (
    <View style={[s.card, style]}>
      {accent ? <View style={[s.accent, { backgroundColor: accent }]} /> : null}
      {children}
    </View>
  );
}

export function Banner({ tone = 'quiet', text, action, onAction, testID }) {
  const t = tones[tone];
  return (
    <View testID={testID} style={[s.banner, { backgroundColor: t.bg, borderLeftColor: t.bar }]}>
      <Text style={[type.small, { color: t.fg === colors.muted ? colors.ink : t.fg, flex: 1 }]}>{text}</Text>
      {action ? <LinkButton title={action} onPress={onAction} color={t.fg === colors.muted ? colors.ink : t.fg} /> : null}
    </View>
  );
}

/** Choice chip. */
export function Chip({ label, selected, onPress, inverse = false, testID }) {
  return (
    <Pressable
      testID={testID}
      accessibilityRole="button"
      accessibilityState={{ selected }}
      onPress={onPress}
      style={({ pressed }) => [s.chip, selected && s.chipOn, inverse && (selected ? s.chipInvOn : s.chipInv), pressed && { opacity: 0.8 }]}
    >
      <Text style={[s.chipText, selected && s.chipTextOn, inverse && { color: selected ? colors.ink : colors.onInk }]}>{label}</Text>
    </Pressable>
  );
}

/** Radio row for settings. */
export function Choice({ label, hint, badge, selected, onPress, testID }) {
  return (
    <Pressable testID={testID} accessibilityRole="radio" accessibilityState={{ checked: selected }} onPress={onPress}
      style={({ pressed }) => [s.choice, pressed && { backgroundColor: colors.paper }]}>
      <View style={[s.radio, selected && s.radioOn]}>{selected ? <View style={s.radioDot} /> : null}</View>
      <View style={{ flex: 1 }}>
        <Text style={type.body}>{label}</Text>
        {hint ? <Text style={type.small}>{hint}</Text> : null}
      </View>
      {badge ? <Text style={s.badge}>{badge}</Text> : null}
    </Pressable>
  );
}

export function Field({ label, error, inputStyle, testID, ...input }) {
  const [focus, setFocus] = useState(false);
  return (
    <View style={{ gap: space.xs }}>
      {label ? <Text style={type.label}>{label}</Text> : null}
      <TextInput
        testID={testID}
        placeholderTextColor={colors.done}
        onFocus={() => setFocus(true)}
        onBlur={() => setFocus(false)}
        style={[s.input, focus && s.inputFocus, error && s.inputError, inputStyle]}
        {...input}
      />
      {error ? <Text style={[type.small, { color: colors.alert }]}>{error}</Text> : null}
    </View>
  );
}

export function Section({ title, children, hint }) {
  return (
    <View style={s.section}>
      {title ? <Text style={s.sectionTitle}>{title}</Text> : null}
      {hint ? <Text style={[type.small, { marginBottom: space.sm }]}>{hint}</Text> : null}
      <View style={s.sectionBody}>{children}</View>
    </View>
  );
}

export function Loading() {
  return <View style={s.center}><ActivityIndicator color={colors.ink} size="large" /></View>;
}

export function Empty({ text, action, onAction }) {
  return (
    <View style={[s.center, { gap: space.md }]}>
      <Text style={[type.body, { color: colors.muted, textAlign: 'center' }]}>{text}</Text>
      {action ? <Button title={action} variant="secondary" compact onPress={onAction} /> : null}
    </View>
  );
}

/** Bottom sheet over the current screen. */
export function Sheet({ visible, title, onClose, children, testID }) {
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose} statusBarTranslucent>
      <View style={s.scrim}>
        <Pressable style={{ flex: 1 }} onPress={onClose} accessibilityLabel="Close" />
        <View style={s.sheet} testID={testID}>
          <View style={s.grabber} />
          {title ? <Text style={[type.title, { marginBottom: space.md }]}>{title}</Text> : null}
          <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{ gap: space.lg, paddingBottom: space.lg }}>
            {children}
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

// ---------- toast ----------
const ToastContext = createContext(() => {});
export function ToastProvider({ children }) {
  const [msg, setMsg] = useState(null);
  const timer = useRef(null);
  const show = useCallback((text, t = 'quiet') => {
    setMsg({ text, tone: t });
    clearTimeout(timer.current);
    timer.current = setTimeout(() => setMsg(null), 3500);
  }, []);
  useEffect(() => () => clearTimeout(timer.current), []);
  return (
    <ToastContext.Provider value={show}>
      {children}
      {msg ? (
        <View pointerEvents="none" style={s.toastWrap}>
          <View style={[s.toast, msg.tone === 'alert' && { backgroundColor: colors.alert }]} accessibilityLiveRegion="polite">
            <Text style={[type.small, { color: colors.onInk }]}>{msg.text}</Text>
          </View>
        </View>
      ) : null}
    </ToastContext.Provider>
  );
}
export const useToast = () => useContext(ToastContext);

const s = StyleSheet.create({
  btn: { minHeight: 52, paddingHorizontal: space.xl, borderRadius: radius.md, borderWidth: 1.5, alignItems: 'center', justifyContent: 'center' },
  btnCompact: { minHeight: 44, paddingHorizontal: space.lg },
  btnDisabled: { opacity: 0.45 },
  btnText: { fontFamily: fonts.semi, fontSize: 17 },
  btnTextCompact: { fontSize: 15 },
  link: { paddingVertical: space.xs },
  linkText: { fontFamily: fonts.semi, fontSize: 15, textDecorationLine: 'underline' },
  card: { backgroundColor: colors.card, borderRadius: radius.md, padding: space.lg, borderWidth: 1, borderColor: colors.line, overflow: 'hidden' },
  accent: { position: 'absolute', left: 0, top: 0, bottom: 0, width: 5 },
  banner: { flexDirection: 'row', alignItems: 'center', gap: space.md, padding: space.md, borderRadius: radius.sm, borderLeftWidth: 4 },
  chip: { minHeight: 44, paddingHorizontal: space.lg, borderRadius: radius.pill, borderWidth: 1.5, borderColor: colors.lineStrong, backgroundColor: colors.card, justifyContent: 'center' },
  chipOn: { backgroundColor: colors.ink, borderColor: colors.ink },
  chipText: { fontFamily: fonts.medium, fontSize: 15, color: colors.ink },
  chipTextOn: { color: colors.onInk },
  chipInv: { backgroundColor: 'transparent', borderColor: colors.onInkMuted, minHeight: 36 },
  chipInvOn: { backgroundColor: colors.onInk, borderColor: colors.onInk, minHeight: 36 },
  choice: { flexDirection: 'row', alignItems: 'center', gap: space.md, paddingVertical: space.md, paddingHorizontal: space.lg, minHeight: 56 },
  radio: { width: 22, height: 22, borderRadius: 11, borderWidth: 2, borderColor: colors.lineStrong, alignItems: 'center', justifyContent: 'center' },
  radioOn: { borderColor: colors.ink },
  radioDot: { width: 11, height: 11, borderRadius: 6, backgroundColor: colors.ink },
  badge: { fontFamily: fonts.medium, fontSize: 12, color: colors.ink, backgroundColor: colors.busSoft, paddingHorizontal: space.sm, paddingVertical: 2, borderRadius: radius.sm, overflow: 'hidden' },
  input: { minHeight: 52, borderWidth: 1.5, borderColor: colors.lineStrong, borderRadius: radius.md, paddingHorizontal: space.lg, fontFamily: fonts.body, fontSize: 18, color: colors.ink, backgroundColor: colors.card },
  inputFocus: { borderColor: colors.ink },
  inputError: { borderColor: colors.alert },
  section: { gap: space.xs },
  sectionTitle: { ...type.heading, marginBottom: space.xs },
  sectionBody: { backgroundColor: colors.card, borderRadius: radius.md, borderWidth: 1, borderColor: colors.line, overflow: 'hidden' },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: space.xl },
  scrim: { flex: 1, backgroundColor: 'rgba(26,34,56,0.45)' },
  sheet: { backgroundColor: colors.card, borderTopLeftRadius: radius.lg, borderTopRightRadius: radius.lg, paddingHorizontal: space.xl, paddingTop: space.sm, maxHeight: '88%' },
  grabber: { alignSelf: 'center', width: 40, height: 4, borderRadius: 2, backgroundColor: colors.line, marginBottom: space.md },
  toastWrap: { position: 'absolute', left: space.lg, right: space.lg, bottom: 96, alignItems: 'center' },
  toast: { backgroundColor: colors.ink, paddingHorizontal: space.lg, paddingVertical: space.md, borderRadius: radius.md, maxWidth: 420 },
});
