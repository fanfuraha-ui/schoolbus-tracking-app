'use strict';
/** Typed wrapper over the parent endpoints (see docs/api.md). `api` = @school-bus/core client. */
function createParentApi(api) {
  return {
    requestOtp: (phone) => api.post('/auth/otp/request', { phone }, { auth: false }),
    verifyOtp: (body) => api.post('/auth/otp/verify', body, { auth: false }),
    logout: (refreshToken) => api.post('/auth/logout', { refreshToken }, { auth: false }),
    me: () => api.get('/parent/me'),
    updatePreferences: (body) => api.patch('/parent/preferences', body),
    consent: (version) => api.post('/parent/consent', { version }),
    registerDevice: (device) => api.put('/parent/device', device),
    trip: (tripId) => api.get(`/parent/trips/${tripId}`),
    absences: () => api.get('/parent/absences').then((r) => r.absences),
    addAbsence: (body) => api.post('/parent/absences', body),
    removeAbsence: (id) => api.del(`/parent/absences/${id}`),
    notifications: (limit = 50) => api.get('/parent/notifications', { query: { limit } }).then((r) => r.notifications),
  };
}

module.exports = { createParentApi };
