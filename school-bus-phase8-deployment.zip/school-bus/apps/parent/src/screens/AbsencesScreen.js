import React, { useMemo, useState } from 'react';
import { RefreshControl, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Button, Chip, Empty, Field, LinkButton, Loading, Sheet } from '../ui/components';
import { colors, fonts, space, type } from '../ui/theme';
import { addDays, fmtDay, schoolDays } from '../lib/time';

/** Upcoming "not riding" days, and the sheet to report one. */
export function AbsencesScreen({ items, error, refreshing, onRefresh, t, lang, serviceDate, rideNames, onOpenAdd, onRemove, busyId }) {
  const grouped = useMemo(() => {
    const m = new Map();
    (items || []).forEach((a) => { if (!m.has(a.serviceDate)) m.set(a.serviceDate, []); m.get(a.serviceDate).push(a); });
    return [...m.entries()];
  }, [items]);
  const dayLabel = (d) => (d === serviceDate ? t('abs.today') : d === addDays(serviceDate, 1) ? t('abs.tomorrow') : fmtDay(d, lang));
  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: colors.paper }}
      contentContainerStyle={s.body}
      refreshControl={<RefreshControl refreshing={Boolean(refreshing)} onRefresh={onRefresh} tintColor={colors.ink} />}
    >
      <Text style={type.display} accessibilityRole="header">{t('abs.title')}</Text>
      <Text style={type.body}>{t('abs.intro')}</Text>
      <Button title={t('abs.add')} onPress={onOpenAdd} testID="abs-add" />
      {items == null && !error ? <Loading /> : null}
      {error && items == null ? <Empty text={t('common.loadFailed')} action={t('common.retry')} onAction={onRefresh} /> : null}
      {items && items.length === 0 ? <Text style={[type.body, { color: colors.muted }]}>{t('abs.empty')}</Text> : null}
      {grouped.map(([day, list]) => (
        <View key={day} style={s.day}>
          <Text style={s.dayLabel}>{dayLabel(day)}</Text>
          {list.map((a) => (
            <View key={a.id} style={s.row} testID={`absence-${a.id}`}>
              <View style={{ flex: 1 }}>
                <Text style={type.bodyStrong}>{a.fullName}</Text>
                <Text style={type.small}>
                  {a.scheduleId ? (rideNames[a.scheduleId] || '') : t('abs.allTrips')}
                  {a.reason ? ` · ${a.reason}` : ''}
                </Text>
              </View>
              <LinkButton title={t('abs.remove')} onPress={busyId === a.id ? undefined : () => onRemove(a)} color={colors.alert} testID={`remove-${a.id}`} />
            </View>
          ))}
        </View>
      ))}
    </ScrollView>
  );
}

/**
 * Report sheet. `children` = overview children (with today's rides, used to offer
 * "which trips"). `preset` = { studentId, date, scheduleId } when opened from a Today card.
 */
export function AbsenceSheet({ visible, onClose, onSubmit, children, serviceDate, t, lang, preset, busy, error }) {
  const [studentId, setStudentId] = useState(null);
  const [date, setDate] = useState(null);
  const [scheduleId, setScheduleId] = useState(undefined);
  const [reason, setReason] = useState('');
  const [openedFor, setOpenedFor] = useState(null);

  // Reset whenever the sheet opens (for a new preset).
  const key = visible ? JSON.stringify(preset || {}) : null;
  if (visible && openedFor !== key) {
    setOpenedFor(key);
    setStudentId(preset?.studentId ?? (children.length === 1 ? children[0].id : null));
    setDate(preset?.date ?? serviceDate);
    setScheduleId(preset?.scheduleId ?? null);
    setReason('');
  }
  if (!visible && openedFor !== null) setOpenedFor(null);

  const days = schoolDays(serviceDate, 10);
  const child = children.find((c) => c.id === studentId);
  const rides = child ? child.today : [];
  const dayLabel = (d) => (d === serviceDate ? t('abs.today') : d === addDays(serviceDate, 1) ? t('abs.tomorrow') : fmtDay(d, lang, { short: true }));

  return (
    <Sheet visible={visible} onClose={onClose} title={t('abs.sheetTitle')} testID="abs-sheet">
      {children.length > 1 ? (
        <View style={s.group}>
          <Text style={type.label}>{t('abs.child')}</Text>
          <View style={s.chips}>
            {children.map((c) => <Chip key={c.id} label={c.fullName.split(' ')[0]} selected={studentId === c.id} onPress={() => { setStudentId(c.id); setScheduleId(null); }} testID={`abs-child-${c.id}`} />)}
          </View>
        </View>
      ) : null}
      <View style={s.group}>
        <Text style={type.label}>{t('abs.day')}</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={s.chipsRow}>
          {days.map((d) => <Chip key={d} label={dayLabel(d)} selected={date === d} onPress={() => setDate(d)} testID={`abs-day-${d}`} />)}
        </ScrollView>
      </View>
      {rides.length > 1 ? (
        <View style={s.group}>
          <Text style={type.label}>{t('abs.which')}</Text>
          <View style={s.chips}>
            <Chip label={t('abs.allTrips')} selected={!scheduleId} onPress={() => setScheduleId(null)} testID="abs-all" />
            {rides.map((r) => <Chip key={r.scheduleId} label={t(`today.dir.${r.direction}`)} selected={scheduleId === r.scheduleId} onPress={() => setScheduleId(r.scheduleId)} testID={`abs-ride-${r.direction}`} />)}
          </View>
        </View>
      ) : null}
      <Field label={t('abs.reason')} placeholder={t('abs.reasonPlaceholder')} value={reason} onChangeText={setReason} maxLength={200} testID="abs-reason" />
      {error ? <Text style={[type.small, { color: colors.alert }]}>{error}</Text> : null}
      <Button
        title={t('abs.submit')} loading={busy} disabled={!studentId || !date} testID="abs-submit"
        onPress={() => onSubmit({ studentId, date, scheduleId: scheduleId || undefined, reason: reason.trim() || undefined })}
      />
    </Sheet>
  );
}

const s = StyleSheet.create({
  body: { padding: space.xl, gap: space.lg, paddingBottom: space.xxl },
  day: { gap: space.sm },
  dayLabel: { fontFamily: fonts.cond, fontSize: 20, color: colors.ink },
  row: { flexDirection: 'row', alignItems: 'center', gap: space.md, backgroundColor: colors.card, borderRadius: 14, borderWidth: 1, borderColor: colors.line, padding: space.lg },
  group: { gap: space.sm },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: space.sm },
  chipsRow: { flexDirection: 'row', gap: space.sm, paddingRight: space.lg },
});
