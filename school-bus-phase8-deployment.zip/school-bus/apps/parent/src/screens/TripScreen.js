import React from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Banner, Button, Loading } from '../ui/components';
import { StopLadder } from '../ui/RouteDots';
import { colors, fonts, radius, space, type } from '../ui/theme';
import { fmtTime, localToMs, minutesUntil, MIN } from '../lib/time';

const LATE_MIN = 10;

/**
 * Live trip: map on top, the countdown and the stop ladder below.
 * `map` is the map element (a WebView in the app, an iframe in the web demo, nothing in tests).
 */
export function TripScreen({ view, summary, connection, now, t, tp, onBack, map, error, insetTop = 0 }) {
  if (!view) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.paper }}>
        <BackButton onPress={onBack} top={insetTop} />
        {error ? (
          <View style={s.center}>
            <Text style={[type.body, { textAlign: 'center' }]}>{error.status === 404 ? t('trip.notFound') : t('common.loadFailed')}</Text>
            <Button title={t('trip.back')} variant="secondary" compact onPress={onBack} />
          </View>
        ) : <Loading />}
      </View>
    );
  }
  const { trip } = view;
  const sm = summary;
  const stopName = sm.target.name;
  const mins = sm.etaAt ? minutesUntil(sm.etaAt, now) : null;
  const sched = localToMs(trip.serviceDate, sm.target.scheduledTime);
  const lateBy = sm.etaAt && sched ? Math.round((Date.parse(sm.etaAt) - sched) / MIN) : 0;
  const stale = sm.bus ? !sm.bus.fresh : trip.status === 'active';
  const live = sm.phase === 'coming' || sm.phase === 'atStop';

  let side = null;
  if (sm.stopsAway > 0) side = tp('ride.stopsAway', sm.stopsAway);
  else if (sm.stopsAway === 0) side = t('ride.nextIsYours');

  return (
    <View style={{ flex: 1, backgroundColor: colors.paper }}>
      <View style={s.mapBox}>
        {map}
        <BackButton onPress={onBack} top={insetTop} />
      </View>
      <ScrollView style={s.sheet} contentContainerStyle={s.sheetBody}>
        <View style={s.metaRow}>
          <Text style={s.plate}>{t('trip.bus', { plate: trip.plateNumber })}</Text>
          {trip.status === 'active' ? (
            <View style={s.pill} testID="connection">
              <View style={[s.pillDot, connection === 'live' ? { backgroundColor: colors.ok } : { backgroundColor: colors.lineStrong }]} />
              <Text style={type.label}>{connection === 'live' ? t('trip.live') : t('trip.polling')}</Text>
            </View>
          ) : null}
        </View>
        <Text style={type.label}>{trip.routeName} · {trip.scheduleName}</Text>

        {/* Under a minute, "0 min" would read as "here": say "almost there" instead. */}
        {sm.phase === 'coming' && mins != null && mins >= 1 && !stale ? (
          <View style={s.countRow} testID="trip-countdown">
            <Text style={s.hero}>{mins}</Text>
            <Text style={s.heroUnit}>{t('ride.min')}</Text>
            {side ? <Text style={[type.heading, s.side]}>{side}</Text> : null}
          </View>
        ) : (
          <Text style={[type.display, phaseColor(sm.phase)]} testID="trip-headline">{phaseText(sm, t, tp, stopName, stale ? null : mins)}</Text>
        )}

        {sm.phase === 'coming' && sm.etaAt ? (
          <Text style={type.body}>
            {sm.toSchool
              ? t('ride.beAtStopBy', { stop: stopName, time: fmtTime(Date.parse(sm.etaAt) - 2 * MIN) })
              : t('ride.dropoffAround', { time: fmtTime(sm.etaAt) })}
          </Text>
        ) : null}
        {live && lateBy >= LATE_MIN && !stale ? <Text style={[type.smallStrong, { color: colors.late }]}>{t('ride.runningLate', { min: lateBy })}</Text> : null}
        {trip.status === 'cancelled' && trip.cancelledReason ? <Text style={type.body}>{t('ride.cancelledReason', { reason: trip.cancelledReason })}</Text> : null}

        {trip.status === 'active' && stale ? (
          <Banner tone="late" testID="stale" text={sm.bus ? t('trip.noSignal', { time: fmtTime(sm.bus.recordedAt) }) : t('trip.waitingSignal')} />
        ) : null}

        {live ? (
          <View style={s.ladder}>
            <StopLadder items={sm.ladder} stopsBehind={sm.stopsBehind} busStale={stale} t={t} tp={tp} />
          </View>
        ) : null}

        {trip.status === 'active' && sm.bus ? (
          <Text style={[type.small, { textAlign: 'center' }]} testID="updated">
            {sm.bus.ageMs < 60000
              ? t('trip.updatedSec', { s: Math.max(1, Math.round(sm.bus.ageMs / 1000)) })
              : t('trip.updatedMin', { min: Math.round(sm.bus.ageMs / 60000) })}
          </Text>
        ) : null}
        {!live ? <Button title={t('trip.back')} variant="secondary" onPress={onBack} /> : null}
      </ScrollView>
    </View>
  );
}

function phaseText(sm, t, tp, stop, mins = null) {
  switch (sm.phase) {
    case 'atStop': return t('trip.atStop', { stop });
    case 'passed': return t('trip.passed', { stop });
    case 'skipped': return t('trip.skipped', { stop });
    case 'cancelled': return t('trip.cancelled');
    case 'ended': return t('trip.ended');
    default:
      if (mins != null && mins < 1) return t('ride.nearNow');
      return sm.stopsAway != null ? tp('ride.stopsAway', sm.stopsAway) : t('ride.onTheWay');
  }
}
function phaseColor(phase) {
  if (phase === 'cancelled' || phase === 'skipped') return { color: colors.alert };
  return null;
}

function BackButton({ onPress, top }) {
  return (
    <Pressable accessibilityRole="button" accessibilityLabel="Back" onPress={onPress} testID="back"
      style={({ pressed }) => [s.back, { top: top + space.md }, pressed && { opacity: 0.7 }]}>
      <Text style={s.backGlyph}>‹</Text>
    </Pressable>
  );
}

const s = StyleSheet.create({
  mapBox: { height: '42%', minHeight: 240, backgroundColor: colors.paper, position: 'relative' },
  back: { position: 'absolute', left: space.lg, width: 44, height: 44, borderRadius: 22, backgroundColor: colors.card, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: colors.line, elevation: 3 },
  backGlyph: { fontFamily: fonts.semi, fontSize: 30, lineHeight: 34, color: colors.ink, marginTop: -3 },
  sheet: { flex: 1, marginTop: -radius.lg, backgroundColor: colors.card, borderTopLeftRadius: radius.lg, borderTopRightRadius: radius.lg },
  sheetBody: { padding: space.xl, gap: space.md, paddingBottom: space.xxl },
  metaRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  plate: { fontFamily: fonts.cond, fontSize: 18, color: colors.ink, letterSpacing: 0.5 },
  pill: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: space.sm, paddingVertical: 3, borderRadius: radius.pill, backgroundColor: colors.paper },
  pillDot: { width: 8, height: 8, borderRadius: 4 },
  countRow: { flexDirection: 'row', alignItems: 'flex-end', gap: space.sm, marginTop: space.xs },
  hero: { ...type.hero, fontSize: 72, lineHeight: 72 },
  heroUnit: { fontFamily: fonts.cond, fontSize: 26, lineHeight: 36, color: colors.ink },
  side: { flex: 1, paddingBottom: 8, marginLeft: space.sm },
  ladder: { marginTop: space.md, paddingTop: space.lg, borderTopWidth: 1, borderTopColor: colors.line },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: space.xl, gap: space.lg },
});
