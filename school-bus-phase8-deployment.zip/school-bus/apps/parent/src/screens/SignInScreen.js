import React, { useEffect, useRef, useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Button, Chip, Field, LinkButton } from '../ui/components';
import { DotStrip } from '../ui/RouteDots';
import { colors, fonts, radius, space, type } from '../ui/theme';
import { displayPhone, normalizeKenyanPhone } from '../lib/phone';

const RESEND_S = 60;

/**
 * Two steps: phone number, then the 6-digit SMS code (auto-filled on Android where possible,
 * submitted as soon as 6 digits are in). Errors are the API's codes translated to plain advice.
 */
export function SignInScreen({ t, lang, onLanguage, requestCode, verify, notice, insetTop = 0 }) {
  const [step, setStep] = useState('phone');
  const [raw, setRaw] = useState('');
  const [phone, setPhone] = useState(null);
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const [info, setInfo] = useState(null);
  const [wait, setWait] = useState(0);
  const submitted = useRef('');

  useEffect(() => {
    if (wait <= 0) return undefined;
    const id = setTimeout(() => setWait((w) => w - 1), 1000);
    return () => clearTimeout(id);
  }, [wait]);

  const errText = (e) => t(`err.${e && e.code}`) !== `err.${e && e.code}` ? t(`err.${e.code}`) : t('err.generic');

  async function send() {
    setError(null); setInfo(null);
    if (!normalizeKenyanPhone(raw)) { setError(t('err.invalid_phone')); return; }
    setBusy(true);
    try {
      const p = await requestCode(raw);
      setPhone(p); setStep('code'); setCode(''); setWait(RESEND_S); submitted.current = '';
    } catch (e) { setError(errText(e)); } finally { setBusy(false); }
  }

  async function resend() {
    setError(null); setBusy(true);
    try { await requestCode(phone); setWait(RESEND_S); setInfo(t('otp.sent')); } catch (e) { setError(errText(e)); } finally { setBusy(false); }
  }

  async function submit(c = code) {
    if (c.length !== 6 || submitted.current === c) return;
    submitted.current = c;
    setError(null); setInfo(null); setBusy(true);
    try { await verify(phone, c); } catch (e) { setError(errText(e)); submitted.current = ''; setBusy(false); }
  }

  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: colors.ink }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={[s.wrap, { paddingTop: insetTop + space.lg }]} keyboardShouldPersistTaps="handled">
        <View style={s.langs}>
          <Chip inverse label="English" selected={lang === 'en'} onPress={() => onLanguage('en')} testID="signin-en" />
          <Chip inverse label="Kiswahili" selected={lang === 'sw'} onPress={() => onLanguage('sw')} testID="signin-sw" />
        </View>
        <View style={s.hero}>
          <View style={s.strip}><DotStrip stopsAway={4} inverse /></View>
          <Text style={s.title} accessibilityRole="header">{t('login.title')}</Text>
          <Text style={s.lead}>{step === 'phone' ? t('login.body') : t('otp.body', { phone: displayPhone(phone) })}</Text>
        </View>

        <View style={s.panel}>
          {step === 'phone' ? (
            <>
              <Field
                label={t('login.phone')} value={raw} onChangeText={(v) => { setRaw(v); setError(null); }}
                placeholder={t('login.phonePlaceholder')} keyboardType="phone-pad" autoComplete="tel"
                textContentType="telephoneNumber" maxLength={16} returnKeyType="send" onSubmitEditing={send} testID="phone"
              />
              {error ? <Text style={s.error} testID="signin-error">{error}</Text> : null}
              <Button title={t('login.send')} onPress={send} loading={busy} testID="send-code" />
            </>
          ) : (
            <>
              <Text style={type.title}>{t('otp.title')}</Text>
              <Field
                label={t('otp.code')} value={code} testID="code"
                onChangeText={(v) => { const c = v.replace(/\D/g, '').slice(0, 6); setCode(c); setError(null); if (c.length === 6) submit(c); }}
                keyboardType="number-pad" autoComplete="sms-otp" textContentType="oneTimeCode" maxLength={6} autoFocus
                inputStyle={s.codeInput}
              />
              {error ? <Text style={s.error} testID="signin-error">{error}</Text> : null}
              {info ? <Text style={[type.small, { color: colors.ok }]}>{info}</Text> : null}
              <Button title={t('otp.verify')} onPress={() => submit()} loading={busy} disabled={code.length !== 6} testID="verify" />
              <View style={s.row}>
                {wait > 0
                  ? <Text style={type.small}>{t('otp.resendIn', { s: wait })}</Text>
                  : <LinkButton title={t('otp.resend')} onPress={resend} testID="resend" />}
                <LinkButton title={t('otp.change')} onPress={() => { setStep('phone'); setError(null); setInfo(null); }} testID="change-number" />
              </View>
              <Text style={type.small}>{t('otp.help')}</Text>
            </>
          )}
          {notice === 'expired' && step === 'phone' ? <Text style={type.small} testID="expired">{t('login.expired')}</Text> : null}
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  wrap: { flexGrow: 1, paddingHorizontal: space.xl, paddingBottom: space.xl, gap: space.xl },
  langs: { flexDirection: 'row', gap: space.sm, alignSelf: 'flex-end' },
  hero: { gap: space.md, paddingTop: space.lg },
  strip: { width: 220, marginBottom: space.md },
  title: { fontFamily: fonts.condBold, fontSize: 42, lineHeight: 44, color: colors.onInk },
  lead: { ...type.body, color: colors.onInkMuted, maxWidth: 420 },
  panel: { backgroundColor: colors.card, borderRadius: radius.lg, padding: space.xl, gap: space.lg },
  error: { ...type.small, color: colors.alert },
  codeInput: { fontFamily: fonts.cond, fontSize: 30, letterSpacing: 10, textAlign: 'center' },
  row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: space.md },
});
