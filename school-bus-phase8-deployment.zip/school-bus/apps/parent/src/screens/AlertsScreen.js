import React, { useMemo } from 'react';
import { RefreshControl, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Empty, Loading } from '../ui/components';
import { colors, fonts, space, type } from '../ui/theme';
import { addDays, fmtDay, fmtTime, localParts } from '../lib/time';

const isoDay = (ms) => { const p = localParts(ms); return `${p.y}-${String(p.mo).padStart(2, '0')}-${String(p.d).padStart(2, '0')}`; };

/**
 * Alert history: every alert, however it travelled. Answers "did the school tell me?" and
 * "why didn't I get an SMS?" (failed ones say so).
 */
export function AlertsScreen({ items, error, refreshing, onRefresh, onOpenTrip, t, lang, now }) {
  const groups = useMemo(() => {
    const m = new Map();
    (items || []).forEach((a) => {
      const d = isoDay(Date.parse(a.createdAt));
      if (!m.has(d)) m.set(d, []);
      m.get(d).push(a);
    });
    return [...m.entries()];
  }, [items]);
  const today = isoDay(now);
  const label = (d) => (d === today ? t('alerts.today') : d === addDays(today, -1) ? t('alerts.yesterday') : fmtDay(d, lang));

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: colors.paper }}
      contentContainerStyle={s.body}
      refreshControl={<RefreshControl refreshing={Boolean(refreshing)} onRefresh={onRefresh} tintColor={colors.ink} />}
    >
      <Text style={type.display} accessibilityRole="header">{t('alerts.title')}</Text>
      {items == null && !error ? <Loading /> : null}
      {error && items == null ? <Empty text={t('common.loadFailed')} action={t('common.retry')} onAction={onRefresh} /> : null}
      {items && items.length === 0 ? <Text style={[type.body, { color: colors.muted }]}>{t('alerts.empty')}</Text> : null}
      {groups.map(([day, list]) => (
        <View key={day} style={s.group}>
          <Text style={s.day}>{label(day)}</Text>
          <View style={s.list}>
            {list.map((a, i) => (
              <View key={a.id} style={[s.row, i > 0 && s.rowBorder]} testID={`alert-${a.id}`}>
                <Text style={s.time}>{fmtTime(a.createdAt)}</Text>
                <View style={{ flex: 1, gap: 4 }}>
                  <Text style={[type.body, a.isCritical && { color: colors.alert }]}>{a.body}</Text>
                  <View style={s.meta}>
                    {a.channels.map((c) => <Text key={c} style={s.via}>{t(`alerts.via.${c}`)}</Text>)}
                    {a.status === 'failed' ? <Text style={[type.label, { color: colors.alert }]}>{t('alerts.failed')}</Text> : null}
                    {a.status === 'queued' ? <Text style={type.label}>{t('alerts.queued')}</Text> : null}
                  </View>
                </View>
              </View>
            ))}
          </View>
        </View>
      ))}
    </ScrollView>
  );
}

const s = StyleSheet.create({
  body: { padding: space.xl, gap: space.lg, paddingBottom: space.xxl },
  group: { gap: space.sm },
  day: { fontFamily: fonts.cond, fontSize: 20, color: colors.ink },
  list: { backgroundColor: colors.card, borderRadius: 14, borderWidth: 1, borderColor: colors.line },
  row: { flexDirection: 'row', gap: space.md, padding: space.lg },
  rowBorder: { borderTopWidth: 1, borderTopColor: colors.line },
  time: { fontFamily: fonts.cond, fontSize: 17, color: colors.muted, width: 64, paddingTop: 1 },
  meta: { flexDirection: 'row', gap: space.sm, alignItems: 'center' },
  via: { fontFamily: fonts.medium, fontSize: 12, color: colors.ink, borderWidth: 1, borderColor: colors.lineStrong, borderRadius: 6, paddingHorizontal: 6, paddingVertical: 1 },
});
