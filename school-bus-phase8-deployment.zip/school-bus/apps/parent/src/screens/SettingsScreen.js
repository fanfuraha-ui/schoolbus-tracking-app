import React from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { Button, Chip, Choice, LinkButton, Section } from '../ui/components';
import { colors, space, type } from '../ui/theme';
import { displayPhone } from '../lib/phone';
import { fmtClock } from '../lib/time';

const CHANNELS = ['push_then_sms', 'push', 'sms'];
const QUIET_PRESETS = [null, { start: '21:00', end: '05:30' }, { start: '20:00', end: '06:00' }, { start: '22:00', end: '05:00' }];

/** Alert channel, language, quiet hours, app notifications, account. */
export function SettingsScreen({
  profile, school, pushState, platform, appVersion, t, lang,
  onChannel, onLanguage, onQuiet, onEnablePush, onOpenPhoneSettings, onCall, onPrivacy, onSignOut,
}) {
  const quiet = profile.quietHoursStart ? { start: profile.quietHoursStart.slice(0, 5), end: profile.quietHoursEnd.slice(0, 5) } : null;
  const quietLabel = (q) => (q ? t('settings.quietOn', { from: fmtClock(q.start), to: fmtClock(q.end) }) : t('settings.quietOff'));
  const sameQuiet = (a, b) => (!a && !b) || (a && b && a.start === b.start && a.end === b.end);
  const presets = QUIET_PRESETS.some((p) => sameQuiet(p, quiet)) ? QUIET_PRESETS : [...QUIET_PRESETS, quiet];

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.paper }} contentContainerStyle={s.body}>
      <Text style={type.display} accessibilityRole="header">{t('settings.title')}</Text>

      <Section title={t('settings.channel')} hint={t('settings.channelHelp')}>
        {CHANNELS.map((c, i) => (
          <View key={c} style={i > 0 && s.divider}>
            <Choice
              label={t(`settings.channel.${c}`)} selected={profile.channelMode === c} onPress={() => onChannel(c)}
              badge={c === 'push_then_sms' ? t('settings.recommended') : null} testID={`channel-${c}`}
            />
          </View>
        ))}
      </Section>

      <Section title={t('settings.push')}>
        <View style={s.pad}>
          {pushState === 'granted' ? <Text style={type.body}>{t('settings.pushOn')}</Text> : null}
          {pushState === 'unsupported' ? <Text style={type.body}>{platform === 'ios' ? t('settings.pushIos') : t('settings.pushOff')}</Text> : null}
          {pushState === 'undetermined' || pushState === 'denied' ? (
            <>
              <Text style={type.body}>{t('settings.pushOff')}</Text>
              <Button title={t('settings.pushTurnOn')} compact variant="secondary" onPress={onEnablePush} testID="push-on" />
            </>
          ) : null}
          {pushState === 'blocked' ? (
            <>
              <Text style={type.body}>{t('settings.pushBlocked')}</Text>
              <Button title={t('settings.openPhoneSettings')} compact variant="secondary" onPress={onOpenPhoneSettings} />
            </>
          ) : null}
        </View>
      </Section>

      <Section title={t('settings.language')} hint={t('settings.languageHelp')}>
        <View style={[s.pad, s.chips]}>
          <Chip label="English" selected={lang === 'en'} onPress={() => onLanguage('en')} testID="lang-en" />
          <Chip label="Kiswahili" selected={lang === 'sw'} onPress={() => onLanguage('sw')} testID="lang-sw" />
        </View>
      </Section>

      <Section title={t('settings.quiet')} hint={t('settings.quietHelp')}>
        <View style={[s.pad, s.chips]}>
          {presets.map((q) => (
            <Chip key={q ? `${q.start}-${q.end}` : 'off'} label={quietLabel(q)} selected={sameQuiet(q, quiet)} onPress={() => onQuiet(q)} testID={`quiet-${q ? q.start : 'off'}`} />
          ))}
        </View>
      </Section>

      <View style={s.account}>
        <Text style={type.small}>{t('settings.account', { phone: displayPhone(profile.phone) })}</Text>
        {school && school.phone ? <Button title={t('settings.callSchool')} variant="secondary" onPress={onCall} testID="call-school" /> : null}
        <LinkButton title={t('settings.privacy')} onPress={onPrivacy} testID="privacy" />
        <Button title={t('settings.signOut')} variant="danger" onPress={onSignOut} testID="sign-out" />
        <Text style={[type.label, { textAlign: 'center' }]}>{t('settings.version', { v: appVersion })}</Text>
      </View>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  body: { padding: space.xl, gap: space.xl, paddingBottom: space.xxl },
  divider: { borderTopWidth: 1, borderTopColor: colors.line },
  pad: { padding: space.lg, gap: space.md },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: space.sm },
  account: { gap: space.md },
});
