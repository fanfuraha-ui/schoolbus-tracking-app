import React from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { Button } from '../ui/components';
import { colors, fonts, radius, space, type } from '../ui/theme';

const POINTS = ['consent.p1', 'consent.p2', 'consent.p3', 'consent.p4', 'consent.p5'];

/**
 * Privacy notice, shown once at first sign-in (and from Settings, read-only).
 * Plain statements of what happens, so "I agree" is informed consent under the Kenya Data
 * Protection Act 2019 rather than a wall of legal text.
 */
export function ConsentScreen({ t, schoolName, onAccept, onDecline, busy, readOnly = false, onClose, insetTop = 0 }) {
  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.paper }} contentContainerStyle={[s.body, { paddingTop: insetTop + space.xl }]}>
      <Text style={type.display} accessibilityRole="header">{t('consent.title')}</Text>
      <Text style={type.body}>{t('consent.intro', { school: schoolName || t('appName') })}</Text>
      <View style={s.list}>
        {POINTS.map((k) => (
          <View key={k} style={s.point}>
            <View style={s.bullet} />
            <Text style={[type.body, { flex: 1 }]}>{t(k)}</Text>
          </View>
        ))}
      </View>
      {readOnly ? (
        <Button title={t('common.close')} variant="secondary" onPress={onClose} />
      ) : (
        <View style={{ gap: space.md }}>
          <Button title={t('consent.accept')} onPress={onAccept} loading={busy} testID="consent-accept" />
          <Button title={t('consent.decline')} variant="ghost" onPress={onDecline} testID="consent-decline" />
          <Text style={[type.small, { textAlign: 'center' }]}>{t('consent.declineNote')}</Text>
        </View>
      )}
    </ScrollView>
  );
}

/** Asked once, after the first Today screen loads: why, then the system prompt. */
export function PushPrimer({ t, onAllow, onLater }) {
  return (
    <View style={s.primer} testID="push-primer">
      <Text style={type.title}>{t('push.title')}</Text>
      <Text style={type.body}>{t('push.body')}</Text>
      <Button title={t('push.allow')} onPress={onAllow} testID="push-allow" />
      <Button title={t('push.later')} variant="ghost" onPress={onLater} testID="push-later" />
    </View>
  );
}

const s = StyleSheet.create({
  body: { padding: space.xl, gap: space.lg, paddingBottom: space.xxl },
  list: { backgroundColor: colors.card, borderRadius: radius.md, borderWidth: 1, borderColor: colors.line, padding: space.lg, gap: space.lg },
  point: { flexDirection: 'row', gap: space.md, alignItems: 'flex-start' },
  bullet: { width: 10, height: 10, borderRadius: 5, borderWidth: 2.5, borderColor: colors.ink, marginTop: 6 },
  primer: { gap: space.md },
  mono: { fontFamily: fonts.body },
});
