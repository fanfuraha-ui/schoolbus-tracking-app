import React from 'react';
import { RefreshControl, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Banner, Button, Card, Empty, LinkButton } from '../ui/components';
import { DotStrip } from '../ui/RouteDots';
import { colors, fonts, space, tone as tones, type } from '../ui/theme';
import { describeRide, rideRank } from '../live/rideStatus';
import { fmtDay, fmtTime, partOfDay } from '../lib/time';

/**
 * Today: one block per child, one card per ride. The card answers the parent's real question
 * in one line ("8 min · 3 stops before yours"), then the next useful thing ("Be at the stop by").
 */
export function TodayScreen({
  overview, now, t, tp, lang, offlineSince, refreshing, onRefresh,
  pushState, onEnablePush, onTrack, onMarkAbsent, onUndoAbsent, busyKey,
}) {
  const first = (overview.profile.fullName || '').split(' ')[0];
  const pushOff = pushState === 'denied' || pushState === 'undetermined' || pushState === 'blocked';
  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: colors.paper }}
      contentContainerStyle={{ paddingBottom: space.xxl }}
      refreshControl={<RefreshControl refreshing={Boolean(refreshing)} onRefresh={onRefresh} tintColor={colors.ink} />}
    >
      <View style={s.header}>
        <Text style={s.greeting} accessibilityRole="header">{t(`today.greeting.${partOfDay(now)}`, { name: first })}</Text>
        <Text style={s.date}>{fmtDay(overview.serviceDate, lang)}</Text>
      </View>
      <View style={s.body}>
        {offlineSince ? <Banner tone="late" testID="offline" text={t('common.offline', { time: fmtTime(offlineSince) })} /> : null}
        {pushOff ? <Banner tone="quiet" testID="push-off" text={t('today.pushOff')} action={t('today.pushOffAction')} onAction={onEnablePush} /> : null}
        {overview.children.length === 0 ? <Empty text={t('today.noChildren')} /> : null}
        {overview.children.map((child) => (
          <ChildBlock
            key={child.id} child={child} now={now} t={t} tp={tp} serviceDate={overview.serviceDate}
            onTrack={onTrack} onMarkAbsent={onMarkAbsent} onUndoAbsent={onUndoAbsent} busyKey={busyKey}
          />
        ))}
      </View>
    </ScrollView>
  );
}

function ChildBlock({ child, now, t, tp, serviceDate, onTrack, onMarkAbsent, onUndoAbsent, busyKey }) {
  const first = child.fullName.split(' ')[0];
  const rides = [...child.today].sort((a, b) => rideRank(a) - rideRank(b) || a.startTime.localeCompare(b.startTime));
  return (
    <View style={s.child} testID={`child-${child.id}`}>
      <View style={s.childHead}>
        <Text style={type.title}>{child.fullName}</Text>
        {child.className ? <Text style={type.small}>{child.className}</Text> : null}
      </View>
      {rides.length === 0 ? <Text style={type.small}>{t('today.noRides', { name: first })}</Text> : null}
      {rides.map((ride) => (
        <RideCard
          key={ride.scheduleId} ride={ride} child={child} now={now} t={t} tp={tp} serviceDate={serviceDate}
          busy={busyKey === `${child.id}:${ride.scheduleId}`}
          onTrack={() => onTrack(ride.tripId)}
          onMarkAbsent={() => onMarkAbsent(child, ride)}
          onUndoAbsent={() => onUndoAbsent(child, ride)}
        />
      ))}
    </View>
  );
}

export function RideCard({ ride, child, now, t, tp, serviceDate, onTrack, onMarkAbsent, onUndoAbsent, busy }) {
  const st = describeRide(ride, { now, serviceDate, childName: child.fullName.split(' ')[0] });
  const tn = tones[st.tone];
  const live = st.canTrack;
  const say = (m) => (m ? t(m.key, m.vars) : null);
  const headline = say(st.headline);
  const meta = [t(`today.dir.${ride.direction}`), ride.routeName].filter(Boolean).join(' · ');
  const showStrip = live && st.stopsAway != null;
  return (
    <Card accent={live || st.tone === 'alert' ? tn.bar : null} style={[s.ride, !live && s.rideQuiet]}>
      <View style={s.meta}>
        <Text style={type.label} numberOfLines={1}>{meta}</Text>
        {ride.plateNumber ? <Text style={s.plate}>{ride.plateNumber}</Text> : null}
      </View>

      {st.big ? (
        <View style={s.bigRow} testID="countdown">
          <Text style={s.bigNum}>{st.big.minutes}</Text>
          <Text style={s.bigUnit}>{t('ride.min')}</Text>
          <Text style={[type.bodyStrong, s.bigHeadline]} numberOfLines={2}>{say(st.big.side)}</Text>
        </View>
      ) : (
        <Text style={[type.heading, { color: st.tone === 'quiet' ? colors.ink : tn.fg }]} testID="headline">{headline}</Text>
      )}

      {showStrip ? <DotStrip stopsAway={st.stopsAway} stale={st.tone === 'late' && !st.lateNote} testID="dots" /> : null}

      {st.detail ? (
        <Text style={[type.body, (st.tone === 'alert' || (st.tone === 'late' && !st.lateNote)) && { color: tn.fg }]}>{t(st.detail.key, st.detail.vars)}</Text>
      ) : null}
      {st.lateNote ? <Text style={[type.smallStrong, { color: colors.late }]}>{t(st.lateNote.key, st.lateNote.vars)}</Text> : null}
      {!live && !st.detail && ride.stopName && !ride.absent ? <Text style={type.small}>{ride.stopName}</Text> : null}

      {live || st.canMarkAbsent || st.canUndoAbsent ? (
        <View style={s.actions}>
          {live ? <Button title={t('ride.track')} variant="bus" compact onPress={onTrack} testID="track" style={{ flex: 1 }} /> : null}
          {st.canMarkAbsent ? <LinkButton title={t('ride.markAbsent')} onPress={busy ? undefined : onMarkAbsent} testID="mark-absent" /> : null}
          {st.canUndoAbsent ? <LinkButton title={t('ride.undoAbsent')} onPress={busy ? undefined : onUndoAbsent} testID="undo-absent" /> : null}
        </View>
      ) : null}
    </Card>
  );
}

const s = StyleSheet.create({
  header: { backgroundColor: colors.ink, paddingHorizontal: space.xl, paddingTop: space.xl, paddingBottom: space.xl, gap: 2 },
  greeting: { fontFamily: fonts.condBold, fontSize: 30, lineHeight: 34, color: colors.onInk },
  date: { ...type.body, color: colors.onInkMuted },
  body: { paddingHorizontal: space.lg, paddingTop: space.lg, gap: space.lg },
  child: { gap: space.sm },
  childHead: { flexDirection: 'row', alignItems: 'baseline', gap: space.sm, flexWrap: 'wrap', paddingHorizontal: space.xs },
  ride: { gap: space.md, paddingLeft: space.xl },
  rideQuiet: { gap: space.xs, paddingLeft: space.lg },
  meta: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: space.sm },
  plate: { fontFamily: fonts.cond, fontSize: 15, color: colors.ink, letterSpacing: 0.5 },
  bigRow: { flexDirection: 'row', alignItems: 'flex-end', gap: space.sm },
  bigNum: { fontFamily: fonts.condBold, fontSize: 56, lineHeight: 56, color: colors.ink },
  bigUnit: { fontFamily: fonts.cond, fontSize: 22, lineHeight: 30, color: colors.ink },
  bigHeadline: { flex: 1, paddingBottom: 4, marginLeft: space.sm },
  actions: { flexDirection: 'row', alignItems: 'center', gap: space.lg, marginTop: space.xs },
});
