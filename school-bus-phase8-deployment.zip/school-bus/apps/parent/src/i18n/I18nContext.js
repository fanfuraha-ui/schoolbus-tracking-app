import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { translate, plural } from './strings';
import { useServices } from '../services/ServicesContext';

const I18nContext = createContext({ lang: 'en', t: (k, v) => translate('en', k, v), tp: (k, n, v) => translate('en', plural(k, n), { n, ...v }), setLang: () => {} });

/**
 * Language: the server's preferred_language is the truth once signed in (it also picks the SMS
 * language). Before sign-in, the toggle on the sign-in screen is remembered locally and sent to
 * the server right after sign-in.
 */
export function I18nProvider({ children, initialLang }) {
  const { kv } = useServices();
  const [lang, setLangState] = useState(initialLang || 'en');
  useEffect(() => { if (!initialLang) kv.get('lang').then((l) => { if (l === 'en' || l === 'sw') setLangState(l); }); }, [kv, initialLang]);
  const setLang = useCallback((l, { picked = false } = {}) => {
    setLangState(l);
    kv.set('lang', l);
    if (picked) kv.set('langPicked', true);
  }, [kv]);
  const value = useMemo(() => ({
    lang,
    setLang,
    t: (k, v) => translate(lang, k, v),
    tp: (k, n, v) => translate(lang, plural(k, n), { n, ...v }),
  }), [lang, setLang]);
  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export const useI18n = () => useContext(I18nContext);
