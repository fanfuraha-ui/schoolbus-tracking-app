import Constants from 'expo-constants';

const extra = Constants.expoConfig?.extra ?? {};

/** e.g. https://bus.school.ac.ke  (set EXPO_PUBLIC_API_URL at build time, or extra.apiUrl) */
export const API_ORIGIN = (process.env.EXPO_PUBLIC_API_URL || extra.apiUrl || 'http://10.0.2.2:4000').replace(/\/+$/, '');
export const API_URL = `${API_ORIGIN}/api/v1`;
export const APP_VERSION = Constants.expoConfig?.version ?? '0.0.0';
export const MAP_TILES = extra.mapTiles || null;
