import { useEffect, useState } from 'react';
import { AppState } from 'react-native';

/** True while the app is in the foreground. Polling and sockets pause when it isn't. */
export function useAppActive() {
  const [active, setActive] = useState(AppState.currentState ? AppState.currentState === 'active' : true);
  useEffect(() => {
    const sub = AppState.addEventListener('change', (s) => setActive(s === 'active'));
    return () => sub.remove();
  }, []);
  return active;
}

/** Re-render every `ms` (for "updated 12 s ago" and countdowns). */
export function useNow(ms, clock) {
  const [now, setNow] = useState(clock());
  useEffect(() => {
    const id = setInterval(() => setNow(clock()), ms);
    return () => clearInterval(id);
  }, [ms, clock]);
  return now;
}
