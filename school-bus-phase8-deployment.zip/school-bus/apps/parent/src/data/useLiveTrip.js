import { useEffect, useMemo, useRef, useState } from 'react';
import { useServices } from '../services/ServicesContext';
import { applyEvent, summarize } from '../live/tripModel';
import { useAppActive, useNow } from './useAppActive';

const POLL_MS = 15 * 1000;

/**
 * A trip, live. Socket first (the bus moves on the map within a second of the driver's phone
 * reporting it); if the socket can't connect, poll GET /parent/trips/:id every 15 s instead.
 * Both stop when the app goes to the background, and resume (with a fresh fetch) on return.
 *
 * connection: 'connecting' | 'live' | 'polling'
 */
export function useLiveTrip(tripId) {
  const { api, socket, now: clock } = useServices();
  const appActive = useAppActive();
  const now = useNow(5000, clock);
  const [view, setView] = useState(null);
  const [error, setError] = useState(null);
  const [connection, setConnection] = useState('connecting');
  const [watching, setWatching] = useState(true);
  const viewRef = useRef(null);
  viewRef.current = view;

  // First paint over plain HTTP: often faster than a websocket handshake on 3G.
  useEffect(() => {
    let alive = true;
    api.trip(tripId).then((v) => { if (alive) { setView((cur) => cur || v); setError(null); } })
      .catch((e) => { if (alive) setError(e); });
    return () => { alive = false; };
  }, [api, tripId]);

  const active = !view || view.trip.status === 'active';

  useEffect(() => {
    if (!appActive || !active || !watching) return undefined;
    const unwatch = socket.watch(tripId, {
      onView: (v) => { setView(v); setError(null); },
      onEvent: (name, payload) => setView((v) => applyEvent(v, name, payload)),
      onStatus: (s) => setConnection(s === 'live' ? 'live' : s === 'connecting' ? 'connecting' : 'polling'),
      // Not active any more (finished while the screen opened), or not theirs: stop asking.
      onRejected: () => { setWatching(false); setConnection('polling'); },
    });
    return unwatch;
  }, [socket, tripId, appActive, active, watching]);

  useEffect(() => {
    if (!appActive || connection === 'live' || (view && view.trip.status !== 'active')) return undefined;
    const tick = () => api.trip(tripId).then((v) => { setView(v); setError(null); }).catch((e) => { if (!viewRef.current) setError(e); });
    const id = setInterval(tick, POLL_MS);
    return () => clearInterval(id);
  }, [api, tripId, appActive, connection, view]);

  const summary = useMemo(() => (view ? summarize(view, now) : null), [view, now]);
  return { view, summary, error, connection, now };
}
