import { useCallback, useEffect, useRef, useState } from 'react';
import { useServices } from '../services/ServicesContext';
import { useI18n } from '../i18n/I18nContext';
import { useAppActive } from './useAppActive';

const LIVE_MS = 20 * 1000;   // a bus is on the road for one of the children
const IDLE_MS = 2 * 60 * 1000;

/**
 * Today's overview (GET /parent/me), cached on the phone so the screen opens instantly and still
 * shows the last known state with no connection. Refreshes on an interval while the screen is
 * focused and the app is open: faster while any bus is on the road.
 */
export function useOverview({ focused = true } = {}) {
  const { api, kv, now } = useServices();
  const { lang, setLang } = useI18n();
  const appActive = useAppActive();
  const [state, setState] = useState({ data: null, fetchedAt: null, error: null, loading: true, refreshing: false, offline: false });
  const langRef = useRef(lang);
  langRef.current = lang;

  const refresh = useCallback(async ({ pull = false } = {}) => {
    if (pull) setState((s) => ({ ...s, refreshing: true }));
    try {
      const data = await api.me();
      const fetchedAt = now();
      setState({ data, fetchedAt, error: null, loading: false, refreshing: false, offline: false });
      kv.set('overview', { data, fetchedAt });
      const serverLang = data.profile && data.profile.preferredLanguage;
      if ((serverLang === 'en' || serverLang === 'sw') && serverLang !== langRef.current) setLang(serverLang);
    } catch (error) {
      setState((s) => ({ ...s, error, loading: false, refreshing: false, offline: Boolean(s.data) }));
    }
  }, [api, kv, now, setLang]);

  useEffect(() => {
    let alive = true;
    kv.get('overview').then((cached) => {
      if (alive && cached && cached.data) setState((s) => (s.data ? s : { ...s, data: cached.data, fetchedAt: cached.fetchedAt, loading: false }));
    });
    refresh();
    return () => { alive = false; };
  }, [kv, refresh]);

  const anyLive = Boolean(state.data && state.data.children.some((c) => c.today.some((r) => r.tripStatus === 'active')));
  useEffect(() => {
    if (!focused || !appActive) return undefined;
    const id = setInterval(refresh, anyLive ? LIVE_MS : IDLE_MS);
    return () => clearInterval(id);
  }, [focused, appActive, anyLive, refresh]);

  // Coming back to the app or the tab: refresh straight away.
  const wasActive = useRef(appActive && focused);
  useEffect(() => {
    const isActive = appActive && focused;
    if (isActive && !wasActive.current) refresh();
    wasActive.current = isActive;
  }, [appActive, focused, refresh]);

  /** Optimistic change to one ride (e.g. "not riding") while the request is in flight. */
  const patchRide = useCallback((studentId, scheduleId, patch) => {
    setState((s) => (!s.data ? s : {
      ...s,
      data: {
        ...s.data,
        children: s.data.children.map((c) => (c.id !== studentId ? c : {
          ...c, today: c.today.map((r) => (scheduleId && r.scheduleId !== scheduleId ? r : { ...r, ...patch })),
        })),
      },
    }));
  }, []);

  return { ...state, refresh, patchRide };
}
