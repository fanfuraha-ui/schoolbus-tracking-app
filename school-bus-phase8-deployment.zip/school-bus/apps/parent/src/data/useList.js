import { useCallback, useEffect, useState } from 'react';
import { useServices } from '../services/ServicesContext';

/** Loads a list (alerts, absences) and reloads when the screen regains focus. */
export function useList(load, { focused = true } = {}) {
  const services = useServices();
  const [state, setState] = useState({ items: null, error: null, refreshing: false });
  const reload = useCallback(async ({ pull = false } = {}) => {
    if (pull) setState((s) => ({ ...s, refreshing: true }));
    try {
      const items = await load(services.api);
      setState({ items, error: null, refreshing: false });
    } catch (error) {
      setState((s) => ({ ...s, error, refreshing: false }));
    }
  }, [load, services]);
  useEffect(() => { if (focused) reload(); }, [focused, reload]);
  const setItems = useCallback((fn) => setState((s) => ({ ...s, items: fn(s.items || []) })), []);
  return { ...state, reload, setItems };
}
