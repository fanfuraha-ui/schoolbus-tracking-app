import { Platform } from 'react-native';
import * as Notifications from 'expo-notifications';

/**
 * Runs once at startup (imported first in index.js).
 *  - Alerts show as a banner with sound even while the app is open: "bus is 5 minutes away"
 *    matters most exactly when the parent is looking at the phone.
 *  - Android channels must exist before the permission prompt (Android 13+) and must match the
 *    channel_id the API sends (bus_alerts / critical_alerts, see apps/api/src/integrations/fcm.js).
 */
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowBanner: true,
    shouldShowList: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

export const channelsReady = Platform.OS === 'android'
  ? Promise.all([
    Notifications.setNotificationChannelAsync('bus_alerts', {
      name: 'Bus alerts',
      description: 'Bus approaching, arrived, running late',
      importance: Notifications.AndroidImportance.HIGH,
      vibrationPattern: [0, 250, 200, 250],
      lightColor: '#FFB400',
    }),
    Notifications.setNotificationChannelAsync('critical_alerts', {
      name: 'Urgent bus alerts',
      description: 'Cancelled trips and breakdowns',
      importance: Notifications.AndroidImportance.MAX,
      vibrationPattern: [0, 500, 250, 500],
      lightColor: '#C8102E',
    }),
  ]).catch(() => {})
  : Promise.resolve();
