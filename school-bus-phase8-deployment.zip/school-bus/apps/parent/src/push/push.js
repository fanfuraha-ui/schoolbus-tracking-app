import { Linking, Platform } from 'react-native';
import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import { channelsReady } from './handler';

/**
 * Push notifications via Firebase Cloud Messaging (the API sends with FCM HTTP v1).
 *
 * iOS note: the API talks to FCM, and an iOS FCM token needs the Firebase iOS SDK
 * (@react-native-firebase/messaging), which is not in this build. On iPhone the app reports
 * "no push" and parents get SMS (the default push_then_sms falls straight through to SMS).
 *
 * status(): 'granted' | 'undetermined' | 'denied' | 'blocked' | 'unsupported'
 */
export const pushSupported = () => Platform.OS === 'android' && Device.isDevice;

export async function pushStatus() {
  if (!pushSupported()) return 'unsupported';
  const p = await Notifications.getPermissionsAsync();
  if (p.granted) return 'granted';
  if (p.status === 'denied' && !p.canAskAgain) return 'blocked';
  return p.status === 'denied' ? 'denied' : 'undetermined';
}

export async function requestPush() {
  if (!pushSupported()) return 'unsupported';
  await channelsReady;
  const p = await Notifications.requestPermissionsAsync();
  if (p.granted) return 'granted';
  return p.canAskAgain ? 'denied' : 'blocked';
}

/**
 * Tell the API about this install: the FCM token when notifications are allowed, or
 * pushEnabled:false when they aren't (so the server stops sending pushes Android would drop).
 * Called at every app start and when the app returns to the foreground: it is also how a parent
 * who flipped the switch in phone settings gets noticed.
 */
export async function syncPushRegistration({ api, deviceUid, appVersion }) {
  const status = await pushStatus();
  const platform = Platform.OS === 'ios' ? 'ios' : 'android';
  if (status !== 'granted') {
    await api.registerDevice({ deviceUid, platform, appVersion, pushEnabled: false });
    return status;
  }
  const token = await Notifications.getDevicePushTokenAsync();
  await api.registerDevice({ deviceUid, platform, appVersion, pushEnabled: true, fcmToken: String(token.data) });
  return status;
}

/** FCM rotates tokens occasionally; re-register when it does. Returns an unsubscribe function. */
export function onPushTokenChange(cb) {
  const sub = Notifications.addPushTokenListener(cb);
  return () => sub.remove();
}

export const openPhoneSettings = () => Linking.openSettings();
