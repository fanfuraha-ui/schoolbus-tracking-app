import * as SecureStore from 'expo-secure-store';

// Parent tokens never need reading while the phone is locked, so use the strictest class.
const OPTS = { keychainAccessible: SecureStore.WHEN_UNLOCKED_THIS_DEVICE_ONLY };
const TOKENS = 'session_tokens';

let cache; // undefined = not loaded yet

/** Token store for @school-bus/core's API client (cached in memory; persisted in the keystore). */
export const secureTokenStore = {
  async get() {
    if (cache === undefined) {
      const raw = await SecureStore.getItemAsync(TOKENS, OPTS);
      cache = raw ? JSON.parse(raw) : null;
    }
    return cache;
  },
  async set(tokens) {
    cache = tokens;
    await SecureStore.setItemAsync(TOKENS, JSON.stringify(tokens), OPTS);
  },
  async clear() {
    cache = null;
    await SecureStore.deleteItemAsync(TOKENS, OPTS);
  },
};

export const secureKv = {
  getItem: (k) => SecureStore.getItemAsync(k, OPTS),
  setItem: (k, v) => SecureStore.setItemAsync(k, v, OPTS),
};
