import Storage from 'expo-sqlite/kv-store';

/**
 * Small JSON key-value store for non-secret data: the last overview (so Today opens instantly and
 * works offline), language, "already asked about notifications". SecureStore is kept for tokens;
 * it has a ~2 KB value limit on some Android versions, too small for the overview.
 */
export const kv = {
  async get(key) {
    const raw = await Storage.getItem(key);
    if (raw == null) return null;
    try { return JSON.parse(raw); } catch { return null; }
  },
  set: (key, value) => Storage.setItem(key, JSON.stringify(value)),
  del: (key) => Storage.removeItem(key),
};
