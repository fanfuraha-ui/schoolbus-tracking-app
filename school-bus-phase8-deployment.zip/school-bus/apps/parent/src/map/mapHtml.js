'use strict';
/**
 * The HTML page that the trip screen's WebView shows: a Leaflet map with the route, the child's
 * stop and the bus. No Google Maps key or billing; tiles default to OpenStreetMap (set
 * EXPO_PUBLIC_MAP_TILES for a commercial provider before launch, see README).
 *
 * If Leaflet can't load (no data, blocked CDN) the page draws a schematic of the same route in SVG,
 * so the screen never shows a grey box.
 *
 * The app pushes updates with webview.injectJavaScript(`window.__update(${json})`), so the page
 * is built once and the map doesn't reload or lose the user's zoom on every bus movement.
 */
const C = { ink: '#1A2238', bus: '#FFB400', done: '#A9B2C3', line: '#5E6779', mine: '#1A2238', paper: '#EEF1F5' };

function mapHtml({ tiles, attribution } = {}) {
  const TILE = tiles || 'https://tile.openstreetmap.org/{z}/{x}/{y}.png';
  const ATTR = attribution || '&copy; OpenStreetMap contributors';
  return `<!DOCTYPE html><html><head>
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha512-Zcn6bjR/8RZbLEpLIeOwNtzREBAJnUKESxces60Mpoj+2okopSAcSUIUOseddDm0cxnGQzxIR7vJgsLZbdLE3w==" crossorigin="">
<style>
html,body,#map{margin:0;height:100%;background:${C.paper};font-family:sans-serif}
#fallback{display:none;width:100%;height:100%}
.bus{width:30px;height:30px;border-radius:15px;background:${C.bus};border:3px solid ${C.ink};box-shadow:0 0 0 6px rgba(255,180,0,.35);box-sizing:border-box}
.bus.stale{background:#fff;box-shadow:none;border-style:dashed}
.home{width:22px;height:22px;border-radius:11px;background:#fff;border:6px solid ${C.ink};box-sizing:border-box}
.leaflet-control-attribution{font-size:9px}
</style></head><body><div id="map"></div><svg id="fallback" xmlns="http://www.w3.org/2000/svg"></svg>
<!-- Subresource integrity: if the CDN ever served a different file the browser refuses it and the
     schematic fallback below takes over, so a tampered CDN can't run code inside the app. -->
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha512-BwHfrr4c9kmRkLw6iXFdzcdWV/PGkVgiIyIWLLlTSXzWQzxuSg4DiQUCpauz/EWjgk5TYQqX/kvn9pG1NpYfqg==" crossorigin=""></script>
<script>
(function(){
  var C=${JSON.stringify(C)}, map=null, layers=null, busMarker=null, fitted=false, last=null;
  function post(m){ try{ window.ReactNativeWebView && window.ReactNativeWebView.postMessage(JSON.stringify(m)); }catch(e){} }

  function drawLeaflet(d){
    if(!map){
      map=L.map('map',{zoomControl:false,attributionControl:true});
      L.tileLayer(${JSON.stringify(TILE)},{maxZoom:18,attribution:${JSON.stringify(ATTR)}}).addTo(map);
      layers=L.layerGroup().addTo(map);
    }
    layers.clearLayers();
    var pts=d.stops.map(function(s){return [s.lat,s.lng];});
    var doneIdx=-1; d.stops.forEach(function(s,i){ if(s.done) doneIdx=i; });
    if(doneIdx>=0) L.polyline(pts.slice(0,doneIdx+1),{color:C.done,weight:5}).addTo(layers);
    L.polyline(pts.slice(Math.max(0,doneIdx)),{color:C.ink,weight:5}).addTo(layers);
    d.stops.forEach(function(s){
      if(s.mine){ L.marker([s.lat,s.lng],{icon:L.divIcon({className:'',html:'<div class="home"></div>',iconSize:[22,22],iconAnchor:[11,11]}),zIndexOffset:500}).addTo(layers); }
      else L.circleMarker([s.lat,s.lng],{radius:s.school?7:5,color:s.done?C.done:C.ink,weight:3,fillColor:'#fff',fillOpacity:1}).addTo(layers);
    });
    if(d.bus){
      busMarker=L.marker([d.bus.lat,d.bus.lng],{icon:L.divIcon({className:'',html:'<div class="bus'+(d.bus.fresh?'':' stale')+'"></div>',iconSize:[30,30],iconAnchor:[15,15]}),zIndexOffset:1000}).addTo(layers);
    }
    if(!fitted){
      var focus=d.stops.filter(function(s){return s.mine;}).map(function(s){return [s.lat,s.lng];});
      if(d.bus) focus.push([d.bus.lat,d.bus.lng]);
      if(focus.length<2) focus=pts;
      map.fitBounds(L.latLngBounds(focus).pad(0.35)); fitted=true;
    }
  }

  // Schematic fallback: same stops, projected to the box, no tiles.
  function drawSvg(d){
    document.getElementById('map').style.display='none';
    var svg=document.getElementById('fallback'); svg.style.display='block';
    var w=svg.clientWidth||360, h=svg.clientHeight||300, pad=28;
    var all=d.stops.slice(); if(d.bus) all.push(d.bus);
    var lats=all.map(function(p){return p.lat;}), lngs=all.map(function(p){return p.lng;});
    var minA=Math.min.apply(0,lats), maxA=Math.max.apply(0,lats), minO=Math.min.apply(0,lngs), maxO=Math.max.apply(0,lngs);
    var k=Math.cos((minA+maxA)/2*Math.PI/180), sx=(maxO-minO)*k||1e-6, sy=(maxA-minA)||1e-6;
    var s=Math.min((w-2*pad)/sx,(h-2*pad)/sy), ox=(w-sx*s)/2, oy=(h-sy*s)/2;
    function P(p){ return [ox+(p.lng-minO)*k*s, h-(oy+(p.lat-minA)*s)]; }
    var doneIdx=-1; d.stops.forEach(function(st,i){ if(st.done) doneIdx=i; });
    function path(list){ return list.map(function(p,i){ var q=P(p); return (i?'L':'M')+q[0].toFixed(1)+' '+q[1].toFixed(1); }).join(' '); }
    var out='<rect width="100%" height="100%" fill="'+C.paper+'"/>';
    if(doneIdx>=0) out+='<path d="'+path(d.stops.slice(0,doneIdx+1))+'" stroke="'+C.done+'" stroke-width="5" fill="none" stroke-linecap="round" stroke-linejoin="round"/>';
    out+='<path d="'+path(d.stops.slice(Math.max(0,doneIdx)))+'" stroke="'+C.ink+'" stroke-width="5" fill="none" stroke-linecap="round" stroke-linejoin="round"/>';
    d.stops.forEach(function(st){ var q=P(st);
      out+= st.mine ? '<circle cx="'+q[0]+'" cy="'+q[1]+'" r="8" fill="#fff" stroke="'+C.ink+'" stroke-width="6"/>'
                    : '<circle cx="'+q[0]+'" cy="'+q[1]+'" r="'+(st.school?6:4.5)+'" fill="#fff" stroke="'+(st.done?C.done:C.ink)+'" stroke-width="3"/>'; });
    if(d.bus){ var b=P(d.bus);
      out+=(d.bus.fresh?'<circle cx="'+b[0]+'" cy="'+b[1]+'" r="17" fill="'+C.bus+'" opacity=".35"/>':'')+
           '<circle cx="'+b[0]+'" cy="'+b[1]+'" r="12" fill="'+(d.bus.fresh?C.bus:'#fff')+'" stroke="'+C.ink+'" stroke-width="3"'+(d.bus.fresh?'':' stroke-dasharray="4 3"')+'/>'; }
    svg.innerHTML=out;
  }

  window.__update=function(d){
    last=d;
    if(window.L){ try{ drawLeaflet(d); return; }catch(e){} }
    drawSvg(d); post({type:'fallback'});
  };
  window.addEventListener('resize',function(){ if(last && !window.L) drawSvg(last); });
  post({type:'ready', leaflet: !!window.L});
})();
</script></body></html>`;
}

/** What the page needs from the live trip: only coordinates and three flags per stop. */
function mapData(view, summary) {
  const mine = new Set(view.myStops.map((m) => m.stopId));
  const stops = [...view.stops].sort((a, b) => a.sequence - b.sequence)
    .filter((s) => Number.isFinite(s.lat) && Number.isFinite(s.lng))
    .map((s) => ({ lat: s.lat, lng: s.lng, mine: mine.has(s.stopId), school: Boolean(s.isSchool), done: s.status === 'departed' || s.status === 'skipped' }));
  const bus = summary.bus ? { lat: summary.bus.lat, lng: summary.bus.lng, fresh: summary.bus.fresh } : null;
  return { stops, bus };
}

module.exports = { mapHtml, mapData };
