import React, { useEffect, useMemo, useRef, useState } from 'react';
import { StyleSheet, View } from 'react-native';
import { WebView } from 'react-native-webview';
import { mapHtml, mapData } from './mapHtml';
import { colors } from '../ui/theme';

/**
 * Leaflet in a WebView. The page is created once; each bus movement is pushed in with
 * injectJavaScript so the map keeps the parent's zoom and doesn't flash.
 */
export function BusMap({ view, summary, tiles }) {
  const ref = useRef(null);
  const [ready, setReady] = useState(false);
  const html = useMemo(() => mapHtml({ tiles }), [tiles]);
  const data = useMemo(() => (view && summary ? mapData(view, summary) : null), [view, summary]);
  const json = data ? JSON.stringify(data) : null;

  useEffect(() => {
    if (ready && json && ref.current) ref.current.injectJavaScript(`window.__update(${json}); true;`);
  }, [ready, json]);

  return (
    <View style={StyleSheet.absoluteFill}>
      <WebView
        ref={ref}
        originWhitelist={['*']}
        source={{ html }}
        style={{ flex: 1, backgroundColor: colors.paper }}
        onMessage={(e) => {
          try { if (JSON.parse(e.nativeEvent.data).type === 'ready') setReady(true); } catch { /* ignore */ }
        }}
        onLoadEnd={() => setReady(true)}
        javaScriptEnabled
        domStorageEnabled={false}
        setSupportMultipleWindows={false}
        allowsLinkPreview={false}
        overScrollMode="never"
      />
    </View>
  );
}
