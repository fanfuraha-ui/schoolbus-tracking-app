'use strict';
/**
 * Turns one of today's rides (GET /parent/me -> children[].today[]) into what the Today screen
 * says. Pure: no React, no clock of its own (pass `now`), so every case is unit-tested.
 *
 * Returns {
 *   tone:     'live' | 'ok' | 'late' | 'alert' | 'quiet'   (colour of the status line)
 *   headline: { key, vars }       one sentence, the answer to "where is the bus for my child?"
 *   detail:   { key, vars }|null  the next useful thing (when to be at the stop, how late)
 *   big:      { minutes }|null    countdown shown large while the bus is coming
 *   stopsAway: number|null        drives the dot strip
 *   canTrack, canMarkAbsent, canUndoAbsent
 * }
 */
const { localToMs, fmtTime, fmtClock, minutesUntil, MIN } = require('../lib/time');

const STALE_MS = 3 * MIN;     // same rule as the admin dashboard's "No GPS"
const LATE_MIN = 10;          // same threshold as the server's first delay alert
const NEAR_MIN = 5;           // "about 4 min away": stop counting stops, show minutes only
const NOT_STARTED_GRACE_MIN = 10;
const AT_STOP_LEAD_MIN = 2;   // "be at the stop by" = ETA minus this

function describeRide(ride, { now, serviceDate, childName }) {
  const toSchool = ride.direction === 'to_school';
  const stop = ride.stopName;
  const base = {
    tone: 'quiet', headline: null, detail: null, big: null, stopsAway: null,
    canTrack: false, canMarkAbsent: false, canUndoAbsent: false,
  };
  const v = (extra) => ({ stop, name: childName, ...extra });

  if (ride.absent) {
    return { ...base, headline: { key: 'ride.absent', vars: v() }, canUndoAbsent: Boolean(ride.absenceId) && !ride.absentAllDay };
  }
  if (ride.tripStatus === 'cancelled') {
    return {
      ...base, tone: 'alert',
      headline: { key: 'ride.cancelled', vars: v() },
      detail: ride.cancelledReason ? { key: 'ride.cancelledReason', vars: { reason: ride.cancelledReason } } : null,
    };
  }

  if (ride.tripStatus === 'not_started' || ride.tripStatus === 'scheduled') {
    const start = localToMs(serviceDate, ride.startTime);
    const late = start != null && now > start + NOT_STARTED_GRACE_MIN * MIN;
    const stopAt = ride.scheduledTime ? fmtClock(ride.scheduledTime) : null;
    if (start != null && now > start + 3 * 60 * MIN) {
      // A run from earlier in the day that never happened (e.g. half day): say nothing alarming.
      return { ...base, headline: { key: 'ride.didNotRun', vars: v() } };
    }
    if (late) {
      return {
        ...base, tone: 'late', canMarkAbsent: true,
        headline: { key: 'ride.notStartedLate', vars: v({ time: fmtClock(ride.startTime) }) },
        detail: { key: 'ride.notStartedLateHelp', vars: v() },
      };
    }
    return {
      ...base, canMarkAbsent: true,
      headline: { key: 'ride.startsAt', vars: v({ time: fmtClock(ride.startTime) }) },
      detail: stopAt
        ? { key: toSchool ? 'ride.usualPickup' : 'ride.usualDropoff', vars: v({ time: stopAt }) }
        : null,
    };
  }

  if (ride.tripStatus === 'completed') {
    if (ride.childEvent === 'dropped_off') return { ...base, tone: 'ok', headline: { key: 'ride.droppedOff', vars: v({ time: fmtTime(ride.childEventAt) }) } };
    if (ride.childEvent === 'no_show') return { ...base, headline: { key: 'ride.finishedNoShow', vars: v() } };
    if (ride.childEvent === 'boarded') return { ...base, tone: 'ok', headline: { key: toSchool ? 'ride.reachedSchool' : 'ride.finished', vars: v({ time: fmtTime(ride.childEventAt) }) } };
    return { ...base, headline: { key: 'ride.finished', vars: v() } };
  }

  // ---- active trip ----
  const live = { ...base, canTrack: true };
  if (ride.childEvent === 'dropped_off') {
    return { ...live, tone: 'ok', headline: { key: 'ride.droppedOff', vars: v({ time: fmtTime(ride.childEventAt) }) } };
  }
  if (ride.childEvent === 'no_show') {
    return {
      ...live, tone: 'alert',
      headline: { key: 'ride.noShow', vars: v({ time: fmtTime(ride.childEventAt) }) },
      detail: { key: 'ride.noShowHelp', vars: v() },
    };
  }
  if (ride.childEvent === 'boarded' && toSchool) {
    return { ...live, tone: 'ok', headline: { key: 'ride.onBoard', vars: v({ time: fmtTime(ride.childEventAt) }) }, detail: { key: 'ride.headingToSchool', vars: v() } };
  }
  if (ride.stopStatus === 'skipped') {
    return { ...live, tone: 'alert', headline: { key: 'ride.skipped', vars: v() }, detail: { key: 'ride.skippedHelp', vars: v() } };
  }
  if (ride.stopStatus === 'arrived') {
    return { ...live, tone: 'live', headline: { key: 'ride.atStop', vars: v() } };
  }
  if (ride.stopStatus === 'departed') {
    return {
      ...live, tone: toSchool ? 'quiet' : 'ok',
      headline: { key: toSchool ? 'ride.leftStop' : 'ride.leftStopPm', vars: v({ time: fmtTime(ride.arrivedAt) }) },
    };
  }
  if (ride.childEvent === 'boarded' && !toSchool) {
    // Afternoon: on the bus and on the way home. Fall through to the countdown with this headline.
  }

  // Coming to the child's stop.
  const seen = ride.busSeenAt ? Date.parse(ride.busSeenAt) : null;
  const stale = seen == null || now - seen > STALE_MS;
  const etaMs = ride.etaAt ? Date.parse(ride.etaAt) : null;
  const mins = etaMs != null ? minutesUntil(etaMs, now) : null;
  const scheduledMs = localToMs(serviceDate, ride.scheduledTime);
  const lateBy = etaMs != null && scheduledMs != null ? Math.round((etaMs - scheduledMs) / MIN) : 0;
  const stopsAway = typeof ride.stopsAway === 'number' ? ride.stopsAway : null;
  const near = ride.stopStatus === 'approaching' || (mins != null && mins <= NEAR_MIN) || stopsAway === 0;
  const tone = stale ? 'late' : lateBy >= LATE_MIN ? 'late' : 'live';

  let headline;
  if (near && mins != null) headline = { key: mins <= 1 ? 'ride.nearNow' : 'ride.nearMinutes', vars: v({ min: mins }) };
  // No ETA (GPS stale) but nothing left before their stop: "0 stops before yours" reads oddly.
  else if (stopsAway === 0) headline = { key: 'ride.nextIsYours', vars: v() };
  else if (stopsAway != null) headline = { key: stopsAway === 1 ? 'ride.stopsAway.one' : 'ride.stopsAway.other', vars: v({ n: stopsAway }) };
  else headline = { key: 'ride.onTheWay', vars: v() };
  if (ride.childEvent === 'boarded' && !toSchool) headline = { key: 'ride.onBoardPm', vars: v({ time: fmtTime(ride.childEventAt) }) };

  let detail = null;
  if (stale) {
    detail = { key: seen ? 'ride.staleSince' : 'ride.staleNever', vars: v({ time: seen ? fmtTime(seen) : '' }) };
  } else if (etaMs != null && toSchool) {
    detail = { key: 'ride.beAtStopBy', vars: v({ time: fmtTime(etaMs - AT_STOP_LEAD_MIN * MIN) }) };
  } else if (etaMs != null) {
    detail = { key: 'ride.dropoffAround', vars: v({ time: fmtTime(etaMs) }) };
  }
  const lateNote = !stale && lateBy >= LATE_MIN ? { key: 'ride.runningLate', vars: { min: lateBy } } : null;

  // Beside the big countdown the minutes are already said, so the side text says the stops.
  let side;
  if (ride.childEvent === 'boarded' && !toSchool) side = headline;
  else if (stopsAway > 0) side = { key: stopsAway === 1 ? 'ride.stopsAway.one' : 'ride.stopsAway.other', vars: v({ n: stopsAway }) };
  else if (stopsAway === 0) side = { key: 'ride.nextIsYours', vars: v() };
  else side = { key: 'ride.onTheWay', vars: v() };

  return {
    ...live, tone, headline, detail, lateNote,
    // Under a minute the number would read "0 min", which sounds like "here": the headline
    // ("The bus is almost there") says it instead.
    big: mins != null && mins >= 1 && !stale ? { minutes: mins, side } : null,
    stopsAway,
    canMarkAbsent: toSchool,
  };
}

/** Order: anything live first, then upcoming, then done. Stable within each group. */
function rideRank(ride) {
  if (ride.tripStatus === 'active' && !ride.absent) return 0;
  if (ride.tripStatus === 'not_started' || ride.tripStatus === 'scheduled') return 1;
  return 2;
}

module.exports = { describeRide, rideRank, STALE_MS, LATE_MIN };
