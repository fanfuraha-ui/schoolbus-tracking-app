'use strict';
/**
 * Live trip state for the parent's trip screen.
 *
 *  applyEvent(view, event, payload)  merges a Socket.IO event into the view returned by
 *                                   GET /parent/trips/:id (or the trip:watch ack). Pure.
 *  summarize(view, now)             what the screen shows: target stop, stops to go, ETA,
 *                                   the "ladder" of stops between the bus and the child, freshness.
 *
 * Analogy: the view is a printed timetable; events are the station announcer's updates.
 * applyEvent pencils each announcement onto the timetable; summarize reads it back for one family.
 */
const { MIN } = require('../lib/time');

const STALE_MS = 3 * MIN;
const TO_SERVE = new Set(['pending', 'approaching']);

function applyEvent(view, event, payload) {
  if (!view || !payload || (payload.tripId && view.trip && payload.tripId !== view.trip.id)) return view;
  switch (event) {
    case 'bus:location': {
      const prev = view.bus && Date.parse(view.bus.recordedAt);
      const next = Date.parse(payload.recordedAt);
      if (prev && next && next <= prev) return view; // out-of-order delivery
      return {
        ...view,
        bus: { lat: payload.lat, lng: payload.lng, speedMps: payload.speedMps ?? null, headingDeg: payload.headingDeg ?? null, recordedAt: payload.recordedAt },
      };
    }
    case 'trip:stops': {
      const byId = new Map((payload.stops || []).map((s) => [s.stopId, s]));
      if (!byId.size) return view;
      return {
        ...view,
        stops: view.stops.map((s) => {
          const u = byId.get(s.stopId);
          if (!u) return s;
          return { ...s, status: u.status ?? s.status, etaAt: u.etaAt ?? null, arrivedAt: u.arrivedAt ?? s.arrivedAt, departedAt: u.departedAt ?? s.departedAt };
        }),
      };
    }
    case 'trip:ended':
      return {
        ...view,
        bus: null,
        trip: { ...view.trip, status: payload.status || 'completed', cancelledReason: payload.reason ?? view.trip.cancelledReason ?? null },
      };
    default:
      return view;
  }
}

function summarize(view, now) {
  const stops = [...view.stops].sort((a, b) => a.sequence - b.sequence);
  const mine = new Map(view.myStops.map((m) => [m.stopId, m.children]));
  const mineIdx = stops.map((s, i) => (mine.has(s.stopId) ? i : -1)).filter((i) => i >= 0);

  // Target: the child's first stop the bus hasn't finished with; otherwise their last stop.
  let targetIdx = mineIdx.find((i) => TO_SERVE.has(stops[i].status) || stops[i].status === 'arrived');
  if (targetIdx === undefined) targetIdx = mineIdx[mineIdx.length - 1] ?? stops.length - 1;
  const target = stops[targetIdx];

  // Where the bus is: at the arrived stop, or between the last finished stop and the next one.
  const atIdx = stops.findIndex((s) => s.status === 'arrived');
  const nextIdx = stops.findIndex((s) => TO_SERVE.has(s.status));
  const busIdx = atIdx >= 0 ? atIdx : nextIdx; // index of the stop the bus is at / heading to

  const ended = view.trip.status === 'completed' || view.trip.status === 'cancelled';
  const stopsAway = !ended && TO_SERVE.has(target.status)
    ? stops.slice(0, targetIdx).filter((s) => TO_SERVE.has(s.status)).length
    : null;

  let phase;
  if (view.trip.status === 'cancelled') phase = 'cancelled';
  else if (target.status === 'arrived') phase = 'atStop';
  else if (target.status === 'departed') phase = 'passed';
  else if (target.status === 'skipped') phase = 'skipped';
  else if (ended) phase = 'ended';
  else phase = 'coming';

  // The ladder: stops from where the bus is up to the child's stop. Earlier stops are folded
  // into a count so the list stays about the child, not the whole route.
  const from = busIdx >= 0 && busIdx <= targetIdx ? busIdx : Math.min(targetIdx, Math.max(0, busIdx));
  const ladder = stops.slice(from, targetIdx + 1).map((s, i) => ({
    stopId: s.stopId,
    name: s.name,
    isSchool: Boolean(s.isSchool),
    isMine: mine.has(s.stopId),
    children: mine.get(s.stopId) || [],
    state: s.status === 'arrived' ? 'here' : TO_SERVE.has(s.status) ? (from + i === nextIdx ? 'next' : 'upcoming') : s.status,
    etaAt: s.etaAt || null,
    at: s.arrivedAt || null,
    scheduledTime: s.scheduledTime || null,
  }));
  const behind = phase === 'coming' || phase === 'atStop' ? from : null;

  const recorded = view.bus && Date.parse(view.bus.recordedAt);
  const fresh = Boolean(recorded && now - recorded <= STALE_MS);
  const children = mine.get(target.stopId) || [];

  return {
    phase,
    target: { stopId: target.stopId, name: target.name, etaAt: target.etaAt || null, arrivedAt: target.arrivedAt || null, departedAt: target.departedAt || null, scheduledTime: target.scheduledTime || null, children },
    stopsAway,
    etaAt: phase === 'coming' ? target.etaAt || null : null,
    ladder,
    stopsBehind: behind,
    bus: view.bus ? { ...view.bus, fresh, ageMs: recorded ? Math.max(0, now - recorded) : null } : null,
    toSchool: view.trip.direction === 'to_school',
  };
}

module.exports = { applyEvent, summarize, STALE_MS };
