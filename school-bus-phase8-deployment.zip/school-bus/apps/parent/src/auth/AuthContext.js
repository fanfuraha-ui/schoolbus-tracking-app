import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { normalizeKenyanPhone } from '../lib/phone';
import { useServices } from '../services/ServicesContext';
import { useI18n } from '../i18n/I18nContext';

export const CONSENT_VERSION = '2026-11';
const AuthContext = createContext(null);

/**
 * Sign-in state for the parent app.
 *   status: 'loading' | 'signedOut' | 'signedIn'
 *   needsConsent: true until the parent accepts the privacy notice (first sign-in only)
 */
export function AuthProvider({ children }) {
  const services = useServices();
  const { api, tokens, kv } = services;
  const { lang } = useI18n();
  const [state, setState] = useState({ status: 'loading', user: null, needsConsent: false, notice: null });

  useEffect(() => {
    let alive = true;
    (async () => {
      const [t, user, needsConsent] = await Promise.all([tokens.get(), kv.get('user'), kv.get('needsConsent')]);
      if (!alive) return;
      setState({ status: t && user ? 'signedIn' : 'signedOut', user: t && user ? user : null, needsConsent: Boolean(needsConsent), notice: null });
    })();
    // Refresh token rejected (expired after 30 days unused, or revoked) -> back to sign-in.
    const off = services.onSessionExpired(() => {
      kv.del('user'); kv.del('overview');
      setState({ status: 'signedOut', user: null, needsConsent: false, notice: 'expired' });
    });
    return () => { alive = false; off(); };
  }, [services, tokens, kv]);

  /** Returns the normalised phone; throws ApiError-like {code} on failure. */
  const requestCode = useCallback(async (rawPhone) => {
    const phone = normalizeKenyanPhone(rawPhone);
    if (!phone) throw Object.assign(new Error('invalid_phone'), { code: 'invalid_phone' });
    await api.requestOtp(phone);
    return phone;
  }, [api]);

  const verify = useCallback(async (phone, code) => {
    const device = { deviceUid: await services.deviceUid(), platform: services.platform, appVersion: services.appVersion };
    const res = await api.verifyOtp({ phone, code, device });
    await tokens.set({ accessToken: res.accessToken, refreshToken: res.refreshToken });
    const user = { id: res.user.id, fullName: res.user.fullName, phone };
    await kv.set('user', user);
    await kv.set('needsConsent', Boolean(res.consentRequired));
    // The language picked on the sign-in screen becomes the account's (it also sets SMS language).
    if (await kv.get('langPicked')) {
      api.updatePreferences({ preferredLanguage: lang }).catch(() => {});
      kv.del('langPicked');
    }
    setState({ status: 'signedIn', user, needsConsent: Boolean(res.consentRequired), notice: null });
  }, [api, tokens, kv, services, lang]);

  const signOut = useCallback(async (notice = null) => {
    const t = await tokens.get();
    // Logout also detaches this phone's push token on the server.
    if (t) await api.logout(t.refreshToken).catch(() => {});
    await tokens.clear();
    await Promise.all([kv.del('user'), kv.del('overview'), kv.del('needsConsent'), kv.del('pushAsked')]);
    setState({ status: 'signedOut', user: null, needsConsent: false, notice });
  }, [api, tokens, kv]);

  const acceptConsent = useCallback(async () => {
    await api.consent(CONSENT_VERSION);
    await kv.set('needsConsent', false);
    setState((s) => ({ ...s, needsConsent: false }));
  }, [api, kv]);

  const value = useMemo(() => ({ ...state, requestCode, verify, signOut, acceptConsent }), [state, requestCode, verify, signOut, acceptConsent]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export const useAuth = () => useContext(AuthContext);
