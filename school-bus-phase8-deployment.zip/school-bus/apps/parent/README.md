# Parent app (Expo SDK 58 / React Native 0.88)

What a parent needs on a school morning: where the bus is, how long until it reaches their stop, and a way to say "my child isn't riding today". Android first. On iPhone everything works except push, which falls back to SMS (see below).

## Run it
```bash
npm install                      # from the repo root (npm workspaces link @school-bus/core)
cd apps/parent
npm run setup                    # expo install --fix: pins expo-* packages to SDK 58 versions
npm run android                  # dev build on a phone/emulator (push needs a dev build, not Expo Go)
EXPO_PUBLIC_API_URL=http://192.168.1.20:4000 npm start   # real phone on the same Wi-Fi as the API
```
**Sign in locally.** Start the API with `SMS_DRY_RUN=true DEV_LOG_SMS=true` (the `.env.example` default), then sign in as a seeded parent, e.g. `0711 000 004`. The 6-digit code appears in the API log. `DEV_LOG_SMS` is refused in production.

**No phone?** `npm run demo:web` builds `dist-demo/index.html`: the real screens on a simulated morning (code `123456`).

## Screens
| Screen | What it does |
|---|---|
| Sign in | Phone number, then a 6-digit SMS code (auto-submits at 6 digits, resend after 60 s). English / Kiswahili chosen here becomes the SMS language too |
| Privacy notice | Shown once. Says what is collected (no location from the parent's phone), how long it is kept, and who sees it (Kenya Data Protection Act) |
| Today | One card per child per ride: big countdown, "2 stops before yours", "be at the stop by 7:09". Shows boarded / dropped-off from the driver's taps, running-late and no-GPS states, cancellations with the office's reason, **Not riding** with Undo, and a call-the-office button |
| Track the bus | Map (Leaflet in a WebView; falls back to a schematic line if tiles can't load) and a stop ladder with times. Live over Socket.IO while open, polling every 15 s if the socket drops. Closes the connection when you leave |
| Alerts | Every alert the school sent, grouped by day, with how it arrived (app / SMS) and failures shown honestly |
| Not riding | Report a child absent for today or a school day up to 60 days ahead, for one trip or both; remove upcoming ones |
| Settings | App, then SMS / app only / SMS only; app-notification state with a fix-it link; language; quiet hours; sign out (also stops push to this phone) |

## Push notifications
- Firebase Cloud Messaging. Put `google-services.json` in this folder (or an EAS file secret `GOOGLE_SERVICES_JSON`). The API needs `FCM_SERVICE_ACCOUNT` (see `apps/api/.env.example`).
- Android channels `bus_alerts` and `critical_alerts` match what the API sends. Tapping an alert opens that trip.
- The app re-registers on every start and return to the foreground. If the parent has turned notifications off in phone settings it tells the API (`pushEnabled:false`), and their alerts go by SMS instead of silently disappearing.
- **iPhone:** an FCM token on iOS needs `@react-native-firebase/messaging` plus an APNs key. This build leaves that out, so iPhone parents get SMS automatically. Add it when the school has enough iPhone parents to justify the Apple developer account.

## Configuration
| Variable | Where | Meaning |
|---|---|---|
| `EXPO_PUBLIC_API_URL` | `eas.json` per profile | API origin. Must be `https://` for preview/production |
| `EXPO_PUBLIC_MAP_TILES` | build env | Optional tile URL (MapTiler/Stadia). Default: OpenStreetMap, which is fine for a school's ~180 families |
| `EAS_PROJECT_ID` | build env | From `eas init` |
| School phone | Admin dashboard, Settings, "Transport office phone" | Shows the call button; empty hides it |

Change `ke.schoolbus.parent` in `app.config.js` before the first store build. Location permissions are explicitly **blocked**: the app never asks where the parent is.

## Release to Google Play
1. `eas init`; set the production API URL in `eas.json`.
2. `npm run build:store`, then upload the `.aab` to an **internal testing** track.
3. Play Console: Data safety form (phone number + name collected, not shared, encrypted in transit, deletable on request), privacy policy URL, content rating.
4. Invite a few parents as testers, then promote to production.

## Tests
```bash
npm test     # needs the test Postgres used by apps/api (see apps/api/db/README.md)
```
| Test | Covers |
|---|---|
| `logic.test.js` | Ride status wording for every state (coming, near, under a minute, late, stale GPS, boarded, dropped off, cancelled, absent), trip reducer, Nairobi time, phone formats, both languages have every string |
| `render.test.js` | Every screen server-rendered in both languages with realistic data |
| `contract.test.js` | The app's logic and screens against the **real** API services on a real database, including socket events from a really moving bus. The live reducer must equal a fresh GET of the trip, and every request body must pass the API's own validation |
