import React, { useState } from 'react';
import { createRoot } from 'react-dom/client';
import { createMockServer } from './mockServer';
import { DemoApp, buildServices } from './DemoApp';

function Page() {
  const [state, setState] = useState(() => { const mock = createMockServer(); return { mock, services: buildServices(mock), key: 1 }; });
  const [link, setLink] = useState(null);
  window.__demoLink = (url) => { setLink(url); setTimeout(() => setLink(null), 4000); };
  const restart = () => { state.mock.stop(); const mock = createMockServer(); setState((s) => ({ mock, services: buildServices(mock), key: s.key + 1 })); };
  return (
    <div className="page">
      <aside className="notes">
        <h1>Parent app</h1>
        <p>The real app screens, running on a simulated morning at 4× speed. Amina's bus is two stops from her stop. Watch the countdown, open <b>Track the bus</b>, and wait for the alert as it gets close.</p>
        <p>Her brother Baraka is marked not riding this morning. Try <b>Undo</b>, report a day in <b>Not riding</b>, or switch to Kiswahili in <b>Settings</b>.</p>
        <p>To see sign-in: Settings, Sign out. Any Kenyan number works; the code is <b>123456</b>.</p>
        <button type="button" className="restart" onClick={restart} data-testid="restart">Restart the run</button>
        {link ? <p className="link-note">The phone would now open: {link.replace('tel:', 'call ')}</p> : null}
      </aside>
      <div className="phone" data-testid="phone">
        <DemoApp key={state.key} mock={state.mock} services={state.services} />
      </div>
    </div>
  );
}

createRoot(document.getElementById('root')).render(<Page />);
