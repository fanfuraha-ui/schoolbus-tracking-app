/**
 * DEMO ONLY: the parent app's real providers, containers and screens, driven by the mock server
 * instead of the API, with a tiny navigator standing in for expo-router.
 */
import React, { useEffect, useMemo, useState } from 'react';
import { ServicesContext } from '../src/services/ServicesContext';
import { I18nProvider, useI18n } from '../src/i18n/I18nContext';
import { AuthProvider, useAuth } from '../src/auth/AuthContext';
import { ToastProvider, Loading } from '../src/ui/components';
import { TabBar } from '../src/ui/TabBar';
import { colors } from '../src/ui/theme';
import { OverviewProvider } from '../src/features/OverviewContext';
import {
  TodayContainer, TripContainer, AbsencesContainer, AlertsContainer, SettingsContainer,
  SignInContainer, ConsentContainer, PrivacyContainer, PushSync,
} from '../src/features/containers';

const ORDER = ['today', 'alerts', 'absences', 'settings'];

function memoryKv(seed = {}) {
  const m = new Map(Object.entries(seed));
  return { get: async (k) => (m.has(k) ? m.get(k) : null), set: async (k, v) => { m.set(k, v); }, del: async (k) => { m.delete(k); } };
}
function memoryTokens(initial) {
  let t = initial;
  return { get: async () => t, set: async (x) => { t = x; }, clear: async () => { t = null; } };
}

export function buildServices(mock, { signedIn = true } = {}) {
  return {
    api: mock.api,
    tokens: memoryTokens(signedIn ? { accessToken: 'demo', refreshToken: 'demo' } : null),
    kv: memoryKv(signedIn ? { user: { id: mock.db.profile.id, fullName: mock.db.profile.fullName, phone: mock.db.profile.phone } } : {}),
    deviceUid: async () => 'demo-device-0001',
    socket: mock.socket,
    platform: 'android',
    appVersion: '0.7.0',
    mapTiles: null,
    now: mock.now,
    openUrl: (url) => window.__demoLink && window.__demoLink(url),
    push: mock.push,
    onSessionExpired: () => () => {},
  };
}

function SignedIn({ route, setRoute, onStatusBar }) {
  const { t } = useI18n();
  const nav = {
    openTrip: (id) => setRoute((r) => ({ ...r, trip: id })),
    back: () => setRoute((r) => ({ ...r, trip: null, privacy: false })),
    openPrivacy: () => setRoute((r) => ({ ...r, privacy: true })),
  };
  useEffect(() => { onStatusBar(route.trip ? 'map' : route.privacy ? 'paper' : route.tab === 'today' ? 'ink' : 'paper'); }, [route, onStatusBar]);
  let body;
  if (route.trip) body = <TripContainer tripId={route.trip} nav={nav} />;
  else if (route.privacy) body = <PrivacyContainer nav={nav} />;
  else {
    body = (
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minHeight: 0 }}>
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minHeight: 0 }}>
          {route.tab === 'today' ? <TodayContainer nav={nav} /> : null}
          {route.tab === 'alerts' ? <AlertsContainer /> : null}
          {route.tab === 'absences' ? <AbsencesContainer /> : null}
          {route.tab === 'settings' ? <SettingsContainer nav={nav} /> : null}
        </div>
        <TabBar tabs={ORDER.map((key) => ({ key, label: t(`tabs.${key}`) }))} active={route.tab} onPress={(tab) => setRoute({ tab, trip: null, privacy: false })} />
      </div>
    );
  }
  return <><PushSync />{body}</>;
}

function Router({ route, setRoute, onStatusBar }) {
  const { status, needsConsent } = useAuth();
  useEffect(() => { if (status !== 'signedIn') { onStatusBar('ink'); setRoute({ tab: 'today', trip: null, privacy: false }); } }, [status, onStatusBar, setRoute]);
  useEffect(() => { if (status === 'signedIn' && needsConsent) onStatusBar('paper'); }, [status, needsConsent, onStatusBar]);
  if (status === 'loading') return <Loading />;
  if (status === 'signedOut') return <SignInContainer />;
  if (needsConsent) return <ConsentContainer />;
  return <OverviewProvider><SignedIn route={route} setRoute={setRoute} onStatusBar={onStatusBar} /></OverviewProvider>;
}

/** A heads-up notification, drawn like the phone's own (not like the app). */
function HeadsUp({ note, onTap, onClose }) {
  if (!note) return null;
  const sms = note.channel === 'sms';
  return (
    <div className="headsup" role="alert" data-testid="headsup" onClick={onTap}>
      <div className="hu-app">{sms ? 'Messages · GREENFIELD' : 'School Bus · now'}</div>
      <div className="hu-title">{sms ? 'GREENFIELD' : note.title}</div>
      <div className="hu-body">{note.body}</div>
      <button type="button" className="hu-x" aria-label="Dismiss" onClick={(e) => { e.stopPropagation(); onClose(); }}>×</button>
    </div>
  );
}

export function DemoApp({ mock, services }) {
  const [route, setRoute] = useState({ tab: 'today', trip: null, privacy: false });
  const [bar, setBar] = useState('ink');
  const [note, setNote] = useState(null);
  const [clock, setClock] = useState(mock.now());
  useEffect(() => mock.onPush((n) => { setNote(n); setTimeout(() => setNote((cur) => (cur === n ? null : cur)), 9000); }), [mock]);
  useEffect(() => { const id = setInterval(() => setClock(mock.now()), 1000); return () => clearInterval(id); }, [mock]);
  const d = new Date(clock + 3 * 3600000);
  const hhmm = `${d.getUTCHours()}:${String(d.getUTCMinutes()).padStart(2, '0')}`;
  const barBg = bar === 'ink' ? colors.ink : bar === 'map' ? 'rgba(243,245,248,.9)' : colors.paper;
  const barFg = bar === 'ink' ? '#fff' : colors.ink;
  const onStatusBar = useMemo(() => (b) => setBar(b), []);
  return (
    <ServicesContext.Provider value={services}>
      <I18nProvider initialLang="en">
        <AuthProvider>
          <div className="statusbar" style={{ background: barBg, color: barFg }}><span>{hhmm}</span><span className="sb-icons">4G ▮▮▮ 78%</span></div>
          <div className="screen">
            <ToastProvider>
              <Router route={route} setRoute={setRoute} onStatusBar={onStatusBar} />
            </ToastProvider>
          </div>
          <HeadsUp note={note} onClose={() => setNote(null)} onTap={() => { setNote(null); if (note && note.data && note.data.tripId) setRoute((r) => ({ ...r, trip: note.data.tripId, privacy: false })); }} />
        </AuthProvider>
      </I18nProvider>
    </ServicesContext.Provider>
  );
}
