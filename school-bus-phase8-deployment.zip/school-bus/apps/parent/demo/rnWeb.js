/**
 * DEMO/TEST ONLY: a small React Native -> DOM layer, so the parent app's real screens run in a
 * browser (web demo, screenshots) and under server-side rendering (tests). It implements only
 * what this app uses. The phone app itself uses real React Native.
 */
import React, { createContext, forwardRef, useContext, useEffect, useImperativeHandle, useRef, useState } from 'react';

const h = React.createElement;
const PX = new Set(['width', 'height', 'minWidth', 'maxWidth', 'minHeight', 'maxHeight', 'top', 'left', 'right', 'bottom',
  'margin', 'marginTop', 'marginBottom', 'marginLeft', 'marginRight', 'padding', 'paddingTop', 'paddingBottom', 'paddingLeft', 'paddingRight',
  'borderRadius', 'borderTopLeftRadius', 'borderTopRightRadius', 'borderBottomLeftRadius', 'borderBottomRightRadius',
  'borderWidth', 'borderTopWidth', 'borderBottomWidth', 'borderLeftWidth', 'borderRightWidth',
  'fontSize', 'lineHeight', 'gap', 'rowGap', 'columnGap', 'letterSpacing', 'flexBasis']);
const FONTS = {
  Barlow_400Regular: ['Barlow', 400], Barlow_500Medium: ['Barlow', 500], Barlow_600SemiBold: ['Barlow', 600],
  BarlowCondensed_600SemiBold: ['"Barlow Condensed"', 600], BarlowCondensed_700Bold: ['"Barlow Condensed"', 700],
};

export function flatten(style) {
  if (!style) return {};
  if (Array.isArray(style)) return style.reduce((acc, s) => Object.assign(acc, flatten(s)), {});
  return style;
}

function toCss(rn) {
  const css = {};
  const px = (v) => (typeof v === 'number' ? `${v}px` : v);
  for (const [k, v] of Object.entries(rn)) {
    if (v === undefined || v === null) continue;
    switch (k) {
      case 'paddingHorizontal': css.paddingLeft = px(v); css.paddingRight = px(v); break;
      case 'paddingVertical': css.paddingTop = px(v); css.paddingBottom = px(v); break;
      case 'marginHorizontal': css.marginLeft = px(v); css.marginRight = px(v); break;
      case 'marginVertical': css.marginTop = px(v); css.marginBottom = px(v); break;
      case 'flex':
        if (v > 0) { css.flexGrow = v; css.flexShrink = 1; css.flexBasis = '0%'; } else if (v === 0) { css.flexGrow = 0; css.flexShrink = 0; } else { css.flexGrow = 0; css.flexShrink = 1; }
        break;
      case 'fontFamily': { const f = FONTS[v]; if (f) { css.fontFamily = `${f[0]}, system-ui, sans-serif`; css.fontWeight = f[1]; } else css.fontFamily = v; break; }
      case 'transform': css.transform = v.map((t) => Object.entries(t).map(([fn, val]) => `${fn}(${typeof val === 'number' && fn.startsWith('translate') ? `${val}px` : val})`).join(' ')).join(' '); break;
      case 'elevation': if (v) css.boxShadow = `0 ${v}px ${v * 2}px rgba(26,34,56,.18)`; break;
      case 'textDecorationLine': css.textDecoration = v; break;
      case 'shadowColor': case 'shadowOffset': case 'shadowOpacity': case 'shadowRadius': break;
      default: css[k] = PX.has(k) ? px(v) : v;
    }
  }
  const sides = ['', 'Top', 'Bottom', 'Left', 'Right'];
  sides.forEach((sd) => {
    if (rn[`border${sd}Width`] != null) {
      css[`border${sd}Style`] = rn.borderStyle || 'solid';
      if (rn.borderColor == null && rn[`border${sd}Color`] == null) css[`border${sd}Color`] = '#000';
    }
  });
  return css;
}

const VIEW_BASE = { display: 'flex', flexDirection: 'column', alignItems: 'stretch', flexShrink: 0, position: 'relative', boxSizing: 'border-box', minWidth: 0, minHeight: 0, border: '0 solid black', margin: 0, padding: 0 };
const ROLE = { header: 'heading', button: 'button', tab: 'tab', tablist: 'tablist', radio: 'radio' };

function a11y(p) {
  const out = {};
  if (p.testID) out['data-testid'] = p.testID;
  if (p.accessibilityRole && ROLE[p.accessibilityRole]) out.role = ROLE[p.accessibilityRole];
  if (p.accessibilityRole === 'header') out['aria-level'] = 2;
  if (p.accessibilityLabel) out['aria-label'] = p.accessibilityLabel;
  const st = p.accessibilityState || {};
  if (st.selected != null) out['aria-selected'] = String(Boolean(st.selected));
  if (st.checked != null) out['aria-checked'] = String(Boolean(st.checked));
  if (st.disabled) out['aria-disabled'] = 'true';
  if (st.busy) out['aria-busy'] = 'true';
  if (p.accessibilityLiveRegion) out['aria-live'] = p.accessibilityLiveRegion;
  return out;
}

export const View = forwardRef(function View({ style, children, pointerEvents, ...p }, ref) {
  const css = { ...VIEW_BASE, ...toCss(flatten(style)) };
  if (pointerEvents === 'none') css.pointerEvents = 'none';
  return h('div', { ref, style: css, ...a11y(p) }, children);
});

const InText = createContext(false);
export function Text({ style, children, numberOfLines, ...p }) {
  const nested = useContext(InText);
  const css = { ...(nested ? {} : { fontFamily: 'Barlow, system-ui, sans-serif', fontSize: '14px', color: '#000', margin: 0, whiteSpace: 'pre-wrap', overflowWrap: 'break-word', minWidth: 0 }), display: 'inline', ...toCss(flatten(style)) };
  if (numberOfLines) Object.assign(css, { display: '-webkit-box', WebkitLineClamp: numberOfLines, WebkitBoxOrient: 'vertical', overflow: 'hidden' });
  return h(InText.Provider, { value: true }, h('span', { style: css, ...a11y(p) }, children));
}

export function Pressable({ style, children, onPress, disabled, ...p }) {
  const [pressed, setPressed] = useState(false);
  const st = typeof style === 'function' ? style({ pressed }) : style;
  const css = { ...VIEW_BASE, cursor: onPress && !disabled ? 'pointer' : 'default', userSelect: 'none', WebkitTapHighlightColor: 'transparent', ...toCss(flatten(st)) };
  const act = (e) => { if (onPress && !disabled) onPress(e); };
  return h('div', {
    style: css, tabIndex: 0, role: 'button', ...a11y(p),
    onClick: act,
    onKeyDown: (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); act(e); } },
    onPointerDown: () => setPressed(true), onPointerUp: () => setPressed(false), onPointerLeave: () => setPressed(false),
  }, typeof children === 'function' ? children({ pressed }) : children);
}

export const TextInput = forwardRef(function TextInput({ style, value, onChangeText, placeholder, maxLength, keyboardType, autoFocus, onSubmitEditing, onFocus, onBlur, secureTextEntry, editable = true, ...p }, ref) {
  const css = { boxSizing: 'border-box', outline: 'none', border: '0 solid black', background: 'transparent', ...toCss(flatten(style)) };
  const inputMode = keyboardType === 'number-pad' || keyboardType === 'numeric' ? 'numeric' : keyboardType === 'phone-pad' ? 'tel' : undefined;
  return h('input', {
    ref, style: css, value: value ?? '', placeholder, maxLength, inputMode, autoFocus, readOnly: !editable,
    type: secureTextEntry ? 'password' : 'text', autoComplete: p.autoComplete === 'sms-otp' ? 'one-time-code' : p.autoComplete,
    'data-testid': p.testID, 'aria-label': placeholder,
    onChange: (e) => onChangeText && onChangeText(e.target.value),
    onKeyDown: (e) => { if (e.key === 'Enter' && onSubmitEditing) onSubmitEditing(); },
    onFocus, onBlur,
  });
});

export function ScrollView({ style, contentContainerStyle, children, horizontal, testID }) {
  const outer = { ...VIEW_BASE, flexGrow: 1, flexShrink: 1, overflowY: horizontal ? 'hidden' : 'auto', overflowX: horizontal ? 'auto' : 'hidden', ...toCss(flatten(style)) };
  const inner = { ...VIEW_BASE, ...(horizontal ? { flexDirection: 'row' } : {}), ...toCss(flatten(contentContainerStyle)) };
  return h('div', { style: outer, 'data-testid': testID, className: 'rn-scroll' }, h('div', { style: inner }, children));
}

export function ActivityIndicator({ color = '#1A2238', size }) {
  const d = size === 'large' ? 32 : 20;
  return h('div', { role: 'progressbar', style: { width: d, height: d, border: `3px solid ${color}`, borderTopColor: 'transparent', borderRadius: '50%', animation: 'rnspin .8s linear infinite', alignSelf: 'center' } });
}

export function Modal({ visible, children }) {
  if (!visible) return null;
  return h('div', { style: { position: 'fixed', inset: 0, zIndex: 1000, display: 'flex', flexDirection: 'column' }, className: 'rn-modal' }, children);
}

export const RefreshControl = () => null;
export const KeyboardAvoidingView = View;
export const SafeAreaView = View;
export const FlatList = ({ data, renderItem }) => h(React.Fragment, null, data.map((item, index) => h(React.Fragment, { key: index }, renderItem({ item, index }))));
export const Image = ({ source, style }) => h('img', { src: source && source.uri, style: toCss(flatten(style)) });

export const StyleSheet = {
  create: (s) => s,
  flatten,
  absoluteFill: { position: 'absolute', left: 0, right: 0, top: 0, bottom: 0 },
  absoluteFillObject: { position: 'absolute', left: 0, right: 0, top: 0, bottom: 0 },
  hairlineWidth: 1,
};
export const Platform = { OS: 'android', select: (o) => (o.android !== undefined ? o.android : o.default) };
const hasDoc = () => typeof document !== 'undefined';
export const AppState = {
  get currentState() { return hasDoc() && document.visibilityState === 'hidden' ? 'background' : 'active'; },
  addEventListener(_e, fn) {
    if (!hasDoc()) return { remove() {} };
    const l = () => fn(document.visibilityState === 'hidden' ? 'background' : 'active');
    document.addEventListener('visibilitychange', l);
    return { remove: () => document.removeEventListener('visibilitychange', l) };
  },
};
export const Linking = {
  openURL: async (url) => { if (typeof window !== 'undefined' && window.__demoLink) window.__demoLink(url); },
  openSettings: async () => { if (typeof window !== 'undefined' && window.__demoLink) window.__demoLink('app-settings:'); },
};
export const Alert = { alert: () => {} };

// ---- react-native-safe-area-context ----
export const SafeAreaProvider = ({ children }) => children;
export const useSafeAreaInsets = () => ({ top: 0, bottom: 0, left: 0, right: 0 });

// ---- react-native-webview: an iframe with injectJavaScript ----
export const WebView = forwardRef(function WebView({ source, style, onMessage, onLoadEnd }, ref) {
  const frame = useRef(null);
  useImperativeHandle(ref, () => ({
    injectJavaScript: (js) => { try { frame.current && frame.current.contentWindow && frame.current.contentWindow.eval(js); } catch (e) { /* not ready */ } },
  }));
  useEffect(() => {
    const f = frame.current;
    if (!f) return undefined;
    const wire = () => {
      try { f.contentWindow.ReactNativeWebView = { postMessage: (data) => onMessage && onMessage({ nativeEvent: { data } }) }; } catch (e) { /* cross-origin */ }
      if (onLoadEnd) onLoadEnd();
    };
    f.addEventListener('load', wire);
    return () => f.removeEventListener('load', wire);
  }, [onMessage, onLoadEnd]);
  return h('iframe', { ref: frame, srcDoc: source && source.html, title: 'map', style: { border: 0, width: '100%', height: '100%', display: 'block', ...toCss(flatten(style)) } });
});
