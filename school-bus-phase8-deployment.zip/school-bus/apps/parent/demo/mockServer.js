/**
 * DEMO ONLY: an in-browser stand-in for the parent API and socket, with a simulated morning run.
 *
 * Same response shapes as the real API (a test compares them field by field), real alert wording
 * (it uses the API's own templates), and a clock that runs 4x so the bus visibly approaches.
 *
 *   createMockServer({ speed }) -> { api, socket, push, now, onPush(fn), restart() }
 */
import { renderAlert } from '../../api/src/notifications/templates';

const MIN = 60000;
const OFFSET = 3 * 60 * MIN;
const DAY = '2026-11-17';
const local = (hhmm, day = DAY) => { const [h, m, s = 0] = hhmm.split(':').map(Number); const [y, mo, d] = day.split('-').map(Number); return Date.UTC(y, mo - 1, d, h, m, s) - OFFSET; };
const iso = (ms) => new Date(ms).toISOString();
const uuid = (n) => `00000000-0000-4000-8000-${String(n).padStart(12, '0')}`;
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const err = (status, code, message) => Object.assign(new Error(message), { status, code, retryable: status === 0 || status >= 500 });

// Route 2: Kamangu -> Gikambura -> Kikuyu (real place names, made-up stop positions).
const ROUTE2 = [
  ['Kamangu Junction', -1.2236, 36.6290, '06:44'],
  ['Gikambura Market', -1.2281, 36.6335, '06:49'],
  ['Kidfarmaco Stage', -1.2317, 36.6391, '06:54'],
  ['Gitaru Road', -1.2352, 36.6436, '06:59'],
  ['Gikambura Stage 7', -1.2390, 36.6474, '07:02'],
  ['Gikambura Stage 9', -1.2418, 36.6522, '07:05'],
  ['Kikuyu Railway', -1.2442, 36.6578, '07:10'],
  ['Kikuyu Town Stage', -1.2461, 36.6629, '07:15'],
  ['Greenfield Academy', -1.2493, 36.6683, '07:25'],
].map(([name, lat, lng, at], i, all) => ({ stopId: uuid(100 + i), sequence: i + 1, name, lat, lng, isSchool: i === all.length - 1, scheduledTime: `${at}:00` }));
const AMINA_STOP = ROUTE2[5].stopId;
const T0 = local('06:41:30');        // left the depot (1.5 min late)
const LEG = 4.5 * MIN; const DWELL = 0.5 * MIN; // per stop: drive, then wait at the stop
const arriveAt = (i) => T0 + (i + 1) * LEG + i * DWELL;
const leaveAt = (i) => arriveAt(i) + DWELL;
const ENDS = leaveAt(ROUTE2.length - 1);
const SCHOOL = { name: 'Greenfield Academy', phone: '+254720000111' };
const GUARDIAN = uuid(1);
const KIDS = { amina: uuid(11), baraka: uuid(12) };
const TRIP2 = uuid(21); const TRIP5 = uuid(25);
const SCHED = { am2: uuid(31), pm2: uuid(32), am5: uuid(35), pm5: uuid(36) };

export function createMockServer({ speed = 4, startAt = '06:57:00' } = {}) {
  let realStart = Date.now();
  const simStart = local(startAt);
  const now = () => simStart + (Date.now() - realStart) * speed;

  const db = {
    profile: { id: GUARDIAN, fullName: 'Wanjiru Kamau', phone: '+254711000004', channelMode: 'push_then_sms', preferredLanguage: 'en', quietHoursStart: null, quietHoursEnd: null, consentAt: iso(local('06:00', '2026-09-01')), consentVersion: '2026-11' },
    consentGiven: false, // a fresh sign-in in the demo shows the privacy notice
    absences: [],
    notifications: [],
    pushStatus: 'undetermined',
    nextId: 500,
    sentApproach: false,
  };
  const seed = () => {
    db.absences = [
      { id: uuid(401), studentId: KIDS.baraka, fullName: 'Baraka Kamau', serviceDate: DAY, scheduleId: SCHED.am5, reason: 'Clinic visit' },
      { id: uuid(402), studentId: KIDS.amina, fullName: 'Amina Wairimu', serviceDate: '2026-11-20', scheduleId: null, reason: 'Family function' },
    ];
    const al = (n, ev, ctx, at, channels, status = 'sent') => {
      const { body } = renderAlert({ eventType: ev, lang: 'en', plate: 'KDA 102B', stopName: 'Gikambura Stage 9', schoolName: 'Greenfield', children: ['Amina'], direction: 'to_school', ...ctx });
      return { id: uuid(n), eventType: ev, isCritical: ev === 'trip_cancelled', title: null, body, tripId: uuid(900 + n), studentName: ev === 'boarded' || ev === 'dropped_off' ? 'Amina Wairimu' : null, createdAt: iso(at), channels, status };
    };
    const y = (hhmm) => local(hhmm, '2026-11-16');
    db.notifications = [
      al(301, 'dropped_off', { direction: 'from_school' }, y('16:41'), ['sms']),
      al(302, 'approaching', { etaMinutes: 5, direction: 'from_school' }, y('16:35'), ['push']),
      al(303, 'delay', { delayMinutes: 15 }, y('07:02'), [], 'failed'),
      al(304, 'boarded', {}, y('07:08'), ['push']),
      al(305, 'approaching', { etaMinutes: 5 }, y('07:03'), ['push']),
      al(306, 'trip_cancelled', { reasonText: 'Bus service', direction: 'from_school' }, local('11:20', '2026-11-13'), ['push', 'sms']),
    ];
    db.sentApproach = false;
  };
  seed();

  // ---------- simulation ----------
  function busAt(t) {
    const tt = Math.min(Math.max(t, T0), ENDS);
    for (let i = 0; i < ROUTE2.length; i += 1) {
      const a = arriveAt(i); const from = i === 0 ? { lat: -1.2195, lng: 36.6252 } : ROUTE2[i - 1];
      const start = i === 0 ? T0 : leaveAt(i - 1);
      if (tt <= a) { const f = (tt - start) / (a - start); return { lat: from.lat + (ROUTE2[i].lat - from.lat) * f, lng: from.lng + (ROUTE2[i].lng - from.lng) * f, moving: true }; }
      if (tt <= leaveAt(i)) return { lat: ROUTE2[i].lat, lng: ROUTE2[i].lng, moving: false };
    }
    const last = ROUTE2[ROUTE2.length - 1];
    return { lat: last.lat, lng: last.lng, moving: false };
  }
  function stopsAt(t) {
    return ROUTE2.map((s, i) => {
      const a = arriveAt(i); const l = leaveAt(i);
      let status = 'pending';
      if (t >= l) status = 'departed'; else if (t >= a) status = 'arrived'; else if (a - t <= 5 * MIN) status = 'approaching';
      return {
        ...s, status,
        etaAt: status === 'pending' || status === 'approaching' ? iso(a) : null,
        arrivedAt: t >= a ? iso(a) : null,
        departedAt: t >= l ? iso(l) : null,
      };
    });
  }
  const trip2Status = (t) => (t >= ENDS ? 'completed' : 'active');
  const aminaEvent = (t) => (t >= leaveAt(5) ? { childEvent: 'boarded', childEventAt: iso(leaveAt(5) - 15000) } : { childEvent: null, childEventAt: null });

  function tripView(id, t = now()) {
    if (id === TRIP5) {
      return {
        trip: { id, status: 'active', serviceDate: DAY, startedAt: iso(local('06:36')), endedAt: null, cancelledReason: null, scheduleName: 'Morning pickup', direction: 'to_school', routeName: 'Route 5 - Thogoto', plateNumber: 'KDB 505E' },
        bus: null,
        stops: [{ stopId: uuid(501), sequence: 1, name: 'Thogoto Gate', lat: -1.2560, lng: 36.6490, isSchool: false, scheduledTime: '07:00:00', status: 'pending', etaAt: null, arrivedAt: null, departedAt: null },
          { stopId: uuid(502), sequence: 2, name: 'Greenfield Academy', lat: -1.2493, lng: 36.6683, isSchool: true, scheduledTime: '07:25:00', status: 'pending', etaAt: null, arrivedAt: null, departedAt: null }],
        myStops: [{ stopId: uuid(501), children: [{ studentId: KIDS.baraka, fullName: 'Baraka Kamau', event: null }] }],
      };
    }
    if (id !== TRIP2) throw err(404, 'not_found', 'Trip not found');
    const status = trip2Status(t);
    const p = busAt(t);
    const recorded = Math.floor(t / 5000) * 5000; // the driver app reports every 5 s
    return {
      trip: { id, status, serviceDate: DAY, startedAt: iso(T0), endedAt: status === 'completed' ? iso(ENDS) : null, cancelledReason: null, scheduleName: 'Morning pickup', direction: 'to_school', routeName: 'Route 2 - Gikambura', plateNumber: 'KDA 102B' },
      bus: status === 'active' ? { lat: +p.lat.toFixed(6), lng: +p.lng.toFixed(6), speedMps: p.moving ? 9.5 : 0, headingDeg: 120, recordedAt: iso(recorded) } : null,
      stops: stopsAt(t).map(({ stopId, sequence, name, lat, lng, isSchool, scheduledTime, status: st, etaAt, arrivedAt, departedAt }) => ({ stopId, sequence, name, lat, lng, isSchool, scheduledTime, status: st, etaAt, arrivedAt, departedAt })),
      myStops: [{ stopId: AMINA_STOP, children: [{ studentId: KIDS.amina, fullName: 'Amina Wairimu', event: aminaEvent(t).childEvent }] }],
    };
  }

  function overview() {
    const t = now();
    const stops = stopsAt(t);
    const mine = stops[5];
    const absentFor = (studentId, scheduleId) => db.absences.find((a) => a.studentId === studentId && a.serviceDate === DAY && (!a.scheduleId || a.scheduleId === scheduleId));
    const ride = (studentId, scheduleId, extra) => {
      const ab = absentFor(studentId, scheduleId);
      return { studentId, scheduleId, ...extra, absenceId: ab ? ab.id : null, absentAllDay: ab ? !ab.scheduleId : null, absent: Boolean(ab) };
    };
    const t2 = trip2Status(t);
    const pmBase = (studentId, sched, route, plate, stop, stopId, lat, lng, at) => ride(studentId, sched, {
      scheduleName: 'Afternoon drop-off', direction: 'from_school', startTime: '15:40:00', routeName: route, stopId, stopName: stop, landmark: null,
      scheduledTime: at, lat, lng, tripId: null, tripStatus: 'not_started', cancelledReason: null, plateNumber: plate, stopStatus: null, etaAt: null,
      arrivedAt: null, stopsAway: null, busSeenAt: null, childEvent: null, childEventAt: null,
    });
    return {
      profile: { ...db.profile },
      school: SCHOOL,
      serviceDate: DAY,
      children: [
        { id: KIDS.amina, fullName: 'Amina Wairimu', className: 'Grade 3', today: [
          ride(KIDS.amina, SCHED.am2, {
            scheduleName: 'Morning pickup', direction: 'to_school', startTime: '06:40:00', routeName: 'Route 2 - Gikambura', stopId: AMINA_STOP, stopName: mine.name, landmark: 'Opposite the PCEA church',
            scheduledTime: mine.scheduledTime, lat: mine.lat, lng: mine.lng, tripId: TRIP2, tripStatus: t2, cancelledReason: null, plateNumber: 'KDA 102B',
            stopStatus: mine.status, etaAt: mine.etaAt, arrivedAt: mine.arrivedAt,
            stopsAway: t2 === 'active' ? stops.slice(0, 5).filter((s) => s.status === 'pending' || s.status === 'approaching').length : null,
            busSeenAt: t2 === 'active' ? iso(Math.floor(t / 5000) * 5000) : null,
            ...aminaEvent(t),
          }),
          pmBase(KIDS.amina, SCHED.pm2, 'Route 2 - Gikambura', 'KDA 102B', 'Gikambura Stage 9', AMINA_STOP, mine.lat, mine.lng, '16:32:00'),
        ] },
        { id: KIDS.baraka, fullName: 'Baraka Kamau', className: 'Grade 6', today: [
          ride(KIDS.baraka, SCHED.am5, {
            scheduleName: 'Morning pickup', direction: 'to_school', startTime: '06:35:00', routeName: 'Route 5 - Thogoto', stopId: uuid(501), stopName: 'Thogoto Gate', landmark: null,
            scheduledTime: '07:00:00', lat: -1.2560, lng: 36.6490, tripId: TRIP5, tripStatus: 'active', cancelledReason: null, plateNumber: 'KDB 505E',
            stopStatus: 'pending', etaAt: null, arrivedAt: null, stopsAway: 0, busSeenAt: iso(t - 20000), childEvent: null, childEventAt: null,
          }),
          pmBase(KIDS.baraka, SCHED.pm5, 'Route 5 - Thogoto', 'KDB 505E', 'Thogoto Gate', uuid(501), -1.2560, 36.6490, '16:20:00'),
        ] },
      ],
    };
  }

  // ---------- push simulation: the "approaching" alert, as the worker would send it ----------
  const pushListeners = new Set();
  function tick() {
    const t = now();
    const mine = stopsAt(t)[5];
    if (!db.sentApproach && (mine.status === 'approaching' || mine.status === 'arrived') && trip2Status(t) === 'active') {
      db.sentApproach = true;
      const eta = Math.max(1, Math.round((Date.parse(mine.etaAt || iso(t)) - t) / MIN));
      const r = renderAlert({ eventType: 'approaching', lang: db.profile.preferredLanguage, plate: 'KDA 102B', stopName: mine.name, schoolName: 'Greenfield', children: ['Amina'], direction: 'to_school', etaMinutes: eta });
      const viaPush = db.pushStatus === 'granted' && db.profile.channelMode !== 'sms';
      db.notifications.unshift({ id: uuid(db.nextId += 1), eventType: 'approaching', isCritical: false, title: r.title, body: r.body, tripId: TRIP2, studentName: null, createdAt: iso(t), channels: [viaPush ? 'push' : 'sms'], status: 'sent' });
      pushListeners.forEach((fn) => fn({ title: r.title, body: r.body, data: { type: 'approaching', tripId: TRIP2 }, channel: viaPush ? 'push' : 'sms' }));
    }
  }
  const ticker = setInterval(tick, 500);

  // ---------- API ----------
  const lat = () => wait(120 + Math.random() * 180);
  const api = {
    async requestOtp(phone) { await lat(); return { sent: true, expiresInSeconds: 600, _phone: phone }; },
    async verifyOtp({ phone, code }) {
      await lat();
      if (code !== '123456') throw err(401, 'otp_invalid', 'The code is wrong or has expired');
      db.profile.phone = phone;
      return { accessToken: 'demo', refreshToken: 'demo', user: { id: GUARDIAN, role: 'guardian', fullName: db.profile.fullName }, consentRequired: !db.consentGiven };
    },
    async logout() { await lat(); return { ok: true }; },
    async me() { await lat(); return overview(); },
    async updatePreferences(b) {
      await lat();
      if (b.channelMode) db.profile.channelMode = b.channelMode;
      if (b.preferredLanguage) db.profile.preferredLanguage = b.preferredLanguage;
      if (b.quietHours !== undefined) { db.profile.quietHoursStart = b.quietHours ? `${b.quietHours.start}:00` : null; db.profile.quietHoursEnd = b.quietHours ? `${b.quietHours.end}:00` : null; }
      const { channelMode, preferredLanguage, quietHoursStart, quietHoursEnd } = db.profile;
      return { channelMode, preferredLanguage, quietHoursStart, quietHoursEnd };
    },
    async consent(version) { await lat(); db.consentGiven = true; db.profile.consentVersion = version; return { consentAt: iso(now()), consentVersion: version }; },
    async registerDevice() { await lat(); return { deviceId: uuid(9) }; },
    async trip(id) { await lat(); return tripView(id); },
    async absences() { await lat(); return db.absences.filter((a) => a.serviceDate >= DAY).sort((a, b) => a.serviceDate.localeCompare(b.serviceDate)).map((a) => ({ ...a })); },
    async addAbsence({ studentId, date, scheduleId, reason }) {
      await lat();
      if (date < DAY) throw err(400, 'date_in_past', 'Absences can only be reported for today or later');
      if (db.absences.some((a) => a.studentId === studentId && a.serviceDate === date && (a.scheduleId || null) === (scheduleId || null))) throw err(409, 'already_reported', 'This absence has already been reported');
      const a = { id: uuid(db.nextId += 1), studentId, fullName: studentId === KIDS.amina ? 'Amina Wairimu' : 'Baraka Kamau', serviceDate: date, scheduleId: scheduleId || null, reason: reason || null };
      db.absences.push(a);
      return { ...a };
    },
    async removeAbsence(id) { await lat(); const n = db.absences.length; db.absences = db.absences.filter((a) => a.id !== id); if (n === db.absences.length) throw err(404, 'not_found', 'Absence not found'); return { deleted: true }; },
    async notifications(limit = 50) { await lat(); return db.notifications.slice(0, limit).map((n) => ({ ...n })); },
  };

  // ---------- socket ----------
  const socket = {
    watch(tripId, h) {
      let last = null;
      let ended = false;
      const t1 = setTimeout(() => {
        h.onStatus && h.onStatus('live');
        try { last = tripView(tripId); h.onView && h.onView(last); } catch (e) { h.onRejected && h.onRejected({ code: 'forbidden' }); }
      }, 350);
      const iv = setInterval(() => {
        if (!last || ended || tripId !== TRIP2) return;
        const v = tripView(tripId);
        if (v.bus && (!last.bus || v.bus.recordedAt !== last.bus.recordedAt)) h.onEvent && h.onEvent('bus:location', { tripId, busId: uuid(2), ...v.bus });
        const changed = v.stops.filter((s, i) => s.status !== last.stops[i].status || s.etaAt !== last.stops[i].etaAt);
        if (changed.length) h.onEvent && h.onEvent('trip:stops', { tripId, stops: changed.map(({ stopId, status, etaAt, arrivedAt, departedAt }) => ({ stopId, status, etaAt, arrivedAt, departedAt })) });
        if (v.trip.status !== 'active') { ended = true; h.onEvent && h.onEvent('trip:ended', { tripId, status: 'completed' }); }
        last = v;
      }, 1000);
      return () => { clearTimeout(t1); clearInterval(iv); };
    },
    close() {},
    isOpen: () => true,
  };

  const push = {
    status: async () => db.pushStatus,
    request: async () => { await wait(200); db.pushStatus = 'granted'; return 'granted'; },
    sync: async () => api.registerDevice(),
    onTokenChange: () => () => {},
    openSettings: () => {},
  };

  return {
    api, socket, push, now, db,
    onPush(fn) { pushListeners.add(fn); return () => pushListeners.delete(fn); },
    restart() { realStart = Date.now(); seed(); },
    stop() { clearInterval(ticker); },
    ids: { TRIP2, TRIP5, KIDS, SCHED },
    sim: { tripView, overview },
  };
}
