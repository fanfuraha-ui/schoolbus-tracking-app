/**
 * Expo config for the PARENT app (Google Play first; see README for iOS).
 *
 *  - No location permission at all. The parent app only shows where the BUS is. Location
 *    permissions are explicitly blocked so no library can add them and trigger a Play review.
 *  - Push: expo-notifications with Firebase Cloud Messaging. Put google-services.json in this
 *    folder, or upload it as an EAS file secret named GOOGLE_SERVICES_JSON.
 *  - EXPO_PUBLIC_API_URL per build profile (eas.json). Production MUST be https://.
 *  - Change the package id to your school's domain before the first store build.
 */
const API_URL = process.env.EXPO_PUBLIC_API_URL || 'http://10.0.2.2:4000';

module.exports = ({ config }) => ({
  ...config,
  name: process.env.EXPO_PUBLIC_APP_NAME || 'School Bus',
  slug: 'school-bus-parent',
  scheme: 'schoolbus',
  version: '0.7.0',
  orientation: 'portrait',
  userInterfaceStyle: 'light',
  icon: './assets/icon.png',
  ios: {
    bundleIdentifier: 'ke.schoolbus.parent',
    supportsTablet: false,
  },
  android: {
    package: 'ke.schoolbus.parent',
    adaptiveIcon: { foregroundImage: './assets/adaptive-icon.png', backgroundColor: '#1A2238' },
    googleServicesFile: process.env.GOOGLE_SERVICES_JSON || './google-services.json',
    permissions: ['POST_NOTIFICATIONS', 'VIBRATE'],
    blockedPermissions: [
      'android.permission.ACCESS_FINE_LOCATION',
      'android.permission.ACCESS_COARSE_LOCATION',
      'android.permission.ACCESS_BACKGROUND_LOCATION',
      'android.permission.RECORD_AUDIO',
    ],
  },
  plugins: [
    'expo-router',
    'expo-secure-store',
    'expo-sqlite',
    'expo-font',
    ['expo-notifications', { color: '#1A2238', defaultChannel: 'bus_alerts' }],
    ['expo-splash-screen', { backgroundColor: '#1A2238', image: './assets/splash-mark.png', imageWidth: 200 }],
  ],
  extra: {
    apiUrl: API_URL,
    mapTiles: process.env.EXPO_PUBLIC_MAP_TILES || null,
    schoolPhone: process.env.EXPO_PUBLIC_SCHOOL_PHONE || null,
    eas: process.env.EAS_PROJECT_ID ? { projectId: process.env.EAS_PROJECT_ID } : undefined,
  },
});
