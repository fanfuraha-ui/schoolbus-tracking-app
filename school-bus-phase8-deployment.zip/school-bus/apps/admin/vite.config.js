import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

// @school-bus/core is a CommonJS workspace package: pre-bundle it so Vite can import it.
export default defineConfig({
  plugins: [react(), tailwindcss()],
  optimizeDeps: { include: ['@school-bus/core'] },
  build: { commonjsOptions: { include: [/packages[\\/]core/, /node_modules/] } },
  server: { port: 5173 },
});
