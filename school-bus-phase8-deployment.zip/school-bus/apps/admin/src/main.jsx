import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import App from './App.jsx';
import { createBrowserApi } from './lib/api.jsx';
import { connectFleetSocket } from './lib/realtime.js';

if (import.meta.env.MODE === 'demo') {
  // npm run demo: simulated backend, buses moving, nothing to install or seed.
  import('./demo/demoMain.jsx').then((m) => m.startDemo());
} else {
  const origin = (import.meta.env.VITE_API_ORIGIN || window.location.origin).replace(/\/+$/, '');
  const expiredListeners = new Set();
  const api = createBrowserApi({ origin, onSessionExpired: () => expiredListeners.forEach((cb) => cb()) });
  const sessionExpiredSignal = (cb) => { expiredListeners.add(cb); return () => expiredListeners.delete(cb); };
  const connectRealtime = (handlers) => connectFleetSocket({ origin, getToken: api.accessToken, refresh: api.refresh, handlers });

  createRoot(document.getElementById('root')).render(
    <React.StrictMode>
      <App api={api} connectRealtime={connectRealtime} sessionExpiredSignal={sessionExpiredSignal}
        schoolName={import.meta.env.VITE_SCHOOL_NAME || 'School bus office'} />
    </React.StrictMode>,
  );
}
