import React from 'react';
import { createRoot } from 'react-dom/client';
import App from '../App.jsx';
import { createMockServer } from './mockServer.js';

/** Demo: the whole dashboard on a simulated backend (no API needed). Password: demo */
/** Some embedded viewers block localStorage; fall back to memory so the demo still runs. */
function ensureStorage() {
  try {
    window.localStorage.setItem('__probe', '1');
    window.localStorage.removeItem('__probe');
  } catch {
    const m = new Map();
    const mem = { getItem: (k) => (m.has(k) ? m.get(k) : null), setItem: (k, v) => m.set(k, String(v)), removeItem: (k) => m.delete(k), clear: () => m.clear() };
    try { Object.defineProperty(window, 'localStorage', { value: mem, configurable: true }); } catch { /* nothing else to do */ }
  }
}

export function startDemo(rootEl = document.getElementById('root')) {
  ensureStorage();
  const server = createMockServer();
  if (!localStorage.getItem('schoolbus.admin.user')) {
    localStorage.setItem('schoolbus.admin.user', JSON.stringify({ id: 'admin-1', role: 'admin', fullName: 'Lucy Wairimu' }));
  }
  createRoot(rootEl).render(
    <App api={server.api} connectRealtime={server.connectRealtime} schoolName="Greenfield Academy"
      loginHint="Demo: use any email and the password demo." />,
  );
  return server;
}
