import React, { useState } from 'react';
import { Link, useLocation } from './lib/router.jsx';
import { useAuth } from './lib/auth.jsx';
import { useRealtime } from './lib/realtimeContext.jsx';
import { Icon } from './ui/icons.jsx';
import { cx } from './ui/kit.jsx';

export const NAV = [
  { group: 'Today', items: [
    { to: '/', label: 'Live', icon: 'live' },
    { to: '/trips', label: 'Trips', icon: 'trips' },
    { to: '/issues', label: 'Issues', icon: 'issues' },
    { to: '/alerts', label: 'Parent alerts', icon: 'alerts' },
  ] },
  { group: 'School', items: [
    { to: '/students', label: 'Students', icon: 'students' },
    { to: '/parents', label: 'Parents', icon: 'parents' },
    { to: '/drivers', label: 'Drivers', icon: 'drivers' },
    { to: '/routes', label: 'Routes and stops', icon: 'routes' },
    { to: '/buses', label: 'Buses', icon: 'buses' },
    { to: '/calendar', label: 'School calendar', icon: 'calendar' },
  ] },
  { group: 'Office', items: [
    { to: '/reports', label: 'Reports', icon: 'reports' },
    { to: '/settings', label: 'Settings', icon: 'settings' },
    { to: '/activity', label: 'Activity log', icon: 'activity' },
  ] },
];

export function Shell({ schoolName = 'School bus office', children }) {
  const { path } = useLocation();
  const { user, logout } = useAuth();
  const { online } = useRealtime();
  const [open, setOpen] = useState(false);
  const active = (to) => (to === '/' ? path === '/' : path === to || path.startsWith(`${to}/`));

  return (
    <div className="min-h-screen lg:grid lg:grid-cols-[15rem_1fr]">
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:z-50 focus:bg-white focus:p-2">Skip to content</a>
      <header className="flex items-center justify-between bg-ink px-4 py-3 text-white lg:hidden">
        <span className="font-display text-xl font-semibold">{schoolName}</span>
        <button type="button" onClick={() => setOpen((o) => !o)} aria-expanded={open} aria-controls="nav" className="rounded p-1"><Icon name="menu" title="Menu" /></button>
      </header>
      <nav id="nav" aria-label="Main" className={cx('bg-ink text-white/85 lg:sticky lg:top-0 lg:flex lg:h-screen lg:flex-col', open ? 'block' : 'hidden lg:flex')}>
        <div className="hidden px-5 pt-5 pb-4 lg:block">
          <div className="flex items-center gap-2">
            <span className="grid size-8 place-items-center rounded-md bg-bus text-ink"><Icon name="buses" size={20} /></span>
            <span className="font-display text-lg leading-tight font-semibold text-white">{schoolName}</span>
          </div>
        </div>
        <div className="flex-1 overflow-y-auto px-3 pb-4">
          {NAV.map((g) => (
            <div key={g.group} className="mt-3">
              <p className="px-2 pb-1 text-xs font-medium text-white/45">{g.group}</p>
              {g.items.map((it) => (
                <Link key={it.to} to={it.to} onClick={() => setOpen(false)}
                  aria-current={active(it.to) ? 'page' : undefined}
                  className={cx('flex items-center gap-3 rounded-md px-2 py-1.5 text-[15px]', active(it.to) ? 'bg-white/12 font-semibold text-white' : 'hover:bg-white/8 hover:text-white')}>
                  <Icon name={it.icon} size={18} className={active(it.to) ? 'text-bus' : ''} />
                  {it.label}
                </Link>
              ))}
            </div>
          ))}
        </div>
        <div className="border-t border-white/10 px-5 py-3 text-sm">
          <p className="flex items-center gap-2 text-white/60">
            <span className={cx('size-2 rounded-full', online ? 'bg-ok' : 'bg-white/30')} />
            {online ? 'Live updates on' : 'Live updates paused'}
          </p>
          <div className="mt-2 flex items-center justify-between">
            <span className="truncate text-white">{user?.fullName}</span>
            <button type="button" onClick={logout} className="rounded p-1 text-white/70 hover:text-white"><Icon name="logout" size={18} title="Sign out" /></button>
          </div>
        </div>
      </nav>
      <main id="main" className="min-w-0 px-4 py-6 sm:px-8">{children}</main>
    </div>
  );
}
