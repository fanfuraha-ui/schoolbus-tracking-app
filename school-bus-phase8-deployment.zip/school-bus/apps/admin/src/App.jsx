import React, { useMemo } from 'react';
import { ApiProvider } from './lib/api.jsx';
import { AuthProvider, useAuth } from './lib/auth.jsx';
import { RealtimeProvider } from './lib/realtimeContext.jsx';
import { RouterProvider, Routes } from './lib/router.jsx';
import { ToastProvider } from './lib/toast.jsx';
import { Shell } from './Shell.jsx';
import Live from './pages/Live.jsx';
import Trips, { TripDrawer } from './pages/Trips.jsx';
import Students, { StudentDrawer } from './pages/Students.jsx';
import { Drivers, Parents } from './pages/People.jsx';
import RoutesPage from './pages/Routes.jsx';
import Buses from './pages/Buses.jsx';
import { Activity, Alerts, Calendar, Issues, Reports, Settings } from './pages/Office.jsx';
import Login from './pages/Login.jsx';
import { Empty } from './ui/kit.jsx';

export const ROUTES = [
  { path: '/', element: () => <Live /> },
  { path: '/trips', element: () => <Trips /> },
  { path: '/trips/:id', element: ({ id }) => <><Trips /><TripDrawer id={id} /></> },
  { path: '/issues', element: () => <Issues /> },
  { path: '/alerts', element: () => <Alerts /> },
  { path: '/students', element: () => <Students /> },
  { path: '/students/:id', element: ({ id }) => <><Students /><StudentDrawer id={id} /></> },
  { path: '/parents', element: () => <Parents /> },
  { path: '/drivers', element: () => <Drivers /> },
  { path: '/routes', element: () => <RoutesPage /> },
  { path: '/buses', element: () => <Buses /> },
  { path: '/calendar', element: () => <Calendar /> },
  { path: '/reports', element: () => <Reports /> },
  { path: '/settings', element: () => <Settings /> },
  { path: '/activity', element: () => <Activity /> },
];

function Gate({ connectRealtime, schoolName, loginHint }) {
  const { user } = useAuth();
  if (!user) return <Login schoolName={schoolName} hint={loginHint} />;
  return (
    <RealtimeProvider connect={connectRealtime} enabled>
      <Shell schoolName={schoolName}>
        <Routes routes={ROUTES} fallback={<Empty text="This page doesn't exist. Use the menu to find what you need." />} />
      </Shell>
    </RealtimeProvider>
  );
}

/**
 * api: @school-bus/core client (or demo mock). connectRealtime(handlers) -> disconnect fn.
 * sessionExpiredSignal(cb) -> unsubscribe: tells the app the refresh token was rejected.
 */
export default function App({ api, connectRealtime, sessionExpiredSignal, schoolName, initialPath, loginHint }) {
  const value = useMemo(() => api, [api]);
  return (
    <ApiProvider api={value}>
      <ToastProvider>
        <RouterProvider initial={initialPath}>
          <AuthProvider sessionExpiredSignal={sessionExpiredSignal}>
            <Gate connectRealtime={connectRealtime} schoolName={schoolName} loginHint={loginHint} />
          </AuthProvider>
        </RouterProvider>
      </ToastProvider>
    </ApiProvider>
  );
}
