import React, { useEffect, useRef } from 'react';
import { Icon } from './icons.jsx';

export const cx = (...c) => c.filter(Boolean).join(' ');

const BTN = {
  primary: 'bg-ink text-white hover:bg-ink-soft',
  bus: 'bg-bus text-ink hover:brightness-95',
  outline: 'border border-line bg-white text-ink hover:bg-canvas',
  danger: 'bg-alert text-white hover:brightness-110',
  ghost: 'text-ink hover:bg-canvas',
};
export function Button({ variant = 'primary', icon, children, className, loading, ...rest }) {
  return (
    <button type="button" {...rest} disabled={rest.disabled || loading}
      className={cx('inline-flex h-9 items-center justify-center gap-2 rounded-md px-3.5 text-sm font-semibold transition-colors disabled:cursor-not-allowed disabled:opacity-50', BTN[variant], className)}>
      {icon ? <Icon name={icon} size={18} /> : null}
      {loading ? 'Working…' : children}
    </button>
  );
}

export function Field({ label, hint, error, children }) {
  return (
    <label className="flex flex-col gap-1 text-sm">
      <span className="font-semibold text-ink">{label}</span>
      {children}
      {error ? <span className="text-alert">{error}</span> : hint ? <span className="text-muted">{hint}</span> : null}
    </label>
  );
}
const inputCls = 'h-9 rounded-md border border-line bg-white px-3 text-sm text-ink placeholder:text-muted/70 focus:border-ink focus:outline-none';
export const Input = (props) => <input {...props} className={cx(inputCls, props.className)} />;
export const Select = ({ children, ...props }) => <select {...props} className={cx(inputCls, 'pr-8', props.className)}>{children}</select>;
export const Textarea = (props) => <textarea {...props} className={cx(inputCls, 'h-auto min-h-24 py-2', props.className)} />;
export function Checkbox({ label, ...props }) {
  return <label className="flex items-center gap-2 text-sm"><input type="checkbox" {...props} className="size-4 accent-ink" />{label}</label>;
}

const TONE = {
  ok: 'bg-ok-soft text-ok', late: 'bg-late-soft text-late', alert: 'bg-alert-soft text-alert',
  bus: 'bg-bus-soft text-ink', neutral: 'bg-canvas text-muted', ink: 'bg-ink text-white',
};
export function Badge({ tone = 'neutral', children, className }) {
  return <span className={cx('inline-flex items-center rounded px-1.5 py-0.5 text-xs font-semibold whitespace-nowrap', TONE[tone], className)}>{children}</span>;
}

export function PageHeader({ title, description, actions }) {
  return (
    <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="font-display text-3xl font-semibold leading-tight text-ink">{title}</h1>
        {description ? <p className="mt-1 max-w-[70ch] text-muted">{description}</p> : null}
      </div>
      {actions ? <div className="flex flex-wrap gap-2">{actions}</div> : null}
    </div>
  );
}

export function Panel({ title, actions, children, className, padded = true }) {
  return (
    <section className={cx('rounded-lg border border-line bg-white', className)}>
      {title ? (
        <header className="flex items-center justify-between gap-2 border-b border-line px-4 py-2.5">
          <h2 className="font-display text-lg font-semibold">{title}</h2>
          {actions}
        </header>
      ) : null}
      <div className={padded ? 'p-4' : ''}>{children}</div>
    </section>
  );
}

/**
 * columns: [{ key, label, render?(row), className? }]
 */
export function Table({ columns, rows, rowKey = 'id', empty, onRowClick, dense }) {
  if (!rows) return <Loading />;
  if (!rows.length) return <Empty text={empty || 'Nothing here yet.'} />;
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-left text-sm">
        <thead>
          <tr className="border-b border-line text-muted">
            {columns.map((c) => <th key={c.key} scope="col" className={cx('px-4 py-2 font-semibold', c.className)}>{c.label}</th>)}
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={typeof rowKey === 'function' ? rowKey(r) : r[rowKey]}
              className={cx('border-b border-line/70 last:border-0', onRowClick && 'cursor-pointer hover:bg-canvas/60')}
              onClick={onRowClick ? () => onRowClick(r) : undefined}
              tabIndex={onRowClick ? 0 : undefined}
              onKeyDown={onRowClick ? (e) => { if (e.key === 'Enter') onRowClick(r); } : undefined}>
              {columns.map((c) => <td key={c.key} className={cx('px-4', dense ? 'py-1.5' : 'py-2.5', c.className)}>{c.render ? c.render(r) : r[c.key]}</td>)}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export const Loading = ({ text = 'Loading…' }) => <p className="px-4 py-8 text-center text-muted" role="status">{text}</p>;
export const Empty = ({ text, action }) => (
  <div className="px-4 py-10 text-center text-muted"><p>{text}</p>{action ? <div className="mt-3">{action}</div> : null}</div>
);
export function ErrorNote({ error, onRetry }) {
  if (!error) return null;
  return (
    <div className="mb-4 flex items-center justify-between gap-3 rounded-md border border-alert/30 bg-alert-soft px-4 py-3 text-sm text-alert" role="alert">
      <span>{error.message || 'Could not load this page.'}</span>
      {onRetry ? <Button variant="outline" icon="refresh" onClick={onRetry}>Try again</Button> : null}
    </div>
  );
}

/** Right-hand drawer for detail/edit views. Esc or backdrop closes it. */
export function Drawer({ open, title, onClose, children, footer, wide }) {
  const ref = useRef(null);
  useEffect(() => {
    if (!open) return undefined;
    const onKey = (e) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    ref.current?.focus();
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-40 flex justify-end">
      <div className="absolute inset-0 bg-ink/40" onClick={onClose} />
      <aside ref={ref} tabIndex={-1} role="dialog" aria-modal="true" aria-label={title}
        className={cx('relative flex h-full w-full flex-col bg-white shadow-2xl outline-none', wide ? 'max-w-3xl' : 'max-w-lg')}>
        <header className="flex items-center justify-between border-b border-line px-5 py-3">
          <h2 className="font-display text-2xl font-semibold">{title}</h2>
          <Button variant="ghost" onClick={onClose} aria-label="Close"><Icon name="x" /></Button>
        </header>
        <div className="flex-1 overflow-y-auto p-5">{children}</div>
        {footer ? <footer className="flex justify-end gap-2 border-t border-line px-5 py-3">{footer}</footer> : null}
      </aside>
    </div>
  );
}

export function Confirm({ open, title, body, confirmLabel, tone = 'danger', onConfirm, onClose, busy, children }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-ink/40" onClick={onClose} />
      <div role="alertdialog" aria-modal="true" aria-label={title} className="relative w-full max-w-md rounded-lg bg-white p-5 shadow-2xl">
        <h2 className="font-display text-2xl font-semibold">{title}</h2>
        {body ? <p className="mt-2 text-muted">{body}</p> : null}
        {children ? <div className="mt-4 flex flex-col gap-3">{children}</div> : null}
        <div className="mt-5 flex justify-end gap-2">
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button variant={tone} onClick={onConfirm} loading={busy}>{confirmLabel}</Button>
        </div>
      </div>
    </div>
  );
}

export function SearchBox({ value, onChange, placeholder }) {
  return (
    <div className="relative">
      <Icon name="search" size={16} className="pointer-events-none absolute top-2.5 left-2.5 text-muted" />
      <Input type="search" value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} className="w-64 pl-8" aria-label={placeholder} />
    </div>
  );
}
