import React from 'react';
import { busPosition, currentStopIndex, tripHealth } from '../lib/fleet.js';
import { fmtRelative, fmtTime, hhmm } from '../lib/format.js';
import { Badge, cx } from '../ui/kit.jsx';

const HEALTH = {
  on_time: { tone: 'ok', text: 'On time', line: 'bg-ok' },
  late: { tone: 'late', text: (h) => `${h.late} min late`, line: 'bg-late' },
  very_late: { tone: 'alert', text: (h) => `${h.late} min late`, line: 'bg-alert' },
  no_gps: { tone: 'alert', text: (h) => (h.gpsAgeMin !== null && h.gpsAgeMin !== undefined ? `No GPS for ${h.gpsAgeMin} min` : 'No GPS yet'), line: 'bg-alert' },
  not_started: { tone: 'neutral', text: 'Not started', line: 'bg-line' },
  completed: { tone: 'ok', text: 'Finished', line: 'bg-ok' },
  cancelled: { tone: 'neutral', text: 'Cancelled', line: 'bg-line' },
};

/**
 * The signature view: one bus = one transit-style line of its stops.
 * Done stops are filled, skipped stops hollow and struck, the bus rides between stops.
 */
export function RouteStrip({ trip, now = Date.now(), onOpen }) {
  const h = tripHealth(trip, now);
  const meta = HEALTH[h.state];
  const n = trip.stops.length;
  const pos = busPosition(trip);
  const cur = currentStopIndex(trip);
  const pct = (i) => (n <= 1 ? 0 : (i / (n - 1)) * 100);
  const doneTo = trip.status === 'scheduled' ? -1 : pos;
  const next = cur >= 0 ? trip.stops[cur] : null;
  const live = trip.status === 'active' && h.state !== 'no_gps';

  return (
    <button type="button" onClick={() => onOpen?.(trip)}
      className="group grid w-full grid-cols-[minmax(9rem,13rem)_1fr] items-center gap-x-6 gap-y-1 border-b border-line px-4 py-3 text-left last:border-0 hover:bg-canvas/50 max-md:grid-cols-1">
      <div className="min-w-0">
        <div className="flex items-baseline gap-2">
          <span className="font-display text-xl font-semibold leading-none">{trip.routeName.replace(/^Route (\d+) - /, '$1 ')}</span>
        </div>
        <div className="mt-1 flex flex-wrap items-center gap-1.5 text-xs text-muted">
          <Badge tone="bus" className="font-display text-[13px] tracking-wide">{trip.plateNumber}</Badge>
          <Badge tone={meta.tone}>{typeof meta.text === 'function' ? meta.text(h) : meta.text}</Badge>
        </div>
      </div>

      <div className="min-w-0">
        <div className="relative mx-2 h-8" aria-hidden="true">
          <div className="absolute top-1/2 right-0 left-0 h-1 -translate-y-1/2 rounded bg-line" />
          {doneTo >= 0 ? <div className={cx('absolute top-1/2 left-0 h-1 -translate-y-1/2 rounded', meta.line)} style={{ width: `${pct(doneTo)}%` }} /> : null}
          {trip.stops.map((s, i) => (
            <span key={s.stopId} title={`${s.name}${s.status === 'skipped' ? ' (skipped)' : ''}`}
              className={cx('absolute top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full border-2',
                s.isSchool ? 'size-4 rounded-sm' : 'size-3',
                s.status === 'departed' || (s.status === 'arrived' && i !== cur) ? 'border-ink bg-ink'
                  : s.status === 'skipped' ? 'border-muted bg-white opacity-60'
                    : 'border-ink/60 bg-white')}
              style={{ left: `${pct(i)}%` }} />
          ))}
          {trip.status === 'active' || trip.status === 'scheduled' ? (
            <span className="absolute top-1/2 -translate-x-1/2 -translate-y-1/2 transition-[left] duration-700" style={{ left: `${pct(pos)}%` }}>
              {live ? <span className="bus-ping absolute inset-0 rounded-full bg-bus" /> : null}
              <span className={cx('relative block size-5 rounded-full border-2 shadow', trip.status === 'scheduled' ? 'border-muted bg-white' : h.state === 'no_gps' ? 'border-ink bg-white' : 'border-ink bg-bus')} />
            </span>
          ) : null}
        </div>
        <div className="mx-2 flex justify-between gap-4 text-xs text-muted">
          <span className="truncate">{next ? <>Next: <strong className="text-ink">{next.name}</strong>{next.etaAt && trip.status === 'active' ? ` at ${fmtTime(next.etaAt)}` : next.scheduledTime ? ` (due ${hhmm(next.scheduledTime)})` : ''}</> : 'All stops done'}</span>
          <span className="shrink-0">{trip.bus?.recordedAt ? `GPS ${fmtRelative(trip.bus.recordedAt, now)}` : trip.status === 'scheduled' ? `Starts ${fmtTime(trip.scheduledStartAt)}` : ''}</span>
        </div>
      </div>
    </button>
  );
}
