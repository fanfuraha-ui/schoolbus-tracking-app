import React, { useEffect, useRef, useState } from 'react';
import { tripHealth } from '../lib/fleet.js';

const TILES = import.meta.env?.VITE_MAP_TILES || 'https://tile.openstreetmap.org/{z}/{x}/{y}.png';
const ATTRIBUTION = import.meta.env?.VITE_MAP_ATTRIBUTION || '&copy; OpenStreetMap contributors';
const COLOR = { on_time: '#1F8A5B', late: '#C26A00', very_late: '#C8102E', no_gps: '#C8102E', not_started: '#5E6779', completed: '#5E6779', cancelled: '#5E6779' };

/**
 * Live map with Leaflet (loaded on demand). If Leaflet or the tile server can't load
 * (offline office network, demo), it falls back to a schematic SVG of the same data.
 */
export function FleetMap({ trips, now, height = 380 }) {
  const el = useRef(null);
  const map = useRef(null);
  const layer = useRef(null);
  const [L, setL] = useState(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    let alive = true;
    Promise.all([import('leaflet'), import('leaflet/dist/leaflet.css')])
      .then(([mod]) => { if (alive) setL(mod.default || mod); })
      .catch(() => { if (alive) setFailed(true); });
    return () => { alive = false; };
  }, []);

  useEffect(() => {
    if (!L || !el.current || map.current) return;
    map.current = L.map(el.current, { zoomControl: true, attributionControl: true }).setView([-1.2463, 36.6629], 13);
    L.tileLayer(TILES, { attribution: ATTRIBUTION, maxZoom: 18 }).addTo(map.current);
    layer.current = L.layerGroup().addTo(map.current);
  }, [L]);

  useEffect(() => {
    if (!L || !layer.current) return;
    layer.current.clearLayers();
    const bounds = [];
    for (const t of trips) {
      const color = COLOR[tripHealth(t, now).state];
      const line = t.stops.map((s) => [s.lat, s.lng]);
      bounds.push(...line);
      L.polyline(line, { color, weight: 3, opacity: 0.55 }).addTo(layer.current);
      if (t.bus) {
        L.marker([t.bus.lat, t.bus.lng], {
          icon: L.divIcon({ className: '', html: `<div style="background:#FFB400;border:2px solid #1A2238;border-radius:6px;padding:1px 5px;font:600 12px Barlow Condensed,sans-serif;white-space:nowrap;color:#1A2238">${t.plateNumber}</div>`, iconAnchor: [28, 10] }),
          title: t.routeName,
        }).addTo(layer.current);
      }
    }
    if (bounds.length && !map.current._fitted) { map.current.fitBounds(bounds, { padding: [24, 24] }); map.current._fitted = true; }
  }, [L, trips, now]);

  if (failed || typeof window === 'undefined') return <SchematicMap trips={trips} now={now} height={height} />;
  return <div ref={el} style={{ height }} className="w-full rounded-b-lg" role="region" aria-label="Map of buses" />;
}

/** Offline fallback: stops and buses projected onto a plain grid. */
export function SchematicMap({ trips, now, height = 380 }) {
  const pts = trips.flatMap((t) => t.stops.map((s) => [s.lat, s.lng]));
  if (!pts.length) return <p className="px-4 py-10 text-center text-muted">No routes to show.</p>;
  const lats = pts.map((p) => p[0]); const lngs = pts.map((p) => p[1]);
  const [minLat, maxLat, minLng, maxLng] = [Math.min(...lats), Math.max(...lats), Math.min(...lngs), Math.max(...lngs)];
  const W = 600; const H = 380; const pad = 30;
  const x = (lng) => pad + ((lng - minLng) / (maxLng - minLng || 1)) * (W - pad * 2);
  const y = (lat) => H - pad - ((lat - minLat) / (maxLat - minLat || 1)) * (H - pad * 2);
  return (
    <svg viewBox={`0 0 ${W} ${H}`} style={{ height }} className="w-full rounded-b-lg bg-[#F7F9FB]" role="img" aria-label="Schematic map of routes and buses">
      {trips.map((t) => {
        const color = COLOR[tripHealth(t, now).state];
        return (
          <g key={t.id}>
            <polyline points={t.stops.map((s) => `${x(s.lng)},${y(s.lat)}`).join(' ')} fill="none" stroke={color} strokeWidth="3" strokeOpacity="0.5" strokeLinejoin="round" />
            {t.stops.map((s) => <circle key={s.stopId} cx={x(s.lng)} cy={y(s.lat)} r={s.isSchool ? 6 : 3} fill={s.isSchool ? '#1A2238' : '#fff'} stroke="#1A2238" strokeWidth="1.5" />)}
            {t.bus ? (
              <g transform={`translate(${x(t.bus.lng)},${y(t.bus.lat)})`}>
                <rect x="-26" y="-11" width="52" height="20" rx="4" fill="#FFB400" stroke="#1A2238" strokeWidth="2" />
                <text textAnchor="middle" y="4" fontSize="11" fontWeight="700" fill="#1A2238" fontFamily="Barlow Condensed, sans-serif">{t.plateNumber}</text>
              </g>
            ) : null}
          </g>
        );
      })}
    </svg>
  );
}
