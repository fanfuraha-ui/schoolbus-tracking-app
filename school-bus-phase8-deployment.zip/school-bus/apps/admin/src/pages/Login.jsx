import React, { useState } from 'react';
import { useAuth } from '../lib/auth.jsx';
import { Button, Field, Input } from '../ui/kit.jsx';

export default function Login({ schoolName = 'School bus office', hint }) {
  const { login } = useAuth();
  const [f, setF] = useState({ email: '', password: '' });
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState(false);
  async function submit(e) {
    e.preventDefault();
    setBusy(true); setError(null);
    try { await login(f.email, f.password); } catch (err) { setError(err.message); } finally { setBusy(false); }
  }
  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="hidden flex-col justify-end bg-ink p-12 text-white lg:flex">
        <svg viewBox="0 0 400 60" className="mb-10 w-full max-w-md" aria-hidden="true">
          <line x1="10" y1="30" x2="390" y2="30" stroke="#FFB400" strokeWidth="4" strokeLinecap="round" />
          {[10, 70, 130, 190, 250, 310].map((x) => <circle key={x} cx={x} cy="30" r="7" fill="#1A2238" stroke="#fff" strokeWidth="3" />)}
          <rect x="374" y="18" width="24" height="24" rx="4" fill="#fff" />
        </svg>
        <p className="max-w-[30ch] font-display text-5xl leading-tight font-semibold">Every bus, every stop, every child.</p>
        <p className="mt-4 max-w-[45ch] text-white/70">Live bus positions, delays and parent alerts for the transport office.</p>
      </div>
      <form onSubmit={submit} className="flex flex-col justify-center gap-4 p-8 sm:p-16">
        <h1 className="font-display text-4xl font-semibold">{schoolName}</h1>
        <p className="-mt-2 text-muted">Sign in to the transport office.</p>
        {hint ? <p className="rounded-md bg-bus-soft px-3 py-2 text-sm">{hint}</p> : null}
        {error ? <p role="alert" className="rounded-md bg-alert-soft px-3 py-2 text-sm text-alert">{error}</p> : null}
        <Field label="Email"><Input type="email" autoComplete="username" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} required /></Field>
        <Field label="Password"><Input type="password" autoComplete="current-password" value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} required /></Field>
        <Button type="submit" loading={busy} className="h-11">Sign in</Button>
      </form>
    </div>
  );
}
