import React, { useState } from 'react';
import { useApi, useResource } from '../lib/api.jsx';
import { useLocation, navigate } from '../lib/router.jsx';
import { addDays, fmtDate, fmtKm, fmtTime, hhmm, todayLocal } from '../lib/format.js';
import { useToast } from '../lib/toast.jsx';
import { Badge, Button, Confirm, Drawer, ErrorNote, Field, Input, PageHeader, Panel, Select, Table, Textarea } from '../ui/kit.jsx';

export const TRIP_STATUS = {
  scheduled: ['neutral', 'Not started'], active: ['bus', 'On the road'], completed: ['ok', 'Finished'], cancelled: ['alert', 'Cancelled'],
};
const STOP_STATUS = {
  pending: ['neutral', 'Waiting'], approaching: ['late', 'Bus close'], arrived: ['bus', 'At stop'], departed: ['ok', 'Done'], skipped: ['neutral', 'Skipped'],
};
export const StatusBadge = ({ map, value }) => { const [tone, text] = map[value] || ['neutral', value]; return <Badge tone={tone}>{text}</Badge>; };

export function TripsTable({ trips, onOpen }) {
  return (
    <Table rows={trips} onRowClick={onOpen} empty="No trips on this day."
      columns={[
        { key: 'time', label: 'Start', render: (t) => <span className="font-display text-lg font-semibold">{fmtTime(t.scheduledStartAt)}</span> },
        { key: 'routeName', label: 'Route', render: (t) => <><div className="font-semibold">{t.routeName}</div><div className="text-xs text-muted">{t.scheduleName}</div></> },
        { key: 'plateNumber', label: 'Bus', render: (t) => <Badge tone="bus">{t.plateNumber}</Badge> },
        { key: 'driverName', label: 'Driver' },
        { key: 'status', label: 'Status', render: (t) => <StatusBadge map={TRIP_STATUS} value={t.status} /> },
        { key: 'progress', label: 'Stops done', render: (t) => `${t.stopsDone} of ${t.stopsTotal}` },
        { key: 'distanceM', label: 'Distance', className: 'text-right', render: (t) => (t.distanceM ? fmtKm(t.distanceM) : '') },
      ]} />
  );
}

export default function Trips() {
  const { query } = useLocation();
  const [date, setDate] = useState(query.date || todayLocal());
  const { data, error, reload } = useResource((api) => api.get('/admin/trips', { query: { date } }).then((r) => r.trips), [date]);
  return (
    <>
      <PageHeader title="Trips" description="Every run of every route on the chosen day. Open a trip to see each stop, cancel it, or change the bus or driver before it starts."
        actions={<>
          <Button variant="outline" onClick={() => setDate(addDays(date, -1))} aria-label="Previous day">Previous day</Button>
          <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} aria-label="Date" />
          <Button variant="outline" onClick={() => setDate(addDays(date, 1))} aria-label="Next day">Next day</Button>
        </>} />
      <ErrorNote error={error} onRetry={reload} />
      <Panel title={fmtDate(date)} padded={false}><TripsTable trips={data} onOpen={(t) => navigate(`/trips/${t.id}`)} /></Panel>
    </>
  );
}

export function TripDetailView({ trip }) {
  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-center gap-2">
        <StatusBadge map={TRIP_STATUS} value={trip.status} />
        <Badge tone="bus">{trip.plateNumber}</Badge>
        <span className="text-muted">{trip.scheduleName}, {fmtDate(trip.serviceDate)}</span>
      </div>
      {trip.cancelledReason ? <p className="rounded-md bg-alert-soft px-3 py-2 text-sm text-alert">Cancelled: {trip.cancelledReason}</p> : null}
      <ol className="relative ml-2 border-l-2 border-line">
        {trip.stops.map((s) => (
          <li key={s.stopId} className="relative pb-4 pl-5 last:pb-0">
            <span className={`absolute top-1.5 -left-[7px] size-3 rounded-full border-2 ${s.status === 'departed' ? 'border-ink bg-ink' : s.status === 'arrived' ? 'border-ink bg-bus' : 'border-ink/50 bg-white'}`} />
            <div className="flex flex-wrap items-baseline justify-between gap-2">
              <span className={`font-semibold ${s.status === 'skipped' ? 'text-muted line-through' : ''}`}>{s.name}</span>
              <StatusBadge map={STOP_STATUS} value={s.status} />
            </div>
            <p className="text-sm text-muted">
              {s.scheduledTime ? `Due ${hhmm(s.scheduledTime)}` : ''}
              {s.arrivedAt ? `, arrived ${fmtTime(s.arrivedAt)}` : s.etaAt && !['departed', 'skipped'].includes(s.status) ? `, expected ${fmtTime(s.etaAt)}` : ''}
              {s.departedAt ? `, left ${fmtTime(s.departedAt)}` : ''}
              {s.skippedReason && s.status === 'skipped' ? `, ${s.skippedReason.replace(/_/g, ' ')}` : ''}
            </p>
            {!s.isSchool ? <p className="text-sm text-muted">{s.expected} riding{s.absent ? `, ${s.absent} absent` : ''}{s.riders?.length ? `: ${s.riders.map((r) => r.fullName.split(' ')[0]).join(', ')}` : ''}</p> : null}
          </li>
        ))}
      </ol>
    </div>
  );
}

export function TripDrawer({ id }) {
  const api = useApi();
  const toast = useToast();
  const { data: trip, error, reload } = useResource((a) => a.get(`/admin/trips/${id}`), [id]);
  const buses = useResource((a) => a.get('/admin/buses', { query: { isActive: true, limit: 100 } }).then((r) => r.items));
  const drivers = useResource((a) => a.get('/admin/drivers').then((r) => r.items));
  const [cancelling, setCancelling] = useState(false);
  const [reason, setReason] = useState('');
  const [busy, setBusy] = useState(false);
  const close = () => navigate('/trips');

  async function cancel() {
    setBusy(true);
    try { await api.post(`/admin/trips/${id}/cancel`, { reason }); toast('Trip cancelled. Parents are being told.'); setCancelling(false); reload(); } catch (e) { toast(e.message, 'alert'); } finally { setBusy(false); }
  }
  async function reassign(patch) {
    try { await api.patch(`/admin/trips/${id}`, patch); toast('Trip updated'); reload(); } catch (e) { toast(e.message, 'alert'); }
  }

  return (
    <Drawer open title={trip ? trip.routeName : 'Trip'} onClose={close} wide
      footer={trip && (trip.status === 'scheduled' || trip.status === 'active') ? <Button variant="danger" onClick={() => setCancelling(true)}>Cancel trip</Button> : null}>
      <ErrorNote error={error} onRetry={reload} />
      {trip ? (
        <>
          {trip.status === 'scheduled' ? (
            <div className="mb-5 grid gap-3 rounded-md border border-line p-3 sm:grid-cols-2">
              <Field label="Bus for this trip">
                <Select value={trip.busId} onChange={(e) => reassign({ busId: e.target.value })}>
                  {(buses.data || []).map((b) => <option key={b.id} value={b.id}>{b.plateNumber}</option>)}
                </Select>
              </Field>
              <Field label="Driver for this trip">
                <Select value={trip.driverId} onChange={(e) => reassign({ driverId: e.target.value })}>
                  {(drivers.data || []).filter((d) => d.isActive).map((d) => <option key={d.id} value={d.id}>{d.fullName}</option>)}
                </Select>
              </Field>
            </div>
          ) : null}
          <TripDetailView trip={trip} />
        </>
      ) : null}
      <Confirm open={cancelling} title="Cancel this trip?" tone="danger" confirmLabel="Cancel trip and tell parents" busy={busy}
        body="Every parent on this trip gets an SMS and push alert with your reason." onClose={() => setCancelling(false)} onConfirm={cancel}>
        <Field label="Reason parents will see"><Textarea value={reason} onChange={(e) => setReason(e.target.value)} maxLength={150} placeholder="e.g. Bus breakdown. Please collect your child from school." /></Field>
      </Confirm>
    </Drawer>
  );
}
