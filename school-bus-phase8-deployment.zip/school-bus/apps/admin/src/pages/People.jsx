import React, { useState } from 'react';
import { useApi, useResource } from '../lib/api.jsx';
import { fmtRelative } from '../lib/format.js';
import { useToast } from '../lib/toast.jsx';
import { Badge, Button, Checkbox, Confirm, Drawer, ErrorNote, Field, Input, PageHeader, Panel, SearchBox, Select, Table } from '../ui/kit.jsx';

const CHANNEL = { push_then_sms: 'App, SMS if needed', push: 'App only', sms: 'SMS only' };

export function Parents() {
  const [search, setSearch] = useState('');
  const [editing, setEditing] = useState(null);
  const { data, error, reload } = useResource((api) => api.get('/admin/guardians', { query: { search: search || undefined, limit: 500 } }), [search]);
  return (
    <>
      <PageHeader title="Parents" description="Phone numbers here receive the bus alerts. Parents sign in to the app with this number."
        actions={<><SearchBox value={search} onChange={setSearch} placeholder="Name or phone" /><Button icon="plus" onClick={() => setEditing({})}>Add parent</Button></>} />
      <ErrorNote error={error} onRetry={reload} />
      <Panel padded={false}>
        <Table rows={data?.items} onRowClick={setEditing} empty="No parents found."
          columns={[
            { key: 'fullName', label: 'Name', render: (g) => <span className="font-semibold">{g.fullName}</span> },
            { key: 'phone', label: 'Phone' },
            { key: 'children', label: 'Children', render: (g) => g.children.map((c) => c.fullName).join(', ') || <span className="text-muted">None linked</span> },
            { key: 'channelMode', label: 'Alerts by', render: (g) => CHANNEL[g.channelMode] },
            { key: 'hasApp', label: 'App', render: (g) => (g.hasApp ? <Badge tone="ok">Installed</Badge> : <Badge>SMS only</Badge>) },
            { key: 'isActive', label: '', render: (g) => (g.isActive ? null : <Badge tone="alert">Disabled</Badge>) },
          ]} />
      </Panel>
      {editing ? <ParentForm parent={editing.id ? editing : null} onClose={() => setEditing(null)} onSaved={() => { setEditing(null); reload(); }} /> : null}
    </>
  );
}

function ParentForm({ parent, onClose, onSaved }) {
  const api = useApi();
  const toast = useToast();
  const [f, setF] = useState({ fullName: parent?.fullName || '', phone: parent?.phone || '', channelMode: parent?.channelMode || 'push_then_sms', preferredLanguage: parent?.preferredLanguage || 'en', isActive: parent ? parent.isActive : true });
  const [busy, setBusy] = useState(false);
  async function save() {
    setBusy(true);
    try {
      if (parent) await api.patch(`/admin/guardians/${parent.id}`, f); else await api.post('/admin/guardians', { fullName: f.fullName, phone: f.phone, channelMode: f.channelMode, preferredLanguage: f.preferredLanguage });
      toast(parent ? 'Parent updated' : 'Parent added');
      onSaved();
    } catch (e) { toast(e.message, 'alert'); } finally { setBusy(false); }
  }
  return (
    <Drawer open title={parent ? parent.fullName : 'Add parent'} onClose={onClose}
      footer={<><Button variant="outline" onClick={onClose}>Cancel</Button><Button onClick={save} loading={busy} disabled={!f.fullName || !f.phone}>{parent ? 'Save changes' : 'Add parent'}</Button></>}>
      <div className="flex flex-col gap-4">
        <Field label="Full name"><Input value={f.fullName} onChange={(e) => setF({ ...f, fullName: e.target.value })} /></Field>
        <Field label="Mobile number" hint="Any format: 0712 345 678 or +254712345678"><Input value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} inputMode="tel" /></Field>
        <Field label="Send alerts by">
          <Select value={f.channelMode} onChange={(e) => setF({ ...f, channelMode: e.target.value })}>
            {Object.entries(CHANNEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </Select>
        </Field>
        <Field label="Language"><Select value={f.preferredLanguage} onChange={(e) => setF({ ...f, preferredLanguage: e.target.value })}><option value="en">English</option><option value="sw">Kiswahili</option></Select></Field>
        {parent ? <Checkbox label="Account enabled (disabling signs them out everywhere)" checked={f.isActive} onChange={(e) => setF({ ...f, isActive: e.target.checked })} /> : null}
        {parent?.children?.length ? <p className="text-sm text-muted">Linked to {parent.children.map((c) => `${c.fullName} (${c.relationship})`).join(', ')}. Change links from the student's page.</p> : null}
      </div>
    </Drawer>
  );
}

export function Drivers() {
  const api = useApi();
  const toast = useToast();
  const { data, error, reload } = useResource((a) => a.get('/admin/drivers').then((r) => r.items));
  const [adding, setAdding] = useState(false);
  const [pinFor, setPinFor] = useState(null);
  const [pin, setPin] = useState('');
  const [phoneFor, setPhoneFor] = useState(null);
  const [busy, setBusy] = useState(false);

  const run = async (fn, msg, after) => { setBusy(true); try { await fn(); toast(msg); after?.(); reload(); } catch (e) { toast(e.message, 'alert'); } finally { setBusy(false); } };

  return (
    <>
      <PageHeader title="Drivers" description="Each driver signs in on one bus phone with their number and a 4-digit PIN. Reset the phone if they switch devices."
        actions={<Button icon="plus" onClick={() => setAdding(true)}>Add driver</Button>} />
      <ErrorNote error={error} onRetry={reload} />
      <Panel padded={false}>
        <Table rows={data} empty="No drivers yet."
          columns={[
            { key: 'fullName', label: 'Name', render: (d) => <span className="font-semibold">{d.fullName}</span> },
            { key: 'phone', label: 'Phone' },
            { key: 'routes', label: 'Usual route', render: (d) => d.routes || <span className="text-muted">None</span> },
            { key: 'deviceRegistered', label: 'Phone', render: (d) => (d.deviceRegistered ? <Badge tone="ok">Set up</Badge> : <Badge>Not signed in yet</Badge>) },
            { key: 'lastLoginAt', label: 'Last sign-in', render: (d) => fmtRelative(d.lastLoginAt) },
            { key: 'actions', label: '', className: 'text-right', render: (d) => (
              <div className="flex justify-end gap-1">
                <Button variant="ghost" className="h-8" onClick={() => { setPin(''); setPinFor(d); }}>New PIN</Button>
                {d.deviceRegistered ? <Button variant="ghost" className="h-8" onClick={() => setPhoneFor(d)}>Reset phone</Button> : null}
              </div>
            ) },
          ]} />
      </Panel>
      {adding ? <DriverForm onClose={() => setAdding(false)} onSaved={() => { setAdding(false); reload(); }} /> : null}
      <Confirm open={Boolean(pinFor)} title={`New PIN for ${pinFor?.fullName}`} tone="primary" confirmLabel="Save PIN" busy={busy}
        body="They will be signed out and must use the new PIN." onClose={() => setPinFor(null)}
        onConfirm={() => run(() => api.post(`/admin/drivers/${pinFor.id}/reset-pin`, { pin }), 'PIN changed', () => setPinFor(null))}>
        <Field label="4-digit PIN"><Input value={pin} onChange={(e) => setPin(e.target.value.replace(/\D/g, '').slice(0, 4))} inputMode="numeric" /></Field>
      </Confirm>
      <Confirm open={Boolean(phoneFor)} title={`Reset ${phoneFor?.fullName}'s phone?`} confirmLabel="Reset phone" busy={busy}
        body="The next phone they sign in on becomes their bus phone. Use this when a phone is replaced or lost."
        onClose={() => setPhoneFor(null)} onConfirm={() => run(() => api.post(`/admin/drivers/${phoneFor.id}/reset-device`), 'Phone reset', () => setPhoneFor(null))} />
    </>
  );
}

function DriverForm({ onClose, onSaved }) {
  const api = useApi();
  const toast = useToast();
  const [f, setF] = useState({ fullName: '', phone: '', pin: '', licenceNumber: '' });
  const [busy, setBusy] = useState(false);
  async function save() {
    setBusy(true);
    try { await api.post('/admin/drivers', { ...f, licenceNumber: f.licenceNumber || undefined }); toast('Driver added'); onSaved(); } catch (e) { toast(e.message, 'alert'); } finally { setBusy(false); }
  }
  return (
    <Drawer open title="Add driver" onClose={onClose}
      footer={<><Button variant="outline" onClick={onClose}>Cancel</Button><Button onClick={save} loading={busy} disabled={!f.fullName || !f.phone || f.pin.length !== 4}>Add driver</Button></>}>
      <div className="flex flex-col gap-4">
        <Field label="Full name"><Input value={f.fullName} onChange={(e) => setF({ ...f, fullName: e.target.value })} /></Field>
        <Field label="Mobile number"><Input value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} inputMode="tel" /></Field>
        <Field label="4-digit PIN" hint="Tell the driver in person. They can't change it themselves."><Input value={f.pin} onChange={(e) => setF({ ...f, pin: e.target.value.replace(/\D/g, '').slice(0, 4) })} inputMode="numeric" /></Field>
        <Field label="Driving licence number (optional)"><Input value={f.licenceNumber} onChange={(e) => setF({ ...f, licenceNumber: e.target.value })} /></Field>
      </div>
    </Drawer>
  );
}
