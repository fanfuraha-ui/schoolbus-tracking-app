import React, { useState } from 'react';
import { useApi, useResource } from '../lib/api.jsx';
import { useToast } from '../lib/toast.jsx';
import { Badge, Button, Checkbox, Drawer, ErrorNote, Field, Input, PageHeader, Panel, Table } from '../ui/kit.jsx';

export default function Buses() {
  const { data, error, reload } = useResource((a) => a.get('/admin/buses', { query: { limit: 200 } }).then((r) => r.items));
  const [editing, setEditing] = useState(null);
  return (
    <>
      <PageHeader title="Buses" description="Seat counts are used to warn you when a run has more students than seats."
        actions={<Button icon="plus" onClick={() => setEditing({})}>Add bus</Button>} />
      <ErrorNote error={error} onRetry={reload} />
      <Panel padded={false}>
        <Table rows={data} onRowClick={setEditing} empty="No buses yet."
          columns={[
            { key: 'plateNumber', label: 'Number plate', render: (b) => <Badge tone="bus" className="font-display text-sm">{b.plateNumber}</Badge> },
            { key: 'capacity', label: 'Seats' },
            { key: 'isActive', label: 'In service', render: (b) => (b.isActive ? 'Yes' : <Badge>Off the road</Badge>) },
          ]} />
      </Panel>
      {editing ? <BusForm bus={editing.id ? editing : null} onClose={() => setEditing(null)} onSaved={() => { setEditing(null); reload(); }} /> : null}
    </>
  );
}

function BusForm({ bus, onClose, onSaved }) {
  const api = useApi();
  const toast = useToast();
  const [f, setF] = useState({ plateNumber: bus?.plateNumber || '', capacity: bus?.capacity ?? 33, isActive: bus ? bus.isActive : true });
  const [busy, setBusy] = useState(false);
  async function save() {
    setBusy(true);
    try {
      const body = { plateNumber: f.plateNumber, capacity: Number(f.capacity), ...(bus ? { isActive: f.isActive } : {}) };
      if (bus) await api.patch(`/admin/buses/${bus.id}`, body); else await api.post('/admin/buses', body);
      toast(bus ? 'Bus updated' : 'Bus added');
      onSaved();
    } catch (e) { toast(e.message, 'alert'); } finally { setBusy(false); }
  }
  return (
    <Drawer open title={bus ? bus.plateNumber : 'Add bus'} onClose={onClose}
      footer={<><Button variant="outline" onClick={onClose}>Cancel</Button><Button onClick={save} loading={busy} disabled={!f.plateNumber}>{bus ? 'Save changes' : 'Add bus'}</Button></>}>
      <div className="flex flex-col gap-4">
        <Field label="Number plate"><Input value={f.plateNumber} onChange={(e) => setF({ ...f, plateNumber: e.target.value.toUpperCase() })} placeholder="KDA 123X" /></Field>
        <Field label="Seats"><Input type="number" min="1" max="100" value={f.capacity} onChange={(e) => setF({ ...f, capacity: e.target.value })} /></Field>
        {bus ? <Checkbox label="In service" checked={f.isActive} onChange={(e) => setF({ ...f, isActive: e.target.checked })} /> : null}
      </div>
    </Drawer>
  );
}
