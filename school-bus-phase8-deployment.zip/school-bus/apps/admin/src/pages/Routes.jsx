import React, { useEffect, useState } from 'react';
import { useApi, useResource } from '../lib/api.jsx';
import { hhmm } from '../lib/format.js';
import { useToast } from '../lib/toast.jsx';
import { Badge, Button, Confirm, Drawer, Empty, ErrorNote, Field, Input, PageHeader, Panel, Select, cx } from '../ui/kit.jsx';
import { Icon } from '../ui/icons.jsx';

const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

export default function RoutesPage() {
  const api = useApi();
  const toast = useToast();
  const routes = useResource((a) => a.get('/admin/routes', { query: { limit: 100 } }).then((r) => r.items));
  const buses = useResource((a) => a.get('/admin/buses', { query: { limit: 100 } }).then((r) => r.items));
  const drivers = useResource((a) => a.get('/admin/drivers').then((r) => r.items));
  const load = useResource((a) => a.get('/admin/schedule-load').then((r) => r.schedules));
  const [routeId, setRouteId] = useState(null);
  const [scheduleId, setScheduleId] = useState(null);
  const [adding, setAdding] = useState(null); // 'route' | 'schedule'
  const route = routes.data?.find((r) => r.id === routeId) || null;
  const schedules = useResource((a) => (routeId ? a.get('/admin/schedules', { query: { routeId, limit: 50 } }).then((r) => r.items) : Promise.resolve([])), [routeId]);

  useEffect(() => { if (!routeId && routes.data?.length) setRouteId(routes.data[0].id); }, [routes.data, routeId]);
  useEffect(() => { if (schedules.data?.length && !schedules.data.some((s) => s.id === scheduleId)) setScheduleId(schedules.data[0].id); }, [schedules.data, scheduleId]);

  async function patchRoute(p) { try { await api.patch(`/admin/routes/${routeId}`, p); toast('Route updated'); routes.reload(); } catch (e) { toast(e.message, 'alert'); } }

  return (
    <>
      <PageHeader title="Routes and stops" description="Each route has a usual bus and driver, a morning and an afternoon run, and its stops in order."
        actions={<Button icon="plus" onClick={() => setAdding('route')}>Add route</Button>} />
      <ErrorNote error={routes.error} onRetry={routes.reload} />
      <div className="grid gap-5 lg:grid-cols-[16rem_1fr]">
        <nav aria-label="Routes" className="flex flex-col gap-1">
          {(routes.data || []).map((r) => (
            <button key={r.id} type="button" onClick={() => setRouteId(r.id)} aria-current={r.id === routeId ? 'true' : undefined}
              className={cx('rounded-md px-3 py-2 text-left', r.id === routeId ? 'bg-ink text-white' : 'hover:bg-white')}>
              <span className="font-display text-lg font-semibold">{r.name}</span>
              {!r.isActive ? <Badge className="ml-2">Off</Badge> : null}
            </button>
          ))}
        </nav>
        {route ? (
          <div className="flex min-w-0 flex-col gap-5">
            <Panel title={route.name}>
              <div className="grid gap-3 sm:grid-cols-2">
                <Field label="Usual bus">
                  <Select value={route.defaultBusId || ''} onChange={(e) => patchRoute({ defaultBusId: e.target.value || null })}>
                    <option value="">No bus</option>
                    {(buses.data || []).map((b) => <option key={b.id} value={b.id}>{b.plateNumber} ({b.capacity} seats)</option>)}
                  </Select>
                </Field>
                <Field label="Usual driver">
                  <Select value={route.defaultDriverId || ''} onChange={(e) => patchRoute({ defaultDriverId: e.target.value || null })}>
                    <option value="">No driver</option>
                    {(drivers.data || []).filter((d) => d.isActive).map((d) => <option key={d.id} value={d.id}>{d.fullName}</option>)}
                  </Select>
                </Field>
              </div>
              <p className="mt-3 text-sm text-muted">Changes apply from the next planned trip. To swap the bus or driver for one day only, open that trip.</p>
            </Panel>
            <div className="flex flex-wrap items-center gap-2" role="tablist">
              {(schedules.data || []).map((s) => {
                const l = load.data?.find((x) => x.scheduleId === s.id);
                return (
                  <button key={s.id} type="button" role="tab" aria-selected={s.id === scheduleId} onClick={() => setScheduleId(s.id)}
                    className={cx('rounded-md border px-3 py-1.5 text-left', s.id === scheduleId ? 'border-ink bg-white' : 'border-transparent hover:bg-white')}>
                    <span className="font-semibold">{s.name}</span> <span className="text-sm text-muted">{hhmm(s.startTime)}, {s.daysOfWeek.map((d) => DAYS[d - 1]).join(' ')}</span>
                    {l ? <span className={cx('ml-2 text-sm', l.overCapacity ? 'font-semibold text-alert' : 'text-muted')}>{l.assignedStudents}/{l.capacity ?? '?'} seats</span> : null}
                  </button>
                );
              })}
              <Button variant="ghost" icon="plus" onClick={() => setAdding('schedule')}>Add run</Button>
            </div>
            {scheduleId ? <StopsEditor scheduleId={scheduleId} /> : <Empty text="This route has no runs yet. Add the morning and afternoon runs." />}
          </div>
        ) : null}
      </div>
      {adding === 'route' ? <NewRoute onClose={() => setAdding(null)} onSaved={(r) => { setAdding(null); routes.reload(); setRouteId(r.id); }} /> : null}
      {adding === 'schedule' && routeId ? <NewSchedule routeId={routeId} onClose={() => setAdding(null)} onSaved={(s) => { setAdding(null); schedules.reload(); setScheduleId(s.id); }} /> : null}
    </>
  );
}

export function StopsEditor({ scheduleId }) {
  const api = useApi();
  const toast = useToast();
  const { data: stops, error, reload } = useResource((a) => a.get('/admin/stops', { query: { scheduleId, limit: 500 } }).then((r) => r.items), [scheduleId]);
  const [editing, setEditing] = useState(null);
  const [removing, setRemoving] = useState(null);
  const [busy, setBusy] = useState(false);

  async function move(i, dir) {
    const ids = stops.map((s) => s.id);
    [ids[i], ids[i + dir]] = [ids[i + dir], ids[i]];
    try { await api.put(`/admin/schedules/${scheduleId}/stop-order`, { stopIds: ids }); reload(); } catch (e) { toast(e.message, 'alert'); }
  }
  async function remove() {
    setBusy(true);
    try { await api.del(`/admin/stops/${removing.id}`); toast('Stop removed'); setRemoving(null); reload(); } catch (e) {
      toast(e.code === 'reference_error' ? 'This stop has trip history. Turn it off instead of removing it.' : e.message, 'alert');
    } finally { setBusy(false); }
  }

  return (
    <Panel title="Stops in order" padded={false} actions={<Button variant="outline" icon="plus" onClick={() => setEditing({})}>Add stop</Button>}>
      <ErrorNote error={error} onRetry={reload} />
      {!stops ? null : !stops.length ? <Empty text="No stops yet." /> : (
        <ol>
          {stops.map((s, i) => (
            <li key={s.id} className="flex items-center gap-3 border-b border-line px-4 py-2 last:border-0">
              <span className="w-6 text-right font-display text-lg font-semibold text-muted">{s.sequence}</span>
              <div className="min-w-0 flex-1">
                <p className={cx('font-semibold', !s.isActive && 'text-muted line-through')}>{s.name} {s.isSchool ? <Badge tone="ink">School</Badge> : null}</p>
                <p className="text-sm text-muted">{s.scheduledTime ? `Due ${hhmm(s.scheduledTime)}, ` : ''}alert {s.approachMinutes} min before, {s.radiusM} m circle</p>
              </div>
              <Button variant="ghost" className="h-8 px-2" disabled={i === 0} onClick={() => move(i, -1)} aria-label={`Move ${s.name} up`}><Icon name="up" size={16} /></Button>
              <Button variant="ghost" className="h-8 px-2" disabled={i === stops.length - 1} onClick={() => move(i, 1)} aria-label={`Move ${s.name} down`}><Icon name="down" size={16} /></Button>
              <Button variant="ghost" className="h-8" onClick={() => setEditing(s)}>Edit</Button>
            </li>
          ))}
        </ol>
      )}
      {editing ? <StopForm scheduleId={scheduleId} stop={editing.id ? editing : null} onClose={() => setEditing(null)} onSaved={() => { setEditing(null); reload(); }} onRemove={(s) => { setEditing(null); setRemoving(s); }} /> : null}
      <Confirm open={Boolean(removing)} title={`Remove ${removing?.name}?`} confirmLabel="Remove stop" busy={busy}
        body="Children assigned to this stop will need a new stop." onClose={() => setRemoving(null)} onConfirm={remove} />
    </Panel>
  );
}

function StopForm({ scheduleId, stop, onClose, onSaved, onRemove }) {
  const api = useApi();
  const toast = useToast();
  const [f, setF] = useState({
    name: stop?.name || '', landmark: stop?.landmark || '', lat: stop?.lat ?? '', lng: stop?.lng ?? '',
    scheduledTime: stop?.scheduledTime ? hhmm(stop.scheduledTime) : '', approachMinutes: stop?.approachMinutes ?? 5, radiusM: stop?.radiusM ?? 120, isActive: stop ? stop.isActive : true,
  });
  const [busy, setBusy] = useState(false);
  const valid = f.name && f.lat !== '' && f.lng !== '' && Math.abs(Number(f.lat)) <= 90 && Math.abs(Number(f.lng)) <= 180;
  async function save() {
    setBusy(true);
    const body = { name: f.name, landmark: f.landmark || null, lat: Number(f.lat), lng: Number(f.lng), scheduledTime: f.scheduledTime || null, approachMinutes: Number(f.approachMinutes), radiusM: Number(f.radiusM) };
    try {
      if (stop) await api.patch(`/admin/stops/${stop.id}`, { ...body, isActive: f.isActive }); else await api.post('/admin/stops', { ...body, scheduleId });
      toast(stop ? 'Stop updated' : 'Stop added');
      onSaved();
    } catch (e) { toast(e.message, 'alert'); } finally { setBusy(false); }
  }
  async function pasteLink() {
    try {
      const text = await navigator.clipboard.readText();
      const m = text.match(/(-?\d+\.\d+)\s*,\s*(-?\d+\.\d+)/);
      if (m) setF((x) => ({ ...x, lat: m[1], lng: m[2] })); else toast('No coordinates found in the clipboard', 'alert');
    } catch { toast('Allow clipboard access, or type the coordinates', 'alert'); }
  }
  return (
    <Drawer open title={stop ? `Edit ${stop.name}` : 'Add stop'} onClose={onClose}
      footer={<>{stop && !stop.isSchool ? <Button variant="ghost" className="mr-auto text-alert" onClick={() => onRemove(stop)}>Remove stop</Button> : null}
        <Button variant="outline" onClick={onClose}>Cancel</Button><Button onClick={save} loading={busy} disabled={!valid}>{stop ? 'Save changes' : 'Add stop'}</Button></>}>
      <div className="flex flex-col gap-4">
        <Field label="Stop name" hint="What parents and drivers call it, e.g. Gikambura Stage"><Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></Field>
        <Field label="Landmark (optional)"><Input value={f.landmark} onChange={(e) => setF({ ...f, landmark: e.target.value })} placeholder="Opposite the Total petrol station" /></Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Latitude"><Input value={f.lat} onChange={(e) => setF({ ...f, lat: e.target.value })} inputMode="decimal" placeholder="-1.246300" /></Field>
          <Field label="Longitude"><Input value={f.lng} onChange={(e) => setF({ ...f, lng: e.target.value })} inputMode="decimal" placeholder="36.662900" /></Field>
        </div>
        <Button variant="outline" onClick={pasteLink}>Paste coordinates from Google Maps</Button>
        <p className="-mt-2 text-sm text-muted">In Google Maps, long-press the stop, tap the coordinates to copy them, then paste here.</p>
        <Field label="Scheduled time (optional)" hint="Used to detect when the bus is running late."><Input type="time" value={f.scheduledTime} onChange={(e) => setF({ ...f, scheduledTime: e.target.value })} /></Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Alert parents (minutes before)"><Input type="number" min="1" max="30" value={f.approachMinutes} onChange={(e) => setF({ ...f, approachMinutes: e.target.value })} /></Field>
          <Field label="Arrival circle (metres)"><Input type="number" min="20" max="1000" value={f.radiusM} onChange={(e) => setF({ ...f, radiusM: e.target.value })} /></Field>
        </div>
      </div>
    </Drawer>
  );
}

function NewRoute({ onClose, onSaved }) {
  const api = useApi();
  const toast = useToast();
  const [name, setName] = useState('');
  return (
    <Drawer open title="Add route" onClose={onClose} footer={<><Button variant="outline" onClick={onClose}>Cancel</Button>
      <Button disabled={!name} onClick={async () => { try { const r = await api.post('/admin/routes', { name }); toast('Route added'); onSaved(r); } catch (e) { toast(e.message, 'alert'); } }}>Add route</Button></>}>
      <Field label="Route name" hint="e.g. Route 7 - Kinoo"><Input value={name} onChange={(e) => setName(e.target.value)} /></Field>
    </Drawer>
  );
}

function NewSchedule({ routeId, onClose, onSaved }) {
  const api = useApi();
  const toast = useToast();
  const [f, setF] = useState({ name: 'Morning pickup', direction: 'to_school', startTime: '06:30', daysOfWeek: [1, 2, 3, 4, 5] });
  const toggle = (d) => setF((x) => ({ ...x, daysOfWeek: x.daysOfWeek.includes(d) ? x.daysOfWeek.filter((y) => y !== d) : [...x.daysOfWeek, d].sort() }));
  return (
    <Drawer open title="Add a run" onClose={onClose} footer={<><Button variant="outline" onClick={onClose}>Cancel</Button>
      <Button disabled={!f.name || !f.daysOfWeek.length} onClick={async () => { try { const s = await api.post('/admin/schedules', { ...f, routeId }); toast('Run added. Now add its stops.'); onSaved(s); } catch (e) { toast(e.message, 'alert'); } }}>Add run</Button></>}>
      <div className="flex flex-col gap-4">
        <Field label="Name"><Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></Field>
        <Field label="Direction"><Select value={f.direction} onChange={(e) => setF({ ...f, direction: e.target.value })}><option value="to_school">Home to school</option><option value="from_school">School to home</option></Select></Field>
        <Field label="Start time"><Input type="time" value={f.startTime} onChange={(e) => setF({ ...f, startTime: e.target.value })} /></Field>
        <fieldset><legend className="mb-1 text-sm font-semibold">Runs on</legend>
          <div className="flex flex-wrap gap-1">{DAYS.map((d, i) => (
            <button key={d} type="button" aria-pressed={f.daysOfWeek.includes(i + 1)} onClick={() => toggle(i + 1)}
              className={cx('rounded-md border px-2.5 py-1 text-sm', f.daysOfWeek.includes(i + 1) ? 'border-ink bg-ink text-white' : 'border-line bg-white')}>{d}</button>
          ))}</div>
        </fieldset>
      </div>
    </Drawer>
  );
}
