import React, { useCallback, useEffect, useMemo, useReducer, useState } from 'react';
import { useApi, useResource } from '../lib/api.jsx';
import { systemWarnings } from '../lib/system.js';
import { useRealtimeEvents } from '../lib/realtimeContext.jsx';
import { fleetReducer, fleetSummary, initialFleet, sortTrips, statusLines } from '../lib/fleet.js';
import { fmtKes, fmtRelative, fmtTime } from '../lib/format.js';
import { navigate } from '../lib/router.jsx';
import { RouteStrip } from '../components/RouteStrip.jsx';
import { FleetMap } from '../components/FleetMap.jsx';
import { Badge, Button, Empty, ErrorNote, Loading, Panel } from '../ui/kit.jsx';
import { useToast } from '../lib/toast.jsx';

const INCIDENT_LABEL = {
  traffic: 'Heavy traffic', breakdown: 'Breakdown', accident: 'Accident', weather: 'Bad weather', road_closure: 'Road closed',
  other: 'Other', stalled: 'Bus not moving', gps_lost: 'No GPS from bus', not_started: 'Trip not started',
};
export const incidentLabel = (t) => INCIDENT_LABEL[t] || t;

/** Today's trips + details for running/planned ones + bus positions. */
export async function loadFleetSnapshot(api) {
  const [{ trips }, { buses }] = await Promise.all([api.get('/admin/trips'), api.get('/admin/fleet')]);
  const details = await Promise.all(trips.filter((t) => t.status === 'active' || t.status === 'scheduled')
    .map((t) => api.get(`/admin/trips/${t.id}`)));
  const finished = trips.filter((t) => t.status === 'completed' || t.status === 'cancelled');
  const finishedDetails = await Promise.all(finished.map((t) => api.get(`/admin/trips/${t.id}`)));
  return { trips: [...details, ...finishedDetails], positions: buses };
}

function runLabel(now) {
  const h = Number(new Intl.DateTimeFormat('en-GB', { timeZone: 'Africa/Nairobi', hour: 'numeric', hour12: false }).format(now));
  return h < 12 ? 'Morning run' : 'Afternoon run';
}

export function LiveView({ fleet, incidents, alerts, system, now, onOpenTrip, onResolve, resolving }) {
  const all = useMemo(() => sortTrips(Object.values(fleet.trips), now), [fleet, now]);
  const morning = all.filter((t) => t.direction === 'to_school');
  const afternoon = all.filter((t) => t.direction === 'from_school');
  const isMorning = runLabel(now) === 'Morning run';
  const current = (isMorning ? morning : afternoon).length ? (isMorning ? morning : afternoon) : all;
  const other = current === morning ? afternoon : current === afternoon ? morning : [];
  const summary = fleetSummary(current, now);
  const lines = statusLines(summary);
  const [showOther, setShowOther] = useState(false);
  const running = all.filter((t) => t.status === 'active');
  const openIssues = (incidents || []).filter((i) => !i.resolvedAt);
  const warnings = systemWarnings(system);
  const attention = openIssues.length + warnings.length;

  return (
    <div className="flex flex-col gap-5">
      <div>
        <p className="text-muted">{runLabel(now)}, {new Intl.DateTimeFormat('en-GB', { timeZone: 'Africa/Nairobi', weekday: 'long', day: 'numeric', month: 'long' }).format(now)}</p>
        <h1 className="mt-1 font-display text-4xl leading-tight font-semibold text-ink sm:text-5xl">{lines.headline}</h1>
        {lines.detail ? <p className="mt-1 font-display text-2xl leading-snug font-medium text-ink-soft">{lines.detail}</p> : null}
      </div>

      <div className="grid gap-5 xl:grid-cols-[1fr_22rem]">
        <div className="flex min-w-0 flex-col gap-5">
          <Panel title={isMorning ? 'Morning buses' : 'Afternoon buses'} padded={false}>
            {current.length ? current.map((t) => <RouteStrip key={t.id} trip={t} now={now} onOpen={onOpenTrip} />) : <Empty text="No trips planned for this run." />}
          </Panel>
          <Panel title="Map" padded={false} actions={<span className="text-sm text-muted">{running.length ? `${running.length} on the road` : 'No bus moving'}</span>}>
            <FleetMap trips={current.filter((t) => t.status === 'active').length ? current.filter((t) => t.status === 'active') : current} now={now} />
          </Panel>
          {other.length ? (
            <Panel title={isMorning ? 'Afternoon buses' : 'Morning buses'} padded={false}
              actions={<Button variant="ghost" className="h-8" aria-expanded={showOther} onClick={() => setShowOther((v) => !v)}>{showOther ? 'Hide' : `Show all ${other.length}`}</Button>}>
              {showOther ? other.map((t) => <RouteStrip key={t.id} trip={t} now={now} onOpen={onOpenTrip} />) : (
                <p className="px-4 py-3 text-muted">{isMorning
                  ? `${other.length} trips, the first leaves school at ${fmtTime(other.map((t) => t.scheduledStartAt).sort()[0])}.`
                  : `${other.filter((t) => t.status === 'completed').length} of ${other.length} morning trips finished.`}</p>
              )}
            </Panel>
          ) : null}
        </div>

        <aside className="flex flex-col gap-5">
          <Panel title="Needs attention" padded={false} actions={attention ? <Badge tone="alert">{attention}</Badge> : null}>
            {warnings.length ? (
              <ul data-testid="system-warnings">
                {warnings.map((w) => (
                  <li key={w.key} className={`border-b border-line border-l-4 px-4 py-3 ${w.tone === 'alert' ? 'border-l-alert bg-alert-soft' : 'border-l-late bg-late-soft'}`}>
                    <p className="font-semibold">{w.title}</p>
                    <p className="mt-0.5 text-sm text-ink-soft">{w.body}</p>
                  </li>
                ))}
              </ul>
            ) : null}
            {!incidents ? <Loading /> : openIssues.length === 0 ? (warnings.length ? null : <Empty text="Nothing needs you right now." />) : (
              <ul>
                {openIssues.map((i) => (
                  <li key={i.id} className="border-b border-line px-4 py-3 last:border-0">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <p className="font-semibold">{incidentLabel(i.type)} <span className="font-normal text-muted">on {i.routeName}</span></p>
                        {i.note ? <p className="mt-0.5 text-sm text-muted">{i.note}</p> : null}
                        <p className="mt-1 text-xs text-muted">{fmtRelative(i.createdAt, now)}{i.autoDetected ? ', detected automatically' : i.reportedByName ? `, reported by ${i.reportedByName}` : ''}</p>
                      </div>
                      {i.severity === 'critical' ? <Badge tone="alert">Urgent</Badge> : null}
                    </div>
                    <div className="mt-2 flex gap-2">
                      <Button variant="outline" className="h-8" onClick={() => onOpenTrip({ id: i.tripId })}>Open trip</Button>
                      <Button variant="ghost" className="h-8" loading={resolving === i.id} onClick={() => onResolve(i)}>Mark resolved</Button>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </Panel>
          <Panel title="Parent alerts today">
            {!alerts ? <Loading /> : (
              <dl className="grid grid-cols-2 gap-y-2 text-sm">
                <dt className="text-muted">Sent</dt><dd className="text-right font-semibold">{alerts.breakdown.filter((b) => b.status === 'sent' || b.status === 'delivered').reduce((a, b) => a + b.count, 0)}</dd>
                <dt className="text-muted">Failed</dt><dd className="text-right font-semibold">{alerts.breakdown.filter((b) => b.status === 'failed').reduce((a, b) => a + b.count, 0)}</dd>
                <dt className="text-muted">SMS cost</dt><dd className="text-right font-semibold">{fmtKes(alerts.smsCostKes)}</dd>
              </dl>
            )}
            <a href="#/alerts" className="mt-3 inline-block text-sm font-semibold text-ink underline decoration-bus decoration-2 underline-offset-4">See every alert</a>
          </Panel>
        </aside>
      </div>
    </div>
  );
}

export default function Live() {
  const api = useApi();
  const toast = useToast();
  const [fleet, dispatch] = useReducer(fleetReducer, initialFleet);
  const [now, setNow] = useState(Date.now());
  const [resolving, setResolving] = useState(null);
  const [error, setError] = useState(null);
  const incidents = useResource((a) => a.get('/admin/incidents', { query: { open: true } }).then((r) => r.incidents));
  const alerts = useResource((a) => a.get('/admin/notifications/summary'));
  // Worker heartbeat, backups and SMS credit change slowly: every 5 minutes is plenty.
  const system = useResource((a) => a.get('/admin/system'));
  useEffect(() => { const t = setInterval(() => system.reload(), 5 * 60 * 1000); return () => clearInterval(t); }, [system.reload]);

  const refresh = useCallback(async () => {
    try { dispatch({ type: 'snapshot', ...(await loadFleetSnapshot(api)) }); setError(null); } catch (e) { setError(e); }
  }, [api]);

  useEffect(() => { refresh(); const t = setInterval(() => setNow(Date.now()), 15000); return () => clearInterval(t); }, [refresh]);
  useEffect(() => { if (fleet.needsRefresh) refresh(); }, [fleet.needsRefresh, refresh]);

  useRealtimeEvents({
    location: (data) => dispatch({ type: 'location', data }),
    stops: (data) => dispatch({ type: 'stops', data }),
    ended: (data) => dispatch({ type: 'ended', data }),
    delay: (data) => dispatch({ type: 'delay', data }),
    started: () => dispatch({ type: 'started' }),
    incident: (i) => { incidents.reload(); toast(`${incidentLabel(i.type)}: ${i.note || 'new issue'}`, 'alert'); },
    incidentResolved: () => incidents.reload(),
  });

  async function resolve(i) {
    setResolving(i.id);
    try { await api.post(`/admin/incidents/${i.id}/resolve`); toast('Marked resolved'); incidents.reload(); } catch (e) { toast(e.message, 'alert'); } finally { setResolving(null); }
  }

  return (
    <>
      <ErrorNote error={error} onRetry={refresh} />
      <LiveView fleet={fleet} incidents={incidents.data} alerts={alerts.data} system={system.data} now={now} resolving={resolving}
        onOpenTrip={(t) => navigate(`/trips/${t.id}`)} onResolve={resolve} />
      <p className="mt-4 text-xs text-muted">Positions update as buses report. Last page refresh {fmtTime(new Date(now).toISOString())}.</p>
    </>
  );
}
