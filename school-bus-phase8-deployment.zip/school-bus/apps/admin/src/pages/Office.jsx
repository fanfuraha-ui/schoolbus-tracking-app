import React, { useState } from 'react';
import { useApi, useResource } from '../lib/api.jsx';
import { addDays, fmtDate, fmtDateTime, fmtKes, fmtKm, fmtPct, fmtTime, todayLocal } from '../lib/format.js';
import { navigate } from '../lib/router.jsx';
import { useToast } from '../lib/toast.jsx';
import { Badge, Button, Checkbox, ErrorNote, Field, Input, PageHeader, Panel, Select, Table, Textarea } from '../ui/kit.jsx';
import { incidentLabel } from './Live.jsx';

// ---------------- Parent alerts ----------------
const EVENT = {
  approaching: 'Bus nearly there', arrived: 'Bus arrived', boarded: 'Child on bus', dropped_off: 'Child dropped off', delay: 'Running late',
  breakdown: 'Bus problem', trip_cancelled: 'Trip cancelled', stalled: 'Bus not moving', trip_not_started: 'Not started', route_change: 'Route change',
};
const NOTIF = { queued: ['neutral', 'Waiting'], sent: ['bus', 'Sent'], delivered: ['ok', 'Delivered'], failed: ['alert', 'Failed'], skipped: ['neutral', 'Not sent'] };

export function Alerts() {
  const api = useApi();
  const toast = useToast();
  const [date, setDate] = useState(todayLocal());
  const [status, setStatus] = useState('');
  const summary = useResource((a) => a.get('/admin/notifications/summary', { query: { date } }), [date]);
  const list = useResource((a) => a.get('/admin/notifications', { query: { status: status || undefined, limit: 200 } }).then((r) => r.notifications), [status]);
  const count = (pred) => (summary.data?.breakdown || []).filter(pred).reduce((n, b) => n + b.count, 0);
  async function retry(n) { try { await api.post(`/admin/notifications/${n.id}/retry`); toast('Sending again'); list.reload(); } catch (e) { toast(e.message, 'alert'); } }

  return (
    <>
      <PageHeader title="Parent alerts" description="Every SMS and app alert sent to parents. Alerts in a parent's quiet hours are recorded but not sent, unless they're urgent."
        actions={<Input type="date" value={date} onChange={(e) => setDate(e.target.value)} aria-label="Day" />} />
      <ErrorNote error={summary.error || list.error} onRetry={() => { summary.reload(); list.reload(); }} />
      <Panel className="mb-5">
        <p className="font-display text-2xl font-semibold">
          {summary.data ? `${count((b) => ['sent', 'delivered'].includes(b.status))} alerts sent on ${fmtDate(date)}, SMS cost ${fmtKes(summary.data.smsCostKes)}.` : 'Loading…'}
        </p>
        {summary.data ? <p className="mt-1 text-muted">{count((b) => b.channel === 'sms' && b.status === 'delivered')} SMS confirmed delivered, {count((b) => b.status === 'failed')} failed, {count((b) => b.status === 'skipped')} held back (quiet hours or too late to be useful).</p> : null}
      </Panel>
      <Panel title="Latest alerts" padded={false} actions={
        <Select value={status} onChange={(e) => setStatus(e.target.value)} aria-label="Status filter" className="h-8">
          <option value="">All</option>{Object.entries(NOTIF).map(([k, [, l]]) => <option key={k} value={k}>{l}</option>)}
        </Select>}>
        <Table rows={list.data} empty="No alerts yet."
          columns={[
            { key: 'createdAt', label: 'Time', render: (n) => fmtDateTime(n.createdAt) },
            { key: 'guardianName', label: 'Parent', render: (n) => <><div className="font-semibold">{n.guardianName || '—'}</div><div className="text-xs text-muted">{n.channel === 'sms' ? n.toAddress : 'App'}</div></> },
            { key: 'eventType', label: 'About', render: (n) => EVENT[n.eventType] || n.eventType },
            { key: 'body', label: 'Message', className: 'max-w-md', render: (n) => <span className="line-clamp-2 text-muted">{n.body}</span> },
            { key: 'status', label: 'Status', render: (n) => { const [tone, l] = NOTIF[n.status] || ['neutral', n.status]; return <><Badge tone={tone}>{l}</Badge>{n.error ? <div className="mt-0.5 text-xs text-muted">{n.error.replace(/_/g, ' ')}</div> : null}</>; } },
            { key: 'retry', label: '', render: (n) => (n.status === 'failed' ? <Button variant="ghost" className="h-8" onClick={() => retry(n)}>Send again</Button> : null) },
          ]} />
      </Panel>
    </>
  );
}

// ---------------- Issues ----------------
export function Issues() {
  const api = useApi();
  const toast = useToast();
  const [open, setOpen] = useState(true);
  const { data, error, reload } = useResource((a) => a.get('/admin/incidents', { query: { open: open ? true : undefined } }).then((r) => r.incidents), [open]);
  async function resolve(i) { try { await api.post(`/admin/incidents/${i.id}/resolve`); toast('Marked resolved'); reload(); } catch (e) { toast(e.message, 'alert'); } }
  return (
    <>
      <PageHeader title="Issues" description="Problems reported by drivers, and ones the system spots by itself: a bus that hasn't started, has stopped sending GPS, or hasn't moved."
        actions={<Checkbox label="Only unresolved" checked={open} onChange={(e) => setOpen(e.target.checked)} />} />
      <ErrorNote error={error} onRetry={reload} />
      <Panel padded={false}>
        <Table rows={data} empty={open ? 'No open issues.' : 'No issues recorded.'} onRowClick={(i) => navigate(`/trips/${i.tripId}`)}
          columns={[
            { key: 'createdAt', label: 'When', render: (i) => fmtDateTime(i.createdAt) },
            { key: 'type', label: 'What', render: (i) => <><span className="font-semibold">{incidentLabel(i.type)}</span>{i.severity === 'critical' ? <Badge tone="alert" className="ml-2">Urgent</Badge> : null}{i.note ? <div className="text-sm text-muted">{i.note}</div> : null}</> },
            { key: 'routeName', label: 'Bus', render: (i) => <>{i.routeName} <Badge tone="bus">{i.plateNumber}</Badge></> },
            { key: 'by', label: 'Reported by', render: (i) => (i.autoDetected ? 'System' : i.reportedByName || '—') },
            { key: 'resolvedAt', label: '', render: (i) => (i.resolvedAt ? <Badge tone="ok">Resolved {fmtTime(i.resolvedAt)}</Badge> : <Button variant="outline" className="h-8" onClick={(e) => { e.stopPropagation(); resolve(i); }}>Mark resolved</Button>) },
          ]} />
      </Panel>
    </>
  );
}

// ---------------- Calendar ----------------
export function Calendar() {
  const api = useApi();
  const toast = useToast();
  const { data, error, reload } = useResource((a) => a.get('/admin/no-service-days').then((r) => r.days));
  const [f, setF] = useState({ date: addDays(todayLocal(), 1), reason: '', notifyParents: false });
  const [busy, setBusy] = useState(false);
  async function add() {
    setBusy(true);
    try {
      const r = await api.post('/admin/no-service-days', f);
      toast(r.cancelledTrips ? `${fmtDate(f.date)} marked. ${r.cancelledTrips} planned trips cancelled${r.parentsNotified ? ' and parents told' : ''}.` : `${fmtDate(f.date)} marked as no bus service`);
      setF({ ...f, reason: '' });
      reload();
    } catch (e) { toast(e.message, 'alert'); } finally { setBusy(false); }
  }
  async function remove(d) { try { await api.del(`/admin/no-service-days/${d.serviceDate}`); toast('Bus service restored for that day'); reload(); } catch (e) { toast(e.message, 'alert'); } }
  return (
    <>
      <PageHeader title="School calendar" description="Days with no buses: holidays, half-term, closures. No trips are planned on these days, so nobody gets 'bus not started' or delay alerts." />
      <ErrorNote error={error} onRetry={reload} />
      <div className="grid gap-5 lg:grid-cols-[22rem_1fr]">
        <Panel title="Add a day with no buses">
          <div className="flex flex-col gap-3">
            <Field label="Date"><Input type="date" value={f.date} min={todayLocal()} onChange={(e) => setF({ ...f, date: e.target.value })} /></Field>
            <Field label="Reason"><Textarea value={f.reason} onChange={(e) => setF({ ...f, reason: e.target.value })} placeholder="e.g. Mid-term break" maxLength={120} /></Field>
            <Checkbox label="Also tell parents (only needed for short-notice closures)" checked={f.notifyParents} onChange={(e) => setF({ ...f, notifyParents: e.target.checked })} />
            <Button onClick={add} loading={busy} disabled={f.reason.trim().length < 3}>Add day</Button>
          </div>
        </Panel>
        <Panel title="Coming up" padded={false}>
          <Table rows={data} rowKey="serviceDate" empty="No closures planned."
            columns={[
              { key: 'serviceDate', label: 'Day', render: (d) => <span className="font-semibold">{fmtDate(d.serviceDate)}</span> },
              { key: 'reason', label: 'Reason' },
              { key: 'x', label: '', className: 'text-right', render: (d) => <Button variant="ghost" className="h-8" onClick={() => remove(d)}>Restore buses</Button> },
            ]} />
        </Panel>
      </div>
    </>
  );
}

// ---------------- Reports ----------------
export function ReportsView({ data }) {
  const t = data.totals;
  const maxTrips = Math.max(1, ...data.byDay.map((d) => d.trips));
  return (
    <div className="flex flex-col gap-5">
      <Panel>
        <p className="font-display text-3xl leading-snug font-semibold">
          {t.completed ? `${fmtPct(t.onTimePct)} of ${t.completed} finished trips ran on time` : 'No finished trips in this period'}
          {t.cancelled ? `, ${t.cancelled} cancelled.` : '.'}
        </p>
        <p className="mt-1 text-muted">
          On time means the bus never fell 10 minutes behind schedule. Buses left on average {t.avgStartLateMin ?? 0} min after their start time and covered {fmtKm(t.distanceM)}.
          Parents got {data.notifications.smsSent.toLocaleString('en-KE')} SMS ({fmtKes(data.notifications.smsCostKes)}) and {data.notifications.pushSent.toLocaleString('en-KE')} app alerts.
        </p>
      </Panel>
      <div className="grid gap-5 xl:grid-cols-[1fr_20rem]">
        <Panel title="By route" padded={false}>
          <Table rows={data.byRoute} rowKey="routeId"
            columns={[
              { key: 'routeName', label: 'Route', render: (r) => <span className="font-semibold">{r.routeName}</span> },
              { key: 'trips', label: 'Trips', className: 'text-right' },
              { key: 'onTimePct', label: 'On time', className: 'text-right', render: (r) => <span className={r.onTimePct !== null && r.onTimePct < 80 ? 'font-semibold text-alert' : ''}>{fmtPct(r.onTimePct)}</span> },
              { key: 'delayed', label: 'Ran late', className: 'text-right' },
              { key: 'cancelled', label: 'Cancelled', className: 'text-right' },
              { key: 'avgStartLateMin', label: 'Avg late start', className: 'text-right', render: (r) => (r.avgStartLateMin === null ? '—' : `${r.avgStartLateMin} min`) },
              { key: 'distanceM', label: 'Distance', className: 'text-right', render: (r) => fmtKm(r.distanceM) },
            ]} />
        </Panel>
        <Panel title="Issues">
          {data.incidents.length ? (
            <ul className="flex flex-col gap-1.5">{data.incidents.map((i) => <li key={i.type} className="flex justify-between"><span>{incidentLabel(i.type)}</span><span className="font-semibold">{i.count}</span></li>)}</ul>
          ) : <p className="text-muted">None reported.</p>}
        </Panel>
      </div>
      <Panel title="Day by day">
        {data.byDay.length ? (
          <div className="flex h-48 items-end gap-1.5 overflow-x-auto" role="img" aria-label="Trips per day, on time versus late">
            {data.byDay.map((d) => (
              <div key={d.date} className="flex min-w-7 flex-1 flex-col items-center gap-1" title={`${fmtDate(d.date)}: ${d.onTime} on time of ${d.completed} finished, ${d.cancelled} cancelled`}>
                <div className="flex w-full flex-col-reverse overflow-hidden rounded-sm" style={{ height: `${(d.trips / maxTrips) * 150}px` }}>
                  <div className="bg-ok" style={{ flex: d.onTime }} />
                  <div className="bg-late" style={{ flex: Math.max(0, d.completed - d.onTime) }} />
                  <div className="bg-line" style={{ flex: d.cancelled + (d.trips - d.completed - d.cancelled) }} />
                </div>
                <span className="text-[11px] text-muted">{d.date.slice(8)}</span>
              </div>
            ))}
          </div>
        ) : <p className="text-muted">No trips in this period.</p>}
        <p className="mt-3 flex flex-wrap gap-4 text-sm text-muted">
          <span className="flex items-center gap-1.5"><span className="size-3 rounded-sm bg-ok" />On time</span>
          <span className="flex items-center gap-1.5"><span className="size-3 rounded-sm bg-late" />Ran late</span>
          <span className="flex items-center gap-1.5"><span className="size-3 rounded-sm bg-line" />Cancelled or not run</span>
        </p>
      </Panel>
    </div>
  );
}

export function Reports() {
  const [range, setRange] = useState({ from: addDays(todayLocal(), -29), to: todayLocal() });
  const { data, error, reload } = useResource((a) => a.get('/admin/reports', { query: range }), [range.from, range.to]);
  return (
    <>
      <PageHeader title="Reports" description="How reliable the buses were over a period. Use it for transport committee meetings and to spot routes that need a schedule change."
        actions={<>
          <Field label="From"><Input type="date" value={range.from} onChange={(e) => setRange({ ...range, from: e.target.value })} /></Field>
          <Field label="To"><Input type="date" value={range.to} onChange={(e) => setRange({ ...range, to: e.target.value })} /></Field>
        </>} />
      <ErrorNote error={error} onRetry={reload} />
      {data ? <ReportsView data={data} /> : null}
    </>
  );
}

// ---------------- Settings ----------------
const SETTINGS = [
  ['school_name', 'School name', 'Shown at the end of every SMS. Keep it short: it uses SMS characters.', 'text'],
  ['school_phone', 'Transport office phone', 'Parents can call this number from the app. Leave empty to hide the call button.', 'text'],
  ['sms_low_balance_kes', 'Warn when SMS credit falls below (KES)', 'The Live page warns the office so credit can be topped up before alerts stop.', 'number'],
  ['default_approach_minutes', 'Alert parents this many minutes before the bus arrives', 'Default for new stops. Each stop can have its own.', 'number'],
  ['default_stop_radius_m', 'Arrival circle around a stop (metres)', 'Default for new stops.', 'number'],
  ['delay_escalation_minutes', 'Tell parents when the bus is this many minutes late', 'Comma-separated, e.g. 10, 20, 30. One alert at each step.', 'list'],
  ['not_started_grace_minutes', 'Flag a trip as not started after (minutes)', null, 'number'],
  ['stalled_minutes', 'Flag a bus that hasn’t moved for (minutes)', 'Waiting at a stop doesn’t count.', 'number'],
  ['critical_events_force_sms', 'Always send urgent alerts by SMS too', 'Breakdowns, accidents and cancellations go by SMS even to parents using the app.', 'bool'],
  ['location_retention_days', 'Keep detailed GPS history for (days)', 'Trip summaries are kept longer. Required by data-protection rules to be limited.', 'number'],
];

export function Settings() {
  const api = useApi();
  const toast = useToast();
  const { data, error, reload } = useResource((a) => a.get('/admin/settings'));
  const [draft, setDraft] = useState({});
  const [busy, setBusy] = useState(false);
  const val = (k) => (k in draft ? draft[k] : data?.[k]);
  async function save() {
    const body = {};
    for (const [k, , , type] of SETTINGS) {
      if (!(k in draft)) continue;
      body[k] = type === 'number' ? Number(draft[k]) : type === 'list' ? String(draft[k]).split(',').map((x) => Number(x.trim())).filter(Boolean) : draft[k];
    }
    setBusy(true);
    try { await api.patch('/admin/settings', body); toast('Settings saved'); setDraft({}); reload(); } catch (e) {
      // Name the setting the way the page does, not by its internal key.
      const hit = SETTINGS.find(([k]) => String(e.message).includes(`"${k}"`));
      const why = e.details?.[0]?.message;
      toast(hit ? `${hit[1]}: ${why ? why.toLowerCase() : 'not a valid value'}` : e.message, 'alert');
    } finally { setBusy(false); }
  }
  return (
    <>
      <PageHeader title="Settings" actions={<Button onClick={save} loading={busy} disabled={!Object.keys(draft).length}>Save changes</Button>} />
      <ErrorNote error={error} onRetry={reload} />
      <Panel className="max-w-3xl">
        {data ? (
          <div className="flex flex-col divide-y divide-line">
            {SETTINGS.map(([k, label, hint, type]) => (
              <div key={k} className="py-3 first:pt-0 last:pb-0">
                {type === 'bool' ? (
                  <><Checkbox label={<span className="font-semibold">{label}</span>} checked={Boolean(val(k))} onChange={(e) => setDraft({ ...draft, [k]: e.target.checked })} />{hint ? <p className="mt-1 ml-6 text-sm text-muted">{hint}</p> : null}</>
                ) : (
                  <Field label={label} hint={hint}>
                    <Input className="max-w-xs" type={type === 'number' ? 'number' : 'text'} value={type === 'list' && Array.isArray(val(k)) ? val(k).join(', ') : val(k) ?? ''}
                      onChange={(e) => setDraft({ ...draft, [k]: e.target.value })} />
                  </Field>
                )}
              </div>
            ))}
          </div>
        ) : null}
      </Panel>
      <ChangePassword />
    </>
  );
}

/** The first admin gets a one-time password from db/scripts/create-admin.js; this is where it is replaced. */
function ChangePassword() {
  const api = useApi();
  const toast = useToast();
  const empty = { currentPassword: '', newPassword: '', repeat: '' };
  const [f, setF] = useState(empty);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState(null);
  const set = (k) => (e) => { setF({ ...f, [k]: e.target.value }); setErr(null); };
  async function submit(e) {
    e.preventDefault();
    if (f.newPassword.length < 10) return setErr('Use at least 10 characters.');
    if (f.newPassword !== f.repeat) return setErr('The two new passwords are not the same.');
    if (f.newPassword === f.currentPassword) return setErr('Choose a password different from the current one.');
    setBusy(true);
    try {
      await api.post('/admin/me/password', { currentPassword: f.currentPassword, newPassword: f.newPassword });
      setF(empty); toast('Password changed');
    } catch (ex) { setErr(ex.code === 'wrong_password' ? 'Your current password is not right.' : ex.message); } finally { setBusy(false); }
  }
  return (
    <Panel title="Your password" className="mt-5 max-w-3xl">
      <form onSubmit={submit} className="grid max-w-md gap-3" aria-describedby={err ? 'pw-error' : undefined}>
        <Field label="Current password"><Input type="password" autoComplete="current-password" value={f.currentPassword} onChange={set('currentPassword')} required /></Field>
        <Field label="New password" hint="At least 10 characters. A short sentence is easy to remember and hard to guess."><Input type="password" autoComplete="new-password" value={f.newPassword} onChange={set('newPassword')} required /></Field>
        <Field label="New password again"><Input type="password" autoComplete="new-password" value={f.repeat} onChange={set('repeat')} required /></Field>
        {err ? <p id="pw-error" role="alert" className="text-sm font-semibold text-alert">{err}</p> : null}
        <div><Button type="submit" loading={busy}>Change password</Button></div>
      </form>
    </Panel>
  );
}

// ---------------- Activity log ----------------
const ACTION = {
  'student.create': 'added a student', 'student.update': 'edited a student', 'student.import_csv': 'imported students',
  'student.link_guardian': 'linked a parent', 'student.unlink_guardian': 'removed a parent link', 'student.assign_stop': 'set a bus stop', 'student.unassign_stop': 'removed a bus stop',
  'guardian.create': 'added a parent', 'guardian.update': 'edited a parent', 'driver.create': 'added a driver', 'driver.update': 'edited a driver',
  'driver.reset_pin': 'reset a driver PIN', 'driver.reset_device': 'reset a driver phone', 'driver.device_bound': 'set up their bus phone',
  'trip.cancel': 'cancelled a trip', 'trip.create': 'planned a trip', 'trip.reassign': 'changed a trip’s bus or driver',
  'route.reorder_stops': 'reordered stops', 'settings.update': 'changed settings', 'incident.resolve': 'resolved an issue',
  'calendar.no_service': 'added a no-bus day', 'calendar.service_restored': 'restored a bus day', 'notification.retry': 'resent an alert',
  'admin.change_password': 'changed their password', 'admin.create': 'added an office user',
  'stop.arrived': 'marked a stop arrived', 'stop.departed': 'marked a stop departed', 'stop.skipped': 'skipped a stop',
};
export function Activity() {
  const { data, error, reload } = useResource((a) => a.get('/admin/audit-logs', { query: { limit: 200 } }).then((r) => r.entries));
  return (
    <>
      <PageHeader title="Activity log" description="Who changed what. Kept for accountability and data-protection requests." />
      <ErrorNote error={error} onRetry={reload} />
      <Panel padded={false}>
        <Table rows={data} empty="Nothing recorded yet."
          columns={[
            { key: 'createdAt', label: 'When', render: (e) => fmtDateTime(e.createdAt) },
            { key: 'who', label: 'Who', render: (e) => <span className="font-semibold">{e.actorName || 'System'}</span> },
            { key: 'action', label: 'Did', render: (e) => ACTION[e.action] || e.action.replace(/[._]/g, ' ') },
            { key: 'changes', label: 'Details', className: 'max-w-md', render: (e) => <span className="line-clamp-2 text-sm text-muted">{e.changes ? Object.entries(e.changes).map(([k, [a, b]]) => `${k}: ${a ?? '—'} → ${typeof b === 'object' && b ? JSON.stringify(b) : b ?? '—'}`).join('; ') : ''}</span> },
          ]} />
      </Panel>
    </>
  );
}
