import React, { useState } from 'react';
import { useApi, useResource } from '../lib/api.jsx';
import { navigate } from '../lib/router.jsx';
import { useToast } from '../lib/toast.jsx';
import { Badge, Button, Checkbox, Drawer, ErrorNote, Field, Input, PageHeader, Panel, SearchBox, Select, Table } from '../ui/kit.jsx';

export default function Students() {
  const [search, setSearch] = useState('');
  const [importing, setImporting] = useState(false);
  const [adding, setAdding] = useState(false);
  const { data, error, reload } = useResource((api) => api.get('/admin/students', { query: { search: search || undefined, limit: 500 } }), [search]);
  return (
    <>
      <PageHeader title="Students" description="Who rides, which stop they use morning and afternoon, and which parents get their alerts."
        actions={<><SearchBox value={search} onChange={setSearch} placeholder="Name or admission number" />
          <Button variant="outline" icon="upload" onClick={() => setImporting(true)}>Import spreadsheet</Button>
          <Button icon="plus" onClick={() => setAdding(true)}>Add student</Button></>} />
      <ErrorNote error={error} onRetry={reload} />
      <Panel padded={false}>
        <Table rows={data?.items} onRowClick={(s) => navigate(`/students/${s.id}`)} empty="No students match. Import your spreadsheet to add everyone at once."
          columns={[
            { key: 'admissionNo', label: 'Admission no.', className: 'w-36' },
            { key: 'fullName', label: 'Name', render: (s) => <span className="font-semibold">{s.fullName}</span> },
            { key: 'className', label: 'Class' },
            { key: 'isActive', label: '', render: (s) => (s.isActive ? null : <Badge>Left school</Badge>) },
          ]} />
        {data ? <p className="border-t border-line px-4 py-2 text-sm text-muted">{data.total} students</p> : null}
      </Panel>
      {adding ? <StudentForm onClose={() => setAdding(false)} onSaved={(s) => { setAdding(false); reload(); navigate(`/students/${s.id}`); }} /> : null}
      {importing ? <ImportDrawer onClose={() => setImporting(false)} onDone={() => { setImporting(false); reload(); }} /> : null}
    </>
  );
}

function StudentForm({ student, onClose, onSaved }) {
  const api = useApi();
  const toast = useToast();
  const [f, setF] = useState({ admissionNo: student?.admissionNo || '', fullName: student?.fullName || '', className: student?.className || '', isActive: student ? student.isActive : true });
  const [busy, setBusy] = useState(false);
  async function save() {
    setBusy(true);
    try {
      const s = student ? await api.patch(`/admin/students/${student.id}`, f) : await api.post('/admin/students', f);
      toast(student ? 'Student updated' : 'Student added');
      onSaved(s);
    } catch (e) { toast(e.message, 'alert'); } finally { setBusy(false); }
  }
  return (
    <Drawer open title={student ? 'Edit student' : 'Add student'} onClose={onClose}
      footer={<><Button variant="outline" onClick={onClose}>Cancel</Button><Button onClick={save} loading={busy} disabled={!f.admissionNo || !f.fullName}>{student ? 'Save changes' : 'Add student'}</Button></>}>
      <div className="flex flex-col gap-4">
        <Field label="Admission number"><Input value={f.admissionNo} onChange={(e) => setF({ ...f, admissionNo: e.target.value })} /></Field>
        <Field label="Full name"><Input value={f.fullName} onChange={(e) => setF({ ...f, fullName: e.target.value })} /></Field>
        <Field label="Class"><Input value={f.className} onChange={(e) => setF({ ...f, className: e.target.value })} placeholder="Grade 4" /></Field>
        {student ? <Checkbox label="Still rides the bus" checked={f.isActive} onChange={(e) => setF({ ...f, isActive: e.target.checked })} /> : null}
      </div>
    </Drawer>
  );
}

export function StudentDrawer({ id }) {
  const api = useApi();
  const toast = useToast();
  const { data: s, error, reload } = useResource((a) => a.get(`/admin/students/${id}`), [id]);
  const schedules = useResource((a) => a.get('/admin/schedules', { query: { isActive: true, limit: 500 } }).then((r) => r.items));
  const routes = useResource((a) => a.get('/admin/routes', { query: { limit: 100 } }).then((r) => r.items));
  const [editing, setEditing] = useState(false);
  const [guardianSearch, setGuardianSearch] = useState('');
  const found = useResource((a) => (guardianSearch.length >= 3 ? a.get('/admin/guardians', { query: { search: guardianSearch, limit: 5 } }).then((r) => r.items) : Promise.resolve([])), [guardianSearch]);
  const [assign, setAssign] = useState({ scheduleId: '', stopId: '' });
  const stops = useResource((a) => (assign.scheduleId ? a.get('/admin/stops', { query: { scheduleId: assign.scheduleId, limit: 500 } }).then((r) => r.items) : Promise.resolve([])), [assign.scheduleId]);
  const close = () => navigate('/students');
  const routeName = (rid) => routes.data?.find((r) => r.id === rid)?.name || '';

  const act = async (fn, msg) => { try { await fn(); toast(msg); reload(); } catch (e) { toast(e.message, 'alert'); } };

  return (
    <Drawer open title={s ? s.fullName : 'Student'} onClose={close} wide footer={s ? <Button variant="outline" onClick={() => setEditing(true)}>Edit details</Button> : null}>
      <ErrorNote error={error} onRetry={reload} />
      {s ? (
        <div className="flex flex-col gap-6">
          <p className="text-muted">Admission no. {s.admissionNo}{s.className ? `, ${s.className}` : ''}{s.isActive ? '' : '. No longer rides.'}</p>
          <section>
            <h3 className="font-display text-xl font-semibold">Parents who get alerts</h3>
            <ul className="mt-2 divide-y divide-line rounded-md border border-line">
              {s.guardians.length ? s.guardians.map((g) => (
                <li key={g.id} className="flex items-center justify-between gap-2 px-3 py-2">
                  <span><span className="font-semibold">{g.fullName}</span> <span className="text-muted">{g.phone}, {g.relationship}</span> {g.isPrimary ? <Badge tone="ink">Main contact</Badge> : null}</span>
                  <Button variant="ghost" className="h-8" onClick={() => act(() => api.del(`/admin/students/${id}/guardians/${g.id}`), 'Parent removed')}>Remove</Button>
                </li>
              )) : <li className="px-3 py-2 text-muted">No parent linked. Nobody will get alerts for this child.</li>}
            </ul>
            <div className="mt-2">
              <Input value={guardianSearch} onChange={(e) => setGuardianSearch(e.target.value)} placeholder="Find a parent by name or phone to link" className="w-full" />
              {(found.data || []).map((g) => (
                <button type="button" key={g.id} className="mt-1 block w-full rounded px-2 py-1 text-left hover:bg-canvas"
                  onClick={() => act(() => api.put(`/admin/students/${id}/guardians`, { guardianId: g.id, relationship: 'guardian', isPrimary: !s.guardians.length }), `${g.fullName} linked`).then(() => setGuardianSearch(''))}>
                  Link {g.fullName} <span className="text-muted">{g.phone}</span>
                </button>
              ))}
            </div>
          </section>
          <section>
            <h3 className="font-display text-xl font-semibold">Bus stops</h3>
            <ul className="mt-2 divide-y divide-line rounded-md border border-line">
              {s.stops.length ? s.stops.map((st) => (
                <li key={st.scheduleId} className="flex items-center justify-between gap-2 px-3 py-2">
                  <span><span className="font-semibold">{st.stopName}</span> <span className="text-muted">{st.routeName}, {st.scheduleName}</span></span>
                  <Button variant="ghost" className="h-8" onClick={() => act(() => api.del(`/admin/students/${id}/stops/${st.scheduleId}`), 'Stop removed')}>Remove</Button>
                </li>
              )) : <li className="px-3 py-2 text-muted">Not assigned to any bus.</li>}
            </ul>
            <div className="mt-2 grid gap-2 sm:grid-cols-[1fr_1fr_auto]">
              <Select value={assign.scheduleId} onChange={(e) => setAssign({ scheduleId: e.target.value, stopId: '' })} aria-label="Trip">
                <option value="">Choose a trip…</option>
                {(schedules.data || []).map((sc) => <option key={sc.id} value={sc.id}>{routeName(sc.routeId)}: {sc.name}</option>)}
              </Select>
              <Select value={assign.stopId} onChange={(e) => setAssign({ ...assign, stopId: e.target.value })} disabled={!assign.scheduleId} aria-label="Stop">
                <option value="">Choose a stop…</option>
                {(stops.data || []).filter((x) => !x.isSchool).map((x) => <option key={x.id} value={x.id}>{x.sequence}. {x.name}</option>)}
              </Select>
              <Button disabled={!assign.stopId} onClick={() => act(() => api.put(`/admin/students/${id}/stops`, assign), 'Stop saved').then(() => setAssign({ scheduleId: '', stopId: '' }))}>Save stop</Button>
            </div>
          </section>
        </div>
      ) : null}
      {editing && s ? <StudentForm student={s} onClose={() => setEditing(false)} onSaved={() => { setEditing(false); reload(); }} /> : null}
    </Drawer>
  );
}

const TEMPLATE = 'admission_no,student_name,class_name,guardian_name,guardian_phone,relationship,guardian2_name,guardian2_phone,route,am_stop,pm_stop\n';

export function ImportDrawer({ onClose, onDone }) {
  const api = useApi();
  const toast = useToast();
  const [csv, setCsv] = useState('');
  const [result, setResult] = useState(null);
  const [busy, setBusy] = useState(false);
  async function run(dryRun) {
    setBusy(true);
    try {
      const r = await api.post('/admin/import/students', csv, { query: { dryRun }, contentType: 'text/csv' });
      setResult(r);
      if (!dryRun && r.ok) { toast(`Imported ${r.rows} rows`); onDone(); }
    } catch (e) {
      if (e.status === 422 && e.details) setResult({ ok: false, errors: e.details }); else toast(e.message, 'alert');
    } finally { setBusy(false); }
  }
  async function readFile(file) { setCsv(await file.text()); setResult(null); }

  return (
    <Drawer open title="Import students from a spreadsheet" onClose={onClose} wide
      footer={<><Button variant="outline" onClick={() => run(true)} loading={busy} disabled={!csv}>Check file</Button>
        <Button onClick={() => run(false)} loading={busy} disabled={!result || !result.ok}>Import {result?.rows ?? ''} rows</Button></>}>
      <div className="flex flex-col gap-4">
        <p className="text-muted">Save your spreadsheet as CSV with these columns. Rows that already exist (same admission number) are updated, so you can re-import a corrected file safely. Nothing is saved until every row is valid.</p>
        <code className="block rounded bg-canvas p-2 text-xs break-all">{TEMPLATE}</code>
        <a className="text-sm font-semibold underline decoration-bus decoration-2 underline-offset-4" download="students-template.csv" href={`data:text/csv;charset=utf-8,${encodeURIComponent(TEMPLATE)}`}>Download an empty template</a>
        <Field label="CSV file"><Input type="file" accept=".csv,text/csv" onChange={(e) => e.target.files[0] && readFile(e.target.files[0])} /></Field>
        {result ? (result.ok ? (
          <div className="rounded-md bg-ok-soft px-3 py-2 text-ok">
            {result.dryRun ? `All ${result.rows} rows look good. Press Import to save them.` : `Done: ${result.summary.studentsCreated} added, ${result.summary.studentsUpdated} updated, ${result.summary.guardiansCreated} new parents.`}
            {(result.warnings || []).map((w) => <p key={w.message} className="mt-1 text-late">{w.message}</p>)}
          </div>
        ) : (
          <div>
            <p className="mb-2 font-semibold text-alert">Fix these {result.errors.length} problems in the spreadsheet, then check again:</p>
            <Table rows={result.errors} rowKey={(e) => `${e.line}-${e.field}`} dense
              columns={[{ key: 'line', label: 'Row', className: 'w-16' }, { key: 'field', label: 'Column' }, { key: 'message', label: 'Problem' }]} />
          </div>
        )) : null}
      </div>
    </Drawer>
  );
}
