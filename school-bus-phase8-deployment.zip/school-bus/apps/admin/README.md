# Admin dashboard (React 19 + Vite + Tailwind CSS v4)

The transport office's web app: live buses, today's trips, issues, parent alerts, students, parents, drivers, routes and stops, buses, the school calendar, reports, settings and the activity log.

## Run it
```bash
npm install                  # from the repo root (npm workspaces)
cd apps/admin
cp .env.example .env         # set VITE_API_ORIGIN to the API (default http://localhost:4000)
npm run dev                  # http://localhost:5173, sign in with admin@school.test / ChangeMe!2026 (dev seed)
npm run demo                 # same app on a simulated backend: buses move, nothing else to run (password: demo)
npm run build                # static files in dist/ for any web host (hash routing, no server rewrites needed)
node scripts/build-demo.mjs  # the demo as ONE self-contained HTML file (dist-demo/index.html)
```
Production: serve `dist/` over HTTPS and add its origin to the API's `CORS_ORIGINS`.

## Design
| Element | Choice |
|---|---|
| Idea | A transit-map line per bus. Stops are dots, the bus rides along the line, and the line colour shows its state. Six lines show the whole fleet at once; the map is secondary. |
| Status | Written as sentences ("5 of 6 buses are on the road. 1 is running late.") rather than stat tiles |
| Colour | Signage navy `#1A2238`, bus yellow `#FFB400` only for the live bus, green / amber / red for on time / late / problem, cool `#EEF1F5` canvas. Tokens live in `src/index.css` (`@theme`) |
| Type | Barlow Condensed for route names and numbers, Barlow for text (Google Fonts) |
| Quality floor | Keyboard focus rings, skip link, Esc closes drawers, reduced motion respected, works down to 360 px |

## How it stays live
- Socket.IO events from the API (`bus:location`, `trip:stops`, `trip:started`, `trip:ended`) and from the worker via Postgres NOTIFY (`incident:new`, `incident:resolved`, `trip:delay`) feed a reducer (`src/lib/fleet.js`). If an event mentions a trip the page doesn't know, it re-fetches.
- "Late" is calculated the same way as the server's delay alerts: the next unreached stop's expected time against its scheduled time. "No GPS" means no position for 3 minutes.
- The map uses Leaflet + OpenStreetMap tiles (set `VITE_MAP_TILES` for MapTiler/Stadia). If the tiles can't load, it falls back to a schematic SVG of the same routes.

## Code map
| Path | What |
|---|---|
| `src/App.jsx` | Providers + route table |
| `src/Shell.jsx` | Sidebar navigation |
| `src/pages/` | One file per area; `Office.jsx` holds the smaller office pages |
| `src/components/RouteStrip.jsx` | The route-line board |
| `src/components/FleetMap.jsx` | Map + schematic fallback |
| `src/lib/` | API client wiring, auth, hash router, realtime, fleet state, formatting (Africa/Nairobi) |
| `src/ui/kit.jsx` | Buttons, fields, table, drawer, confirm, badges |
| `src/demo/mockServer.js` | Mock backend for `npm run demo`, same responses as the real API (a test enforces this) |

## Tests
```bash
npm test
```
| Test | Covers |
|---|---|
| `fleet.test.mjs` | Fleet state, health rules, status sentence, formatting, routing |
| `contract.test.mjs` | Runs the dashboard's loaders against the **real** backend and database, renders the real views with that data, and checks the demo mock returns no field the real API lacks |
