import test from 'node:test';
import assert from 'node:assert/strict';
import { busPosition, fleetReducer, fleetSummary, initialFleet, lateMinutes, sortTrips, statusLines, statusSentence, tripHealth } from '../src/lib/fleet.js';
import { addDays, fmtDate, fmtKes, fmtRelative, scheduledAt, todayLocal } from '../src/lib/format.js';
import { matchRoute } from '../src/lib/routeMatch.js';
import { systemWarnings } from '../src/lib/system.js';

const NOW = Date.parse('2026-11-17T04:00:00Z'); // 07:00 in Nairobi
const trip = (over = {}) => ({
  id: 't1', status: 'active', serviceDate: '2026-11-17', routeName: 'Route 1 - Kikuyu Town', direction: 'to_school',
  bus: { lat: 0, lng: 0, recordedAt: new Date(NOW - 20000).toISOString() },
  stops: [
    { stopId: 'a', status: 'departed', scheduledTime: '06:30:00' },
    { stopId: 'b', status: 'approaching', scheduledTime: '06:55:00', etaAt: new Date(NOW + 2 * 60000).toISOString() },
    { stopId: 'c', status: 'pending', scheduledTime: '07:05:00' },
  ],
  ...over,
});

test('format: Nairobi time, dates, money, relative times', () => {
  assert.equal(todayLocal(Date.parse('2026-11-17T22:30:00Z')), '2026-11-18', 'after 21:00 UTC it is already tomorrow in Nairobi');
  assert.equal(addDays('2026-11-30', 1), '2026-12-01');
  assert.equal(fmtDate('2026-11-17'), 'Tue 17 Nov');
  assert.equal(fmtKes(1824), 'KES 1,824.00');
  assert.equal(fmtRelative(new Date(NOW - 5 * 60000).toISOString(), NOW), '5 min ago');
  assert.equal(scheduledAt('2026-11-17', '06:55:00').toISOString(), '2026-11-17T03:55:00.000Z');
});

test('health: on time, late, very late, no GPS, not started, finished', () => {
  assert.equal(lateMinutes(trip(), NOW), 7);
  assert.equal(tripHealth(trip(), NOW).state, 'on_time');
  assert.equal(tripHealth(trip({ stops: trip().stops.map((s) => ({ ...s, etaAt: s.stopId === 'b' ? new Date(NOW + 9 * 60000).toISOString() : s.etaAt })) }), NOW).late, 14);
  assert.equal(tripHealth(trip({ delay: { minutes: 25, level: 2 } }), NOW).state, 'very_late');
  assert.equal(tripHealth(trip({ bus: { recordedAt: new Date(NOW - 6 * 60000).toISOString() } }), NOW).state, 'no_gps');
  assert.equal(tripHealth(trip({ bus: null }), NOW).state, 'no_gps');
  assert.equal(tripHealth(trip({ status: 'scheduled', bus: null, stops: trip().stops.map((s) => ({ ...s, status: 'pending', etaAt: null, scheduledTime: '07:30:00' })) }), NOW).state, 'not_started');
  assert.equal(tripHealth(trip({ status: 'scheduled', bus: null, stops: trip().stops.map((s) => ({ ...s, status: 'pending', etaAt: null })) }), NOW).state, 'late', 'never started and already 30 min past the first stop');
  assert.equal(tripHealth(trip({ status: 'completed' }), NOW).state, 'completed');
});

test('bus position on the route line', () => {
  assert.equal(busPosition(trip()), 0.5);
  assert.equal(busPosition(trip({ stops: trip().stops.map((s, i) => ({ ...s, status: i === 1 ? 'arrived' : s.status })) })), 1);
  assert.equal(busPosition(trip({ stops: trip().stops.map((s) => ({ ...s, status: 'departed' })) })), 2);
});

test('reducer: snapshot, live location, stop updates, delay, end, unknown trip asks for refresh', () => {
  let s = fleetReducer(initialFleet, { type: 'snapshot', trips: [trip({ bus: undefined })], positions: [{ tripId: 't1', lat: 1, lng: 2, positionAt: 'x' }] });
  assert.deepEqual(s.trips.t1.bus, { lat: 1, lng: 2, speedMps: undefined, headingDeg: undefined, recordedAt: 'x' });
  s = fleetReducer(s, { type: 'location', data: { tripId: 't1', lat: 3, lng: 4, recordedAt: 'y' } });
  assert.equal(s.trips.t1.bus.lat, 3);
  s = fleetReducer(s, { type: 'stops', data: { tripId: 't1', stops: [{ stopId: 'b', status: 'arrived' }] } });
  assert.equal(s.trips.t1.stops[1].status, 'arrived');
  assert.equal(s.trips.t1.stops[0].status, 'departed', 'other stops untouched');
  s = fleetReducer(s, { type: 'delay', data: { tripId: 't1', delayMinutes: 21, level: 2 } });
  assert.deepEqual(s.trips.t1.delay, { minutes: 21, level: 2 });
  const s2 = fleetReducer(s, { type: 'snapshot', trips: [trip()], positions: [] });
  assert.deepEqual(s2.trips.t1.delay, { minutes: 21, level: 2 }, 'delay survives a refresh');
  s = fleetReducer(s, { type: 'ended', data: { tripId: 't1', status: 'completed' } });
  assert.deepEqual([s.trips.t1.status, s.trips.t1.bus], ['completed', null]);
  assert.equal(fleetReducer(s, { type: 'location', data: { tripId: 'new' } }).needsRefresh, true);
  assert.equal(fleetReducer(s, { type: 'started', data: {} }).needsRefresh, true);
});

test('summary sentence and problem-first ordering', () => {
  const trips = [trip({ id: 'ok' }), trip({ id: 'late', routeName: 'Route 2', delay: { minutes: 12 } }), trip({ id: 'gps', routeName: 'Route 3', bus: null }), trip({ id: 'done', status: 'completed', routeName: 'Route 0' })];
  const sum = fleetSummary(trips, NOW);
  assert.deepEqual(sum, { total: 4, onRoad: 3, late: 1, noGps: 1, notStarted: 0, done: 1 });
  assert.equal(statusSentence(sum), '3 of 4 buses are on the road. 1 is running late. 1 has stopped sending its location.');
  assert.deepEqual(statusLines(sum), { headline: '3 of 4 buses are on the road.', detail: '1 is running late. 1 has stopped sending its location.' });
  assert.deepEqual(sortTrips(trips, NOW).map((t) => t.id), ['gps', 'late', 'ok', 'done']);
  assert.equal(statusSentence(fleetSummary([], NOW)), 'No trips are planned for today.');
  assert.equal(statusSentence(fleetSummary([trip({ status: 'completed' })], NOW)), 'All 1 trips are finished for today.');
  assert.equal(statusSentence(fleetSummary([trip()], NOW)), '1 of 1 buses are on the road. All on time.');
});

test('router matching', () => {
  assert.deepEqual(matchRoute('/students/:id', '/students/abc%20d'), { id: 'abc d' });
  assert.equal(matchRoute('/students/:id', '/students'), null);
  assert.deepEqual(matchRoute('/', '/'), {});
});

test('system warnings: plain language for the office, quiet when all is well', () => {
  const healthy = { worker: { ok: true, failedMonitors: [] }, backup: { expected: true, ok: true, offsite: true }, sms: { ok: true, status: 'ok', amount: 2000 } };
  assert.deepEqual(systemWarnings(healthy), []);
  assert.deepEqual(systemWarnings(null), []);
  const w = systemWarnings({
    worker: { ok: false, minutesAgo: 12, failedMonitors: [] },
    backup: { expected: true, ok: false, lastRunAt: '2026-11-15T23:00:00Z', hoursAgo: 31 },
    sms: { ok: false, amount: 420, daysLeft: 2 },
  });
  assert.deepEqual(w.map((x) => [x.key, x.tone]), [['worker', 'alert'], ['sms', 'late'], ['backup', 'late']]);
  assert.match(w[0].body, /last ran 12 minutes ago/);
  assert.match(w[1].body, /KES 420\.00 left, about 2 school days/);
  assert.match(w[2].body, /31 hours old/);
  assert.equal(systemWarnings({ ...healthy, sms: { ok: false, amount: 0, daysLeft: 0 } })[0].title, 'SMS credit has run out');
  assert.equal(systemWarnings({ ...healthy, backup: { expected: true, ok: true, offsite: false } })[0].key, 'offsite');
  assert.equal(systemWarnings({ ...healthy, backup: { expected: false, ok: true, offsite: null } }).length, 0, 'dev: no backup nagging');
});
