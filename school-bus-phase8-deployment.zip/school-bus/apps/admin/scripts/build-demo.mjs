/**
 * Builds the dashboard demo (mock backend) as ONE self-contained HTML file:
 *   node scripts/build-demo.mjs [outDir]
 * Uses esbuild + Tailwind v4's compiler directly (both ship with the dev dependencies).
 * Leaflet is left out on purpose, so the demo shows the offline schematic map.
 */
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
const out = path.resolve(process.argv[2] || path.join(root, 'dist-demo'));
const extraPaths = (process.env.NODE_PATH || '').split(path.delimiter).filter(Boolean);
const require = createRequire(path.join(root, 'package.json'));
const resolve = (id) => require.resolve(id, { paths: [root, ...extraPaths] });

const esbuild = require(resolve('esbuild'));
const { compile } = require(resolve('tailwindcss'));

// ---- JS ----
const stub = path.join(out, '.no-leaflet.js');
fs.mkdirSync(out, { recursive: true });
fs.writeFileSync(stub, 'throw new Error("Leaflet is not bundled in the demo");');
const entry = path.join(out, '.entry.jsx');
fs.writeFileSync(entry, `import { startDemo } from ${JSON.stringify(path.join(root, 'src/demo/demoMain.jsx'))};\nstartDemo();\n`);
const js = await esbuild.build({
  entryPoints: [entry], bundle: true, write: false, format: 'iife', platform: 'browser', minify: true, target: 'es2020',
  loader: { '.js': 'jsx', '.jsx': 'jsx', '.css': 'empty' }, jsx: 'automatic', nodePaths: extraPaths, logLevel: 'error',
  alias: { leaflet: stub, 'leaflet/dist/leaflet.css': stub },
  define: { 'process.env.NODE_ENV': '"production"', 'import.meta.env': '{"MODE":"demo"}' },
});

// ---- CSS (Tailwind v4: compile, then build from candidate class names found in the source) ----
const twCss = resolve('tailwindcss/index.css');
const compiler = await compile(fs.readFileSync(path.join(root, 'src/index.css'), 'utf8'), {
  base: path.join(root, 'src'),
  loadStylesheet: async (id, base) => {
    const p = id === 'tailwindcss' ? twCss : path.resolve(base, id);
    return { path: p, base: path.dirname(p), content: fs.readFileSync(p, 'utf8') };
  },
});
const candidates = new Set();
const walk = (d) => { for (const f of fs.readdirSync(d, { withFileTypes: true })) { const p = path.join(d, f.name); if (f.isDirectory()) walk(p); else if (/\.(jsx?|mjs)$/.test(f.name)) fs.readFileSync(p, 'utf8').split(/[\s'"`]+/).forEach((t) => candidates.add(t.replace(/[,;)}]+$/, ''))); } };
walk(path.join(root, 'src'));
const css = compiler.build([...candidates]);

const html = `<!doctype html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="theme-color" content="#1A2238"><title>Greenfield Academy, school bus office (demo)</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700&family=Barlow+Condensed:wght@500;600;700&display=swap" rel="stylesheet">
<style>${css}</style></head>
<body><div id="root"></div><script>${js.outputFiles[0].text.replace(/<\/script/gi, '<\\/script')}</script></body></html>`;
fs.writeFileSync(path.join(out, 'index.html'), html);
fs.rmSync(stub); fs.rmSync(entry);
console.log(`demo written: ${path.join(out, 'index.html')} (${Math.round(html.length / 1024)} KB, css ${Math.round(css.length / 1024)} KB)`);
