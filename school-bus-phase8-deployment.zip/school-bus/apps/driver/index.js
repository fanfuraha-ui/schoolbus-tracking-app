// Entry point. The background location task MUST be defined before anything else, because
// Android may start the app headlessly (no UI) just to deliver locations.
import './src/location/backgroundTask';
import 'expo-router/entry';
