'use strict';
/**
 * Pure view logic for the trip screen. Works on the server's trip detail
 * (GET /driver/trips/:id) with not-yet-synced driver actions applied on top, so taps show
 * up instantly even when offline.
 */
const DONE = new Set(['departed', 'skipped']);

/** Apply queued actions (oldest first) to a copy of the trip. */
function applyPending(trip, actions = []) {
  if (!trip) return trip;
  const t = { ...trip, stops: trip.stops.map((s) => ({ ...s, riders: s.riders.map((r) => ({ ...r, events: [...(r.events || [])] })) })) };
  for (const a of actions) {
    if (a.tripId !== t.id) continue;
    if (a.type === 'stop') {
      const idx = t.stops.findIndex((s) => s.stopId === a.payload.stopId);
      if (idx === -1) continue;
      const s = t.stops[idx];
      if (DONE.has(s.status)) continue;
      if (a.payload.action === 'skipped') { s.status = 'skipped'; s.skippedReason = a.payload.reason || 'skipped_by_driver'; continue; }
      // arriving/departing closes earlier stops, like the server does
      for (let j = 0; j < idx; j += 1) {
        const e = t.stops[j];
        if (e.status === 'arrived') e.status = 'departed';
        else if (!DONE.has(e.status)) e.status = 'skipped';
      }
      s.status = a.payload.action === 'departed' ? 'departed' : 'arrived';
    } else if (a.type === 'student') {
      for (const s of t.stops) {
        const r = s.riders.find((x) => x.studentId === a.payload.studentId);
        if (r && !r.events.includes(a.payload.status)) r.events.push(a.payload.status);
      }
    }
  }
  return t;
}

/** The stop the driver should act on now: first stop not departed/skipped. */
function currentStopIndex(trip) {
  if (!trip) return -1;
  return trip.stops.findIndex((s) => !DONE.has(s.status));
}

function progress(trip) {
  const total = trip ? trip.stops.length : 0;
  const done = trip ? trip.stops.filter((s) => DONE.has(s.status)).length : 0;
  return { done, total, ratio: total ? done / total : 0 };
}

/** Buttons for a stop: pending/approaching -> arrive or skip; arrived -> depart. */
function stopActions(stop) {
  if (!stop || DONE.has(stop.status)) return [];
  if (stop.status === 'arrived') return ['departed'];
  return stop.isSchool ? ['arrived'] : ['arrived', 'skipped'];
}

/** waiting | boarded | dropped_off | absent | no_show */
function riderState(rider) {
  if (rider.absent) return 'absent';
  const ev = rider.events || [];
  if (ev.includes('dropped_off')) return 'dropped_off';
  if (ev.includes('no_show')) return 'no_show';
  if (ev.includes('absent')) return 'absent';
  if (ev.includes('boarded')) return 'boarded';
  return 'waiting';
}

/** Check-on/off buttons for a child, depending on trip direction. */
function riderActions(rider, direction) {
  const state = riderState(rider);
  if (direction === 'to_school') return state === 'waiting' ? ['boarded', 'no_show'] : [];
  // Afternoon: children board at school, get off at their stop.
  if (state === 'waiting') return ['boarded', 'dropped_off'];
  if (state === 'boarded') return ['dropped_off'];
  return [];
}

/** Minutes until ETA (0 = due now), or null when unknown. */
function etaMinutes(etaAt, nowMs = Date.now()) {
  if (!etaAt) return null;
  const ms = new Date(etaAt).getTime() - nowMs;
  return Math.max(0, Math.round(ms / 60000));
}

/** Google Maps turn-by-turn link to a stop (opens the Maps app if installed). */
function navigationUrl(stop) {
  return `https://www.google.com/maps/dir/?api=1&destination=${stop.lat},${stop.lng}&travelmode=driving`;
}

/** Today's schedule list: what the main button should say. */
function scheduleAction(s) {
  if (s.tripStatus === 'active') return 'resume';
  if (s.tripStatus === 'not_started' || s.tripStatus === 'scheduled') return 'start';
  return null; // completed / cancelled
}

module.exports = { applyPending, currentStopIndex, progress, stopActions, riderState, riderActions, etaMinutes, navigationUrl, scheduleAction };
