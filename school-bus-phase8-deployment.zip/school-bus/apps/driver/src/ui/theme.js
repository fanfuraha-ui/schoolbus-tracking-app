export const colors = {
  brand: '#F2B705',      // school-bus yellow
  brandDark: '#8A6500',
  ink: '#1F2937',
  muted: '#6B7280',
  line: '#E5E7EB',
  bg: '#F9FAFB',
  card: '#FFFFFF',
  success: '#15803D',
  successBg: '#DCFCE7',
  warning: '#B45309',
  warningBg: '#FEF3C7',
  danger: '#B91C1C',
  dangerBg: '#FEE2E2',
  info: '#1D4ED8',
  infoBg: '#DBEAFE',
};

export const space = { xs: 4, sm: 8, md: 12, lg: 16, xl: 24 };
export const radius = 12;
export const font = { body: 16, small: 14, title: 22, big: 28 };
