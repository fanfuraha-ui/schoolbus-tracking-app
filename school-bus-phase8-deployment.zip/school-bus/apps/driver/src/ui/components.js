import React from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text, View } from 'react-native';
import { colors, font, radius, space } from './theme';

/** Big, glove-friendly buttons (min 56 px tall). */
export function Button({ title, onPress, variant = 'primary', disabled, loading, compact, testID }) {
  const v = VARIANTS[variant] || VARIANTS.primary;
  return (
    <Pressable
      testID={testID}
      accessibilityRole="button"
      accessibilityState={{ disabled: Boolean(disabled || loading) }}
      onPress={onPress}
      disabled={disabled || loading}
      style={({ pressed }) => [styles.btn, compact && styles.btnCompact, { backgroundColor: v.bg, borderColor: v.border }, (pressed || disabled) && styles.dim]}
    >
      {loading ? <ActivityIndicator color={v.fg} /> : <Text style={[styles.btnText, compact && styles.btnTextCompact, { color: v.fg }]}>{title}</Text>}
    </Pressable>
  );
}

const VARIANTS = {
  primary: { bg: colors.brand, fg: colors.ink, border: colors.brand },
  success: { bg: colors.success, fg: '#fff', border: colors.success },
  danger: { bg: colors.danger, fg: '#fff', border: colors.danger },
  outline: { bg: colors.card, fg: colors.ink, border: colors.line },
  ghost: { bg: 'transparent', fg: colors.info, border: 'transparent' },
};

export function Card({ children, style }) {
  return <View style={[styles.card, style]}>{children}</View>;
}

const PILL = {
  neutral: [colors.line, colors.ink], success: [colors.successBg, colors.success], warning: [colors.warningBg, colors.warning],
  danger: [colors.dangerBg, colors.danger], info: [colors.infoBg, colors.info],
};
export function Pill({ text, tone = 'neutral' }) {
  const [bg, fg] = PILL[tone] || PILL.neutral;
  return <View style={[styles.pill, { backgroundColor: bg }]}><Text style={[styles.pillText, { color: fg }]}>{text}</Text></View>;
}

export function Banner({ text, tone = 'warning', action }) {
  const [bg, fg] = PILL[tone] || PILL.warning;
  return (
    <View style={[styles.banner, { backgroundColor: bg }]}>
      <Text style={[styles.bannerText, { color: fg }]}>{text}</Text>
      {action}
    </View>
  );
}

export function Row({ children, style }) {
  return <View style={[styles.row, style]}>{children}</View>;
}

export const styles = StyleSheet.create({
  btn: { minHeight: 56, borderRadius: radius, borderWidth: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: space.lg, flexGrow: 1 },
  btnCompact: { minHeight: 44, paddingHorizontal: space.md },
  btnText: { fontSize: font.body + 2, fontWeight: '700' },
  btnTextCompact: { fontSize: font.small + 1 },
  dim: { opacity: 0.6 },
  card: { backgroundColor: colors.card, borderRadius: radius, padding: space.lg, borderWidth: 1, borderColor: colors.line, marginBottom: space.md },
  pill: { borderRadius: 999, paddingHorizontal: space.sm + 2, paddingVertical: 3, alignSelf: 'flex-start' },
  pillText: { fontSize: font.small - 1, fontWeight: '700' },
  banner: { borderRadius: radius, padding: space.md, marginBottom: space.md, gap: space.sm },
  bannerText: { fontSize: font.small, fontWeight: '600' },
  row: { flexDirection: 'row', alignItems: 'center', gap: space.sm },
});
