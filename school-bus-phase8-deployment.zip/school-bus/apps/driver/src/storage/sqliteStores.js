'use strict';
/**
 * SQLite-backed stores for the driver app. `db` is an expo-sqlite database
 * (SQLite.openDatabaseSync('driver.db')): uses execSync, runAsync, getAllAsync, getFirstAsync.
 * Data survives app restarts, phone reboots and the app being killed mid-trip.
 */
const SCHEMA = `
  CREATE TABLE IF NOT EXISTS gps_points (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    trip_id TEXT NOT NULL,
    recorded_at TEXT NOT NULL,
    lat REAL NOT NULL, lng REAL NOT NULL,
    speed REAL, heading REAL, accuracy REAL,
    UNIQUE (trip_id, recorded_at)
  );
  CREATE INDEX IF NOT EXISTS gps_points_time ON gps_points (recorded_at, id);
  CREATE TABLE IF NOT EXISTS actions (
    id TEXT PRIMARY KEY, seq INTEGER NOT NULL, body TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY, value TEXT);
`;

function migrate(db) {
  db.execSync('PRAGMA journal_mode = WAL;');
  db.execSync(SCHEMA);
}

function createSqlitePointStore(db) {
  const toRow = (r) => ({
    id: r.id, tripId: r.trip_id, recordedAt: r.recorded_at, lat: r.lat, lng: r.lng,
    speedMps: r.speed, headingDeg: r.heading, accuracyM: r.accuracy,
  });
  return {
    async insert(rows) {
      let inserted = 0;
      for (let i = 0; i < rows.length; i += 100) { // 7 params x 100 rows stays under SQLite's limit
        const chunk = rows.slice(i, i + 100);
        const res = await db.runAsync(
          `INSERT OR IGNORE INTO gps_points (trip_id, recorded_at, lat, lng, speed, heading, accuracy) VALUES ${chunk.map(() => '(?,?,?,?,?,?,?)').join(',')}`,
          chunk.flatMap((r) => [r.tripId, r.recordedAt, r.lat, r.lng, r.speedMps ?? null, r.headingDeg ?? null, r.accuracyM ?? null]),
        );
        inserted += res.changes;
      }
      return inserted;
    },
    async oldest(limit) {
      return (await db.getAllAsync('SELECT * FROM gps_points ORDER BY recorded_at, id LIMIT ?', [limit])).map(toRow);
    },
    async deleteIds(ids) {
      for (let i = 0; i < ids.length; i += 500) {
        const chunk = ids.slice(i, i + 500);
        await db.runAsync(`DELETE FROM gps_points WHERE id IN (${chunk.map(() => '?').join(',')})`, chunk);
      }
    },
    async deleteTrip(tripId) { await db.runAsync('DELETE FROM gps_points WHERE trip_id = ?', [tripId]); },
    async deleteOldest(n) {
      await db.runAsync('DELETE FROM gps_points WHERE id IN (SELECT id FROM gps_points ORDER BY recorded_at, id LIMIT ?)', [n]);
    },
    async count(tripId) {
      const row = tripId
        ? await db.getFirstAsync('SELECT count(*) AS n FROM gps_points WHERE trip_id = ?', [tripId])
        : await db.getFirstAsync('SELECT count(*) AS n FROM gps_points');
      return row ? Number(row.n) : 0;
    },
  };
}

function createSqliteActionStore(db) {
  return {
    async list() {
      return (await db.getAllAsync('SELECT body FROM actions ORDER BY seq')).map((r) => JSON.parse(r.body));
    },
    async put(action) {
      await db.runAsync('INSERT OR REPLACE INTO actions (id, seq, body) VALUES (?, ?, ?)', [action.id, action.seq, JSON.stringify(action)]);
    },
    async remove(id) { await db.runAsync('DELETE FROM actions WHERE id = ?', [id]); },
  };
}

function createSqliteKv(db) {
  return {
    async get(key) {
      const row = await db.getFirstAsync('SELECT value FROM kv WHERE key = ?', [key]);
      return row ? JSON.parse(row.value) : null;
    },
    async set(key, value) { await db.runAsync('INSERT OR REPLACE INTO kv (key, value) VALUES (?, ?)', [key, JSON.stringify(value)]); },
    async del(key) { await db.runAsync('DELETE FROM kv WHERE key = ?', [key]); },
  };
}

module.exports = { migrate, createSqlitePointStore, createSqliteActionStore, createSqliteKv };
