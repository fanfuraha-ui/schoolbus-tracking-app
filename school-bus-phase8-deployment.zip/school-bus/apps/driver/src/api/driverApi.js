'use strict';
/** Typed wrapper over the driver endpoints (see docs/api.md). `api` = @school-bus/core client. */
function createDriverApi(api) {
  return {
    login: (body) => api.post('/auth/driver/login', body, { auth: false }),
    logout: (refreshToken) => api.post('/auth/logout', { refreshToken }, { auth: false }),
    today: () => api.get('/driver/today'),
    startTrip: (scheduleId) => api.post(`/driver/schedules/${scheduleId}/start`),
    trip: (tripId) => api.get(`/driver/trips/${tripId}`),
    uploadLocations: (tripId, points) => api.post(`/driver/trips/${tripId}/locations`, { points }, { timeout: 30000 }),
    stopAction: (tripId, stopId, body) => api.post(`/driver/trips/${tripId}/stops/${stopId}`, body),
    studentEvent: (tripId, studentId, body) => api.post(`/driver/trips/${tripId}/students/${studentId}`, body),
    reportIncident: (tripId, body) => api.post(`/driver/trips/${tripId}/incidents`, body),
    endTrip: (tripId) => api.post(`/driver/trips/${tripId}/end`),
  };
}

module.exports = { createDriverApi };
