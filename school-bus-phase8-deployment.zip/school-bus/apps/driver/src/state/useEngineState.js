import { useSyncExternalStore } from 'react';
import { getEngine } from '../engine';

/** Subscribe a component to one field of the engine state. */
export function useEngineState(key) {
  const { state } = getEngine();
  return useSyncExternalStore(state.subscribe, () => state.get()[key]);
}
