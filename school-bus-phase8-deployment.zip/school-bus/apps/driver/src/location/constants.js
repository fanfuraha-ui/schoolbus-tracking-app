export const LOCATION_TASK = 'school-bus-driver-location';
