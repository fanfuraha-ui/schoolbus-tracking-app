'use strict';
/**
 * Converts expo-location readings into API GPS points and drops junk before it is stored:
 * missing/zero coordinates, readings worse than 200 m accuracy, timestamps from the future,
 * and readings closer than 2 s to the previous one (some phones burst several fixes at once).
 * (The server ignores >100 m points for stop detection but keeps them for the map trail.)
 */
const MAX_ACCURACY_M = 200;
const MIN_GAP_MS = 2000;
const FUTURE_TOLERANCE_MS = 60 * 1000;

const round = (n, dp) => Math.round(n * 10 ** dp) / 10 ** dp;
const num = (v) => (typeof v === 'number' && Number.isFinite(v) ? v : null);

function toApiPoint(loc) {
  const c = loc.coords || {};
  const speed = num(c.speed);
  const heading = num(c.heading);
  const accuracy = num(c.accuracy);
  return {
    lat: round(c.latitude, 6),
    lng: round(c.longitude, 6),
    recordedAt: new Date(loc.timestamp).toISOString(),
    speedMps: speed !== null && speed >= 0 ? round(speed, 1) : null,
    headingDeg: heading !== null && heading >= 0 && heading <= 360 ? Math.round(heading) : null,
    accuracyM: accuracy !== null && accuracy >= 0 ? Math.round(accuracy) : null,
  };
}

function isUsable(loc, nowMs) {
  const c = loc && loc.coords;
  if (!c || num(c.latitude) === null || num(c.longitude) === null) return false;
  if (Math.abs(c.latitude) > 90 || Math.abs(c.longitude) > 180) return false;
  if (c.latitude === 0 && c.longitude === 0) return false;
  if (num(c.accuracy) !== null && c.accuracy > MAX_ACCURACY_M) return false;
  if (!Number.isFinite(loc.timestamp) || loc.timestamp > nowMs + FUTURE_TOLERANCE_MS) return false;
  return true;
}

/**
 * locations: expo-location objects (any order). lastMs: timestamp of the last stored point.
 * Returns { points, lastMs }.
 */
function filterLocations(locations, { lastMs = 0, nowMs = Date.now() } = {}) {
  const sorted = [...(locations || [])].filter((l) => isUsable(l, nowMs)).sort((a, b) => a.timestamp - b.timestamp);
  const points = [];
  let last = lastMs;
  for (const loc of sorted) {
    if (loc.timestamp - last < MIN_GAP_MS) continue;
    points.push(toApiPoint(loc));
    last = loc.timestamp;
  }
  return { points, lastMs: last };
}

module.exports = { filterLocations, toApiPoint, MAX_ACCURACY_M };
