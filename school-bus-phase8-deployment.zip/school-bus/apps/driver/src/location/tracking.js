import { startUpdates, stopUpdates } from './updates';

/** Begin sharing location for a trip (idempotent; also used to resume after a restart). */
export async function startTracking(engine, tripId) {
  await engine.setActiveTrip(tripId);
  await startUpdates();
}

/** Stop sharing and push whatever is still buffered. */
export async function stopTracking(engine) {
  await stopUpdates();
  await engine.setActiveTrip(null);
  await engine.sync.flush({ force: true });
}
