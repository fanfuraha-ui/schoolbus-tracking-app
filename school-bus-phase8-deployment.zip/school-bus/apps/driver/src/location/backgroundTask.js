/**
 * Background location task. Must be defined at app start-up (imported from index.js),
 * because on Android the OS can wake the app headlessly to deliver locations.
 */
import * as TaskManager from 'expo-task-manager';
import { LOCATION_TASK } from './constants';
import { getEngine } from '../engine';

TaskManager.defineTask(LOCATION_TASK, async ({ data, error }) => {
  if (error) {
    console.warn('[location task]', error.message);
    return;
  }
  try {
    await getEngine().onLocations((data && data.locations) || []);
  } catch (err) {
    console.warn('[location task] failed', err && err.message);
  }
});
