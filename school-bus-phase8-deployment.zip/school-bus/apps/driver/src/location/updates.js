import * as Location from 'expo-location';
import { LOCATION_TASK } from './constants';

/**
 * Tracking settings, tuned for a bus phone that is mounted and charging:
 *  - a fix every 5 s, even when parked (distanceInterval 0). The server needs points while
 *    the bus is stopped to tell "waiting at a stop" from "GPS lost" or "stalled".
 *  - Android foreground service with a visible notification, which keeps tracking alive
 *    with the screen off and stops battery savers killing it.
 */
export const TRACKING_OPTIONS = {
  accuracy: Location.Accuracy.High,
  timeInterval: 5000,
  distanceInterval: 0,
  deferredUpdatesInterval: 5000,
  pausesUpdatesAutomatically: false,
  activityType: Location.ActivityType.AutomotiveNavigation,
  showsBackgroundLocationIndicator: true,
  foregroundService: {
    notificationTitle: 'Trip in progress',
    notificationBody: 'Sharing the bus location with parents',
    notificationColor: '#F2B705',
    killServiceOnDestroy: false,
  },
};

export async function isTracking() {
  try {
    return await Location.hasStartedLocationUpdatesAsync(LOCATION_TASK);
  } catch {
    return false;
  }
}

export async function startUpdates() {
  if (!(await isTracking())) await Location.startLocationUpdatesAsync(LOCATION_TASK, TRACKING_OPTIONS);
}

export async function stopUpdates() {
  if (await isTracking()) await Location.stopLocationUpdatesAsync(LOCATION_TASK);
}
