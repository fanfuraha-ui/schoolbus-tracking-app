import * as Location from 'expo-location';
import { Linking, Platform } from 'react-native';

/** Everything the phone needs before a trip can be tracked reliably. */
export async function checkSetup(kv) {
  const [services, fg, bg, batteryAck] = await Promise.all([
    Location.hasServicesEnabledAsync(),
    Location.getForegroundPermissionsAsync(),
    Location.getBackgroundPermissionsAsync(),
    kv.get('battery_ack'),
  ]);
  const status = {
    services,
    foreground: fg.granted,
    background: bg.granted,
    battery: Platform.OS !== 'android' || Boolean(batteryAck),
  };
  return { ...status, ready: status.services && status.foreground && status.background };
}

/** Try to fix one checklist item; falls back to the app's settings page. */
export async function fixSetupItem(key, kv) {
  if (key === 'services') {
    try { await Location.enableNetworkProviderAsync(); } catch { await Linking.openSettings(); }
  } else if (key === 'foreground') {
    const r = await Location.requestForegroundPermissionsAsync();
    if (!r.granted && !r.canAskAgain) await Linking.openSettings();
  } else if (key === 'background') {
    const fg = await Location.getForegroundPermissionsAsync();
    if (!fg.granted) await Location.requestForegroundPermissionsAsync();
    const r = await Location.requestBackgroundPermissionsAsync(); // Android 11+: opens the settings page
    if (!r.granted && !r.canAskAgain) await Linking.openSettings();
  } else if (key === 'battery') {
    await Linking.openSettings();
    await kv.set('battery_ack', true); // can't be read back; the driver confirms by doing it
  }
}
