import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { translate } from './strings';
import { getEngine } from '../engine';

const I18nContext = createContext({ lang: 'en', t: (k, v) => translate('en', k, v), setLang: () => {} });

export function I18nProvider({ children }) {
  const [lang, setLangState] = useState('en');
  useEffect(() => { getEngine().kv.get('lang').then((l) => { if (l) setLangState(l); }); }, []);
  const setLang = useCallback((l) => { setLangState(l); getEngine().kv.set('lang', l); }, []);
  const value = useMemo(() => ({ lang, setLang, t: (k, v) => translate(lang, k, v) }), [lang, setLang]);
  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export const useI18n = () => useContext(I18nContext);
