import { io } from 'socket.io-client';

/**
 * Driver socket: streams live GPS with acknowledgements.
 * The token is read on every (re)connect, so a refreshed token is always used.
 * If the server rejects the token, refresh it and reconnect (Socket.IO doesn't retry
 * automatically after an auth rejection).
 */
export function createDriverSocket({ url, getToken, refresh, onStatus = () => {} }) {
  let socket = null;

  function connect() {
    if (socket) { if (!socket.connected) socket.connect(); return; }
    socket = io(url, {
      transports: ['websocket'],
      auth: (cb) => { getToken().then((token) => cb({ token })).catch(() => cb({})); },
      reconnectionDelay: 1000,
      reconnectionDelayMax: 10000,
    });
    socket.on('connect', () => onStatus(true));
    socket.on('disconnect', () => onStatus(false));
    socket.on('connect_error', async (err) => {
      onStatus(false);
      if (err && err.message === 'unauthorized') {
        try { await refresh(); socket.connect(); } catch { /* signed out; app will show login */ }
      }
    });
  }

  function disconnect() {
    if (socket) { socket.removeAllListeners(); socket.disconnect(); socket = null; }
    onStatus(false);
  }

  /** Resolves to the server ack, or null if no ack arrived in time (treated as retryable). */
  async function emitWithAck(event, payload, timeoutMs = 10000) {
    if (!socket || !socket.connected) return null;
    try {
      return await socket.timeout(timeoutMs).emitWithAck(event, payload);
    } catch {
      return null;
    }
  }

  return { connect, disconnect, emitWithAck, connected: () => Boolean(socket && socket.connected) };
}
