/**
 * The driver app's engine: one instance per JS runtime (UI or headless background task).
 * Owns local storage, the API client, the socket, the GPS buffer + sync, and the action queue.
 */
import * as SQLite from 'expo-sqlite';
import { AppState } from 'react-native';
import { createApiClient } from '@school-bus/core';
import { API_ORIGIN, API_URL } from './config';
import { secureTokenStore } from './storage/secureStore';
import { migrate, createSqlitePointStore, createSqliteActionStore, createSqliteKv } from './storage/sqliteStores';
import { createPointBuffer } from './sync/pointBuffer';
import { createLocationSync } from './sync/locationSync';
import { createActionQueue } from './sync/actionQueue';
import { executeAction } from './sync/executeAction';
import { createDriverApi } from './api/driverApi';
import { createDriverSocket } from './realtime/socket';
import { filterLocations } from './location/pointFilter';
import { stopUpdates } from './location/updates';
import { createStore } from './state/store';

let engine = null;

export function getEngine() {
  if (!engine) engine = createEngine();
  return engine;
}

function createEngine() {
  const db = SQLite.openDatabaseSync('driver.db');
  migrate(db);
  const kv = createSqliteKv(db);

  const state = createStore({
    online: false,
    sync: { pending: 0, lastSyncAt: null, lastError: null, via: null },
    pendingActions: [],
    notice: null,          // { kind, message } for a one-off banner
    sessionExpired: false,
    activeTripId: null,
  });

  const api = createApiClient({
    baseUrl: API_URL,
    tokenStore: secureTokenStore,
    onSessionExpired: () => state.set({ sessionExpired: true }),
  });
  const driverApi = createDriverApi(api);

  let sync; // assigned below; socket status callback uses it
  const socket = createDriverSocket({
    url: API_ORIGIN,
    getToken: api.accessToken,
    refresh: api.refresh,
    onStatus: (online) => {
      state.set({ online });
      if (online && sync) sync.flush({ force: true });
    },
  });

  const buffer = createPointBuffer(createSqlitePointStore(db));

  async function setActiveTrip(tripId) {
    if (tripId) await kv.set('active_trip_id', tripId); else await kv.del('active_trip_id');
    state.set({ activeTripId: tripId || null });
  }
  const getActiveTrip = () => kv.get('active_trip_id');

  sync = createLocationSync({
    buffer,
    transport: {
      socketConnected: socket.connected,
      sendSocket: (tripId, points) => socket.emitWithAck('location', { tripId, points }),
      sendHttp: driverApi.uploadLocations,
    },
    onStatus: (s) => state.set({ sync: s }),
    onTripGone: async (tripId) => {
      // The office ended/cancelled the trip (or it's not ours): stop tracking it.
      if ((await getActiveTrip()) === tripId) {
        await stopUpdates();
        await setActiveTrip(null);
        state.set({ notice: { kind: 'trip_gone', tripId } });
      }
    },
  });

  const actions = createActionQueue({
    store: createSqliteActionStore(db),
    execute: (a) => executeAction(driverApi, a),
    onChange: (list) => state.set({ pendingActions: list }),
    onDropped: (a, err) => state.set({ notice: { kind: 'action_dropped', message: err && err.message } }),
  });

  let lastMs = 0;
  async function onLocations(locations) {
    const tripId = await getActiveTrip();
    if (!tripId) return;
    const r = filterLocations(locations, { lastMs });
    lastMs = r.lastMs;
    if (r.points.length) await buffer.add(tripId, r.points);
    await sync.flush();
  }

  // Foreground housekeeping: flush on resume and every 10 s.
  let timer = null;
  const tick = () => { sync.flush(); actions.drain(); };
  function startForegroundLoop() {
    if (!timer) timer = setInterval(tick, 10000);
  }
  AppState.addEventListener('change', (s) => {
    if (s === 'active') { sync.flush({ force: true }); actions.drain(); startForegroundLoop(); }
    else if (timer) { clearInterval(timer); timer = null; }
  });
  startForegroundLoop();
  getActiveTrip().then((id) => state.set({ activeTripId: id }));
  actions.pending().then((list) => state.set({ pendingActions: list }));

  return { db, kv, api, driverApi, socket, buffer, sync, actions, state, onLocations, setActiveTrip, getActiveTrip };
}
