'use strict';
/** In-memory implementations of the storage interfaces (tests, and fallback if SQLite fails). */

function createMemoryPointStore() {
  let rows = [];
  let seq = 0;
  return {
    async insert(newRows) {
      let inserted = 0;
      for (const r of newRows) {
        if (rows.some((x) => x.tripId === r.tripId && x.recordedAt === r.recordedAt)) continue;
        rows.push({ ...r, id: (seq += 1) });
        inserted += 1;
      }
      return inserted;
    },
    async oldest(limit) {
      return [...rows].sort((a, b) => (a.recordedAt < b.recordedAt ? -1 : a.recordedAt > b.recordedAt ? 1 : a.id - b.id)).slice(0, limit);
    },
    async deleteIds(ids) { const s = new Set(ids); rows = rows.filter((r) => !s.has(r.id)); },
    async deleteTrip(tripId) { rows = rows.filter((r) => r.tripId !== tripId); },
    async deleteOldest(n) { const drop = new Set((await this.oldest(n)).map((r) => r.id)); rows = rows.filter((r) => !drop.has(r.id)); },
    async count(tripId) { return tripId ? rows.filter((r) => r.tripId === tripId).length : rows.length; },
  };
}

function createMemoryKv() {
  const m = new Map();
  return {
    async get(k) { return m.has(k) ? m.get(k) : null; },
    async set(k, v) { m.set(k, v); },
    async del(k) { m.delete(k); },
  };
}

function createMemoryActionStore() {
  let items = [];
  return {
    async list() { return [...items].sort((a, b) => a.seq - b.seq); },
    async put(a) { items = items.filter((x) => x.id !== a.id).concat([a]); },
    async remove(id) { items = items.filter((x) => x.id !== id); },
  };
}

module.exports = { createMemoryPointStore, createMemoryKv, createMemoryActionStore };
