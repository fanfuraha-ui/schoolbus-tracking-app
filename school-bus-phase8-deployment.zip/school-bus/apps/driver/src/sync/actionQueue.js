'use strict';
/**
 * Offline queue for driver taps (stop arrived/departed/skipped, child boarded/dropped off,
 * incidents). Actions are saved first, then sent in order. If the phone is offline they stay
 * queued and are retried; the UI shows them immediately (optimistic) via pending().
 * Non-retryable rejections (e.g. trip already ended) are dropped and reported via onDropped.
 *
 * store: { list(), put(action), remove(id) }
 * execute(action): Promise — performs the API call; throws ApiError on failure
 */
function createActionQueue({ store, execute, onDropped = () => {}, onChange = () => {}, now = () => Date.now() }) {
  let seq = now();
  let draining = null;

  async function changed() { onChange(await store.list()); }

  async function enqueue({ type, tripId, payload }) {
    seq = Math.max(seq + 1, now());
    const action = { id: `${type}:${seq}:${Math.random().toString(36).slice(2, 8)}`, seq, type, tripId, payload, attempts: 0, createdAt: new Date(now()).toISOString() };
    await store.put(action);
    await changed();
    drain();
    return action;
  }

  async function run() {
    const results = { done: 0, dropped: 0, waiting: 0 };
    // Re-read the queue every step so actions tapped while we're sending are picked up, in order.
    for (;;) {
      const [action] = await store.list();
      if (!action) break;
      try {
        await execute(action);
        await store.remove(action.id);
        results.done += 1;
      } catch (err) {
        if (err && err.retryable) {
          await store.put({ ...action, attempts: action.attempts + 1, lastError: err.code });
          results.waiting = (await store.list()).length;
          break; // keep order: later actions wait for this one
        }
        await store.remove(action.id);
        results.dropped += 1;
        onDropped(action, err);
      }
    }
    await changed();
    return results;
  }

  function drain() {
    if (!draining) draining = run().finally(() => { draining = null; });
    return draining;
  }

  async function dropTrip(tripId) {
    for (const a of await store.list()) if (a.tripId === tripId) await store.remove(a.id);
    await changed();
  }

  return { enqueue, drain, dropTrip, pending: () => store.list() };
}

module.exports = { createActionQueue };
