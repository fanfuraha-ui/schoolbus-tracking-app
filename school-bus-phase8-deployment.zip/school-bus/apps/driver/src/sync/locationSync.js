'use strict';
/**
 * Moves buffered GPS points to the server.
 *  - Socket.IO when connected (lower latency, server acks each batch, ≤100 points),
 *    otherwise HTTP backlog upload (≤500 points). Both are idempotent on the server, so a
 *    batch that was delivered but whose ack got lost is simply resent harmlessly.
 *  - Points are removed from the buffer only after the server confirms.
 *  - Trip finished / not ours / gone  -> drop that trip's points and tell the app.
 *  - Network down, timeout, 5xx, rate limited -> keep points, back off (5 s .. 60 s).
 *  - One flush at a time (single-flight), safe to call from the background task and UI.
 *
 * transport: {
 *   socketConnected(): boolean,
 *   sendSocket(tripId, points): Promise<ack>   ack = { ok, ... } | { ok: false, error: { code } }
 *   sendHttp(tripId, points): Promise<result>  throws ApiError on failure
 * }
 */
const SOCKET_BATCH = 100;
const HTTP_BATCH = 500;
const TRIP_GONE = new Set(['trip_not_active', 'not_your_trip', 'not_found', 'forbidden']);
const BAD_BATCH = new Set(['validation_failed']);

class SyncError extends Error {
  constructor(code, message, retryable) { super(message || code); this.code = code; this.retryable = retryable; }
}

function createLocationSync({ buffer, transport, onTripGone = () => {}, onStatus = () => {}, now = () => Date.now(), maxRounds = 20 }) {
  const { toWirePoint } = require('./pointBuffer');
  let inflight = null;
  let failures = 0;
  let nextAllowedAt = 0;
  const status = { pending: 0, lastSyncAt: null, lastError: null, via: null };

  const emit = async () => { status.pending = await buffer.count(); onStatus({ ...status }); };

  async function sendBatch(tripId, rows) {
    const points = rows.map(toWirePoint);
    if (transport.socketConnected()) {
      const ack = await transport.sendSocket(tripId, points);
      if (!ack || !ack.ok) {
        const code = (ack && ack.error && ack.error.code) || 'no_ack';
        throw new SyncError(code, ack && ack.error && ack.error.message, !TRIP_GONE.has(code) && !BAD_BATCH.has(code));
      }
      status.via = 'socket';
      return ack;
    }
    status.via = 'http';
    return transport.sendHttp(tripId, points);
  }

  async function run() {
    let sent = 0;
    for (let round = 0; round < maxRounds; round += 1) {
      const limit = transport.socketConnected() ? SOCKET_BATCH : HTTP_BATCH;
      const batch = await buffer.nextBatch(limit);
      if (!batch) break;
      const ids = batch.rows.map((r) => r.id);
      try {
        await sendBatch(batch.tripId, batch.rows);
        await buffer.remove(ids);
        sent += ids.length;
        failures = 0;
        status.lastSyncAt = now();
        status.lastError = null;
      } catch (err) {
        const code = err.code || 'error';
        if (TRIP_GONE.has(code)) {
          await buffer.dropTrip(batch.tripId);
          onTripGone(batch.tripId, err);
          continue;
        }
        if (BAD_BATCH.has(code)) {
          await buffer.remove(ids); // never let one bad batch block the queue
          continue;
        }
        failures += 1;
        nextAllowedAt = now() + Math.min(60000, 5000 * 2 ** (failures - 1));
        status.lastError = code;
        break;
      }
    }
    await emit();
    return { sent, pending: status.pending };
  }

  /** Flush the buffer. force=true ignores the backoff window (e.g. app came to foreground). */
  function flush({ force = false } = {}) {
    if (inflight) return inflight;
    if (!force && now() < nextAllowedAt) return Promise.resolve({ sent: 0, skipped: 'backoff' });
    inflight = run().finally(() => { inflight = null; });
    return inflight;
  }

  return { flush, status: () => ({ ...status }), _state: () => ({ failures, nextAllowedAt }) };
}

module.exports = { createLocationSync, SyncError };
