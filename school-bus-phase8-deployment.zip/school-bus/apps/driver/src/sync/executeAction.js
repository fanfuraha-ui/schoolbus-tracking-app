'use strict';

/** Performs one queued driver action against the API. driverApi: see src/api/driverApi.js */
function executeAction(driverApi, action) {
  const { tripId, payload } = action;
  switch (action.type) {
    case 'stop':
      return driverApi.stopAction(tripId, payload.stopId, { action: payload.action, ...(payload.reason ? { reason: payload.reason } : {}) });
    case 'student':
      return driverApi.studentEvent(tripId, payload.studentId, { status: payload.status, ...(payload.stopId ? { stopId: payload.stopId } : {}) });
    case 'incident':
      return driverApi.reportIncident(tripId, payload);
    default:
      return Promise.reject(Object.assign(new Error(`Unknown action ${action.type}`), { retryable: false, code: 'unknown_action' }));
  }
}

module.exports = { executeAction };
