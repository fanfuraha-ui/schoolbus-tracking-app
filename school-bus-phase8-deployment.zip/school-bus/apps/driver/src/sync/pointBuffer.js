'use strict';
/**
 * Persistent GPS buffer. Every reading is written here FIRST (so nothing is lost if the
 * network or app dies) and deleted only after the server confirms it.
 * Capped (default 20 000 points, ~28 h at one point per 5 s); the oldest are dropped first.
 *
 * store: { insert(rows), oldest(limit), deleteIds(ids), deleteTrip(tripId), deleteOldest(n), count(tripId?) }
 */
function createPointBuffer(store, { maxPoints = 20000 } = {}) {
  async function add(tripId, points) {
    if (!points.length) return 0;
    const inserted = await store.insert(points.map((p) => ({ tripId, ...p })));
    const total = await store.count();
    if (total > maxPoints) await store.deleteOldest(total - maxPoints);
    return inserted;
  }

  /** Oldest points of the oldest trip in the buffer (a batch never mixes trips). */
  async function nextBatch(limit) {
    const rows = await store.oldest(limit);
    if (!rows.length) return null;
    const { tripId } = rows[0];
    return { tripId, rows: rows.filter((r) => r.tripId === tripId) };
  }

  return {
    add,
    nextBatch,
    remove: (ids) => store.deleteIds(ids),
    dropTrip: (tripId) => store.deleteTrip(tripId),
    count: (tripId) => store.count(tripId),
  };
}

const toWirePoint = (r) => ({
  lat: r.lat, lng: r.lng, recordedAt: r.recordedAt, speedMps: r.speedMps ?? null, headingDeg: r.headingDeg ?? null, accuracyM: r.accuracyM ?? null,
});

module.exports = { createPointBuffer, toWirePoint };
