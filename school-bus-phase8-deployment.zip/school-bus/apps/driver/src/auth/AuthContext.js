import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { Platform } from 'react-native';
import * as Crypto from 'expo-crypto';
import { getOrCreateDeviceUid } from '@school-bus/core';
import { getEngine } from '../engine';
import { secureTokenStore, secureKv } from '../storage/secureStore';
import { APP_VERSION } from '../config';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const engine = getEngine();
  const [state, setState] = useState({ loading: true, user: null, deviceUid: null });

  useEffect(() => {
    (async () => {
      const deviceUid = await getOrCreateDeviceUid(secureKv, Crypto.randomUUID);
      const tokens = await secureTokenStore.get();
      const user = await engine.kv.get('user');
      const signedIn = Boolean(tokens && user);
      setState({ loading: false, user: signedIn ? user : null, deviceUid });
      if (signedIn) engine.socket.connect();
    })();
    // Refresh token rejected (e.g. admin reset the device) -> back to login.
    return engine.state.subscribe(() => {
      if (engine.state.get().sessionExpired) {
        engine.state.set({ sessionExpired: false });
        engine.socket.disconnect();
        setState((s) => ({ ...s, user: null }));
      }
    });
  }, [engine]);

  const signIn = useCallback(async (phone, pin) => {
    const res = await engine.driverApi.login({
      phone, pin, device: { deviceUid: state.deviceUid, platform: Platform.OS === 'ios' ? 'ios' : 'android', appVersion: APP_VERSION },
    });
    await secureTokenStore.set({ accessToken: res.accessToken, refreshToken: res.refreshToken });
    await engine.kv.set('user', res.user);
    engine.socket.connect();
    setState((s) => ({ ...s, user: res.user }));
  }, [engine, state.deviceUid]);

  const signOut = useCallback(async () => {
    if (await engine.getActiveTrip()) throw Object.assign(new Error('active_trip'), { code: 'active_trip' });
    const tokens = await secureTokenStore.get();
    if (tokens) await engine.driverApi.logout(tokens.refreshToken).catch(() => {});
    await secureTokenStore.clear();
    await engine.kv.del('user');
    engine.socket.disconnect();
    setState((s) => ({ ...s, user: null }));
  }, [engine]);

  const value = useMemo(() => ({ ...state, signIn, signOut }), [state, signIn, signOut]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export const useAuth = () => useContext(AuthContext);
