import React, { useState } from 'react';
import { Modal, Pressable, StyleSheet, Switch, Text, TextInput, View } from 'react-native';
import { Button, Row } from '../ui/components';
import { colors, font, radius, space } from '../ui/theme';

const INCIDENT_TYPES = ['traffic', 'breakdown', 'accident', 'weather', 'road_closure', 'other'];
const CRITICAL = new Set(['breakdown', 'accident']);

function Sheet({ visible, onClose, title, children }) {
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <Pressable style={s.backdrop} onPress={onClose} />
      <View style={s.sheet}>
        <Text style={s.title}>{title}</Text>
        {children}
      </View>
    </Modal>
  );
}

/** One-tap incident report. Breakdown/accident always alert parents + office (server rule). */
export function IncidentSheet({ t, visible, onClose, onSend, sending }) {
  const [type, setType] = useState(null);
  const [note, setNote] = useState('');
  const [notify, setNotify] = useState(true);
  const critical = CRITICAL.has(type);
  const reset = () => { setType(null); setNote(''); setNotify(true); };
  return (
    <Sheet visible={visible} onClose={() => { reset(); onClose(); }} title={t('incident.title')}>
      <View style={s.grid}>
        {INCIDENT_TYPES.map((k) => (
          <Pressable key={k} onPress={() => setType(k)} style={[s.choice, type === k && s.choiceOn, CRITICAL.has(k) && s.choiceCritical]}
            accessibilityRole="radio" accessibilityState={{ selected: type === k }}>
            <Text style={[s.choiceText, type === k && s.choiceTextOn]}>{t(`incident.${k}`)}</Text>
          </Pressable>
        ))}
      </View>
      <TextInput style={s.input} value={note} onChangeText={setNote} placeholder={t('incident.note')} maxLength={300} multiline />
      {type && !critical ? (
        <Row style={s.switchRow}><Text style={s.switchText}>{t('incident.notify')}</Text><Switch value={notify} onValueChange={setNotify} /></Row>
      ) : null}
      {critical ? <Text style={s.critical}>{t('incident.criticalNote')}</Text> : null}
      <Row>
        <Button title={t('common.cancel')} variant="outline" onPress={() => { reset(); onClose(); }} />
        <Button title={t('incident.send')} variant={critical ? 'danger' : 'primary'} disabled={!type} loading={sending}
          onPress={() => { onSend({ type, note: note.trim() || undefined, notifyParents: critical || notify, severity: critical ? 'critical' : 'medium' }); reset(); }} />
      </Row>
    </Sheet>
  );
}

// Label is translated for the driver; the English reason is what the office sees in reports.
const SKIP_REASONS = [['skip.noChildren', 'No children waiting'], ['skip.roadClosed', 'Road closed'], ['skip.unsafe', 'Unsafe to stop']];

export function SkipSheet({ t, visible, stop, onClose, onSkip }) {
  return (
    <Sheet visible={visible} onClose={onClose} title={t('trip.skipReason')}>
      <Text style={s.stopName}>{stop ? stop.name : ''}</Text>
      {SKIP_REASONS.map(([key, reason]) => <View key={key} style={s.reason}><Button title={t(key)} variant="outline" onPress={() => onSkip(reason)} /></View>)}
      <Button title={t('common.cancel')} variant="ghost" onPress={onClose} />
    </Sheet>
  );
}

const s = StyleSheet.create({
  backdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.4)' },
  sheet: { backgroundColor: colors.card, padding: space.xl, borderTopLeftRadius: 20, borderTopRightRadius: 20, gap: space.md },
  title: { fontSize: font.title, fontWeight: '800', color: colors.ink },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: space.sm },
  choice: { borderWidth: 1, borderColor: colors.line, borderRadius: radius, paddingVertical: space.md, paddingHorizontal: space.md, minWidth: '47%', flexGrow: 1 },
  choiceCritical: { borderColor: colors.danger },
  choiceOn: { backgroundColor: colors.brand, borderColor: colors.brand },
  choiceText: { fontSize: font.body, color: colors.ink, textAlign: 'center', fontWeight: '600' },
  choiceTextOn: { fontWeight: '800' },
  input: { borderWidth: 1, borderColor: colors.line, borderRadius: radius, padding: space.md, minHeight: 64, fontSize: font.body, textAlignVertical: 'top' },
  switchRow: { justifyContent: 'space-between' },
  switchText: { fontSize: font.body, color: colors.ink, flex: 1 },
  critical: { color: colors.danger, fontWeight: '700' },
  stopName: { fontSize: font.body + 2, fontWeight: '700', color: colors.ink },
  reason: { flexDirection: 'row' },
});
