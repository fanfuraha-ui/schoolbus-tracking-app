import React from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { Banner, Button, Card, Pill, Row } from '../ui/components';
import { colors, font, space } from '../ui/theme';
import { currentStopIndex, etaMinutes, progress, riderActions, riderState, stopActions } from '../trip/selectors';
import { SyncBar } from './SyncBar';

const STATE_TONE = { boarded: 'success', dropped_off: 'success', absent: 'neutral', no_show: 'danger', waiting: 'warning' };
const STATUS_DOT = { pending: colors.line, approaching: colors.warning, arrived: colors.info, departed: colors.success, skipped: colors.muted };

/**
 * Presentational trip screen. `trip` already has queued (unsynced) actions applied.
 * Callbacks: onStopAction(stop, action), onRiderAction(stop, rider, status), onNavigate(stop),
 *            onReport(), onEnd()
 */
export function TripView({ t, trip, online, pendingPoints, pendingActions, nowMs = Date.now(), ending, notice,
  onStopAction, onRiderAction, onNavigate, onReport, onEnd }) {
  const idx = currentStopIndex(trip);
  const current = idx >= 0 ? trip.stops[idx] : null;
  const p = progress(trip);
  const morning = trip.direction === 'to_school';
  const finished = trip.status !== 'active';

  return (
    <View style={s.screen}>
      <SyncBar t={t} online={online} pendingPoints={pendingPoints} pendingActions={pendingActions} />
      <ScrollView contentContainerStyle={s.body}>
        <View style={s.header}>
          <Text style={s.route}>{trip.routeName}</Text>
          <Row>
            <Pill text={trip.plateNumber} />
            <Text style={s.sub}>{trip.scheduleName} · {t('trip.progress', { done: p.done, total: p.total })}</Text>
          </Row>
          <View style={s.track}><View style={[s.fill, { width: `${Math.round(p.ratio * 100)}%` }]} /></View>
        </View>

        {notice ? <Banner tone="warning" text={notice} /> : null}
        {finished ? <Banner tone="info" text={t('trip.ended')} /> : null}

        {current && !finished ? (
          <CurrentStop t={t} stop={current} morning={morning} nowMs={nowMs}
            onStopAction={onStopAction} onRiderAction={onRiderAction} onNavigate={onNavigate} direction={trip.direction} />
        ) : null}

        {!current && !finished ? (
          <Card><Text style={s.doneText}>✓ {t('trip.progress', { done: p.done, total: p.total })}</Text>
            <Button title={t('trip.end')} variant="success" onPress={onEnd} loading={ending} testID="end-trip-main" /></Card>
        ) : null}

        <Text style={s.section}>{t('trip.allStops')}</Text>
        <Card style={s.stopList}>
          {trip.stops.map((st, i) => (
            <View key={st.stopId} style={[s.stopRow, i === idx && s.stopRowCurrent]}>
              <View style={[s.dot, { backgroundColor: STATUS_DOT[st.status] || colors.line }]} />
              <Text style={[s.stopName, (st.status === 'departed' || st.status === 'skipped') && s.stopDone]} numberOfLines={1}>
                {st.sequence}. {st.name}
              </Text>
              <Text style={s.stopMeta}>
                {st.status === 'skipped' ? '—' : st.isSchool ? '🏫' : `${st.expected}`}
              </Text>
            </View>
          ))}
        </Card>

        {!finished ? (
          <View style={s.footer}>
            <Button title={t('trip.report')} variant="outline" onPress={onReport} testID="report" />
            {current ? <Button title={t('trip.end')} variant="danger" onPress={onEnd} loading={ending} testID="end-trip" /> : null}
          </View>
        ) : null}
      </ScrollView>
    </View>
  );
}

function CurrentStop({ t, stop, morning, nowMs, direction, onStopAction, onRiderAction, onNavigate }) {
  const eta = etaMinutes(stop.etaAt, nowMs);
  const actions = stopActions(stop);
  const actionVariant = { arrived: 'primary', departed: 'success', skipped: 'outline' };
  const riders = stop.riders || [];
  return (
    <Card style={s.current}>
      <Row style={s.spread}>
        <Text style={s.overline}>{t('trip.next')}</Text>
        {stop.status !== 'arrived' && eta !== null ? <Pill tone="info" text={eta === 0 ? t('trip.etaNow') : t('trip.eta', { min: eta })} /> : null}
      </Row>
      <Text style={s.stopTitle}>{stop.name}</Text>
      {!stop.isSchool ? <Text style={s.sub}>{t(morning ? 'trip.expected' : 'trip.expectedPm', { n: stop.expected })}</Text> : null}
      {stop.canSkip ? <Banner tone="info" text={t('trip.allAbsent')} /> : null}

      <View style={s.actions}>
        {actions.map((a) => (
          <Button key={a} title={t(`trip.${a}`)} variant={actionVariant[a]} onPress={() => onStopAction(stop, a)} testID={`stop-${a}`} />
        ))}
      </View>
      <Button title={`🧭 ${t('trip.navigate')}`} variant="ghost" compact onPress={() => onNavigate(stop)} />

      {riders.length ? <View style={s.riders}>
        {riders.map((r) => {
          const state = riderState(r);
          const buttons = riderActions(r, direction);
          return (
            <View key={r.studentId} style={s.rider}>
              <View style={s.riderInfo}>
                <Text style={[s.riderName, state === 'absent' && s.stopDone]}>{r.fullName}</Text>
                <Text style={s.riderClass}>{r.className || ''}</Text>
              </View>
              {state === 'absent' ? <Pill text={t('trip.absentToday')} />
                : buttons.length ? (
                  <Row>
                    {buttons.map((b) => (
                      <Button key={b} compact title={t(`trip.${b}`)} variant={b === 'no_show' ? 'outline' : 'success'}
                        onPress={() => onRiderAction(stop, r, b)} testID={`rider-${r.studentId}-${b}`} />
                    ))}
                  </Row>
                ) : <Pill tone={STATE_TONE[state]} text={t(`trip.${state}`)} />}
            </View>
          );
        })}
      </View> : null}
    </Card>
  );
}

const s = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.bg },
  body: { padding: space.lg, paddingBottom: 48 },
  header: { marginBottom: space.lg, gap: space.xs },
  route: { fontSize: font.title, fontWeight: '800', color: colors.ink },
  sub: { color: colors.muted, fontSize: font.small },
  track: { height: 6, backgroundColor: colors.line, borderRadius: 3, overflow: 'hidden', marginTop: space.sm },
  fill: { height: 6, backgroundColor: colors.success },
  current: { borderColor: colors.brand, borderWidth: 2 },
  spread: { justifyContent: 'space-between' },
  overline: { color: colors.brandDark, fontWeight: '800', textTransform: 'uppercase', fontSize: font.small },
  stopTitle: { fontSize: font.big, fontWeight: '800', color: colors.ink, marginVertical: space.xs },
  actions: { flexDirection: 'row', gap: space.sm, marginTop: space.md, marginBottom: space.xs },
  riders: { marginTop: space.md, borderTopWidth: 1, borderTopColor: colors.line },
  rider: { flexDirection: 'row', alignItems: 'center', paddingVertical: space.sm, borderBottomWidth: 1, borderBottomColor: colors.line, gap: space.sm },
  riderInfo: { flex: 1 },
  riderName: { fontSize: font.body, fontWeight: '600', color: colors.ink },
  riderClass: { fontSize: font.small - 1, color: colors.muted },
  section: { fontSize: font.small, fontWeight: '800', color: colors.muted, textTransform: 'uppercase', marginTop: space.md, marginBottom: space.sm },
  stopList: { paddingVertical: space.xs },
  stopRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: space.sm, gap: space.sm },
  stopRowCurrent: { backgroundColor: colors.warningBg, marginHorizontal: -space.lg, paddingHorizontal: space.lg },
  dot: { width: 10, height: 10, borderRadius: 5 },
  stopName: { flex: 1, fontSize: font.body, color: colors.ink },
  stopDone: { color: colors.muted, textDecorationLine: 'line-through' },
  stopMeta: { color: colors.muted, fontWeight: '700' },
  doneText: { fontSize: font.title, fontWeight: '800', color: colors.success, marginBottom: space.md },
  footer: { gap: space.sm, marginTop: space.lg },
});
