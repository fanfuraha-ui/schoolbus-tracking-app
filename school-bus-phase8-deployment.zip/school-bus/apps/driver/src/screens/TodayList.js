import React from 'react';
import { FlatList, RefreshControl, StyleSheet, Text, View } from 'react-native';
import { Banner, Button, Card, Pill } from '../ui/components';
import { colors, font, space } from '../ui/theme';
import { scheduleAction } from '../trip/selectors';

const STATUS_TONE = { active: 'info', completed: 'success', cancelled: 'danger', scheduled: 'neutral', not_started: 'neutral' };

export function TodayList({ t, schedules, loading, error, busyId, onAction, onRefresh }) {
  return (
    <FlatList
      contentContainerStyle={s.list}
      data={schedules || []}
      keyExtractor={(item) => item.scheduleId}
      refreshControl={<RefreshControl refreshing={Boolean(loading)} onRefresh={onRefresh} />}
      ListHeaderComponent={error ? <Banner tone="danger" text={error} /> : null}
      ListEmptyComponent={!loading ? <Text style={s.empty}>{t('today.empty')}</Text> : null}
      renderItem={({ item }) => {
        const action = scheduleAction(item);
        return (
          <Card>
            <View style={s.head}>
              <Text style={s.time}>{String(item.startTime).slice(0, 5)}</Text>
              <Pill text={item.plateNumber || '—'} />
            </View>
            <Text style={s.name}>{item.scheduleName}</Text>
            <Text style={s.route}>{item.routeName} · {t('today.students', { n: item.students })}</Text>
            {action ? (
              <Button
                title={t(action === 'resume' ? 'today.resume' : 'today.start')}
                variant={action === 'resume' ? 'success' : 'primary'}
                loading={busyId === item.scheduleId}
                disabled={Boolean(busyId) && busyId !== item.scheduleId}
                onPress={() => onAction(item, action)}
                testID={`schedule-${item.scheduleId}`}
              />
            ) : (
              <Pill tone={STATUS_TONE[item.tripStatus]} text={t(item.tripStatus === 'cancelled' ? 'today.cancelled' : 'today.done')} />
            )}
          </Card>
        );
      }}
    />
  );
}

const s = StyleSheet.create({
  list: { padding: space.lg },
  empty: { textAlign: 'center', color: colors.muted, marginTop: space.xl, fontSize: font.body },
  head: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  time: { fontSize: font.big, fontWeight: '800', color: colors.ink },
  name: { fontSize: font.body + 2, fontWeight: '700', color: colors.ink, marginTop: space.xs },
  route: { color: colors.muted, marginBottom: space.md, marginTop: 2 },
});
