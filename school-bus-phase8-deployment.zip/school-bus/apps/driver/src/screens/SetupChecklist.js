import React from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { Banner, Button, Card, Row } from '../ui/components';
import { colors, font, space } from '../ui/theme';

const ITEMS = [
  ['services', 'setup.services'],
  ['foreground', 'setup.foreground'],
  ['background', 'setup.background', 'setup.backgroundHelp'],
  ['battery', 'setup.battery', 'setup.batteryHelp'],
];

/** Phone readiness checklist shown before the first trip (and whenever something is off). */
export function SetupChecklist({ t, status, fixing, onFix, onContinue }) {
  return (
    <ScrollView contentContainerStyle={s.body}>
      {status && status.ready ? <Banner tone="success" text={`✓ ${t('setup.ready')}`} /> : null}
      {ITEMS.map(([key, label, help]) => {
        const ok = Boolean(status && status[key]);
        return (
          <Card key={key}>
            <Row style={s.spread}>
              <Text style={[s.mark, { color: ok ? colors.success : colors.danger }]}>{ok ? '✓' : '✕'}</Text>
              <Text style={s.label}>{t(label)}</Text>
              {!ok ? <View style={s.fix}><Button compact title={t('setup.fix')} onPress={() => onFix(key)} loading={fixing === key} /></View> : null}
            </Row>
            {help && !ok ? <Text style={s.help}>{t(help)}</Text> : null}
          </Card>
        );
      })}
      <Button title={t('common.confirm')} onPress={onContinue} disabled={!status || !status.ready} testID="setup-continue" />
    </ScrollView>
  );
}

const s = StyleSheet.create({
  body: { padding: space.lg },
  spread: { justifyContent: 'space-between' },
  mark: { fontSize: font.title, fontWeight: '800', width: 28 },
  label: { flex: 1, fontSize: font.body, color: colors.ink, fontWeight: '600' },
  fix: { width: 110 },
  help: { marginTop: space.sm, color: colors.muted, fontSize: font.small },
});
