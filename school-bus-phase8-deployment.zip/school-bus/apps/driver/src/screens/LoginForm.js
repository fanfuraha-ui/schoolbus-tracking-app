import React, { useState } from 'react';
import { KeyboardAvoidingView, Platform, StyleSheet, Text, TextInput, View } from 'react-native';
import { Banner, Button } from '../ui/components';
import { colors, font, radius, space } from '../ui/theme';

export function LoginForm({ t, onSubmit, busy, error }) {
  const [phone, setPhone] = useState('');
  const [pin, setPin] = useState('');
  const valid = phone.replace(/\D/g, '').length >= 9 && /^\d{4}$/.test(pin);
  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={s.wrap}>
      <View style={s.logo}><Text style={s.logoText}>🚌</Text></View>
      <Text style={s.title}>{t('login.title')}</Text>
      {error ? <Banner tone="danger" text={error} /> : null}
      <Text style={s.label}>{t('login.phone')}</Text>
      <TextInput
        style={s.input} value={phone} onChangeText={setPhone} keyboardType="phone-pad"
        placeholder="07XX XXX XXX" autoComplete="tel" textContentType="telephoneNumber" maxLength={16}
      />
      <Text style={s.label}>{t('login.pin')}</Text>
      <TextInput
        style={[s.input, s.pin]} value={pin} onChangeText={(v) => setPin(v.replace(/\D/g, '').slice(0, 4))}
        keyboardType="number-pad" secureTextEntry maxLength={4} placeholder="••••"
      />
      <Button title={t('login.submit')} onPress={() => onSubmit(phone, pin)} disabled={!valid} loading={busy} testID="login-submit" />
      <Text style={s.help}>{t('login.help')}</Text>
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  wrap: { flex: 1, padding: space.xl, justifyContent: 'center', backgroundColor: colors.bg },
  logo: { alignSelf: 'center', width: 72, height: 72, borderRadius: 36, backgroundColor: colors.brand, alignItems: 'center', justifyContent: 'center', marginBottom: space.lg },
  logoText: { fontSize: 36 },
  title: { fontSize: font.title, fontWeight: '800', color: colors.ink, textAlign: 'center', marginBottom: space.xl },
  label: { fontSize: font.small, color: colors.muted, marginBottom: space.xs, fontWeight: '600' },
  input: { backgroundColor: colors.card, borderWidth: 1, borderColor: colors.line, borderRadius: radius, padding: space.lg, fontSize: font.big - 6, marginBottom: space.lg, color: colors.ink },
  pin: { letterSpacing: 12, textAlign: 'center' },
  help: { marginTop: space.lg, color: colors.muted, textAlign: 'center', fontSize: font.small },
});
