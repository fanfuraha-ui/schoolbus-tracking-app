import React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import { colors, font, space } from '../ui/theme';

/** Thin status strip: online/offline + what is waiting to upload. */
export function SyncBar({ t, online, pendingPoints = 0, pendingActions = 0 }) {
  const backlog = pendingPoints > 20 || pendingActions > 0;
  const bg = online ? (backlog ? colors.warningBg : colors.successBg) : colors.dangerBg;
  const fg = online ? (backlog ? colors.warning : colors.success) : colors.danger;
  const parts = [online ? t('sync.online') : t('sync.offline')];
  if (pendingPoints > 20) parts.push(t('sync.pending', { n: pendingPoints }));
  if (pendingActions > 0) parts.push(t('sync.queued', { n: pendingActions }));
  return (
    <View style={[s.bar, { backgroundColor: bg }]} accessibilityLiveRegion="polite">
      <View style={[s.dot, { backgroundColor: fg }]} />
      <Text style={[s.text, { color: fg }]}>{parts.join(' · ')}</Text>
    </View>
  );
}

const s = StyleSheet.create({
  bar: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: space.lg, paddingVertical: space.sm, gap: space.sm },
  dot: { width: 8, height: 8, borderRadius: 4 },
  text: { fontSize: font.small, fontWeight: '600', flexShrink: 1 },
});
