import React, { useEffect, useState } from 'react';
import { ActivityIndicator, View } from 'react-native';
import { Redirect } from 'expo-router';
import { useAuth } from '../src/auth/AuthContext';
import { getEngine } from '../src/engine';

/** Launch: login, or straight back into an active trip after a restart/crash. */
export default function Index() {
  const { loading, user } = useAuth();
  const [activeTrip, setActiveTrip] = useState(undefined);
  useEffect(() => { getEngine().getActiveTrip().then(setActiveTrip); }, []);
  if (loading || activeTrip === undefined) {
    return <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}><ActivityIndicator size="large" /></View>;
  }
  if (!user) return <Redirect href="/login" />;
  if (activeTrip) return <Redirect href={`/trip/${activeTrip}`} />;
  return <Redirect href="/today" />;
}
