import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, Alert, AppState, Linking, View } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { useKeepAwake } from 'expo-keep-awake';
import { useI18n } from '../../src/i18n/I18nContext';
import { getEngine } from '../../src/engine';
import { useEngineState } from '../../src/state/useEngineState';
import { applyPending, navigationUrl } from '../../src/trip/selectors';
import { startTracking, stopTracking } from '../../src/location/tracking';
import { isTracking } from '../../src/location/updates';
import { TripView } from '../../src/screens/TripView';
import { IncidentSheet, SkipSheet } from '../../src/screens/Sheets';

const REFRESH_MS = 15000;

export default function TripScreen() {
  useKeepAwake(); // screen stays on while driving
  const { id } = useLocalSearchParams();
  const { t } = useI18n();
  const engine = getEngine();
  const online = useEngineState('online');
  const sync = useEngineState('sync');
  const pendingActions = useEngineState('pendingActions');
  const engineNotice = useEngineState('notice');
  const [trip, setTrip] = useState(null);
  const [notice, setNotice] = useState(null);
  const [incidentOpen, setIncidentOpen] = useState(false);
  const [skipStop, setSkipStop] = useState(null);
  const [ending, setEnding] = useState(false);
  const [now, setNow] = useState(Date.now());
  const mounted = useRef(true);

  const load = useCallback(async () => {
    try {
      const fresh = await engine.driverApi.trip(id);
      if (!mounted.current) return;
      setTrip(fresh);
      if (fresh.status === 'active' && !(await isTracking())) await startTracking(engine, fresh.id); // resume after restart
    } catch (err) {
      if (err.status === 403 || err.status === 404) { await stopTracking(engine); router.replace('/today'); }
      // offline: keep showing the last known trip
    }
  }, [engine, id]);

  useEffect(() => {
    mounted.current = true;
    load();
    const poll = setInterval(() => { load(); setNow(Date.now()); }, REFRESH_MS);
    const sub = AppState.addEventListener('change', (s) => { if (s === 'active') load(); });
    return () => { mounted.current = false; clearInterval(poll); sub.remove(); };
  }, [load]);

  useEffect(() => {
    if (!engineNotice) return;
    if (engineNotice.kind === 'trip_gone' && engineNotice.tripId === id) setNotice(t('trip.goneNotice'));
    if (engineNotice.kind === 'action_dropped') setNotice(t('trip.actionDropped', { message: engineNotice.message }));
    engine.state.set({ notice: null });
  }, [engineNotice, engine, id, t]);

  const view = useMemo(() => applyPending(trip, pendingActions), [trip, pendingActions]);

  const enqueue = async (type, payload) => {
    await engine.actions.enqueue({ type, tripId: id, payload });
    load();
  };

  function onStopAction(stop, action) {
    if (action === 'skipped') { setSkipStop(stop); return; }
    enqueue('stop', { stopId: stop.stopId, action });
  }

  function onEnd() {
    Alert.alert(t('trip.end'), t('trip.endConfirm'), [
      { text: t('common.cancel'), style: 'cancel' },
      {
        text: t('common.confirm'), style: 'destructive', onPress: async () => {
          setEnding(true);
          try {
            await engine.sync.flush({ force: true }); // last points first
            await engine.actions.drain();
            await engine.driverApi.endTrip(id);
            await stopTracking(engine);
            router.replace('/today');
          } catch (err) {
            if (err.retryable) setNotice(t('trip.needsConnection'));
            else if (err.code === 'trip_not_active') { await stopTracking(engine); router.replace('/today'); }
            else setNotice(err.message);
          } finally {
            setEnding(false);
          }
        },
      },
    ]);
  }

  if (!view) return <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}><ActivityIndicator size="large" /></View>;

  return (
    <>
      <TripView
        t={t} trip={view} online={online} pendingPoints={sync.pending} pendingActions={pendingActions.length}
        nowMs={now} ending={ending} notice={notice}
        onStopAction={onStopAction}
        onRiderAction={(stop, rider, status) => enqueue('student', { studentId: rider.studentId, status, stopId: stop.stopId })}
        onNavigate={(stop) => Linking.openURL(navigationUrl(stop))}
        onReport={() => setIncidentOpen(true)}
        onEnd={onEnd}
      />
      <IncidentSheet t={t} visible={incidentOpen} onClose={() => setIncidentOpen(false)}
        onSend={(payload) => { setIncidentOpen(false); enqueue('incident', payload); }} />
      <SkipSheet t={t} visible={Boolean(skipStop)} stop={skipStop} onClose={() => setSkipStop(null)}
        onSkip={(reason) => { enqueue('stop', { stopId: skipStop.stopId, action: 'skipped', reason }); setSkipStop(null); }} />
    </>
  );
}
