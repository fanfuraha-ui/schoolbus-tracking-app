import React, { useState } from 'react';
import { ScrollView, Text } from 'react-native';
import { router } from 'expo-router';
import { useAuth } from '../src/auth/AuthContext';
import { useI18n } from '../src/i18n/I18nContext';
import { useEngineState } from '../src/state/useEngineState';
import { Banner, Button, Card, Row } from '../src/ui/components';
import { colors, space } from '../src/ui/theme';

export default function Settings() {
  const { t, lang, setLang } = useI18n();
  const { user, deviceUid, signOut } = useAuth();
  const sync = useEngineState('sync');
  const pendingActions = useEngineState('pendingActions');
  const [error, setError] = useState(null);

  async function logout() {
    try { await signOut(); router.replace('/login'); } catch (err) {
      setError(err.code === 'active_trip' ? t('settings.logoutBlocked') : err.message);
    }
  }

  return (
    <ScrollView contentContainerStyle={{ padding: space.lg }}>
      {error ? <Banner tone="danger" text={error} /> : null}
      <Card>
        <Text style={{ fontWeight: '800', fontSize: 18, color: colors.ink }}>{user ? user.fullName : ''}</Text>
        <Text style={{ color: colors.muted, marginTop: space.xs }}>{t('settings.device')}: {deviceUid ? deviceUid.slice(0, 8) : '—'}</Text>
        <Text style={{ color: colors.muted }}>{t('sync.pending', { n: sync.pending })} · {t('sync.queued', { n: pendingActions.length })}</Text>
      </Card>
      <Card>
        <Text style={{ fontWeight: '700', marginBottom: space.sm, color: colors.ink }}>{t('settings.language')}</Text>
        <Row>
          <Button compact title="English" variant={lang === 'en' ? 'primary' : 'outline'} onPress={() => setLang('en')} />
          <Button compact title="Kiswahili" variant={lang === 'sw' ? 'primary' : 'outline'} onPress={() => setLang('sw')} />
        </Row>
      </Card>
      <Button title={t('setup.title')} variant="outline" onPress={() => router.push('/setup')} />
      <Text> </Text>
      <Button title={t('settings.logout')} variant="danger" onPress={logout} />
    </ScrollView>
  );
}
