import React, { useCallback, useEffect, useState } from 'react';
import { AppState } from 'react-native';
import { router } from 'expo-router';
import { useI18n } from '../src/i18n/I18nContext';
import { getEngine } from '../src/engine';
import { checkSetup, fixSetupItem } from '../src/location/permissions';
import { SetupChecklist } from '../src/screens/SetupChecklist';

export default function Setup() {
  const { t } = useI18n();
  const engine = getEngine();
  const [status, setStatus] = useState(null);
  const [fixing, setFixing] = useState(null);
  const refresh = useCallback(async () => setStatus(await checkSetup(engine.kv)), [engine]);

  useEffect(() => {
    refresh();
    // Re-check when the driver returns from the system settings page.
    const sub = AppState.addEventListener('change', (s) => { if (s === 'active') refresh(); });
    return () => sub.remove();
  }, [refresh]);

  async function onFix(key) {
    setFixing(key);
    try { await fixSetupItem(key, engine.kv); } finally { setFixing(null); refresh(); }
  }

  return <SetupChecklist t={t} status={status} fixing={fixing} onFix={onFix} onContinue={() => router.back()} />;
}
