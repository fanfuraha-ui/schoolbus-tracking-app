import React, { useEffect, useState } from 'react';
import { router } from 'expo-router';
import { useAuth } from '../src/auth/AuthContext';
import { useI18n } from '../src/i18n/I18nContext';
import { LoginForm } from '../src/screens/LoginForm';

export default function Login() {
  const { t } = useI18n();
  const { user, signIn } = useAuth();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  useEffect(() => { if (user) router.replace('/today'); }, [user]);

  async function submit(phone, pin) {
    setBusy(true);
    setError(null);
    try {
      await signIn(phone, pin);
    } catch (err) {
      setError(err.message || t('common.error'));
    } finally {
      setBusy(false);
    }
  }
  return <LoginForm t={t} onSubmit={submit} busy={busy} error={error} />;
}
