import React from 'react';
import { Stack, router } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { AuthProvider } from '../src/auth/AuthContext';
import { I18nProvider, useI18n } from '../src/i18n/I18nContext';
import { Button } from '../src/ui/components';
import { colors } from '../src/ui/theme';

function Screens() {
  const { t } = useI18n();
  const settingsButton = () => <Button compact variant="ghost" title="⚙" onPress={() => router.push('/settings')} />;
  return (
    <Stack screenOptions={{ headerStyle: { backgroundColor: colors.brand }, headerTintColor: colors.ink, headerTitleStyle: { fontWeight: '800' } }}>
      <Stack.Screen name="index" options={{ headerShown: false }} />
      <Stack.Screen name="login" options={{ headerShown: false }} />
      <Stack.Screen name="today" options={{ title: t('today.title'), headerRight: settingsButton, headerBackVisible: false }} />
      <Stack.Screen name="trip/[id]" options={{ title: t('appName'), headerRight: settingsButton }} />
      <Stack.Screen name="setup" options={{ title: t('setup.title') }} />
      <Stack.Screen name="settings" options={{ title: t('settings.title') }} />
    </Stack>
  );
}

export default function RootLayout() {
  return (
    <SafeAreaProvider>
      <I18nProvider>
        <AuthProvider>
          <StatusBar style="dark" />
          <Screens />
        </AuthProvider>
      </I18nProvider>
    </SafeAreaProvider>
  );
}
