import React, { useCallback, useState } from 'react';
import { Redirect, router, useFocusEffect } from 'expo-router';
import { useAuth } from '../src/auth/AuthContext';
import { useI18n } from '../src/i18n/I18nContext';
import { getEngine } from '../src/engine';
import { checkSetup } from '../src/location/permissions';
import { startTracking } from '../src/location/tracking';
import { TodayList } from '../src/screens/TodayList';

export default function Today() {
  const { t } = useI18n();
  const { user } = useAuth();
  const engine = getEngine();
  const [schedules, setSchedules] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [busyId, setBusyId] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setSchedules((await engine.driverApi.today()).schedules);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [engine]);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  async function onAction(schedule) {
    setBusyId(schedule.scheduleId);
    setError(null);
    try {
      const setup = await checkSetup(engine.kv);
      if (!setup.ready) { router.push('/setup'); return; }
      const { trip } = await engine.driverApi.startTrip(schedule.scheduleId); // idempotent: resumes if already active
      await startTracking(engine, trip.id);
      router.push(`/trip/${trip.id}`);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusyId(null);
    }
  }

  if (!user) return <Redirect href="/login" />;
  return <TodayList t={t} schedules={schedules} loading={loading} error={error} busyId={busyId} onAction={onAction} onRefresh={load} />;
}
