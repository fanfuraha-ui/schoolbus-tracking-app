# Driver app (Expo SDK 58 / React Native 0.88)

Android-first app for school-owned phones mounted in each bus. **Background GPS needs a development or production build. It does not work in Expo Go.**

## Run it
```bash
# from the repo root (npm workspaces link @school-bus/core)
npm install
cd apps/driver
npm run setup                    # expo install --fix: pins every expo-* package to SDK 58-compatible versions
npx expo-doctor@latest
npm run android                  # builds a dev client on a connected phone/emulator
# API on your laptop? Android emulator reaches it at http://10.0.2.2:4000 (the default)
EXPO_PUBLIC_API_URL=http://192.168.1.20:4000 npm start   # real phone on the same Wi-Fi
```
Seeded test login (from `apps/api/db/seeds/dev_seed.sql`): phone `0700000001`, PIN `1234`.

## Build the APK for the bus phones
1. `npm i -g eas-cli && eas login && eas init` (sets the project id).
2. Set the real API URL in `eas.json` under `driver-internal` (it must be **https**).
3. Change `ke.schoolbus.driver` in `app.config.js` to your own id.
4. Run `npm run build:apk` and install the APK on each bus phone (link or QR from EAS).

## How it stays reliable
| Situation | What happens |
|---|---|
| Screen off / app in background | An Android foreground service ("Trip in progress" notification) keeps GPS running |
| App killed or phone restarted mid-trip | The active trip is stored on the phone. On reopen, the app goes straight back to the trip and resumes tracking |
| No signal | Every GPS fix is saved to SQLite first. Up to about 28 h are stored, then uploaded in batches when signal returns. Taps (arrived, boarded, incident) are queued too and shown immediately |
| Signal returns | Live points stream over Socket.IO (with acknowledgements). The backlog goes over HTTP. Points are deleted only after the server confirms, and duplicates are harmless |
| Office ends or cancels the trip | Tracking stops and buffered points for that trip are discarded |
| Token expires | Refreshed automatically. If the account is reset, the driver is sent back to login |

## Phone setup (do once per bus phone)
The app's **Phone setup** checklist walks the driver through it:
- Turn GPS on.
- Allow location **"Allow all the time"**.
- Turn **battery optimisation off** for the app.

Battery optimisation matters most on Tecno, Infinix, itel, Xiaomi, Oppo and Samsung phones, whose battery savers kill background apps. https://dontkillmyapp.com has per-brand steps.

Recommended for school-owned phones:
- Keep the phone mounted and charging.
- Use Android **App pinning**, or a free MDM such as Android Enterprise / Google Workspace, to lock the phone to this app.

## Code map
| Path | What |
|---|---|
| `index.js` | Entry: defines the background location task before anything else |
| `app/` | Screens (Expo Router): login, today, trip/[id], setup, settings |
| `src/screens/` | Presentational components, rendered in tests |
| `src/engine.js` | Wires storage, API, socket, GPS sync, action queue |
| `src/location/` | Point filter, background task, tracking options, permissions checklist |
| `src/sync/` | GPS buffer, socket/HTTP sync, offline action queue |
| `src/storage/` | SQLite stores, secure token storage |
| `src/trip/selectors.js` | Next stop, buttons, optimistic updates |
| `src/i18n/strings.js` | English + Kiswahili |

## Tests
```bash
npm test   # needs the API's test Postgres for the contract/render tests (see apps/api/README)
```
| Test | Covers |
|---|---|
| `engine.test.js` | Point filter, buffer, sync engine, action queue, i18n parity |
| `sqlite.test.js` | The real SQLite stores, including surviving a restart |
| `contract.test.js` | The driver sync engine and action queue against the real backend services and database |
| `render.test.js` | Screens rendered with stubbed native views, including real trip data from the backend |
