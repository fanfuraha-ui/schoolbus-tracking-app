/**
 * Expo config for the driver app.
 *  - Background location via a foreground service (Android) / location background mode (iOS).
 *  - Set EXPO_PUBLIC_API_URL per build profile (eas.json). Production MUST be https://.
 *  - Change the bundle/package ids to your school's domain before the first build.
 */
const API_URL = process.env.EXPO_PUBLIC_API_URL || 'http://10.0.2.2:4000';
const ALWAYS = 'The bus location is shared with parents during a trip, including when the screen is off. Tracking stops when you end the trip.';

module.exports = ({ config }) => ({
  ...config,
  name: 'School Bus Driver',
  slug: 'school-bus-driver',
  scheme: 'schoolbusdriver',
  version: '0.5.0',
  orientation: 'portrait',
  userInterfaceStyle: 'light',
  ios: {
    bundleIdentifier: 'ke.schoolbus.driver',
    supportsTablet: false,
    infoPlist: {
      UIBackgroundModes: ['location'],
      NSLocationWhenInUseUsageDescription: 'Used to share the bus location with parents during a trip.',
      NSLocationAlwaysAndWhenInUseUsageDescription: ALWAYS,
    },
  },
  android: {
    package: 'ke.schoolbus.driver',
    permissions: [
      'ACCESS_FINE_LOCATION',
      'ACCESS_COARSE_LOCATION',
      'ACCESS_BACKGROUND_LOCATION',
      'FOREGROUND_SERVICE',
      'FOREGROUND_SERVICE_LOCATION',
      'WAKE_LOCK',
    ],
  },
  plugins: [
    'expo-router',
    'expo-secure-store',
    'expo-sqlite',
    ['expo-location', {
      locationAlwaysAndWhenInUsePermission: ALWAYS,
      isAndroidBackgroundLocationEnabled: true,
      isAndroidForegroundServiceEnabled: true,
    }],
  ],
  extra: {
    apiUrl: API_URL,
    eas: process.env.EAS_PROJECT_ID ? { projectId: process.env.EAS_PROJECT_ID } : undefined,
  },
});
