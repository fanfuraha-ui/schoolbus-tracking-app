'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { filterLocations } = require('../src/location/pointFilter');
const { createPointBuffer } = require('../src/sync/pointBuffer');
const { createLocationSync } = require('../src/sync/locationSync');
const { createActionQueue } = require('../src/sync/actionQueue');
const { createMemoryPointStore, createMemoryActionStore } = require('../src/sync/memoryStores');
const { strings, translate } = require('../src/i18n/strings');
const { ApiError } = require('@school-bus/core');

const loc = (ts, extra = {}) => ({ timestamp: ts, coords: { latitude: -1.25, longitude: 36.66, accuracy: 8, speed: 7.94, heading: 271.6, ...extra } });
const T0 = Date.parse('2026-11-17T04:00:00Z');

test('point filter: drops junk, bursts and future fixes; converts to API points', () => {
  const { points, lastMs } = filterLocations([
    loc(T0 + 5000), loc(T0), loc(T0 + 1000), // burst: 1 s after T0 dropped
    loc(T0 + 10000, { accuracy: 450 }),       // too inaccurate
    loc(T0 + 15000, { latitude: 0, longitude: 0 }),
    loc(T0 + 20000, { speed: -1, heading: -1 }),
    loc(T0 + 10 * 60000),                     // far future
  ], { nowMs: T0 + 30000 });
  assert.deepEqual(points.map((p) => p.recordedAt), ['2026-11-17T04:00:00.000Z', '2026-11-17T04:00:05.000Z', '2026-11-17T04:00:20.000Z']);
  assert.deepEqual(points[0], { lat: -1.25, lng: 36.66, recordedAt: '2026-11-17T04:00:00.000Z', speedMps: 7.9, headingDeg: 272, accuracyM: 8 });
  assert.equal(points[2].speedMps, null);
  assert.equal(lastMs, T0 + 20000);
  assert.equal(filterLocations([loc(T0 + 1000)], { lastMs: T0, nowMs: T0 + 5000 }).points.length, 0, 'gap is measured from the last stored point');
});

test('buffer: de-duplicates, batches per trip, caps size by dropping the oldest', async () => {
  const buf = createPointBuffer(createMemoryPointStore(), { maxPoints: 5 });
  const p = (s) => ({ lat: 1, lng: 1, recordedAt: new Date(T0 + s * 1000).toISOString() });
  await buf.add('A', [p(1), p(2), p(2)]);
  await buf.add('B', [p(3)]);
  assert.equal(await buf.count(), 3);
  const b = await buf.nextBatch(10);
  assert.equal(b.tripId, 'A');
  assert.equal(b.rows.length, 2);
  await buf.add('B', [p(4), p(5), p(6), p(7)]);
  assert.equal(await buf.count(), 5);
  assert.equal((await buf.nextBatch(10)).rows[0].recordedAt, p(3).recordedAt, 'oldest points were dropped');
});

function setup({ connected = false } = {}) {
  const buffer = createPointBuffer(createMemoryPointStore());
  const sent = { socket: [], http: [] };
  const t = {
    connected,
    socketReply: () => ({ ok: true }),
    httpReply: () => ({ accepted: 1 }),
    socketConnected() { return this.connected; },
    async sendSocket(tripId, points) { sent.socket.push({ tripId, n: points.length }); return this.socketReply(); },
    async sendHttp(tripId, points) { sent.http.push({ tripId, n: points.length, points }); return this.httpReply(); },
  };
  let clock = T0;
  const gone = [];
  const sync = createLocationSync({ buffer, transport: t, now: () => clock, onTripGone: (id) => gone.push(id) });
  const pts = (n, base = 0) => Array.from({ length: n }, (_, i) => ({ lat: -1.25, lng: 36.66, recordedAt: new Date(T0 + (base + i) * 5000).toISOString(), speedMps: 5 }));
  return { buffer, t, sent, sync, pts, gone, tick: (ms) => { clock += ms; } };
}

test('sync: uses socket batches of 100 when connected, HTTP batches of 500 otherwise', async () => {
  const a = setup({ connected: true });
  await a.buffer.add('trip-1', a.pts(250));
  const r = await a.sync.flush();
  assert.deepEqual(a.sent.socket.map((s) => s.n), [100, 100, 50]);
  assert.equal(r.pending, 0);

  const b = setup({ connected: false });
  await b.buffer.add('trip-1', b.pts(700));
  await b.sync.flush();
  assert.deepEqual(b.sent.http.map((s) => s.n), [500, 200]);
  assert.deepEqual(Object.keys(b.sent.http[0].points[0]).sort(), ['accuracyM', 'headingDeg', 'lat', 'lng', 'recordedAt', 'speedMps']);
});

test('sync: offline keeps points and backs off; later flush delivers everything', async () => {
  const s = setup();
  await s.buffer.add('trip-1', s.pts(10));
  s.t.httpReply = () => { throw new ApiError({ status: 0, code: 'network_error' }); };
  await s.sync.flush();
  assert.equal(await s.buffer.count(), 10, 'nothing lost');
  assert.equal(s.sync.status().lastError, 'network_error');
  assert.equal((await s.sync.flush()).skipped, 'backoff');
  s.t.httpReply = () => ({ accepted: 10 });
  s.tick(6000);
  await s.sync.flush();
  assert.equal(await s.buffer.count(), 0);
  assert.equal(s.sync.status().lastError, null);
});

test('sync: a lost socket ack is retried, ended trips are purged, bad batches never block the queue', async () => {
  const s = setup({ connected: true });
  await s.buffer.add('ended', s.pts(3));
  await s.buffer.add('live', s.pts(3, 100));
  let n = 0;
  s.t.socketReply = () => { n += 1; return n === 1 ? { ok: false, error: { code: 'trip_not_active' } } : { ok: true }; };
  await s.sync.flush();
  assert.deepEqual(s.gone, ['ended']);
  assert.equal(await s.buffer.count(), 0);

  await s.buffer.add('live', s.pts(2, 200));
  s.t.socketReply = () => null; // ack timed out
  await s.sync.flush();
  assert.equal(await s.buffer.count(), 2, 'no ack -> keep and retry');

  s.t.socketReply = () => ({ ok: false, error: { code: 'validation_failed' } });
  await s.sync.flush({ force: true });
  assert.equal(await s.buffer.count(), 0, 'invalid batch discarded');
});

test('sync: concurrent flush calls share one run', async () => {
  const s = setup();
  await s.buffer.add('t', s.pts(5));
  const [a, b] = await Promise.all([s.sync.flush(), s.sync.flush()]);
  assert.equal(a, b);
  assert.equal(s.sent.http.length, 1);
});

test('action queue: in order, waits while offline, drops rejected actions', async () => {
  const done = [];
  let offline = true;
  const dropped = [];
  const q = createActionQueue({
    store: createMemoryActionStore(),
    onDropped: (a, e) => dropped.push([a.type, e.code]),
    execute: async (a) => {
      if (offline) throw new ApiError({ status: 0, code: 'network_error' });
      if (a.payload.bad) throw new ApiError({ status: 409, code: 'trip_not_active' });
      done.push(a.payload.n);
    },
  });
  await q.enqueue({ type: 'stop', tripId: 't', payload: { n: 1 } });
  await q.enqueue({ type: 'student', tripId: 't', payload: { n: 2 } });
  await q.enqueue({ type: 'incident', tripId: 't', payload: { bad: true } });
  await q.drain();
  assert.equal((await q.pending()).length, 3);
  assert.equal((await q.pending())[0].attempts >= 1, true);
  offline = false;
  await q.drain();
  assert.deepEqual(done, [1, 2]);
  assert.deepEqual(dropped, [['incident', 'trip_not_active']]);
  assert.equal((await q.pending()).length, 0);
});

test('action queue: taps made while a send is in progress are not left behind', async () => {
  const done = [];
  const q = createActionQueue({
    store: createMemoryActionStore(),
    execute: async (a) => { await new Promise((r) => setTimeout(r, 5)); done.push(a.payload.n); },
  });
  await Promise.all([1, 2, 3, 4].map((n) => q.enqueue({ type: 'stop', tripId: 't', payload: { n } })));
  await q.drain();
  await q.drain();
  assert.deepEqual(done, [1, 2, 3, 4]);
  assert.equal((await q.pending()).length, 0);
});

test('i18n: English and Kiswahili have the same keys; placeholders filled', () => {
  assert.deepEqual(Object.keys(strings.sw).sort(), Object.keys(strings.en).sort());
  for (const k of Object.keys(strings.en)) {
    const ph = (s) => (s.match(/\{\w+\}/g) || []).sort().join();
    assert.equal(ph(strings.sw[k]), ph(strings.en[k]), `placeholders differ for ${k}`);
  }
  assert.equal(translate('sw', 'trip.progress', { done: 3, total: 11 }), 'Vituo 3 kati ya 11');
  assert.equal(translate('xx', 'trip.eta', { min: 4 }), 'ETA 4 min');
});
