'use strict';
/** TEST-ONLY: exposes Node's built-in SQLite with the expo-sqlite async API used by the app. */
const { DatabaseSync } = require('node:sqlite');

function openDatabaseSync(path = ':memory:') {
  const db = new DatabaseSync(path);
  const norm = (p) => (p || []).map((v) => (v === undefined ? null : v));
  return {
    execSync: (sql) => db.exec(sql),
    runAsync: async (sql, params) => { const r = db.prepare(sql).run(...norm(params)); return { changes: Number(r.changes), lastInsertRowId: Number(r.lastInsertRowid) }; },
    getAllAsync: async (sql, params) => db.prepare(sql).all(...norm(params)).map((r) => ({ ...r })),
    getFirstAsync: async (sql, params) => { const r = db.prepare(sql).get(...norm(params)); return r ? { ...r } : null; },
    closeSync: () => db.close(),
  };
}

module.exports = { openDatabaseSync };
