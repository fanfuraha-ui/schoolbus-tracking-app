'use strict';
/** TEST-ONLY: React Native primitives rendered as plain DOM elements for server-side rendering. */
const React = require('react');
const h = React.createElement;

const host = (tag) => function Host({ children, testID, accessibilityRole }) {
  return h(tag, { 'data-testid': testID, role: accessibilityRole }, typeof children === 'function' ? children({ pressed: false }) : children);
};

module.exports = {
  View: host('div'),
  Text: host('span'),
  ScrollView: host('section'),
  KeyboardAvoidingView: host('div'),
  SafeAreaView: host('div'),
  Pressable: function Pressable({ children, testID, disabled }) {
    return h('button', { 'data-testid': testID, disabled: Boolean(disabled) }, typeof children === 'function' ? children({ pressed: false }) : children);
  },
  TextInput: ({ value, placeholder }) => h('input', { value: value ?? '', placeholder, readOnly: true }),
  Switch: ({ value }) => h('input', { type: 'checkbox', checked: Boolean(value), readOnly: true }),
  ActivityIndicator: () => h('progress'),
  RefreshControl: () => null,
  Modal: ({ visible, children }) => (visible ? h('dialog', { open: true }, children) : null),
  FlatList: ({ data, renderItem, keyExtractor, ListHeaderComponent, ListEmptyComponent }) => h('ul', null,
    ListHeaderComponent || null,
    data.length ? data.map((item, index) => h('li', { key: keyExtractor ? keyExtractor(item, index) : index }, renderItem({ item, index }))) : (ListEmptyComponent || null)),
  StyleSheet: { create: (s) => s },
  Platform: { OS: 'android', select: (o) => o.android ?? o.default },
  Alert: { alert: () => {} },
  Linking: { openURL: async () => {}, openSettings: async () => {} },
  AppState: { addEventListener: () => ({ remove() {} }) },
};
