'use strict';
/** The real SQLite stores (same code the phone runs), on Node's built-in SQLite. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { openDatabaseSync } = require('./support/expoSqliteShim');
const { migrate, createSqlitePointStore, createSqliteActionStore, createSqliteKv } = require('../src/storage/sqliteStores');
const { createPointBuffer } = require('../src/sync/pointBuffer');
const { createActionQueue } = require('../src/sync/actionQueue');

const T0 = Date.parse('2026-11-17T04:00:00Z');
const pts = (n, base = 0) => Array.from({ length: n }, (_, i) => ({ lat: -1.25 + i * 1e-5, lng: 36.66, recordedAt: new Date(T0 + (base + i) * 5000).toISOString(), speedMps: 5.5, headingDeg: null, accuracyM: 7 }));

test('point store: dedupe, ordering, per-trip batches, cap, deletes (250+ rows across chunks)', async () => {
  const db = openDatabaseSync();
  migrate(db);
  const buf = createPointBuffer(createSqlitePointStore(db), { maxPoints: 300 });
  assert.equal(await buf.add('trip-A', pts(250)), 250);
  assert.equal(await buf.add('trip-A', pts(10)), 0, 'duplicates ignored');
  await buf.add('trip-B', pts(100, 1000));
  assert.equal(await buf.count(), 300, 'capped at 300');
  assert.equal(await buf.count('trip-A'), 200, 'oldest 50 dropped');
  const batch = await buf.nextBatch(500);
  assert.equal(batch.tripId, 'trip-A');
  assert.equal(batch.rows.length, 200);
  assert.deepEqual(Object.keys(batch.rows[0]).sort(), ['accuracyM', 'headingDeg', 'id', 'lat', 'lng', 'recordedAt', 'speedMps', 'tripId']);
  assert.equal(batch.rows[0].speedMps, 5.5);
  await buf.remove(batch.rows.map((r) => r.id));
  assert.equal(await buf.count(), 100);
  await buf.dropTrip('trip-B');
  assert.equal(await buf.count(), 0);
});

test('data survives an app restart (file database reopened)', async () => {
  const file = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'drv-')), 'driver.db');
  let db = openDatabaseSync(file);
  migrate(db);
  await createPointBuffer(createSqlitePointStore(db)).add('trip-X', pts(5));
  await createSqliteKv(db).set('active_trip_id', 'trip-X');
  const q = createActionQueue({ store: createSqliteActionStore(db), execute: async () => { const e = new Error('offline'); e.retryable = true; throw e; } });
  await q.enqueue({ type: 'stop', tripId: 'trip-X', payload: { stopId: 's1', action: 'arrived' } });
  await q.drain();
  db.closeSync();

  db = openDatabaseSync(file); // "phone rebooted"
  migrate(db);
  assert.equal(await createPointBuffer(createSqlitePointStore(db)).count(), 5);
  assert.equal(await createSqliteKv(db).get('active_trip_id'), 'trip-X');
  const pending = await createSqliteActionStore(db).list();
  assert.equal(pending.length, 1);
  assert.equal(pending[0].attempts, 1);
  assert.deepEqual(pending[0].payload, { stopId: 's1', action: 'arrived' });
  db.closeSync();
});
