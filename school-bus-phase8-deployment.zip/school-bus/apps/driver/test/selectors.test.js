'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const S = require('../src/trip/selectors');

const trip = () => ({
  id: 't1', direction: 'to_school',
  stops: [
    { stopId: 's1', status: 'arrived', isSchool: false, riders: [{ studentId: 'a', events: [] }, { studentId: 'b', absent: true, events: [] }] },
    { stopId: 's2', status: 'approaching', isSchool: false, etaAt: new Date(Date.now() + 4 * 60000).toISOString(), riders: [{ studentId: 'c', events: [] }] },
    { stopId: 's3', status: 'pending', isSchool: false, riders: [] },
    { stopId: 'school', status: 'pending', isSchool: true, riders: [] },
  ],
});

test('pending actions are applied optimistically, like the server would', () => {
  const t = S.applyPending(trip(), [
    { tripId: 't1', type: 'student', payload: { studentId: 'a', status: 'boarded' } },
    { tripId: 't1', type: 'stop', payload: { stopId: 's2', action: 'arrived' } },
    { tripId: 'other', type: 'stop', payload: { stopId: 's3', action: 'arrived' } },
  ]);
  assert.equal(t.stops[0].status, 'departed', 'arriving at s2 closes s1');
  assert.equal(t.stops[1].status, 'arrived');
  assert.equal(t.stops[2].status, 'pending');
  assert.deepEqual(t.stops[0].riders[0].events, ['boarded']);
  assert.equal(trip().stops[0].status, 'arrived', 'original untouched');
  const skipped = S.applyPending(trip(), [{ tripId: 't1', type: 'stop', payload: { stopId: 's3', action: 'skipped', reason: 'Road closed' } }]);
  assert.equal(skipped.stops[2].status, 'skipped');
  assert.equal(skipped.stops[1].status, 'approaching', 'skipping does not close earlier stops');
});

test('current stop, progress, buttons', () => {
  const t = trip();
  assert.equal(S.currentStopIndex(t), 0);
  assert.deepEqual(S.stopActions(t.stops[0]), ['departed']);
  assert.deepEqual(S.stopActions(t.stops[1]), ['arrived', 'skipped']);
  assert.deepEqual(S.stopActions(t.stops[3]), ['arrived'], 'school gate cannot be skipped');
  t.stops[0].status = 'departed';
  assert.deepEqual(S.progress(t), { done: 1, total: 4, ratio: 0.25 });
  assert.equal(S.etaMinutes(t.stops[1].etaAt), 4);
  assert.equal(S.etaMinutes(null), null);
  assert.equal(S.etaMinutes(new Date(Date.now() - 60000).toISOString()), 0);
});

test('rider states and check-on buttons per direction', () => {
  assert.equal(S.riderState({ absent: true, events: [] }), 'absent');
  assert.equal(S.riderState({ events: ['boarded', 'dropped_off'] }), 'dropped_off');
  assert.deepEqual(S.riderActions({ events: [] }, 'to_school'), ['boarded', 'no_show']);
  assert.deepEqual(S.riderActions({ events: ['boarded'] }, 'to_school'), []);
  assert.deepEqual(S.riderActions({ events: ['boarded'] }, 'from_school'), ['dropped_off']);
  assert.deepEqual(S.riderActions({ absent: true, events: [] }, 'from_school'), []);
});

test('schedule button and navigation link', () => {
  assert.equal(S.scheduleAction({ tripStatus: 'scheduled' }), 'start');
  assert.equal(S.scheduleAction({ tripStatus: 'active' }), 'resume');
  assert.equal(S.scheduleAction({ tripStatus: 'completed' }), null);
  assert.equal(S.navigationUrl({ lat: -1.2, lng: 36.7 }), 'https://www.google.com/maps/dir/?api=1&destination=-1.2,36.7&travelmode=driving');
});
