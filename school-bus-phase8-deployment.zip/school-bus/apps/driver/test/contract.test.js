'use strict';
/**
 * Contract test: the driver app's real sync engine and offline action queue, talking to the
 * real backend services (validated by the backend's own request schemas) on a real database.
 * Catches payload-shape drift between the two codebases.
 */
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('path');

const API = path.join(__dirname, '../../api');
const { freshDatabase, fakeBroadcaster, quietLogger } = require(path.join(API, 'test/support/context'));
const { createSettingsService } = require(path.join(API, 'src/services/settingsService'));
const { createTripService } = require(path.join(API, 'src/services/tripService'));
const S = require(path.join(API, 'src/http/schemas'));
const { AppError } = require(path.join(API, 'src/lib/errors'));

const { ApiError } = require('@school-bus/core');
const { filterLocations } = require('../src/location/pointFilter');
const { createPointBuffer } = require('../src/sync/pointBuffer');
const { createLocationSync } = require('../src/sync/locationSync');
const { createActionQueue } = require('../src/sync/actionQueue');
const { createMemoryPointStore, createMemoryActionStore } = require('../src/sync/memoryStores');
const { executeAction } = require('../src/sync/executeAction');

let pool; let trips; let driverId; let tripId; let trip;

/** Simulates the network: JSON round-trip + backend validation + service call, errors as ApiError. */
async function wire(schema, payload, fn) {
  const parsed = schema.safeParse(JSON.parse(JSON.stringify(payload)));
  if (!parsed.success) throw new ApiError({ status: 400, code: 'validation_failed', message: parsed.error.issues[0].message });
  try {
    return await fn(parsed.data);
  } catch (err) {
    if (err instanceof AppError) throw new ApiError({ status: err.status, code: err.code, message: err.message });
    throw err;
  }
}

/** Driver API surface used by executeAction(), backed by the real trip service. */
const fakeDriverApi = () => ({
  stopAction: (tId, stopId, body) => wire(S.driver.stopAction, body, (b) => trips.markStop({ tripId: tId, stopId, driverId, ...b })),
  studentEvent: (tId, studentId, body) => wire(S.driver.studentEvent, body, (b) => trips.recordStudentEvent({ tripId: tId, studentId, driverId, ...b })),
  reportIncident: (tId, body) => wire(S.driver.incident, body, (b) => trips.reportIncident({ tripId: tId, driverId, ...b })),
});

test.before(async () => {
  let db;
  ({ pool, db } = await freshDatabase('schoolbus_test_driver_contract'));
  trips = createTripService({ db, settings: createSettingsService({ db }), broadcaster: fakeBroadcaster(), logger: quietLogger });
  driverId = (await db.one("SELECT id FROM users WHERE phone = '+254700000004'")).id;
  const sched = (await db.one("SELECT sc.id FROM schedules sc JOIN routes r ON r.id = sc.route_id WHERE r.name LIKE 'Route 4%' AND sc.direction = 'to_school'")).id;
  trip = (await trips.startTrip({ scheduleId: sched, driverId })).trip;
  tripId = trip.id;
});
test.after(() => pool.end());

test('GPS from expo-location -> buffer -> HTTP and socket payloads accepted and processed by the backend', async () => {
  const stop1 = trip.stops[0];
  const now = Date.now();
  const readings = [40, 30, 20, 10, 0].map((ago, i) => ({
    timestamp: now - ago * 1000,
    coords: { latitude: stop1.lat + (4 - i) * 0.0004, longitude: stop1.lng, accuracy: 6, speed: i === 4 ? 0.3 : 6, heading: 180 },
  }));
  const { points } = filterLocations(readings, { nowMs: now });
  const buffer = createPointBuffer(createMemoryPointStore());
  await buffer.add(tripId, points);

  let connected = false;
  const results = [];
  const sync = createLocationSync({
    buffer,
    transport: {
      socketConnected: () => connected,
      sendSocket: async (tId, pts) => {
        try {
          const r = await wire(S.driver.socketLocations, { tripId: tId, points: pts }, (d) => trips.ingestPoints({ tripId: d.tripId, driverId, points: d.points, source: 'live' }));
          results.push(['socket', r]);
          return { ok: true, ...r };
        } catch (err) { return { ok: false, error: { code: err.code, message: err.message } }; }
      },
      sendHttp: async (tId, pts) => {
        const r = await wire(S.driver.locations, { points: pts }, (d) => trips.ingestPoints({ tripId: tId, driverId, points: d.points, source: 'backlog' }));
        results.push(['http', r]);
        return r;
      },
    },
  });

  await sync.flush();
  assert.equal(results[0][0], 'http');
  assert.equal(results[0][1].accepted, 5);
  assert.equal(results[0][1].processed, 5);
  assert.equal(await buffer.count(), 0);

  // Same points again over the socket (e.g. app restarted before deleting them): harmless.
  await buffer.add(tripId, points);
  connected = true;
  await sync.flush();
  assert.equal(results[1][0], 'socket');
  assert.equal(results[1][1].duplicates, 5);
  assert.equal(await buffer.count(), 0);

  const fresh = await trips.getTripDetail(tripId, { driverId });
  assert.equal(fresh.stops[0].status, 'arrived', 'server detected arrival from the driver app points');
});

test('offline action queue -> backend: check-on, depart, incident; ended trip purges its points', async () => {
  const fresh = await trips.getTripDetail(tripId, { driverId });
  const stop1 = fresh.stops[0];
  const child = stop1.riders[0];
  const api = fakeDriverApi();
  const dropped = [];
  const q = createActionQueue({ store: createMemoryActionStore(), execute: (a) => executeAction(api, a), onDropped: (a, e) => dropped.push(e.code) });
  await q.enqueue({ type: 'student', tripId, payload: { studentId: child.studentId, status: 'boarded' } });
  await q.enqueue({ type: 'stop', tripId, payload: { stopId: stop1.stopId, action: 'departed' } });
  await q.enqueue({ type: 'incident', tripId, payload: { type: 'traffic', notifyParents: true, note: 'Jam at Muguga' } });
  await q.drain();
  assert.equal((await q.pending()).length, 0);
  assert.deepEqual(dropped, []);
  const after = await trips.getTripDetail(tripId, { driverId });
  assert.equal(after.stops[0].status, 'departed');
  assert.deepEqual(after.stops[0].riders.find((r) => r.studentId === child.studentId).events, ['boarded']);

  await trips.endTrip({ tripId, driverId });
  const buffer = createPointBuffer(createMemoryPointStore());
  await buffer.add(tripId, [{ lat: stop1.lat, lng: stop1.lng, recordedAt: new Date().toISOString() }]);
  const gone = [];
  const sync = createLocationSync({
    buffer,
    onTripGone: (id) => gone.push(id),
    transport: {
      socketConnected: () => false,
      sendSocket: async () => ({ ok: true }),
      sendHttp: (tId, pts) => wire(S.driver.locations, { points: pts }, (d) => trips.ingestPoints({ tripId: tId, driverId, points: d.points })),
    },
  });
  await sync.flush();
  assert.deepEqual(gone, [tripId]);
  assert.equal(await buffer.count(), 0);

  await q.enqueue({ type: 'stop', tripId, payload: { stopId: after.stops[1].stopId, action: 'arrived' } });
  await q.drain();
  assert.deepEqual(dropped, ['trip_not_active'], 'actions on an ended trip are dropped, not retried forever');
});
