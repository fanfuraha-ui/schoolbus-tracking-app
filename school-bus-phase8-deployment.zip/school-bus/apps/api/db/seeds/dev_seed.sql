-- dev_seed.sql — DEVELOPMENT ONLY. Never run against production.
-- Creates a realistic dataset matching the school's real scale:
--   1 admin, 6 drivers, 6 buses (33 seats), 6 routes, 12 schedules (AM + PM),
--   10 stops + school gate per schedule, 180 students, 150 guardian households,
--   and one active morning trip today on Route 1 for testing the live flow.
--
-- Logins:  admin@school.test / ChangeMe!2026
--          drivers +254700000001 .. +254700000006, PIN 1234
--          guardians +254711000001 .. (OTP flow; no password)
-- pgcrypto is used only here, to produce bcrypt hashes the API (bcryptjs) can verify.

BEGIN;
CREATE EXTENSION IF NOT EXISTS pgcrypto;

UPDATE app_settings SET value = '"Greenfield Academy"' WHERE key = 'school_name';

-- ---------- Admin ----------
INSERT INTO users (role, full_name, email, password_hash)
VALUES ('admin', 'Transport Manager', 'admin@school.test', crypt('ChangeMe!2026', gen_salt('bf', 10)));

-- ---------- Buses, drivers, routes ----------
CREATE TEMP TABLE seed_routes (n int PRIMARY KEY, area text, bus_id uuid, driver_id uuid, route_id uuid,
                               am_id uuid, pm_id uuid) ON COMMIT DROP;
INSERT INTO seed_routes (n, area)
VALUES (1, 'Kikuyu Town'), (2, 'Gikambura'), (3, 'Kinoo'), (4, 'Muguga'), (5, 'Thogoto'), (6, 'Zambezi');

WITH b AS (
  INSERT INTO buses (plate_number)
  SELECT 'KDA ' || (100 + n) || chr(64 + n) FROM seed_routes
  RETURNING id, plate_number
)
UPDATE seed_routes r SET bus_id = b.id FROM b WHERE b.plate_number = 'KDA ' || (100 + r.n) || chr(64 + r.n);

WITH u AS (
  INSERT INTO users (role, full_name, phone, pin_hash)
  SELECT 'driver', 'Driver ' || area, '+25470000000' || n, crypt('1234', gen_salt('bf', 10))
  FROM seed_routes
  RETURNING id, phone
), d AS (
  INSERT INTO drivers (user_id) SELECT id FROM u RETURNING user_id
)
UPDATE seed_routes r SET driver_id = u.id FROM u WHERE u.phone = '+25470000000' || r.n;

WITH ins AS (
  INSERT INTO routes (name, description, default_bus_id, default_driver_id)
  SELECT 'Route ' || n || ' - ' || area, 'Serves ' || area, bus_id, driver_id FROM seed_routes
  RETURNING id, default_bus_id
)
UPDATE seed_routes r SET route_id = ins.id FROM ins WHERE ins.default_bus_id = r.bus_id;

-- ---------- Schedules ----------
WITH ins AS (
  INSERT INTO schedules (route_id, name, direction, start_time)
  SELECT route_id, 'Morning pickup', 'to_school', '06:30' FROM seed_routes
  RETURNING id, route_id
)
UPDATE seed_routes r SET am_id = ins.id FROM ins WHERE ins.route_id = r.route_id;

WITH ins AS (
  INSERT INTO schedules (route_id, name, direction, start_time)
  SELECT route_id, 'Afternoon drop-off', 'from_school', '16:00' FROM seed_routes
  RETURNING id, route_id
)
UPDATE seed_routes r SET pm_id = ins.id FROM ins WHERE ins.route_id = r.route_id;

-- ---------- Stops ----------
-- School gate at (-1.246300, 36.662900). Route n heads out at bearing n*60 degrees;
-- physical stage k (1..10) sits k*0.6 km from school.
-- AM: sequence 1 = farthest stage (k=10) ... sequence 10 = k=1, sequence 11 = school.
-- PM: sequence 1 = school, sequence 2..11 = k=1..10.
INSERT INTO stops (schedule_id, sequence, name, landmark, lat, lng, scheduled_time, is_school)
SELECT r.am_id, 11 - k,
       r.area || ' Stage ' || k, 'Seeded stop',
       round((-1.2463 + (k * 0.6 / 111.0) * cos(radians(r.n * 60)))::numeric, 6),
       round(( 36.6629 + (k * 0.6 / 111.0) * sin(radians(r.n * 60)))::numeric, 6),
       time '06:30' + make_interval(mins => (10 - k) * 6),
       false
FROM seed_routes r CROSS JOIN generate_series(1, 10) k
UNION ALL
SELECT r.am_id, 11, 'School gate', 'Main gate', -1.2463, 36.6629, time '07:30', true
FROM seed_routes r
UNION ALL
SELECT r.pm_id, 1, 'School gate', 'Main gate', -1.2463, 36.6629, time '16:00', true
FROM seed_routes r
UNION ALL
SELECT r.pm_id, k + 1,
       r.area || ' Stage ' || k, 'Seeded stop',
       round((-1.2463 + (k * 0.6 / 111.0) * cos(radians(r.n * 60)))::numeric, 6),
       round(( 36.6629 + (k * 0.6 / 111.0) * sin(radians(r.n * 60)))::numeric, 6),
       time '16:00' + make_interval(mins => k * 6),
       false
FROM seed_routes r CROSS JOIN generate_series(1, 10) k;

-- ---------- Students (180: 30 per route, 3 per stage) ----------
CREATE TEMP TABLE seed_students (i int PRIMARY KEY, student_id uuid, route_n int, stage_k int, household int)
  ON COMMIT DROP;
INSERT INTO seed_students (i, route_n, stage_k, household)
SELECT i,
       (i - 1) / 30 + 1,
       ((i - 1) % 30) / 3 + 1,
       CASE WHEN i % 6 = 0 THEN i - 1 ELSE i END   -- every 6th child is a sibling of the previous one
FROM generate_series(1, 180) i;

WITH ins AS (
  INSERT INTO students (admission_no, full_name, class_name)
  SELECT 'ADM' || lpad(i::text, 4, '0'), 'Student ' || i, 'Grade ' || (i % 6 + 1) FROM seed_students
  RETURNING id, admission_no
)
UPDATE seed_students s SET student_id = ins.id FROM ins WHERE ins.admission_no = 'ADM' || lpad(s.i::text, 4, '0');

-- ---------- Guardians (150 households) ----------
CREATE TEMP TABLE seed_guardians (household int PRIMARY KEY, user_id uuid) ON COMMIT DROP;
WITH ins AS (
  INSERT INTO users (role, full_name, phone)
  SELECT 'guardian', 'Parent ' || household, '+254711' || lpad(household::text, 6, '0')
  FROM (SELECT DISTINCT household FROM seed_students) h
  RETURNING id, phone
)
INSERT INTO seed_guardians (household, user_id)
SELECT substr(phone, 8)::int, id FROM ins;

INSERT INTO guardians (user_id, channel_mode, consent_at, consent_version)
SELECT user_id,
       CASE WHEN household % 5 = 0 THEN 'sms'::channel_mode ELSE 'push_then_sms'::channel_mode END,  -- ~20% basic phones
       now(), '2026-11'
FROM seed_guardians;

INSERT INTO student_guardians (student_id, guardian_id, relationship, is_primary)
SELECT s.student_id, g.user_id, 'mother', true
FROM seed_students s JOIN seed_guardians g USING (household);

-- ---------- Stop assignments ----------
INSERT INTO student_stops (student_id, schedule_id, stop_id)
SELECT s.student_id, r.am_id, st.id
FROM seed_students s
JOIN seed_routes r ON r.n = s.route_n
JOIN stops st ON st.schedule_id = r.am_id AND st.sequence = 11 - s.stage_k
UNION ALL
SELECT s.student_id, r.pm_id, st.id
FROM seed_students s
JOIN seed_routes r ON r.n = s.route_n
JOIN stops st ON st.schedule_id = r.pm_id AND st.sequence = s.stage_k + 1;

-- ---------- Today's live test trip: Route 1 morning, started 10 min ago ----------
INSERT INTO trips (schedule_id, service_date, bus_id, driver_id, status, scheduled_start_at, started_at)
SELECT am_id, current_date, bus_id, driver_id, 'active',
       (current_date + time '06:30') AT TIME ZONE 'Africa/Nairobi',
       now() - interval '10 minutes'
FROM seed_routes WHERE n = 1;

INSERT INTO trip_stop_events (trip_id, schedule_id, stop_id, status)
SELECT t.id, t.schedule_id, st.id, 'pending'
FROM trips t JOIN stops st ON st.schedule_id = t.schedule_id
WHERE t.service_date = current_date;

-- All three children at Route 1 Stage 1 are off today -> that stop should show can_skip.
INSERT INTO absences (student_id, service_date, reason, reported_by)
SELECT s.student_id, current_date, 'Sick', g.user_id
FROM seed_students s JOIN seed_guardians g USING (household)
WHERE s.route_n = 1 AND s.stage_k = 1;

-- A short GPS trail approaching the first stop.
INSERT INTO location_points (trip_id, recorded_at, lat, lng, speed_mps, heading_deg, accuracy_m)
SELECT t.id, now() - make_interval(secs => (20 - g) * 5),
       round((-1.2463 + ((6.6 - g * 0.03) / 111.0) * cos(radians(60)))::numeric, 6),
       round(( 36.6629 + ((6.6 - g * 0.03) / 111.0) * sin(radians(60)))::numeric, 6),
       8.5, 240, 6
FROM trips t CROSS JOIN generate_series(1, 20) g
WHERE t.service_date = current_date;

INSERT INTO bus_positions (bus_id, trip_id, lat, lng, speed_mps, heading_deg, accuracy_m, recorded_at)
SELECT t.bus_id, t.id, lp.lat, lp.lng, lp.speed_mps, lp.heading_deg, lp.accuracy_m, lp.recorded_at
FROM trips t
JOIN LATERAL (SELECT * FROM location_points WHERE trip_id = t.id ORDER BY recorded_at DESC LIMIT 1) lp ON true
WHERE t.service_date = current_date;

COMMIT;
