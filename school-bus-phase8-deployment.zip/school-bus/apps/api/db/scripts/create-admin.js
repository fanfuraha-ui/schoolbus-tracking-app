'use strict';
/**
 * Create a dashboard admin from the server (the production database starts with none).
 *
 *   docker compose -f deploy/docker-compose.prod.yml exec api node db/scripts/create-admin.js "Lucy Wairimu" lucy@school.ac.ke
 *   (locally: DATABASE_URL=... node db/scripts/create-admin.js "Name" email)
 *
 * Prints a random one-time password; the admin changes it after signing in. Further admins can be
 * created the same way, or from the dashboard by an existing admin.
 */
const crypto = require('crypto');
const { z } = require('zod');
const { loadConfig } = require('../../src/config');
const { createDb, createPgPool } = require('../../src/db');
const { createPasswordHasher } = require('../../src/lib/passwords');
const { createSettingsService } = require('../../src/services/settingsService');
const { createAdminService } = require('../../src/services/admin/adminService');

// No 0/O/1/l/I: easy to read out over the phone.
const ALPHABET = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function oneTimePassword(length = 14) {
  return Array.from(crypto.randomBytes(length), (b) => ALPHABET[b % ALPHABET.length]).join('');
}

async function main(argv, deps = {}) {
  const [fullName, email] = argv;
  const args = z.object({ fullName: z.string().trim().min(2).max(120), email: z.string().trim().email() })
    .safeParse({ fullName, email });
  if (!args.success) {
    console.error('Usage: node db/scripts/create-admin.js "Full Name" email@school.ac.ke');
    return 2;
  }
  const db = deps.db || createDb(createPgPool(loadConfig().databaseUrl, { max: 1 }));
  const hasher = deps.hasher || createPasswordHasher();
  const admins = createAdminService({ db, hasher, settings: createSettingsService({ db }) });
  const password = oneTimePassword();
  try {
    const u = await admins.createAdmin({ ...args.data, password }, { actorId: null });
    console.log(`Created admin ${u.fullName} <${u.email}>`);
    console.log(`One-time password: ${password}`);
    console.log('Sign in at the dashboard and change it: Settings > Your password.');
    return 0;
  } catch (err) {
    console.error(err.code === 'email_in_use' || err.status === 409 ? `An admin with ${args.data.email} already exists.` : err.message);
    return 1;
  } finally {
    if (!deps.db) await db.pool.end();
  }
}

if (require.main === module) main(process.argv.slice(2)).then((code) => process.exit(code));
module.exports = { main, oneTimePassword };
