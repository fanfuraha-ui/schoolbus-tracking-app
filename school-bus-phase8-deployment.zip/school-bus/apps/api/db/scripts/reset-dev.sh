#!/usr/bin/env bash
# Drop and rebuild the DEV database: migrations -> seed -> constraint tests.
# Usage: DATABASE_URL=postgres://user:pass@localhost:5432/schoolbus_dev ./db/scripts/reset-dev.sh
set -euo pipefail

: "${DATABASE_URL:?DATABASE_URL is not set}"
case "$DATABASE_URL" in
  *prod*|*production*) echo "Refusing to reset a database whose URL mentions prod." >&2; exit 1 ;;
esac

DB_DIR="$(cd "$(dirname "$0")/.." && pwd)"
DB_NAME="${DATABASE_URL##*/}"; DB_NAME="${DB_NAME%%\?*}"
ADMIN_URL="${DATABASE_URL%/*}/postgres"

echo "Recreating database $DB_NAME"
psql "$ADMIN_URL" -q -v ON_ERROR_STOP=1 -c "DROP DATABASE IF EXISTS \"$DB_NAME\" WITH (FORCE)" -c "CREATE DATABASE \"$DB_NAME\""

node "$DB_DIR/migrate.js"
psql "$DATABASE_URL" -q -v ON_ERROR_STOP=1 -f "$DB_DIR/seeds/dev_seed.sql"
echo "Seed loaded. Running constraint tests:"
psql "$DATABASE_URL" -q -v ON_ERROR_STOP=1 -f "$DB_DIR/tests/constraints_test.sql" 2>&1 | sed 's/^.*NOTICE:  //'
