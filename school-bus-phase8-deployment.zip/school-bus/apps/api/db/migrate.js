#!/usr/bin/env node
'use strict';
/**
 * Minimal forward-only migration runner.
 *
 *   DATABASE_URL=postgres://... node db/migrate.js            apply pending migrations
 *   DATABASE_URL=postgres://... node db/migrate.js --status   list applied / pending
 *
 * - Applies db/migrations/NNNN_name.sql in filename order, each in its own transaction.
 * - Records version + SHA-256 checksum in schema_migrations; refuses to run if an
 *   already-applied file has been edited (write a new migration instead).
 * - Takes a Postgres advisory lock so two app instances starting together can't race.
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { Client } = require('pg');

const MIGRATIONS_DIR = path.join(__dirname, 'migrations');
const LOCK_KEY = 727001; // arbitrary, unique to this app
const FILE_PATTERN = /^\d{4}_[a-z0-9_]+\.sql$/;

const sha256 = (text) => crypto.createHash('sha256').update(text).digest('hex');

function loadMigrations() {
  return fs
    .readdirSync(MIGRATIONS_DIR)
    .filter((f) => FILE_PATTERN.test(f))
    .sort()
    .map((file) => {
      const sql = fs.readFileSync(path.join(MIGRATIONS_DIR, file), 'utf8');
      return { file, sql, checksum: sha256(sql) };
    });
}

async function main() {
  const statusOnly = process.argv.includes('--status');
  if (!process.env.DATABASE_URL) {
    throw new Error('DATABASE_URL is not set');
  }

  const client = new Client({ connectionString: process.env.DATABASE_URL });
  await client.connect();

  try {
    await client.query('SELECT pg_advisory_lock($1)', [LOCK_KEY]);
    await client.query(`
      CREATE TABLE IF NOT EXISTS schema_migrations (
        version    text PRIMARY KEY,
        checksum   text NOT NULL,
        applied_at timestamptz NOT NULL DEFAULT now()
      )`);

    const { rows } = await client.query('SELECT version, checksum FROM schema_migrations');
    const applied = new Map(rows.map((r) => [r.version, r.checksum]));
    const migrations = loadMigrations();

    // Integrity check before doing anything.
    for (const m of migrations) {
      if (applied.has(m.file) && applied.get(m.file) !== m.checksum) {
        throw new Error(`${m.file} was modified after it was applied. Add a new migration instead.`);
      }
    }

    const pending = migrations.filter((m) => !applied.has(m.file));

    if (statusOnly) {
      for (const m of migrations) console.log(`${applied.has(m.file) ? 'applied' : 'pending'}  ${m.file}`);
      return;
    }

    if (pending.length === 0) {
      console.log('Database is up to date.');
      return;
    }

    for (const m of pending) {
      await client.query('BEGIN');
      try {
        await client.query(m.sql);
        await client.query('INSERT INTO schema_migrations (version, checksum) VALUES ($1, $2)', [m.file, m.checksum]);
        await client.query('COMMIT');
        console.log(`applied  ${m.file}`);
      } catch (err) {
        await client.query('ROLLBACK');
        err.message = `${m.file}: ${err.message}`;
        throw err;
      }
    }
  } finally {
    await client.query('SELECT pg_advisory_unlock($1)', [LOCK_KEY]).catch(() => {});
    await client.end();
  }
}

main().catch((err) => {
  console.error(`Migration failed: ${err.message}`);
  process.exit(1);
});
