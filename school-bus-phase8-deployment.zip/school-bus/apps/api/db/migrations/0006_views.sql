-- 0006_views.sql
-- Read models used by the trip engine, notification worker, driver app and admin dashboard.

-- Who to notify for each stop of a trip: active students assigned to that stop on the
-- trip's schedule, minus absences, joined to guardians who receive alerts.
-- A guardian with two children at one stop appears twice; the notification dedupe key
-- (trip:stop:guardian:event) collapses that to a single alert.
CREATE VIEW trip_stop_recipients AS
SELECT t.id                 AS trip_id,
       ss.stop_id,
       s.id                 AS student_id,
       s.full_name          AS student_name,
       g.user_id            AS guardian_id,
       u.full_name          AS guardian_name,
       u.phone,
       g.channel_mode,
       g.preferred_language,
       g.quiet_hours_start,
       g.quiet_hours_end
FROM trips t
JOIN student_stops ss     ON ss.schedule_id = t.schedule_id
JOIN students s           ON s.id = ss.student_id AND s.is_active
JOIN student_guardians sg ON sg.student_id = s.id AND sg.receives_alerts
JOIN guardians g          ON g.user_id = sg.guardian_id
JOIN users u              ON u.id = g.user_id AND u.is_active
WHERE NOT EXISTS (
  SELECT 1 FROM absences a
  WHERE a.student_id = s.id
    AND a.service_date = t.service_date
    AND (a.schedule_id IS NULL OR a.schedule_id = t.schedule_id)
);

-- Driver stop list for a trip: riders expected vs absent, and whether the stop can be skipped.
CREATE VIEW trip_stop_manifest AS
SELECT t.id AS trip_id,
       st.id AS stop_id,
       st.sequence,
       st.name,
       st.lat,
       st.lng,
       st.scheduled_time,
       st.is_school,
       count(s.id)                                      AS assigned,
       count(s.id) FILTER (WHERE ab.is_absent)          AS absent,
       count(s.id) FILTER (WHERE NOT ab.is_absent)      AS expected,
       (NOT st.is_school
        AND count(s.id) > 0
        AND count(s.id) FILTER (WHERE NOT ab.is_absent) = 0) AS can_skip
FROM trips t
JOIN stops st              ON st.schedule_id = t.schedule_id AND st.is_active
LEFT JOIN student_stops ss ON ss.stop_id = st.id
LEFT JOIN students s       ON s.id = ss.student_id AND s.is_active
-- EXISTS (not a join) so a student with two matching absences is counted once.
LEFT JOIN LATERAL (
  SELECT EXISTS (
    SELECT 1 FROM absences a
    WHERE a.student_id = s.id
      AND a.service_date = t.service_date
      AND (a.schedule_id IS NULL OR a.schedule_id = t.schedule_id)
  ) AS is_absent
) ab ON true
GROUP BY t.id, st.id;

-- Seats assigned vs bus capacity per schedule (admin warning when over capacity).
CREATE VIEW schedule_load AS
SELECT sc.id          AS schedule_id,
       r.name         AS route_name,
       sc.name        AS schedule_name,
       b.plate_number,
       b.capacity,
       count(ss.student_id) FILTER (WHERE s.is_active) AS assigned_students,
       count(ss.student_id) FILTER (WHERE s.is_active) > COALESCE(b.capacity, 0) AS over_capacity
FROM schedules sc
JOIN routes r              ON r.id = sc.route_id
LEFT JOIN buses b          ON b.id = r.default_bus_id
LEFT JOIN student_stops ss ON ss.schedule_id = sc.id
LEFT JOIN students s       ON s.id = ss.student_id
GROUP BY sc.id, r.name, sc.name, b.plate_number, b.capacity;

-- Live fleet map for the admin dashboard.
CREATE VIEW active_fleet AS
SELECT t.id AS trip_id,
       t.service_date,
       r.name  AS route_name,
       sc.name AS schedule_name,
       b.id    AS bus_id,
       b.plate_number,
       u.full_name AS driver_name,
       u.phone     AS driver_phone,
       t.started_at,
       bp.lat, bp.lng, bp.speed_mps, bp.heading_deg,
       bp.recorded_at AS position_at,
       now() - bp.recorded_at AS position_age
FROM trips t
JOIN schedules sc        ON sc.id = t.schedule_id
JOIN routes r            ON r.id = sc.route_id
JOIN buses b             ON b.id = t.bus_id
JOIN users u             ON u.id = t.driver_id
LEFT JOIN bus_positions bp ON bp.bus_id = t.bus_id AND bp.trip_id = t.id
WHERE t.status = 'active';
