-- 0008_notification_worker.sql
-- Phase 4: the notifications table becomes the send queue, plus calendar/monitor support.

-- New auto-detected incident types (raised by the worker's monitors for the admin dashboard).
ALTER TYPE incident_type ADD VALUE IF NOT EXISTS 'stalled';
ALTER TYPE incident_type ADD VALUE IF NOT EXISTS 'gps_lost';
ALTER TYPE incident_type ADD VALUE IF NOT EXISTS 'not_started';

ALTER TABLE incidents
  ADD COLUMN auto_detected boolean NOT NULL DEFAULT false;
-- Auto-detected incidents (e.g. GPS lost) can also close themselves when the condition clears.
ALTER TABLE incidents DROP CONSTRAINT incidents_check;
ALTER TABLE incidents ADD CONSTRAINT incidents_resolved_by_check
  CHECK (resolved_at IS NULL OR resolved_by IS NOT NULL OR auto_detected);

-- Queue mechanics: a row is "due" when status = 'queued' and next_attempt_at <= now().
-- A sender claims rows by setting locked_until, so several worker instances can run safely.
ALTER TABLE notifications
  ADD COLUMN trip_event_id   bigint REFERENCES trip_events(id) ON DELETE SET NULL,
  ADD COLUMN title           text,                                   -- push notification title
  ADD COLUMN payload         jsonb NOT NULL DEFAULT '{}'::jsonb,     -- push data, SMS fallback text, etc.
  ADD COLUMN next_attempt_at timestamptz NOT NULL DEFAULT now(),
  ADD COLUMN locked_until    timestamptz;
CREATE INDEX notifications_due_idx ON notifications (next_attempt_at) WHERE status = 'queued';
CREATE INDEX notifications_event_idx ON notifications (trip_event_id);

-- School calendar: days with no bus service (holidays, closures). The daily planner skips them.
CREATE TABLE no_service_days (
  service_date date PRIMARY KEY,
  reason       text NOT NULL CHECK (length(btrim(reason)) > 0),
  created_by   uuid REFERENCES users(id) ON DELETE SET NULL,
  created_at   timestamptz NOT NULL DEFAULT now()
);

-- Bookkeeping for periodic jobs (e.g. nightly maintenance runs once per day).
CREATE TABLE job_runs (
  name        text PRIMARY KEY,
  last_run_at timestamptz NOT NULL,
  last_result jsonb
);
