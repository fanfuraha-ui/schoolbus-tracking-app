-- 0002_people.sql
-- Users, auth artefacts, guardians, drivers, students.

CREATE TABLE users (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  role            user_role NOT NULL,
  full_name       text NOT NULL CHECK (length(btrim(full_name)) > 0),
  phone           ke_phone UNIQUE,
  email           text,
  password_hash   text,          -- admins (bcrypt)
  pin_hash        text,          -- drivers (bcrypt of 4-digit PIN)
  totp_secret_enc text,          -- admins, optional 2FA (encrypted by the API)
  is_active       boolean NOT NULL DEFAULT true,
  last_login_at   timestamptz,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now(),
  -- Lets role-specific tables enforce the role via a composite FK.
  CONSTRAINT users_id_role_uq UNIQUE (id, role),
  CONSTRAINT admin_has_credentials CHECK (role <> 'admin'    OR (email IS NOT NULL AND password_hash IS NOT NULL)),
  CONSTRAINT driver_has_pin        CHECK (role <> 'driver'   OR (phone IS NOT NULL AND pin_hash IS NOT NULL)),
  CONSTRAINT guardian_has_phone    CHECK (role <> 'guardian' OR phone IS NOT NULL)
);
CREATE UNIQUE INDEX users_email_lower_uq ON users (lower(email)) WHERE email IS NOT NULL;
CREATE TRIGGER users_updated_at BEFORE UPDATE ON users
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- Phones/browsers a user is signed in on. fcm_token is what push is sent to.
CREATE TABLE devices (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  device_uid   text NOT NULL,     -- stable install ID from the app
  app          app_kind NOT NULL,
  platform     device_platform NOT NULL,
  fcm_token    text,
  app_version  text,
  last_seen_at timestamptz NOT NULL DEFAULT now(),
  created_at   timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, device_uid, app)
);
-- A token belongs to exactly one install; re-registering moves it.
CREATE UNIQUE INDEX devices_fcm_token_uq ON devices (fcm_token) WHERE fcm_token IS NOT NULL;

CREATE TABLE refresh_tokens (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  device_id   uuid REFERENCES devices(id) ON DELETE CASCADE,
  token_hash  text NOT NULL UNIQUE,  -- SHA-256 of the token; raw token never stored
  expires_at  timestamptz NOT NULL,
  revoked_at  timestamptz,
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX refresh_tokens_user_idx ON refresh_tokens (user_id) WHERE revoked_at IS NULL;

-- SMS one-time codes for parent login.
CREATE TABLE otp_codes (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  phone       ke_phone NOT NULL,
  purpose     otp_purpose NOT NULL DEFAULT 'login',
  code_hash   text NOT NULL,
  attempts    smallint NOT NULL DEFAULT 0 CHECK (attempts BETWEEN 0 AND 10),
  expires_at  timestamptz NOT NULL,
  consumed_at timestamptz,
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX otp_codes_phone_idx ON otp_codes (phone, created_at DESC);

-- Guardian profile + notification preferences (one row per guardian user).
CREATE TABLE guardians (
  user_id            uuid PRIMARY KEY,
  role               user_role NOT NULL DEFAULT 'guardian' CHECK (role = 'guardian'),
  channel_mode       channel_mode NOT NULL DEFAULT 'push_then_sms',
  preferred_language text NOT NULL DEFAULT 'en' CHECK (preferred_language IN ('en', 'sw')),
  quiet_hours_start  time,   -- non-critical alerts suppressed in this window
  quiet_hours_end    time,
  consent_at         timestamptz,  -- Kenya DPA consent captured at first login
  consent_version    text,
  created_at         timestamptz NOT NULL DEFAULT now(),
  updated_at         timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (user_id, role) REFERENCES users (id, role) ON DELETE CASCADE,
  CHECK ((quiet_hours_start IS NULL) = (quiet_hours_end IS NULL))
);
CREATE TRIGGER guardians_updated_at BEFORE UPDATE ON guardians
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE drivers (
  user_id              uuid PRIMARY KEY,
  role                 user_role NOT NULL DEFAULT 'driver' CHECK (role = 'driver'),
  licence_number       text,
  registered_device_id uuid REFERENCES devices(id) ON DELETE SET NULL, -- PIN login only works here
  created_at           timestamptz NOT NULL DEFAULT now(),
  updated_at           timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (user_id, role) REFERENCES users (id, role) ON DELETE CASCADE
);
CREATE TRIGGER drivers_updated_at BEFORE UPDATE ON drivers
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE students (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  admission_no text NOT NULL UNIQUE,
  full_name    text NOT NULL CHECK (length(btrim(full_name)) > 0),
  class_name   text,
  is_active    boolean NOT NULL DEFAULT true,
  notes        text,
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now()
);
CREATE TRIGGER students_updated_at BEFORE UPDATE ON students
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE student_guardians (
  student_id      uuid NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  guardian_id     uuid NOT NULL REFERENCES guardians(user_id) ON DELETE CASCADE,
  relationship    guardian_relationship NOT NULL DEFAULT 'guardian',
  is_primary      boolean NOT NULL DEFAULT false,
  receives_alerts boolean NOT NULL DEFAULT true,
  created_at      timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (student_id, guardian_id)
);
CREATE INDEX student_guardians_guardian_idx ON student_guardians (guardian_id);
CREATE UNIQUE INDEX student_guardians_one_primary_uq
  ON student_guardians (student_id) WHERE is_primary;
