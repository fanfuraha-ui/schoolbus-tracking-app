-- 0001_foundation.sql
-- Shared enum types, domains, helper functions and system settings.
-- Requires PostgreSQL 15+ (uses UNIQUE NULLS NOT DISTINCT in later migrations).

-- ---------- Enum types ----------
CREATE TYPE user_role             AS ENUM ('admin', 'driver', 'guardian');
CREATE TYPE app_kind              AS ENUM ('driver', 'parent', 'admin');
CREATE TYPE device_platform       AS ENUM ('android', 'ios', 'web');
CREATE TYPE guardian_relationship AS ENUM ('mother', 'father', 'guardian', 'other');
CREATE TYPE schedule_direction    AS ENUM ('to_school', 'from_school');
CREATE TYPE trip_status           AS ENUM ('scheduled', 'active', 'completed', 'cancelled');
CREATE TYPE stop_event_status     AS ENUM ('pending', 'approaching', 'arrived', 'departed', 'skipped');
CREATE TYPE student_event_status  AS ENUM ('boarded', 'dropped_off', 'absent', 'no_show');
CREATE TYPE channel_mode          AS ENUM ('push', 'sms', 'push_then_sms');
CREATE TYPE notification_channel  AS ENUM ('push', 'sms');
CREATE TYPE notification_status   AS ENUM ('queued', 'sent', 'delivered', 'failed', 'skipped');
CREATE TYPE notification_event    AS ENUM (
  'approaching', 'arrived', 'boarded', 'dropped_off',
  'delay', 'stalled', 'trip_not_started',
  'trip_cancelled', 'route_change', 'breakdown'
);
CREATE TYPE incident_type         AS ENUM ('traffic', 'breakdown', 'accident', 'weather', 'road_closure', 'other');
CREATE TYPE incident_severity     AS ENUM ('low', 'medium', 'critical');
CREATE TYPE otp_purpose           AS ENUM ('login', 'phone_change');
CREATE TYPE point_source          AS ENUM ('live', 'backlog');

-- ---------- Domains ----------
-- Kenyan mobile numbers in E.164: +2547XXXXXXXX or +2541XXXXXXXX.
-- The API normalises 07.., 01.., 2547.. inputs to this form before insert.
CREATE DOMAIN ke_phone  AS text CHECK (VALUE ~ '^\+254(7|1)[0-9]{8}$');
CREATE DOMAIN latitude  AS numeric(9,6) CHECK (VALUE BETWEEN -90 AND 90);
CREATE DOMAIN longitude AS numeric(9,6) CHECK (VALUE BETWEEN -180 AND 180);

-- ---------- Helpers ----------
CREATE OR REPLACE FUNCTION set_updated_at() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END $$;

-- ---------- System settings (tunable without a deploy) ----------
CREATE TABLE app_settings (
  key         text PRIMARY KEY,
  value       jsonb NOT NULL,
  description text,
  updated_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TRIGGER app_settings_updated_at BEFORE UPDATE ON app_settings
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

INSERT INTO app_settings (key, value, description) VALUES
  ('school_name',               '"School Name"',      'Shown in SMS signatures and the apps'),
  ('timezone',                  '"Africa/Nairobi"',   'Timezone for schedules and reports'),
  ('sms_sender_id',             '"SCHOOLBUS"',        'Africa''s Talking sender ID (must be registered)'),
  ('default_approach_minutes',  '5',                  'Default "bus approaching" alert lead time per stop'),
  ('default_stop_radius_m',     '120',                'Default arrival geofence radius in metres'),
  ('delay_threshold_minutes',   '10',                 'First delay alert when ETA exceeds schedule by this much'),
  ('delay_escalation_minutes',  '[10, 20, 30]',       'Delay levels; one alert per guardian per level'),
  ('stalled_minutes',           '8',                  'Bus within stalled_radius_m for this long (off-stop) = stalled'),
  ('stalled_radius_m',          '50',                 'Radius used for stalled-bus detection'),
  ('not_started_grace_minutes', '10',                 'Alert admin if a trip has not started this long after schedule'),
  ('stale_point_max_age_s',     '120',                'GPS points older than this never trigger parent alerts'),
  ('location_retention_days',   '90',                 'Raw GPS points older than this are purged'),
  ('critical_events_force_sms', 'true',               'Cancellations and breakdowns always go by SMS + push');
