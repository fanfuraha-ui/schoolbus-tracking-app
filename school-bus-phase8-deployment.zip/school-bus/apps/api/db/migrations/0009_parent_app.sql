-- 0009_parent_app.sql
-- Phase 7: the parent app's "Call the school office" button needs a number to call.
INSERT INTO app_settings (key, value, description) VALUES
  ('school_phone', '""', 'Transport office phone shown in the parent app (empty = hide the call button)')
ON CONFLICT (key) DO NOTHING;
