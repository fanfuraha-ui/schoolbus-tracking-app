-- 0004_trips_tracking.sql
-- Trips (one run of a schedule on a date), stop/student events, absences,
-- GPS points, latest bus positions, and learned segment times for ETA.

CREATE TABLE trips (
  id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  schedule_id        uuid NOT NULL REFERENCES schedules(id) ON DELETE RESTRICT,
  service_date       date NOT NULL,
  bus_id             uuid NOT NULL REFERENCES buses(id) ON DELETE RESTRICT,
  driver_id          uuid NOT NULL REFERENCES drivers(user_id) ON DELETE RESTRICT,
  status             trip_status NOT NULL DEFAULT 'scheduled',
  scheduled_start_at timestamptz NOT NULL,
  started_at         timestamptz,
  ended_at           timestamptz,
  cancelled_reason   text,
  distance_m         integer CHECK (distance_m >= 0),
  created_at         timestamptz NOT NULL DEFAULT now(),
  updated_at         timestamptz NOT NULL DEFAULT now(),
  -- One trip per schedule per day: stops a double-tapped "Start" creating duplicates.
  CONSTRAINT trips_schedule_date_uq UNIQUE (schedule_id, service_date),
  CONSTRAINT trips_id_schedule_uq   UNIQUE (id, schedule_id),
  CHECK (status <> 'active'    OR started_at IS NOT NULL),
  CHECK (status <> 'completed' OR (started_at IS NOT NULL AND ended_at IS NOT NULL)),
  CHECK (status <> 'cancelled' OR cancelled_reason IS NOT NULL),
  CHECK (ended_at IS NULL OR started_at IS NULL OR ended_at >= started_at)
);
-- A bus or a driver can only be on one active trip at a time.
CREATE UNIQUE INDEX trips_one_active_per_bus_uq    ON trips (bus_id)    WHERE status = 'active';
CREATE UNIQUE INDEX trips_one_active_per_driver_uq ON trips (driver_id) WHERE status = 'active';
CREATE INDEX trips_date_status_idx ON trips (service_date, status);
CREATE TRIGGER trips_updated_at BEFORE UPDATE ON trips
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- Enforce legal status transitions:
--   scheduled -> active | cancelled
--   active    -> completed | cancelled
CREATE OR REPLACE FUNCTION enforce_trip_transition() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.status = OLD.status THEN
    RETURN NEW;
  END IF;
  IF (OLD.status = 'scheduled' AND NEW.status IN ('active', 'cancelled'))
  OR (OLD.status = 'active'    AND NEW.status IN ('completed', 'cancelled')) THEN
    RETURN NEW;
  END IF;
  RAISE EXCEPTION 'Illegal trip status change % -> % (trip %)', OLD.status, NEW.status, OLD.id
    USING ERRCODE = 'check_violation';
END $$;
CREATE TRIGGER trips_status_transition BEFORE UPDATE OF status ON trips
  FOR EACH ROW EXECUTE FUNCTION enforce_trip_transition();

-- Per-stop progress for a trip. schedule_id is carried so composite FKs can prove
-- the stop belongs to the trip's schedule.
CREATE TABLE trip_stop_events (
  trip_id        uuid NOT NULL,
  schedule_id    uuid NOT NULL,
  stop_id        uuid NOT NULL,
  status         stop_event_status NOT NULL DEFAULT 'pending',
  eta_at         timestamptz,
  approaching_at timestamptz,
  arrived_at     timestamptz,
  departed_at    timestamptz,
  skipped_reason text,
  updated_at     timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (trip_id, stop_id),
  FOREIGN KEY (trip_id, schedule_id) REFERENCES trips (id, schedule_id) ON DELETE CASCADE,
  FOREIGN KEY (stop_id, schedule_id) REFERENCES stops (id, schedule_id) ON DELETE RESTRICT,
  CHECK (status <> 'skipped' OR skipped_reason IS NOT NULL)
);
CREATE TRIGGER trip_stop_events_updated_at BEFORE UPDATE ON trip_stop_events
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- Driver check-on / check-off per child.
CREATE TABLE student_trip_events (
  id          bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  trip_id     uuid NOT NULL REFERENCES trips(id) ON DELETE CASCADE,
  student_id  uuid NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  stop_id     uuid REFERENCES stops(id) ON DELETE SET NULL,
  status      student_event_status NOT NULL,
  recorded_by uuid REFERENCES users(id) ON DELETE SET NULL,
  recorded_at timestamptz NOT NULL DEFAULT now(),
  lat         latitude,
  lng         longitude,
  UNIQUE (trip_id, student_id, status)
);
CREATE INDEX student_trip_events_student_idx ON student_trip_events (student_id, recorded_at DESC);

-- Parent-reported "not riding today". schedule_id NULL = all trips that day.
CREATE TABLE absences (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id   uuid NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  service_date date NOT NULL,
  schedule_id  uuid REFERENCES schedules(id) ON DELETE CASCADE,
  reason       text,
  reported_by  uuid REFERENCES users(id) ON DELETE SET NULL,
  created_at   timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT absences_once_uq UNIQUE NULLS NOT DISTINCT (student_id, service_date, schedule_id)
);
CREATE INDEX absences_date_idx ON absences (service_date);

-- Raw GPS. About 12k rows/day at this scale; purged after location_retention_days.
CREATE TABLE location_points (
  id          bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  trip_id     uuid NOT NULL REFERENCES trips(id) ON DELETE CASCADE,
  recorded_at timestamptz NOT NULL,             -- device clock
  received_at timestamptz NOT NULL DEFAULT now(),
  lat         latitude NOT NULL,
  lng         longitude NOT NULL,
  speed_mps   real CHECK (speed_mps >= 0),
  heading_deg real CHECK (heading_deg >= 0 AND heading_deg <= 360),
  accuracy_m  real CHECK (accuracy_m >= 0),
  source      point_source NOT NULL DEFAULT 'live',
  -- Live + backlog uploads can overlap; insert with ON CONFLICT DO NOTHING.
  CONSTRAINT location_points_trip_time_uq UNIQUE (trip_id, recorded_at)
);
-- Append-only and time-ordered: BRIN is tiny and fast for retention purges.
CREATE INDEX location_points_recorded_brin ON location_points USING brin (recorded_at);

-- Latest known position per bus (one upserted row per bus) for the live map.
CREATE TABLE bus_positions (
  bus_id      uuid PRIMARY KEY REFERENCES buses(id) ON DELETE CASCADE,
  trip_id     uuid REFERENCES trips(id) ON DELETE SET NULL,
  lat         latitude NOT NULL,
  lng         longitude NOT NULL,
  speed_mps   real,
  heading_deg real,
  accuracy_m  real,
  recorded_at timestamptz NOT NULL,
  updated_at  timestamptz NOT NULL DEFAULT now()
);

-- Measured stop-to-stop travel time per completed trip leg.
CREATE TABLE trip_segment_times (
  trip_id      uuid NOT NULL REFERENCES trips(id) ON DELETE CASCADE,
  from_stop_id uuid NOT NULL REFERENCES stops(id) ON DELETE CASCADE,
  to_stop_id   uuid NOT NULL REFERENCES stops(id) ON DELETE CASCADE,
  seconds      integer NOT NULL CHECK (seconds > 0),
  hour_bucket  smallint NOT NULL CHECK (hour_bucket BETWEEN 0 AND 23),  -- local hour the leg started
  recorded_at  timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (trip_id, from_stop_id),
  CHECK (from_stop_id <> to_stop_id)
);
CREATE INDEX trip_segment_times_leg_idx
  ON trip_segment_times (from_stop_id, to_stop_id, hour_bucket, recorded_at DESC);

-- Median of the last 10 runs per leg and hour; feeds the ETA engine.
CREATE TABLE segment_stats (
  from_stop_id   uuid NOT NULL REFERENCES stops(id) ON DELETE CASCADE,
  to_stop_id     uuid NOT NULL REFERENCES stops(id) ON DELETE CASCADE,
  hour_bucket    smallint NOT NULL CHECK (hour_bucket BETWEEN 0 AND 23),
  median_seconds integer NOT NULL CHECK (median_seconds > 0),
  samples        integer NOT NULL CHECK (samples > 0),
  updated_at     timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (from_stop_id, to_stop_id, hour_bucket)
);

-- Recompute segment_stats. The worker runs this nightly.
CREATE OR REPLACE FUNCTION refresh_segment_stats(p_window integer DEFAULT 10) RETURNS integer
LANGUAGE plpgsql AS $$
DECLARE
  n integer;
BEGIN
  INSERT INTO segment_stats AS s (from_stop_id, to_stop_id, hour_bucket, median_seconds, samples, updated_at)
  SELECT from_stop_id, to_stop_id, hour_bucket,
         round(percentile_cont(0.5) WITHIN GROUP (ORDER BY seconds))::integer,
         count(*), now()
  FROM (
    SELECT t.*,
           row_number() OVER (PARTITION BY from_stop_id, to_stop_id, hour_bucket
                              ORDER BY recorded_at DESC) AS rn
    FROM trip_segment_times t
  ) recent
  WHERE rn <= p_window
  GROUP BY from_stop_id, to_stop_id, hour_bucket
  ON CONFLICT (from_stop_id, to_stop_id, hour_bucket) DO UPDATE
    SET median_seconds = EXCLUDED.median_seconds,
        samples        = EXCLUDED.samples,
        updated_at     = now();
  GET DIAGNOSTICS n = ROW_COUNT;
  RETURN n;
END $$;

-- Delete raw GPS older than the retention window. Returns rows deleted.
CREATE OR REPLACE FUNCTION purge_old_location_points() RETURNS bigint
LANGUAGE plpgsql AS $$
DECLARE
  days integer := (SELECT value::text::integer FROM app_settings WHERE key = 'location_retention_days');
  n bigint;
BEGIN
  DELETE FROM location_points WHERE recorded_at < now() - make_interval(days => COALESCE(days, 90));
  GET DIAGNOSTICS n = ROW_COUNT;
  RETURN n;
END $$;
