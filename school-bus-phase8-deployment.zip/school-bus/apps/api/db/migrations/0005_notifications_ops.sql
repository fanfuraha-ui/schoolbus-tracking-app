-- 0005_notifications_ops.sql
-- Notification log (with dedupe), SMS delivery reports, incidents, audit log, USSD sessions.
-- Note: pg-boss creates and manages its own "pgboss" schema at worker start-up;
-- it is intentionally not part of these migrations.

CREATE TABLE notifications (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  -- trip:stop:guardian:event[:escalation]. Same key may exist once per channel,
  -- so push + fallback SMS (or forced SMS for critical events) are two rows.
  dedupe_key          text NOT NULL,
  channel             notification_channel NOT NULL,
  guardian_id         uuid REFERENCES guardians(user_id) ON DELETE SET NULL,
  trip_id             uuid REFERENCES trips(id) ON DELETE SET NULL,
  stop_id             uuid REFERENCES stops(id) ON DELETE SET NULL,
  student_id          uuid REFERENCES students(id) ON DELETE SET NULL,
  event_type          notification_event NOT NULL,
  is_critical         boolean NOT NULL DEFAULT false,
  to_address          text NOT NULL,          -- phone (sms) or FCM token (push) at send time
  body                text NOT NULL,
  status              notification_status NOT NULL DEFAULT 'queued',
  attempts            smallint NOT NULL DEFAULT 0 CHECK (attempts >= 0),
  provider_message_id text,                   -- Africa's Talking messageId or FCM message name
  error               text,
  cost_kes            numeric(10,4) CHECK (cost_kes >= 0),
  created_at          timestamptz NOT NULL DEFAULT now(),
  sent_at             timestamptz,
  delivered_at        timestamptz,
  updated_at          timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT notifications_dedupe_uq UNIQUE (dedupe_key, channel),
  -- One SMS segment only (GSM-7). The API also rejects non-GSM characters such as emoji.
  CONSTRAINT notifications_sms_length CHECK (channel <> 'sms' OR char_length(body) <= 160)
);
CREATE INDEX notifications_provider_msg_idx ON notifications (provider_message_id)
  WHERE provider_message_id IS NOT NULL;
CREATE INDEX notifications_trip_idx     ON notifications (trip_id);
CREATE INDEX notifications_guardian_idx ON notifications (guardian_id, created_at DESC);
CREATE INDEX notifications_pending_idx  ON notifications (status) WHERE status IN ('queued', 'failed');
CREATE TRIGGER notifications_updated_at BEFORE UPDATE ON notifications
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- Raw Africa's Talking delivery-report callbacks, kept for audit and cost reconciliation.
CREATE TABLE sms_delivery_reports (
  id                  bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  provider_message_id text NOT NULL,
  status              text NOT NULL,     -- e.g. Success, Failed, Rejected, Buffered
  failure_reason      text,
  network_code        text,
  payload             jsonb NOT NULL,
  received_at         timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX sms_delivery_reports_msg_idx ON sms_delivery_reports (provider_message_id);

CREATE TABLE incidents (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  trip_id        uuid NOT NULL REFERENCES trips(id) ON DELETE CASCADE,
  reported_by    uuid REFERENCES users(id) ON DELETE SET NULL,
  type           incident_type NOT NULL,
  severity       incident_severity NOT NULL DEFAULT 'medium',
  note           text,
  lat            latitude,
  lng            longitude,
  notify_parents boolean NOT NULL DEFAULT false,
  created_at     timestamptz NOT NULL DEFAULT now(),
  resolved_at    timestamptz,
  resolved_by    uuid REFERENCES users(id) ON DELETE SET NULL,
  CHECK ((resolved_at IS NULL) OR (resolved_by IS NOT NULL))
);
CREATE INDEX incidents_trip_idx ON incidents (trip_id);
CREATE INDEX incidents_open_idx ON incidents (created_at DESC) WHERE resolved_at IS NULL;

CREATE TABLE audit_logs (
  id         bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  actor_id   uuid REFERENCES users(id) ON DELETE SET NULL,
  action     text NOT NULL,          -- e.g. 'student.update', 'route.reorder_stops'
  entity     text NOT NULL,
  entity_id  text,
  changes    jsonb,                  -- {"field": [old, new]}
  ip         inet,
  user_agent text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX audit_logs_entity_idx  ON audit_logs (entity, entity_id);
CREATE INDEX audit_logs_created_idx ON audit_logs (created_at DESC);

-- Optional (later phase): USSD "where is the bus?" sessions for basic-phone parents.
CREATE TABLE ussd_sessions (
  session_id   text PRIMARY KEY,     -- Africa's Talking sessionId
  phone        text NOT NULL,
  guardian_id  uuid REFERENCES guardians(user_id) ON DELETE SET NULL,
  service_code text NOT NULL,
  last_input   text,
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now()
);
CREATE TRIGGER ussd_sessions_updated_at BEFORE UPDATE ON ussd_sessions
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
