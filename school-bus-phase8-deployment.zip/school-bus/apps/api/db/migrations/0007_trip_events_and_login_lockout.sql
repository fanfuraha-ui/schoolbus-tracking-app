-- 0007_trip_events_and_login_lockout.sql
-- Phase 3 additions.
--
-- 1. trip_events: a transactional OUTBOX. The trip engine writes alert-worthy events here
--    in the same transaction as the trip/stop changes that caused them, so an event can
--    never be lost (or sent for a change that rolled back). The Phase 4 worker reads
--    unprocessed rows, expands them to recipients via trip_stop_recipients and sends.
--    The unique constraint makes every event happen at most once per trip.
-- 2. Login lockout counters on users (driver PINs are only 4 digits).
-- 3. trips.last_point_at: newest GPS point already run through the trip engine.

CREATE TABLE trip_events (
  id           bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  trip_id      uuid NOT NULL REFERENCES trips(id) ON DELETE CASCADE,
  stop_id      uuid REFERENCES stops(id) ON DELETE SET NULL,
  student_id   uuid REFERENCES students(id) ON DELETE SET NULL,
  event_type   notification_event NOT NULL,
  escalation   smallint NOT NULL DEFAULT 0 CHECK (escalation >= 0),  -- delay level (0 = driver-reported)
  is_critical  boolean NOT NULL DEFAULT false,
  payload      jsonb NOT NULL DEFAULT '{}'::jsonb,                   -- e.g. {"etaMinutes": 5}
  occurred_at  timestamptz NOT NULL DEFAULT now(),
  processed_at timestamptz,
  attempts     smallint NOT NULL DEFAULT 0 CHECK (attempts >= 0),
  last_error   text,
  CONSTRAINT trip_events_once_uq
    UNIQUE NULLS NOT DISTINCT (trip_id, stop_id, student_id, event_type, escalation)
);
CREATE INDEX trip_events_unprocessed_idx ON trip_events (occurred_at) WHERE processed_at IS NULL;
CREATE INDEX trip_events_trip_idx ON trip_events (trip_id, occurred_at);

ALTER TABLE users
  ADD COLUMN failed_login_count smallint NOT NULL DEFAULT 0 CHECK (failed_login_count >= 0),
  ADD COLUMN locked_until       timestamptz;

ALTER TABLE trips
  ADD COLUMN last_point_at timestamptz;
