-- 0003_fleet_routes.sql
-- Buses, routes, schedules (AM/PM/early-release), ordered stops, student stop assignments.

CREATE TABLE buses (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  plate_number text NOT NULL UNIQUE CHECK (plate_number = upper(btrim(plate_number))),  -- e.g. 'KDA 123X'
  capacity     smallint NOT NULL DEFAULT 33 CHECK (capacity BETWEEN 1 AND 100),
  is_active    boolean NOT NULL DEFAULT true,
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now()
);
CREATE TRIGGER buses_updated_at BEFORE UPDATE ON buses
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE routes (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name              text NOT NULL UNIQUE,
  description       text,
  default_bus_id    uuid REFERENCES buses(id) ON DELETE SET NULL,
  default_driver_id uuid REFERENCES drivers(user_id) ON DELETE SET NULL,
  is_active         boolean NOT NULL DEFAULT true,
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now()
);
-- A bus is the default for at most one active route.
CREATE UNIQUE INDEX routes_one_active_per_bus_uq ON routes (default_bus_id) WHERE is_active;
CREATE TRIGGER routes_updated_at BEFORE UPDATE ON routes
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- A schedule is one recurring run of a route ("Morning pickup", "Afternoon drop-off",
-- "Friday early release"). days_of_week uses ISO numbering: 1 = Monday ... 7 = Sunday.
CREATE TABLE schedules (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  route_id     uuid NOT NULL REFERENCES routes(id) ON DELETE CASCADE,
  name         text NOT NULL,
  direction    schedule_direction NOT NULL,
  days_of_week smallint[] NOT NULL DEFAULT '{1,2,3,4,5}'
               CHECK (cardinality(days_of_week) > 0 AND days_of_week <@ '{1,2,3,4,5,6,7}'::smallint[]),
  start_time   time NOT NULL,
  is_active    boolean NOT NULL DEFAULT true,
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now(),
  UNIQUE (route_id, name)
);
CREATE TRIGGER schedules_updated_at BEFORE UPDATE ON schedules
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- Stops belong to a schedule because AM and PM order (and sometimes locations) differ.
CREATE TABLE stops (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  schedule_id      uuid NOT NULL REFERENCES schedules(id) ON DELETE CASCADE,
  sequence         smallint NOT NULL CHECK (sequence > 0),
  name             text NOT NULL,
  landmark         text,
  lat              latitude NOT NULL,
  lng              longitude NOT NULL,
  radius_m         smallint NOT NULL DEFAULT 120 CHECK (radius_m BETWEEN 20 AND 1000),
  approach_minutes smallint NOT NULL DEFAULT 5   CHECK (approach_minutes BETWEEN 1 AND 30),
  scheduled_time   time,
  is_school        boolean NOT NULL DEFAULT false,  -- the school gate itself
  is_active        boolean NOT NULL DEFAULT true,
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now(),
  -- Deferrable so the admin can reorder stops in one transaction.
  CONSTRAINT stops_schedule_sequence_uq UNIQUE (schedule_id, sequence) DEFERRABLE INITIALLY IMMEDIATE,
  -- Target for composite FKs that guarantee "this stop belongs to that schedule".
  CONSTRAINT stops_id_schedule_uq UNIQUE (id, schedule_id)
);
CREATE TRIGGER stops_updated_at BEFORE UPDATE ON stops
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- Which stop a student uses on each schedule (one stop per student per schedule).
CREATE TABLE student_stops (
  student_id  uuid NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  schedule_id uuid NOT NULL REFERENCES schedules(id) ON DELETE CASCADE,
  stop_id     uuid NOT NULL,
  created_at  timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (student_id, schedule_id),
  FOREIGN KEY (stop_id, schedule_id) REFERENCES stops (id, schedule_id) ON DELETE CASCADE
);
CREATE INDEX student_stops_stop_idx ON student_stops (stop_id);
