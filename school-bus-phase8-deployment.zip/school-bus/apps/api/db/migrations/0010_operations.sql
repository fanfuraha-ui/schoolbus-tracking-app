-- 0010_operations.sql
-- Phase 8: production health. The worker records an SMS-credit check and a heartbeat in job_runs,
-- and the backup job records each run there too. This setting is when the dashboard warns.
INSERT INTO app_settings (key, value, description) VALUES
  ('sms_low_balance_kes', '500', 'Warn the office when Africa''s Talking credit falls below this many shillings')
ON CONFLICT (key) DO NOTHING;
