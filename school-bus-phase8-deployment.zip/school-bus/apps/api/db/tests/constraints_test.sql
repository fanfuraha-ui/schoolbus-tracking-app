-- constraints_test.sql — run after migrations + dev_seed.sql.
-- Every test prints PASS or aborts with FAIL. Everything is rolled back at the end.
--   psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f tests/constraints_test.sql

BEGIN;

CREATE TEMP TABLE ctx ON COMMIT DROP AS
SELECT t.id AS trip_id, t.schedule_id, t.bus_id, t.driver_id,
       (SELECT id FROM schedules WHERE route_id = sc.route_id AND id <> t.schedule_id) AS other_schedule_id,
       (SELECT user_id FROM guardians LIMIT 1) AS guardian_id,
       (SELECT id FROM students ORDER BY admission_no DESC LIMIT 1) AS student_id
FROM trips t JOIN schedules sc ON sc.id = t.schedule_id
WHERE t.status = 'active' LIMIT 1;

-- 1. Phone numbers must be Kenyan E.164
DO $$ BEGIN
  BEGIN
    INSERT INTO users (role, full_name, phone) VALUES ('guardian', 'Bad Phone', '0712345678');
    RAISE EXCEPTION 'FAIL 1: local-format phone accepted';
  EXCEPTION WHEN check_violation THEN RAISE NOTICE 'PASS 1: non-E.164 phone rejected';
  END;
END $$;

-- 2. A driver user cannot be given a guardian profile (role enforced by composite FK)
DO $$ BEGIN
  BEGIN
    INSERT INTO guardians (user_id) SELECT user_id FROM drivers LIMIT 1;
    RAISE EXCEPTION 'FAIL 2: driver accepted as guardian';
  EXCEPTION WHEN foreign_key_violation THEN RAISE NOTICE 'PASS 2: role mismatch rejected';
  END;
END $$;

-- 3. A student cannot be assigned a stop from a different schedule
DO $$
DECLARE new_student uuid;
BEGIN
  INSERT INTO students (admission_no, full_name) VALUES ('TEST0003', 'Test Student') RETURNING id INTO new_student;
  BEGIN
    INSERT INTO student_stops (student_id, schedule_id, stop_id)
    SELECT new_student,
           (SELECT other_schedule_id FROM ctx),
           (SELECT id FROM stops WHERE schedule_id = (SELECT schedule_id FROM ctx) LIMIT 1);
    RAISE EXCEPTION 'FAIL 3: cross-schedule stop accepted';
  EXCEPTION WHEN foreign_key_violation THEN
    RAISE NOTICE 'PASS 3: stop from another schedule rejected';
  END;
END $$;

-- 4. Only one trip per schedule per day (double-tapped Start)
DO $$ BEGIN
  BEGIN
    INSERT INTO trips (schedule_id, service_date, bus_id, driver_id, scheduled_start_at)
    SELECT schedule_id, current_date, bus_id, driver_id, now() FROM ctx;
    RAISE EXCEPTION 'FAIL 4: duplicate trip accepted';
  EXCEPTION WHEN unique_violation THEN RAISE NOTICE 'PASS 4: duplicate trip rejected';
  END;
END $$;

-- 5. A bus cannot be on two active trips at once
DO $$ BEGIN
  BEGIN
    INSERT INTO trips (schedule_id, service_date, bus_id, driver_id, status, scheduled_start_at, started_at)
    SELECT other_schedule_id, current_date, bus_id,
           (SELECT user_id FROM drivers WHERE user_id <> (SELECT driver_id FROM ctx) LIMIT 1),
           'active', now(), now()
    FROM ctx;
    RAISE EXCEPTION 'FAIL 5: second active trip on same bus accepted';
  EXCEPTION WHEN unique_violation THEN RAISE NOTICE 'PASS 5: second active trip on same bus rejected';
  END;
END $$;

-- 6. Illegal status transitions are blocked; legal ones work
DO $$ BEGIN
  UPDATE trips SET status = 'completed', ended_at = now() WHERE id = (SELECT trip_id FROM ctx);
  BEGIN
    UPDATE trips SET status = 'active' WHERE id = (SELECT trip_id FROM ctx);
    RAISE EXCEPTION 'FAIL 6: completed -> active accepted';
  EXCEPTION WHEN check_violation THEN RAISE NOTICE 'PASS 6: completed -> active rejected (active -> completed allowed)';
  END;
END $$;

-- 7. Notification dedupe: same key twice on one channel rejected; push + SMS allowed
DO $$ BEGIN
  INSERT INTO notifications (dedupe_key, channel, guardian_id, event_type, to_address, body)
  SELECT 'test:stop:g:approaching', 'push', guardian_id, 'approaching', 'fcm-token', 'Bus is 5 min away' FROM ctx;
  INSERT INTO notifications (dedupe_key, channel, guardian_id, event_type, to_address, body)
  SELECT 'test:stop:g:approaching', 'sms', guardian_id, 'approaching', '+254711000001', 'Bus is 5 min away' FROM ctx;
  BEGIN
    INSERT INTO notifications (dedupe_key, channel, guardian_id, event_type, to_address, body)
    SELECT 'test:stop:g:approaching', 'sms', guardian_id, 'approaching', '+254711000001', 'dup' FROM ctx;
    RAISE EXCEPTION 'FAIL 7: duplicate SMS accepted';
  EXCEPTION WHEN unique_violation THEN RAISE NOTICE 'PASS 7: duplicate alert rejected, push + SMS pair allowed';
  END;
END $$;

-- 8. SMS longer than one segment rejected
DO $$ BEGIN
  BEGIN
    INSERT INTO notifications (dedupe_key, channel, event_type, to_address, body)
    VALUES ('test:long', 'sms', 'delay', '+254711000001', repeat('x', 161));
    RAISE EXCEPTION 'FAIL 8: 161-char SMS accepted';
  EXCEPTION WHEN check_violation THEN RAISE NOTICE 'PASS 8: SMS over 160 chars rejected';
  END;
END $$;

-- 9. Duplicate whole-day absence rejected (NULL schedule treated as a value)
DO $$ BEGIN
  BEGIN
    INSERT INTO absences (student_id, service_date)
    SELECT student_id, service_date FROM absences WHERE schedule_id IS NULL LIMIT 1;
    RAISE EXCEPTION 'FAIL 9: duplicate absence accepted';
  EXCEPTION WHEN unique_violation THEN RAISE NOTICE 'PASS 9: duplicate absence rejected';
  END;
END $$;

-- 10. Overlapping live/backlog GPS uploads: duplicate point rejected; ON CONFLICT is a no-op
DO $$
DECLARE n int;
BEGIN
  INSERT INTO location_points (trip_id, recorded_at, lat, lng, source)
  SELECT trip_id, recorded_at, lat, lng, 'backlog'
  FROM location_points WHERE trip_id = (SELECT trip_id FROM ctx) LIMIT 1
  ON CONFLICT ON CONSTRAINT location_points_trip_time_uq DO NOTHING;
  GET DIAGNOSTICS n = ROW_COUNT;
  IF n <> 0 THEN RAISE EXCEPTION 'FAIL 10: duplicate GPS point inserted'; END IF;
  RAISE NOTICE 'PASS 10: duplicate GPS point ignored';
END $$;

-- 11. Absent students are excluded from alert recipients
DO $$ BEGIN
  IF EXISTS (
    SELECT 1 FROM trip_stop_recipients r
    JOIN absences a ON a.student_id = r.student_id AND a.service_date = current_date
  ) THEN RAISE EXCEPTION 'FAIL 11: absent student still receives alerts'; END IF;
  RAISE NOTICE 'PASS 11: absent students excluded from recipients';
END $$;

-- 12. Over-capacity schedules are flagged
DO $$ BEGIN
  UPDATE buses SET capacity = 20 WHERE id = (SELECT bus_id FROM ctx);
  IF NOT EXISTS (SELECT 1 FROM schedule_load WHERE schedule_id = (SELECT schedule_id FROM ctx) AND over_capacity)
  THEN RAISE EXCEPTION 'FAIL 12: 30 students on a 20-seat bus not flagged'; END IF;
  RAISE NOTICE 'PASS 12: over-capacity schedule flagged';
END $$;

-- 13. Segment medians: 5 runs of 300,320,340,360,900 s -> median 340 (outlier ignored)
DO $$
DECLARE m int;
BEGIN
  CREATE TEMP TABLE legs ON COMMIT DROP AS
  SELECT (SELECT id FROM stops WHERE schedule_id = c.schedule_id AND sequence = 1) a,
         (SELECT id FROM stops WHERE schedule_id = c.schedule_id AND sequence = 2) b
  FROM ctx c;
  INSERT INTO trips (schedule_id, service_date, bus_id, driver_id, status, scheduled_start_at, started_at, ended_at)
  SELECT schedule_id, current_date - d, bus_id, driver_id, 'completed', now(), now(), now()
  FROM ctx CROSS JOIN generate_series(1, 5) d;
  INSERT INTO trip_segment_times (trip_id, from_stop_id, to_stop_id, seconds, hour_bucket, recorded_at)
  SELECT t.id, l.a, l.b, (ARRAY[300, 320, 340, 360, 900])[current_date - t.service_date], 6,
         now() - make_interval(days => current_date - t.service_date)
  FROM trips t, legs l, ctx c
  WHERE t.schedule_id = c.schedule_id AND t.service_date < current_date;
  PERFORM refresh_segment_stats();
  SELECT median_seconds INTO m FROM segment_stats s JOIN legs l ON s.from_stop_id = l.a AND s.to_stop_id = l.b;
  IF m IS DISTINCT FROM 340 THEN RAISE EXCEPTION 'FAIL 13: median % (expected 340)', m; END IF;
  RAISE NOTICE 'PASS 13: segment median = 340 s';
END $$;

-- 14. Stops can be reordered in one transaction (deferrable sequence constraint)
DO $$ BEGIN
  SET CONSTRAINTS stops_schedule_sequence_uq DEFERRED;
  UPDATE stops SET sequence = CASE sequence WHEN 1 THEN 2 ELSE 1 END
  WHERE schedule_id = (SELECT schedule_id FROM ctx) AND sequence IN (1, 2);
  SET CONSTRAINTS stops_schedule_sequence_uq IMMEDIATE;
  RAISE NOTICE 'PASS 14: stops 1 and 2 swapped without conflict';
END $$;

-- 15. Retention purge removes only old points
DO $$
DECLARE n bigint;
BEGIN
  INSERT INTO location_points (trip_id, recorded_at, lat, lng)
  SELECT trip_id, now() - interval '91 days', -1.2463, 36.6629 FROM ctx;
  n := purge_old_location_points();
  IF n <> 1 THEN RAISE EXCEPTION 'FAIL 15: purged % rows (expected 1)', n; END IF;
  RAISE NOTICE 'PASS 15: retention purge removed 1 old point, kept recent ones';
END $$;

ROLLBACK;
