'use strict';
/**
 * Integration-test harness: builds a fresh database (all migrations + dev seed) and
 * wires real services with lightweight fakes for SMS, JWT and broadcasting.
 *
 * Env: PGTEST_HOST (default /tmp), PGTEST_PORT (5544), PGTEST_USER (postgres).
 * Uses node-postgres when installed, otherwise the psql-backed test pool.
 */
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');
const { createDb } = require('../../src/db');

const HOST = process.env.PGTEST_HOST || '/tmp';
const PORT = process.env.PGTEST_PORT || '5544';
const USER = process.env.PGTEST_USER || 'postgres';
const DB_DIR = path.join(__dirname, '../../db');

function psql(args) {
  execFileSync('psql', ['-h', HOST, '-p', PORT, '-U', USER, '-X', '-q', '-v', 'ON_ERROR_STOP=1', ...args], { stdio: 'pipe' });
}

function createPool(database) {
  try {
    const { createPgPool } = require('../../src/db');
    require.resolve('pg');
    const url = HOST.startsWith('/')
      ? `postgres://${USER}@localhost:${PORT}/${database}?host=${encodeURIComponent(HOST)}` // unix socket dir
      : `postgres://${USER}@${HOST}:${PORT}/${database}`;
    return createPgPool(url, { max: 1 });
  } catch {
    const { createPsqlPool } = require('./psqlPool');
    return createPsqlPool({ host: HOST, port: PORT, user: USER, database });
  }
}

async function freshDatabase(name) {
  psql(['-d', 'postgres', '-c', `DROP DATABASE IF EXISTS ${name} WITH (FORCE)`, '-c', `CREATE DATABASE ${name}`]);
  const migrations = fs.readdirSync(path.join(DB_DIR, 'migrations')).filter((f) => f.endsWith('.sql')).sort();
  for (const file of migrations) psql(['-d', name, '-1', '-f', path.join(DB_DIR, 'migrations', file)]);
  psql(['-d', name, '-f', path.join(DB_DIR, 'seeds', 'dev_seed.sql')]);
  // Make every seeded schedule run every day so tests don't depend on the weekday.
  psql(['-d', name, '-c', "UPDATE schedules SET days_of_week = '{1,2,3,4,5,6,7}'"]);
  const pool = createPool(name);
  return { pool, db: createDb(pool) };
}

function fakeBroadcaster() {
  const calls = [];
  return {
    calls,
    toTrip: (tripId, event, data) => calls.push({ to: `trip:${tripId}`, event, data }),
    toFleet: (event, data) => calls.push({ to: 'fleet', event, data }),
    closeTrip: (tripId) => calls.push({ to: `trip:${tripId}`, event: '__close__' }),
  };
}

function fakeSms() {
  const sent = [];
  return { sent, send: async ({ to, message }) => { sent.push({ to, message }); return [{ number: to, accepted: true }]; } };
}

const fakeTokens = {
  signAccess: ({ id, role }) => `access:${id}:${role}`,
  verifyAccess: (token) => {
    const [kind, id, role] = String(token).split(':');
    if (kind !== 'access') throw new Error('bad token');
    return { id, role };
  },
};

/** bcrypt-compatible hasher implemented with pgcrypto (same $2a$ format as bcryptjs). */
function pgHasher(db) {
  return {
    hash: async (plain) => (await db.one("SELECT crypt($1, gen_salt('bf', 10)) AS h", [plain])).h,
    compare: async (plain, hash) => Boolean((await db.one('SELECT crypt($1, $2) = $2 AS ok', [plain, hash])).ok),
  };
}

const quietLogger = { info() {}, warn() {}, error() {}, debug() {} };

module.exports = { freshDatabase, fakeBroadcaster, fakeSms, fakeTokens, pgHasher, quietLogger };
