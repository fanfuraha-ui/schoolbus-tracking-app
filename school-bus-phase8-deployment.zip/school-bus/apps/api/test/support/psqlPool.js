'use strict';
/**
 * TEST-ONLY pg-compatible pool backed by one long-lived `psql` process.
 *
 * Why: lets the integration tests exercise the real services against real PostgreSQL
 * in environments where the `pg` npm package cannot be installed. When `pg` is
 * available, the same tests can run against createPgPool() instead (see
 * test/support/context.js).
 *
 * It mimics node-postgres closely enough for this app:
 *  - parameters are inlined as quoted literals (same "unknown" typing as pg's text params)
 *  - result columns are typed with \gdesc and converted like our pg type parsers
 *    (int2/int4/int8/numeric/float -> number, bool -> boolean, timestamptz -> Date,
 *     date/time -> string, json/jsonb -> object, arrays of the above -> arrays)
 *  - errors carry `code` (SQLSTATE) and `constraint`
 * One connection only: transactions work because every query shares the session.
 */
const { spawn } = require('child_process');

const NULL_MARK = '<<NULL>>';

function quoteLiteral(value) {
  if (value === null || value === undefined) return 'NULL';
  if (value instanceof Date) return `'${value.toISOString()}'`;
  if (Array.isArray(value)) return `'${arrayLiteral(value).replace(/'/g, "''")}'`;
  if (typeof value === 'object') return `'${JSON.stringify(value).replace(/'/g, "''")}'`;
  return `'${String(value).replace(/'/g, "''")}'`;
}

function arrayLiteral(arr) {
  const items = arr.map((v) => {
    if (v === null || v === undefined) return 'NULL';
    const s = v instanceof Date ? v.toISOString() : typeof v === 'object' ? JSON.stringify(v) : String(v);
    return `"${s.replace(/\\/g, '\\\\').replace(/"/g, '\\"')}"`;
  });
  return `{${items.join(',')}}`;
}

function inlineParams(sql, params) {
  return sql.replace(/\$(\d+)/g, (_, n) => {
    const i = Number(n) - 1;
    if (i >= params.length) throw new Error(`Missing parameter $${n}`);
    return quoteLiteral(params[i]);
  });
}

// Minimal RFC 4180 CSV parser (psql csv output quotes fields containing , " or newlines).
function parseCsv(text) {
  const rows = [];
  let row = [];
  let field = '';
  let quoted = false;
  let i = 0;
  while (i < text.length) {
    const c = text[i];
    if (quoted) {
      if (c === '"' && text[i + 1] === '"') { field += '"'; i += 2; continue; }
      if (c === '"') { quoted = false; i += 1; continue; }
      field += c; i += 1; continue;
    }
    if (c === '"') { quoted = true; i += 1; continue; }
    if (c === ',') { row.push(field); field = ''; i += 1; continue; }
    if (c === '\n') { row.push(field); rows.push(row); row = []; field = ''; i += 1; continue; }
    field += c; i += 1;
  }
  if (field !== '' || row.length) { row.push(field); rows.push(row); }
  return rows;
}

function parsePgArray(text, convert) {
  // Handles one-dimensional arrays: {1,2,3} / {"a b",NULL}
  const inner = text.slice(1, -1);
  if (inner === '') return [];
  const out = [];
  let cur = '';
  let quoted = false;
  let wasQuoted = false;
  for (let i = 0; i < inner.length; i += 1) {
    const c = inner[i];
    if (quoted) {
      if (c === '\\') { cur += inner[i + 1]; i += 1; } else if (c === '"') quoted = false; else cur += c;
    } else if (c === '"') { quoted = true; wasQuoted = true; } else if (c === ',') {
      out.push(!wasQuoted && cur === 'NULL' ? null : convert(cur)); cur = ''; wasQuoted = false;
    } else cur += c;
  }
  out.push(!wasQuoted && cur === 'NULL' ? null : convert(cur));
  return out;
}

function converterFor(type) {
  const t = type.toLowerCase();
  if (t.endsWith('[]')) {
    const inner = converterFor(t.slice(0, -2));
    return (v) => parsePgArray(v, inner);
  }
  if (/^(smallint|integer|bigint|real|double precision)$/.test(t) || t.startsWith('numeric')) return Number;
  if (t === 'boolean') return (v) => v === 't';
  if (t.startsWith('timestamp with time zone')) {
    return (v) => new Date(v.replace(' ', 'T').replace(/([+-]\d\d)$/, '$1:00'));
  }
  if (t.startsWith('timestamp without time zone')) return (v) => new Date(`${v}Z`);
  if (t === 'json' || t === 'jsonb') return (v) => JSON.parse(v);
  return (v) => v; // text, uuid, date, time, enums, domains over text, inet, interval
}

class PsqlConnection {
  constructor(psqlArgs) {
    this.proc = spawn('psql', [...psqlArgs, '-X', '-q', '-v', 'ON_ERROR_STOP=0'], { stdio: ['pipe', 'pipe', 'pipe'] });
    this.out = '';
    this.err = '';
    this.waiter = null;
    this.chain = Promise.resolve();
    this.seq = 0;
    this.proc.stdout.on('data', (d) => { this.out += d; this.check(); });
    this.proc.stderr.on('data', (d) => { this.err += d; this.check(); });
    this.send(`\\set VERBOSITY verbose\n\\pset format csv\n\\pset null '${NULL_MARK}'\n\\pset footer off\nSET TIME ZONE 'UTC';\n`);
  }

  send(text) { this.proc.stdin.write(text); }

  check() {
    if (!this.waiter) return;
    const { mark, resolve } = this.waiter;
    const o = this.out.indexOf(mark);
    const e = this.err.indexOf(mark);
    if (o === -1 || e === -1) return;
    const stdout = this.out.slice(0, o);
    const stderr = this.err.slice(0, e);
    this.out = this.out.slice(o + mark.length + 1);
    this.err = this.err.slice(e + mark.length + 1);
    this.waiter = null;
    resolve({ stdout, stderr });
  }

  run(script) {
    const mark = `__MARK_${(this.seq += 1)}__`;
    return new Promise((resolve) => {
      this.waiter = { mark, resolve };
      this.send(`${script}\n\\echo ${mark}\n\\warn ${mark}\n`);
    });
  }

  static toError(stderr) {
    const m = stderr.match(/ERROR:\s+([0-9A-Z]{5}):\s+([^\n]*)/);
    if (!m) return null;
    const err = new Error(m[2]);
    err.code = m[1];
    const c = m[2].match(/constraint "([^"]+)"/);
    if (c) err.constraint = c[1];
    const detail = stderr.match(/DETAIL:\s+([^\n]*)/);
    if (detail) err.detail = detail[1];
    return err;
  }

  query(sql, params = []) {
    const job = this.chain.then(() => this.exec(sql, params));
    this.chain = job.catch(() => {});
    return job;
  }

  async exec(sql, params) {
    const text = inlineParams(sql, params).trim().replace(/;\s*$/, '');
    if (/^(BEGIN|COMMIT|ROLLBACK)$/i.test(text)) {
      const { stderr } = await this.run(`${text};`);
      const err = PsqlConnection.toError(stderr);
      if (err) throw err;
      return { rows: [], rowCount: 0 };
    }
    // 1) describe result columns without executing
    const desc = await this.run(`${text}\n\\gdesc`);
    const descErr = PsqlConnection.toError(desc.stderr);
    if (descErr) throw descErr;
    const descRows = parseCsv(desc.stdout).slice(1); // header: Column,Type
    const columns = descRows.map(([name, type]) => ({ name, convert: converterFor(type) }));
    // 2) execute; psql reports the affected/returned row count in :ROW_COUNT
    const res = await this.run(`${text}\n\\g\n\\echo __RC__ :ROW_COUNT`);
    const err = PsqlConnection.toError(res.stderr);
    if (err) throw err;
    const rcAt = res.stdout.lastIndexOf('__RC__ ');
    const rowCount = Number(res.stdout.slice(rcAt + 7).trim());
    if (!columns.length) return { rows: [], rowCount };
    const lines = parseCsv(res.stdout.slice(0, rcAt));
    const body = lines.slice(1).filter((r) => !(r.length === 1 && r[0] === ''));
    const rows = body.map((vals) => {
      const row = {};
      columns.forEach((col, idx) => {
        const v = vals[idx];
        row[col.name] = v === NULL_MARK || v === undefined ? null : col.convert(v);
      });
      return row;
    });
    return { rows, rowCount };
  }

  connect() {
    return Promise.resolve({ query: (s, p) => this.query(s, p), release: () => {} });
  }

  end() {
    return new Promise((resolve) => {
      this.proc.on('close', resolve);
      this.proc.stdin.end('\\q\n');
    });
  }
}

function createPsqlPool({ host = '/tmp', port = 5544, user = 'postgres', database }) {
  return new PsqlConnection(['-h', host, '-p', String(port), '-U', user, '-d', database]);
}

module.exports = { createPsqlPool };
