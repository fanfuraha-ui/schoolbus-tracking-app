'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('crypto');
const { toGsm7, gsmLength, fitSms } = require('../../src/notifications/gsm');
const { renderAlert, joinNames } = require('../../src/notifications/templates');
const { inQuietHours } = require('../../src/notifications/outbox');
const { backoffSeconds } = require('../../src/notifications/sender');
const { createFcmClient, PushError } = require('../../src/integrations/fcm');
const { createFleetEventRelay } = require('../../src/realtime/fleetEventRelay');

test('GSM-7: smart punctuation, accents and emoji are normalised so SMS stays 160 chars', () => {
  assert.equal(toGsm7('Bus “KDA” – arriving… 🚌 Wanjirũ'), 'Bus "KDA" - arriving... Wanjiru');
  assert.equal(gsmLength('a€b'), 4, 'euro counts double');
  const long = fitSms((v) => `Hello ${v.names}, bus is here. -School`, { names: 'x'.repeat(300) }, { flex: ['names'] });
  assert.ok(gsmLength(long) <= 160);
  assert.match(long, /\.\.\., bus is here\. -School$/);
});

test('templates: every event fits one SMS in English and Kiswahili, with correct plurals', () => {
  const base = { plate: 'KDA 101A', stopName: 'A Very Long Stop Name Near The Big Market Roundabout', schoolName: 'Greenfield Academy International', etaMinutes: 4, delayMinutes: 25, direction: 'to_school' };
  const events = [['approaching'], ['arrived'], ['arrived', { isSchool: true }], ['boarded'], ['dropped_off'], ['delay'], ['delay', { delayMinutes: null, reasonType: 'weather' }], ['breakdown', { incidentType: 'breakdown' }], ['trip_cancelled', { reasonText: 'x '.repeat(100) }]];
  for (const lang of ['en', 'sw']) {
    for (const [eventType, extra] of events) {
      const r = renderAlert({ ...base, ...extra, eventType, lang, children: ['Amina Wairimu', 'Baraka Otieno', 'Chebet Kip'] });
      assert.ok(gsmLength(r.body) <= 160, `${lang} ${eventType}: ${gsmLength(r.body)}`);
      assert.ok(r.title.length > 0);
    }
  }
  assert.match(renderAlert({ ...base, lang: 'sw', eventType: 'boarded', children: ['Amina W'] }).body, /^Amina amepanda/);
  assert.match(renderAlert({ ...base, lang: 'sw', eventType: 'boarded', children: ['Amina W', 'Baraka O'] }).body, /^Amina & Baraka wamepanda/);
  assert.match(renderAlert({ ...base, lang: 'en', eventType: 'delay', delayMinutes: null, reasonType: 'traffic' }).body, /delayed by heavy traffic/);
  assert.match(renderAlert({ ...base, lang: 'fr', eventType: 'arrived' }).body, /^Bus KDA 101A has arrived/, 'unknown language falls back to English');
  assert.equal(joinNames(['Amina W', 'Amina W', 'Baraka O', 'Chebet K']), 'Amina, Baraka & Chebet');
});

test('quiet hours handle windows that cross midnight', () => {
  assert.equal(inQuietHours('22:30:00', '21:00:00', '06:00:00'), true);
  assert.equal(inQuietHours('05:59:00', '21:00', '06:00'), true);
  assert.equal(inQuietHours('06:00:00', '21:00', '06:00'), false);
  assert.equal(inQuietHours('13:00:00', '12:00', '14:00'), true);
  assert.equal(inQuietHours('13:00:00', null, null), false);
});

test('backoff doubles and caps at 10 minutes', () => {
  assert.deepEqual([1, 2, 3, 4, 5, 10].map(backoffSeconds), [30, 60, 120, 240, 480, 600]);
});

test('FCM: signs a valid service-account JWT, sends HTTP v1 message, classifies dead tokens', async () => {
  const { publicKey, privateKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
  const sa = { project_id: 'school-bus-ke', client_email: 'push@school-bus-ke.iam.gserviceaccount.com', private_key: privateKey.export({ type: 'pkcs8', format: 'pem' }) };
  const calls = [];
  let mode = 'ok';
  const fetchImpl = async (url, init) => {
    calls.push({ url, init });
    if (url.startsWith('https://oauth2')) return { ok: true, status: 200, json: async () => ({ access_token: 'ya29.token', expires_in: 3600 }) };
    if (mode === 'dead') return { ok: false, status: 404, json: async () => ({ error: { status: 'NOT_FOUND', message: 'Requested entity was not found.', details: [{ errorCode: 'UNREGISTERED' }] } }) };
    if (mode === 'busy') return { ok: false, status: 503, json: async () => ({ error: { status: 'UNAVAILABLE' } }) };
    return { ok: true, status: 200, json: async () => ({ name: 'projects/school-bus-ke/messages/123' }) };
  };
  const fcm = createFcmClient({ serviceAccount: Buffer.from(JSON.stringify(sa)).toString('base64'), fetchImpl });
  const r = await fcm.send({ token: 'device-token', title: 'Bus is 5 min away', body: 'Bus KDA 101A ...', data: { tripId: 't1', n: 5 }, critical: true });
  assert.equal(r.messageId, 'projects/school-bus-ke/messages/123');

  const assertion = new URLSearchParams(calls[0].init.body).get('assertion');
  const [h, p, sig] = assertion.split('.');
  assert.ok(crypto.createVerify('RSA-SHA256').update(`${h}.${p}`).verify(publicKey, sig, 'base64url'), 'JWT signature valid');
  const claims = JSON.parse(Buffer.from(p, 'base64url').toString());
  assert.equal(claims.scope, 'https://www.googleapis.com/auth/firebase.messaging');
  assert.equal(calls[1].url, 'https://fcm.googleapis.com/v1/projects/school-bus-ke/messages:send');
  assert.equal(calls[1].init.headers.Authorization, 'Bearer ya29.token');
  const msg = JSON.parse(calls[1].init.body).message;
  assert.deepEqual(msg.data, { tripId: 't1', n: '5' }, 'data values are strings');
  assert.equal(msg.android.notification.channel_id, 'critical_alerts');

  await fcm.send({ token: 'x', title: 't', body: 'b' });
  assert.equal(calls.filter((c) => c.url.startsWith('https://oauth2')).length, 1, 'access token cached');

  mode = 'dead';
  await assert.rejects(fcm.send({ token: 'x', title: 't', body: 'b' }), (e) => e instanceof PushError && e.unregistered && !e.retryable);
  mode = 'busy';
  await assert.rejects(fcm.send({ token: 'x', title: 't', body: 'b' }), (e) => e.retryable && !e.unregistered);

  const dry = createFcmClient({ serviceAccount: null, logger: { info() {} } });
  assert.match((await dry.send({ token: 'x', title: 't', body: 'b' })).messageId, /^dry-push/);
});

test('fleet relay forwards only allowed worker events to admins', () => {
  const sent = [];
  const relay = createFleetEventRelay({ pool: {}, broadcaster: { toFleet: (e, d) => sent.push([e, d]) }, logger: { warn() {} } });
  assert.equal(relay.handle(JSON.stringify({ event: 'incident:new', data: { id: 1 } })), true);
  assert.equal(relay.handle(JSON.stringify({ event: 'bus:location', data: {} })), false);
  assert.equal(relay.handle('not json'), false);
  assert.deepEqual(sent, [['incident:new', { id: 1 }]]);
});
