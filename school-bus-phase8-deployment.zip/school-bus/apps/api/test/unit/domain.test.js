'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');

const { distanceM } = require('../../src/domain/geo');
const { normalizeKenyanPhone, maskPhone } = require('../../src/domain/phone');
const { rollingSpeed, computeEtas } = require('../../src/domain/eta');
const engine = require('../../src/domain/tripEngine');

// ---------- helpers ----------
const ORIGIN = { lat: -1.25, lng: 36.66 };
// Same Earth radius as geo.js so test distances are exact.
const M_PER_DEG_LNG = ((Math.PI / 180) * 6371008.8) * Math.cos((ORIGIN.lat * Math.PI) / 180);
const east = (m) => ({ lat: ORIGIN.lat, lng: ORIGIN.lng + m / M_PER_DEG_LNG });
const T0 = new Date('2026-11-17T04:00:00Z');
const at = (s) => new Date(T0.getTime() + s * 1000);

// Stops every 600 m east, then the school gate.
function makeCtx({ direction = 'to_school', states = {} } = {}) {
  const stops = [
    { id: 's1', sequence: 1, ...east(600), radiusM: 120, approachMinutes: 5, isSchool: false },
    { id: 's2', sequence: 2, ...east(1200), radiusM: 120, approachMinutes: 5, isSchool: false },
    { id: 's3', sequence: 3, ...east(1800), radiusM: 120, approachMinutes: 5, isSchool: false },
    { id: 'school', sequence: 4, ...east(2400), radiusM: 120, approachMinutes: 5, isSchool: true },
  ];
  return engine.createTripContext({
    trip: { id: 't1', direction },
    stops,
    states: stops.map((s) => ({ stopId: s.id, status: states[s.id] || 'pending' })),
  });
}
const pt = (m, s, extra = {}) => ({ ...east(m), speedMps: 8, accuracyM: 8, recordedAt: at(s), ...extra });
const feed = (ctx, points, opts) => points.map((p) => engine.processPoint(ctx, p, opts));
const status = (ctx, id) => ctx.states.get(id).status;
const allEvents = (results) => results.flatMap((r) => r.events);

// ---------- geo / phone / eta ----------
test('distanceM: 1 km east is ~1000 m', () => {
  assert.ok(Math.abs(distanceM(ORIGIN, east(1000)) - 1000) < 1);
});

test('normalizeKenyanPhone handles common formats', () => {
  for (const input of ['0712345678', '712345678', '254712345678', '+254 712 345 678', '0712-345-678']) {
    assert.equal(normalizeKenyanPhone(input), '+254712345678', input);
  }
  assert.equal(normalizeKenyanPhone('0112345678'), '+254112345678');
  for (const bad of ['0812345678', '12345', '+255712345678', '', null, 'abc']) {
    assert.equal(normalizeKenyanPhone(bad), null, String(bad));
  }
  assert.equal(maskPhone('+254712345678'), '+254712***678');
});

test('rollingSpeed: averages recent movement and clamps', () => {
  const pts = [0, 10, 20, 30].map((s) => ({ ...east(s * 10), recordedAt: at(s) })); // 10 m/s
  assert.ok(Math.abs(rollingSpeed(pts, at(30).getTime()) - 10) < 0.05);
  const parked = [0, 10, 20, 30].map((s) => ({ ...ORIGIN, recordedAt: at(s) }));
  assert.equal(rollingSpeed(parked, at(30).getTime()), 3, 'clamped to minimum crawl speed');
  assert.equal(rollingSpeed([], at(0).getTime()), 5.5, 'fallback with no data');
});

test('computeEtas: distance-based, then learned median for partial first leg', () => {
  const stops = [{ id: 'a', ...east(0) }, { id: 'b', ...east(1000) }, { id: 'c', ...east(2000) }];
  const plain = computeEtas({ position: east(500), stops, startIndex: 1, speedMps: 10 });
  assert.equal(plain[0].secondsAway, 65);           // 500 m * 1.3 / 10
  assert.equal(plain[1].secondsAway, 65 + 30 + 130); // + dwell + 1000*1.3/10
  const learned = computeEtas({
    position: east(500), stops, startIndex: 1, speedMps: 10, segmentStats: new Map([['a:b', 200]]),
  });
  assert.equal(learned[0].secondsAway, 100);        // half of the 200 s learned leg
});

// ---------- trip engine ----------
test('engine: approaching alert fires once ETA <= 5 min', () => {
  const ctx = makeCtx();
  const results = feed(ctx, [pt(0, 0), pt(-3000, -1)].reverse()); // far away first
  assert.equal(allEvents(results).length, 1);
  const [ev] = allEvents(results);
  assert.equal(ev.type, 'approaching');
  assert.equal(ev.stopId, 's1');
  assert.equal(status(ctx, 's1'), 'approaching');
});

test('engine: one noisy point inside the radius does NOT count as arrival', () => {
  const ctx = makeCtx();
  feed(ctx, [pt(300, 0), pt(560, 20, { speedMps: 9 }), pt(800, 40, { speedMps: 9 })]);
  assert.notEqual(status(ctx, 's1'), 'arrived');
});

test('engine: two consecutive points inside = arrival; departure needs two outside', () => {
  const ctx = makeCtx();
  const r = feed(ctx, [pt(300, 0), pt(550, 20), pt(590, 30)]);
  assert.equal(status(ctx, 's1'), 'arrived');
  // s2 is also within 5 min (600 m on) so it gets its own approaching alert; check s1 only.
  assert.deepEqual(allEvents(r).filter((e) => e.stopId === 's1').map((e) => e.type), ['approaching', 'arrived']);
  feed(ctx, [pt(760, 60)]); // first point outside radius + hysteresis
  assert.equal(status(ctx, 's1'), 'arrived', 'single point outside is not enough');
  feed(ctx, [pt(800, 70)]);
  assert.equal(status(ctx, 's1'), 'departed');
});

test('engine: a single slow point inside the radius counts as arrival', () => {
  const ctx = makeCtx();
  feed(ctx, [pt(300, 0), pt(580, 30, { speedMps: 0.5 })]);
  assert.equal(status(ctx, 's1'), 'arrived');
});

test('engine: arriving at a later stop skips bypassed ones', () => {
  const ctx = makeCtx();
  feed(ctx, [pt(1000, 0), pt(1780, 60), pt(1800, 70)]);
  assert.equal(status(ctx, 's1'), 'skipped');
  assert.equal(status(ctx, 's2'), 'skipped');
  assert.equal(ctx.states.get('s1').skippedReason, 'bypassed');
  assert.equal(status(ctx, 's3'), 'arrived');
});

test('engine: learns stop-to-stop leg time', () => {
  const ctx = makeCtx();
  feed(ctx, [pt(590, 0), pt(600, 10), pt(760, 30), pt(800, 40)]); // arrive s1, depart at t=40
  const r = feed(ctx, [pt(1190, 150), pt(1200, 160)]);
  const segs = r.flatMap((x) => x.segments);
  assert.deepEqual(segs.map((s) => [s.fromStopId, s.toStopId, s.seconds]), [['s1', 's2', 120]]);
});

test('engine: silent (stale) points advance state without alerts', () => {
  const ctx = makeCtx();
  const r = feed(ctx, [pt(300, 0), pt(590, 20), pt(600, 30)], { silent: true });
  assert.equal(status(ctx, 's1'), 'arrived');
  assert.equal(allEvents(r).length, 0);
});

test('engine: school gate on an afternoon trip never alerts; morning arrival at school does', () => {
  // Afternoon: school gate is stop 1 and the bus starts there.
  const pmStops = [
    { id: 'school', sequence: 1, ...east(0), radiusM: 120, approachMinutes: 5, isSchool: true },
    { id: 'p1', sequence: 2, ...east(600), radiusM: 120, approachMinutes: 5, isSchool: false },
  ];
  const pm = engine.createTripContext({
    trip: { id: 't2', direction: 'from_school' },
    stops: pmStops,
    states: pmStops.map((s) => ({ stopId: s.id, status: 'pending' })),
  });
  const r = feed(pm, [pt(0, 0, { speedMps: 0 }), pt(10, 10), pt(200, 30), pt(260, 40)]);
  assert.equal(status(pm, 'school'), 'departed');
  assert.ok(!allEvents(r).some((e) => e.stopId === 'school'), 'no alerts for the school gate in the afternoon');

  // Morning: earlier stops done, bus arrives at the school gate -> alert.
  const am = makeCtx({ direction: 'to_school', states: { s1: 'departed', s2: 'departed', s3: 'departed' } });
  const r2 = feed(am, [pt(2000, 0), pt(2390, 40), pt(2400, 50)]);
  assert.equal(status(am, 'school'), 'arrived');
  assert.ok(allEvents(r2).some((e) => e.stopId === 'school' && e.type === 'arrived'));
});

test('engine: inaccurate points are ignored', () => {
  const ctx = makeCtx();
  const [r] = feed(ctx, [pt(600, 0, { accuracyM: 250, speedMps: 0 })]);
  assert.equal(r.ignored, true);
  assert.equal(status(ctx, 's1'), 'pending');
});

test('engine: ETAs are written for upcoming stops and only re-written on >=30 s change', () => {
  const ctx = makeCtx();
  feed(ctx, [pt(-3000, 0), pt(-2900, 10), pt(-2800, 20)]); // steady 10 m/s
  assert.ok(ctx.states.get('s3').etaAt instanceof Date);
  ctx.changed.clear();
  feed(ctx, [pt(-2790, 21)]); // same speed, 1 s later: ETA moves < 1 s
  assert.ok(!ctx.changed.has('school'), 'tiny ETA change is not persisted');
});

test('manual actions: depart without arrive records both; skip after arrive is rejected', () => {
  const ctx = makeCtx();
  const r = engine.applyManualAction(ctx, 's1', 'departed', { at: at(0) });
  assert.equal(status(ctx, 's1'), 'departed');
  assert.deepEqual(r.events.map((e) => e.type), ['arrived']);
  engine.applyManualAction(ctx, 's2', 'arrived', { at: at(60) });
  assert.throws(() => engine.applyManualAction(ctx, 's2', 'skipped', { at: at(70) }), { code: 'stop_already_arrived' });
  const again = engine.applyManualAction(ctx, 's1', 'arrived', { at: at(80) });
  assert.equal(again.events.length, 0, 'idempotent on finished stops');
  assert.throws(() => engine.applyManualAction(ctx, 'nope', 'arrived', { at: at(0) }), { code: 'stop_not_on_trip' });
});

test('engine: changedStates serialises only touched stops', () => {
  const ctx = makeCtx();
  feed(ctx, [pt(300, 0), pt(590, 20), pt(600, 30)]);
  const changed = engine.changedStates(ctx);
  assert.ok(changed.find((c) => c.stopId === 's1' && c.status === 'arrived'));
});
