'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { freshDatabase, fakeBroadcaster, quietLogger } = require('../support/context');
const { createSettingsService } = require('../../src/services/settingsService');
const { createTripService } = require('../../src/services/tripService');

let pool;
let db;
let trips;
let bc;
let drv; // Route 2 driver
let otherDriver;
let amSchedule;
let pmSchedule;
let tripId;

// Same geometry as dev_seed.sql: Route n leaves school at bearing n*60 degrees.
const SCHOOL = { lat: -1.2463, lng: 36.6629 };
const onRoute2 = (km) => ({
  lat: SCHOOL.lat + (km / 111) * Math.cos((120 * Math.PI) / 180),
  lng: SCHOOL.lng + (km / 111) * Math.sin((120 * Math.PI) / 180),
});
/** Bus driving toward school from `fromKm` to `toKm`, one point every 10 s, ending ~now. */
function drive(fromKm, toKm, n, { endAgoS = 0, speedMps = 8 } = {}) {
  const now = Date.now();
  return Array.from({ length: n }, (_, i) => {
    const km = fromKm + ((toKm - fromKm) * i) / (n - 1);
    return { ...onRoute2(km), speedMps, accuracyM: 8, headingDeg: 300, recordedAt: new Date(now - (endAgoS + (n - 1 - i) * 10) * 1000) };
  });
}

test.before(async () => {
  ({ pool, db } = await freshDatabase('schoolbus_test_trips'));
  bc = fakeBroadcaster();
  trips = createTripService({ db, settings: createSettingsService({ db }), broadcaster: bc, logger: quietLogger });
  drv = (await db.one("SELECT id FROM users WHERE phone = '+254700000002'")).id;
  otherDriver = (await db.one("SELECT id FROM users WHERE phone = '+254700000003'")).id;
  const scheds = await db.many(
    `SELECT sc.id, sc.direction FROM schedules sc JOIN routes r ON r.id = sc.route_id WHERE r.name LIKE 'Route 2%'`,
  );
  amSchedule = scheds.find((s) => s.direction === 'to_school').id;
  pmSchedule = scheds.find((s) => s.direction === 'from_school').id;
});
test.after(() => pool.end());

test('driver sees both of today\'s schedules before starting', async () => {
  const today = await trips.listDriverToday(drv);
  assert.equal(today.length, 2);
  assert.ok(today.every((s) => s.tripStatus === 'not_started' && s.students === 30));
});

test('start trip is idempotent and only for the assigned driver', async () => {
  await assert.rejects(trips.startTrip({ scheduleId: amSchedule, driverId: otherDriver }), { code: 'not_your_route' });
  const first = await trips.startTrip({ scheduleId: amSchedule, driverId: drv });
  assert.equal(first.created, true);
  assert.equal(first.trip.status, 'active');
  assert.equal(first.trip.stops.length, 11);
  assert.equal(first.trip.stops[0].riders.length, 3);
  tripId = first.trip.id;
  const again = await trips.startTrip({ scheduleId: amSchedule, driverId: drv });
  assert.equal(again.created, false);
  assert.equal(again.trip.id, tripId);
  assert.ok(bc.calls.some((c) => c.event === 'trip:started'));
});

test('a second active trip on the same bus/driver is refused', async () => {
  await assert.rejects(trips.startTrip({ scheduleId: pmSchedule, driverId: drv }), (err) => ['bus_busy', 'driver_busy'].includes(err.code));
});

test('GPS: approaching then arrival at stop 1 creates outbox events and broadcasts', async () => {
  bc.calls.length = 0;
  // From 6.8 km to 6.0 km (stop 1 = Stage 10 at 6.0 km), final two points inside the radius.
  const points = [...drive(6.8, 6.05, 10, { endAgoS: 10 }), ...drive(6.0, 6.0, 2)].map((p, i, arr) => p);
  points[points.length - 2].recordedAt = new Date(Date.now() - 5000);
  const r = await trips.ingestPoints({ tripId, driverId: drv, points, source: 'live' });
  assert.equal(r.rejected, 0);
  assert.equal(r.processed, points.length);
  assert.ok(r.eventsCreated >= 2);

  const s1 = await db.one(
    `SELECT e.status FROM trip_stop_events e JOIN stops st ON st.id = e.stop_id WHERE e.trip_id = $1 AND st.sequence = 1`, [tripId],
  );
  assert.equal(s1.status, 'arrived');
  const events = await db.many(
    `SELECT te.event_type, st.sequence FROM trip_events te JOIN stops st ON st.id = te.stop_id
     WHERE te.trip_id = $1 ORDER BY te.id`, [tripId],
  );
  assert.deepEqual(events.filter((e) => e.sequence === 1).map((e) => e.eventType), ['approaching', 'arrived']);

  const pos = await db.one('SELECT trip_id FROM bus_positions bp JOIN trips t ON t.bus_id = bp.bus_id WHERE t.id = $1', [tripId]);
  assert.equal(pos.tripId, tripId);
  assert.ok(bc.calls.some((c) => c.to === `trip:${tripId}` && c.event === 'bus:location'));
  assert.ok(bc.calls.some((c) => c.to === 'fleet' && c.event === 'trip:stops'));
});

test('GPS: replaying the same batch is harmless (duplicates ignored, no new events)', async () => {
  const before = (await db.one('SELECT count(*)::int AS n FROM trip_events WHERE trip_id = $1', [tripId])).n;
  const pts = await db.many('SELECT lat, lng, speed_mps, accuracy_m, recorded_at FROM location_points WHERE trip_id = $1', [tripId]);
  const r = await trips.ingestPoints({
    tripId, driverId: drv, source: 'backlog',
    points: pts.map((p) => ({ lat: p.lat, lng: p.lng, speedMps: p.speedMps, accuracyM: p.accuracyM, recordedAt: p.recordedAt })),
  });
  assert.equal(r.duplicates, pts.length);
  assert.equal(r.processed, 0);
  const after = (await db.one('SELECT count(*)::int AS n FROM trip_events WHERE trip_id = $1', [tripId])).n;
  assert.equal(after, before);
});

test('GPS: points from the future or long before the trip are rejected; other drivers are refused', async () => {
  const r = await trips.ingestPoints({
    tripId, driverId: drv, points: [
      { ...onRoute2(6), recordedAt: new Date(Date.now() + 10 * 60000) },
      { ...onRoute2(6), recordedAt: new Date(Date.now() - 60 * 60000) },
    ],
  });
  assert.equal(r.rejected, 2);
  await assert.rejects(
    trips.ingestPoints({ tripId, driverId: otherDriver, points: drive(6, 5.9, 2) }),
    { code: 'not_your_trip' },
  );
});

test('driver check-on creates one "boarded" event per child', async () => {
  const student = await db.one(
    `SELECT ss.student_id FROM student_stops ss JOIN stops st ON st.id = ss.stop_id
     WHERE ss.schedule_id = $1 AND st.sequence = 1 LIMIT 1`, [amSchedule],
  );
  const r1 = await trips.recordStudentEvent({ tripId, driverId: drv, studentId: student.studentId, status: 'boarded' });
  assert.deepEqual([r1.recorded, r1.eventsCreated], [true, 1]);
  const r2 = await trips.recordStudentEvent({ tripId, driverId: drv, studentId: student.studentId, status: 'boarded' });
  assert.equal(r2.duplicate, true);
  const stranger = await db.one(
    `SELECT s.id FROM students s WHERE NOT EXISTS (SELECT 1 FROM student_stops ss WHERE ss.student_id = s.id AND ss.schedule_id = $1) LIMIT 1`,
    [amSchedule],
  );
  await assert.rejects(trips.recordStudentEvent({ tripId, driverId: drv, studentId: stranger.id, status: 'boarded' }), { status: 404 });
});

test('manual stop actions: depart stop 1, skip stop 2', async () => {
  const stops = await db.many('SELECT id, sequence FROM stops WHERE schedule_id = $1 ORDER BY sequence', [amSchedule]);
  await trips.markStop({ tripId, driverId: drv, stopId: stops[0].id, action: 'departed' });
  await trips.markStop({ tripId, driverId: drv, stopId: stops[1].id, action: 'skipped', reason: 'Road closed' });
  const rows = await db.many('SELECT stop_id, status, skipped_reason FROM trip_stop_events WHERE trip_id = $1', [tripId]);
  const byId = Object.fromEntries(rows.map((r) => [r.stopId, r]));
  assert.equal(byId[stops[0].id].status, 'departed');
  assert.equal(byId[stops[1].id].status, 'skipped');
  assert.equal(byId[stops[1].id].skippedReason, 'Road closed');
});

test('incidents: traffic delay notifies parents once; breakdown is critical', async () => {
  await trips.reportIncident({ tripId, driverId: drv, type: 'traffic', note: 'Jam at Kikuyu roundabout', notifyParents: true });
  await trips.reportIncident({ tripId, driverId: drv, type: 'traffic', notifyParents: true });
  await trips.reportIncident({ tripId, driverId: drv, type: 'breakdown', note: 'Flat tyre' });
  const ev = await db.many(
    "SELECT event_type, is_critical FROM trip_events WHERE trip_id = $1 AND event_type IN ('delay', 'breakdown') ORDER BY id", [tripId],
  );
  assert.deepEqual(ev.map((e) => [e.eventType, e.isCritical]), [['delay', false], ['breakdown', true]]);
  assert.equal((await db.one('SELECT count(*)::int AS n FROM incidents WHERE trip_id = $1', [tripId])).n, 3);
});

test('end trip: completes, measures distance, closes remaining stops and the live room', async () => {
  bc.calls.length = 0;
  const r = await trips.endTrip({ tripId, driverId: drv });
  assert.equal(r.status, 'completed');
  assert.ok(r.distanceM > 600 && r.distanceM < 1200, `distance ${r.distanceM}`);
  const open = await db.one(
    "SELECT count(*)::int AS n FROM trip_stop_events WHERE trip_id = $1 AND status IN ('pending', 'approaching', 'arrived')", [tripId],
  );
  assert.equal(open.n, 0);
  const pos = await db.one('SELECT bp.trip_id FROM bus_positions bp JOIN trips t ON t.bus_id = bp.bus_id WHERE t.id = $1', [tripId]);
  assert.equal(pos.tripId, null, 'location no longer shared after the trip');
  assert.ok(bc.calls.some((c) => c.event === '__close__'));
  await assert.rejects(trips.ingestPoints({ tripId, driverId: drv, points: drive(5, 4.9, 2) }), { code: 'trip_not_active' });
  await assert.rejects(trips.cancelTrip({ tripId, actor: { id: drv, role: 'driver' }, reason: 'late' }), { code: 'trip_not_cancellable' });
});

test('afternoon trip starts "at" the school gate; admin can pre-create and cancel trips', async () => {
  const pm = await trips.startTrip({ scheduleId: pmSchedule, driverId: drv });
  assert.equal(pm.trip.stops[0].isSchool, true);
  assert.equal(pm.trip.stops[0].status, 'arrived');
  const admin = (await db.one("SELECT id FROM users WHERE role = 'admin'")).id;
  const r = await trips.cancelTrip({ tripId: pm.trip.id, actor: { id: admin, role: 'admin' }, reason: 'School closed early' });
  assert.equal(r.status, 'cancelled');
  const ev = await db.one("SELECT is_critical, payload FROM trip_events WHERE trip_id = $1 AND event_type = 'trip_cancelled'", [pm.trip.id]);
  assert.equal(ev.isCritical, true);
  assert.equal(ev.payload.reason, 'School closed early');

  const tomorrow = (await db.one("SELECT ((now() AT TIME ZONE 'Africa/Nairobi')::date + 1)::text AS d")).d;
  const pre = await trips.createScheduledTrip({ scheduleId: amSchedule, serviceDate: tomorrow, driverId: otherDriver, actorId: admin });
  assert.equal(pre.status, 'scheduled');
  assert.equal(pre.driverId, otherDriver);
});
