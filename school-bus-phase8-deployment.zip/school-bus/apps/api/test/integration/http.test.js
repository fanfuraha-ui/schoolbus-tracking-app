'use strict';
/**
 * End-to-end through the real route modules, validation, auth middleware, error handler
 * and Socket.IO handlers (with framework stand-ins), against real services + database.
 */
const test = require('node:test');
const assert = require('node:assert/strict');
const fake = require('../support/fakeFramework');

fake.install();

const { freshDatabase, fakeSms, fakeTokens, pgHasher, quietLogger } = require('../support/context');
const { createSettingsService } = require('../../src/services/settingsService');
const { createAuthService } = require('../../src/services/authService');
const { createTripService } = require('../../src/services/tripService');
const { createParentService } = require('../../src/services/parentService');
const { createAdminService } = require('../../src/services/admin/adminService');
const { importStudentsCsv } = require('../../src/services/admin/importStudents');
const { createBroadcaster } = require('../../src/realtime/broadcaster');
const { attachRealtime } = require('../../src/realtime/socket');
const { createApp } = require('../../src/http/app');

let pool;
let app;
let io;
let ids;
const config = { corsOrigins: ['http://localhost:5173'], trustProxy: false };

const call = (method, url, { token, body, query } = {}) => fake.request(app, {
  method, url, body, query, headers: token ? { Authorization: `Bearer ${token}` } : {},
});
const tok = (id, role) => `access:${id}:${role}`;

test.before(async () => {
  let db;
  ({ pool, db } = await freshDatabase('schoolbus_test_http'));
  const settings = createSettingsService({ db });
  const broadcaster = createBroadcaster();
  const hasher = pgHasher(db);
  const services = {
    db,
    settings,
    authService: createAuthService({ db, hasher, tokens: fakeTokens, sms: fakeSms(), settings, otpPepper: 'pepper-for-tests-123', logger: quietLogger }),
    tripService: createTripService({ db, settings, broadcaster, logger: quietLogger }),
    parentService: createParentService({ db, settings }),
    adminService: createAdminService({ db, hasher, settings }),
    importStudents: (csv, opts) => importStudentsCsv({ db }, csv, opts),
  };
  app = createApp({ services, tokens: fakeTokens, config, logger: quietLogger });
  attachRealtime({ server: {}, tokens: fakeTokens, services, broadcaster, config, logger: quietLogger });
  io = fake.lastSocketServer();

  ids = {
    admin: (await db.one("SELECT id FROM users WHERE role = 'admin'")).id,
    driver3: (await db.one("SELECT id FROM users WHERE phone = '+254700000003'")).id,
    parentRoute1: (await db.one("SELECT id FROM users WHERE phone = '+254711000004'")).id,
    parentRoute3: (await db.one("SELECT id FROM users WHERE phone = '+254711000061'")).id,
    route1Trip: (await db.one("SELECT id FROM trips WHERE status = 'active'")).id,
    route3Am: (await db.one("SELECT sc.id FROM schedules sc JOIN routes r ON r.id = sc.route_id WHERE r.name LIKE 'Route 3%' AND sc.direction = 'to_school'")).id,
    student: (await db.one("SELECT id FROM students WHERE admission_no = 'ADM0004'")).id,
  };
});
test.after(() => pool.end());

test('health and unknown routes', async () => {
  assert.equal((await call('GET', '/health')).status, 200);
  const r = await call('GET', '/api/v1/nope');
  assert.equal(r.status, 404);
  assert.equal(r.body.error.code, 'route_not_found');
});

test('auth: login, validation errors and role checks', async () => {
  const ok = await call('POST', '/api/v1/auth/admin/login', {
    body: { email: 'admin@school.test', password: 'ChangeMe!2026', device: { deviceUid: 'browser-123456', platform: 'web' } },
  });
  assert.equal(ok.status, 200);
  assert.ok(ok.body.refreshToken);

  const bad = await call('POST', '/api/v1/auth/driver/login', { body: { phone: '0700000003', pin: '12', device: { deviceUid: 'x', platform: 'android' } } });
  assert.equal(bad.status, 400);
  assert.equal(bad.body.error.code, 'validation_failed');
  assert.ok(bad.body.error.details.some((d) => d.field === 'body.pin'));

  assert.equal((await call('GET', '/api/v1/admin/buses')).status, 401);
  assert.equal((await call('GET', '/api/v1/admin/buses', { token: tok(ids.parentRoute1, 'guardian') })).status, 403);
  assert.equal((await call('GET', '/api/v1/admin/buses', { token: 'garbage' })).status, 401);
});

test('admin: every read endpoint responds', async () => {
  const t = tok(ids.admin, 'admin');
  const sched = (await call('GET', '/api/v1/admin/schedules', { token: t, query: { limit: '5' } })).body.items[0].id;
  const urls = [
    ['/api/v1/admin/buses', { isActive: 'true' }], ['/api/v1/admin/routes', {}], ['/api/v1/admin/stops', { scheduleId: sched }],
    ['/api/v1/admin/students', { search: 'Student 1', limit: '10' }], [`/api/v1/admin/students/${ids.student}`, {}],
    ['/api/v1/admin/guardians', { search: 'Parent' }], ['/api/v1/admin/drivers', {}], ['/api/v1/admin/trips', {}],
    [`/api/v1/admin/trips/${ids.route1Trip}`, {}], ['/api/v1/admin/fleet', {}], ['/api/v1/admin/schedule-load', {}],
    ['/api/v1/admin/notifications', {}], ['/api/v1/admin/incidents', { open: 'true' }], ['/api/v1/admin/audit-logs', {}],
    ['/api/v1/admin/settings', {}],
  ];
  for (const [url, query] of urls) {
    const r = await call('GET', url, { token: t, query });
    assert.equal(r.status, 200, `${url} -> ${r.status} ${JSON.stringify(r.body)}`);
  }
  const student = await call('GET', `/api/v1/admin/students/${ids.student}`, { token: t });
  assert.equal(student.body.guardians.length, 1);
  assert.equal(student.body.stops.length, 2);
});

test('admin: create/update/delete with validation and conflict mapping', async () => {
  const t = tok(ids.admin, 'admin');
  const badPlate = await call('POST', '/api/v1/admin/buses', { token: t, body: { plateNumber: 'kda-1@' } });
  assert.equal(badPlate.status, 400);
  const created = await call('POST', '/api/v1/admin/buses', { token: t, body: { plateNumber: 'kdc 555q' } });
  assert.equal(created.status, 201);
  assert.equal(created.body.plateNumber, 'KDC 555Q');
  const dup = await call('POST', '/api/v1/admin/buses', { token: t, body: { plateNumber: 'KDC 555Q' } });
  assert.equal(dup.status, 409);
  assert.equal(dup.body.error.code, 'already_exists');
  const upd = await call('PATCH', `/api/v1/admin/buses/${created.body.id}`, { token: t, body: { capacity: 25 } });
  assert.equal(upd.body.capacity, 25);
  const del = await call('DELETE', `/api/v1/admin/buses/${created.body.id}`, { token: t });
  assert.equal(del.body.deactivated, true);
  const missing = await call('GET', '/api/v1/admin/buses/00000000-0000-0000-0000-000000000000', { token: t });
  assert.equal(missing.status, 404);

  const drv = await call('POST', '/api/v1/admin/drivers', { token: t, body: { fullName: 'New Driver', phone: '0799 000 111', pin: '2468' } });
  assert.equal(drv.status, 201);
  assert.equal((await call('POST', `/api/v1/admin/drivers/${drv.body.id}/reset-device`, { token: t })).status, 200);

  const settings = await call('PATCH', '/api/v1/admin/settings', { token: t, body: { default_approach_minutes: 7 } });
  assert.equal(settings.body.default_approach_minutes, 7);
  const badSetting = await call('PATCH', '/api/v1/admin/settings', { token: t, body: { default_approach_minutes: 99 } });
  assert.equal(badSetting.status, 400);
});

test('admin: CSV import over HTTP (dry run, then 422 on errors)', async () => {
  const t = tok(ids.admin, 'admin');
  const csv = 'admission_no,student_name,guardian_name,guardian_phone\nHTTP1,Kid One,Mum One,0746000001';
  const dry = await call('POST', '/api/v1/admin/import/students', { token: t, body: csv, query: { dryRun: 'true' } });
  assert.equal(dry.status, 200);
  assert.equal(dry.body.dryRun, true);
  const bad = await call('POST', '/api/v1/admin/import/students', { token: t, body: `${csv}\nHTTP2,Kid Two,Dad,123` });
  assert.equal(bad.status, 422);
  assert.equal(bad.body.errors[0].line, 3);
});

test('driver flow over HTTP: today -> start -> backlog upload -> stop -> end', async () => {
  const t = tok(ids.driver3, 'driver');
  const today = await call('GET', '/api/v1/driver/today', { token: t });
  assert.equal(today.body.schedules.length, 2);
  const started = await call('POST', `/api/v1/driver/schedules/${ids.route3Am}/start`, { token: t });
  assert.equal(started.status, 201);
  const tripId = started.body.trip.id;
  const stop1 = started.body.trip.stops[0];

  const now = Date.now();
  const up = await call('POST', `/api/v1/driver/trips/${tripId}/locations`, {
    token: t,
    body: { points: [0, 1, 2].map((i) => ({ lat: stop1.lat, lng: stop1.lng, speedMps: 0.5, accuracyM: 5, recordedAt: new Date(now - (3 - i) * 5000).toISOString() })) },
  });
  assert.equal(up.status, 200, JSON.stringify(up.body));
  // HTTP JSON gives recordedAt as a string; zod coerces it to a Date before the service sees it.
  assert.equal(up.body.processed, 3);

  const detail = await call('GET', `/api/v1/driver/trips/${tripId}`, { token: t });
  assert.equal(detail.body.stops[0].status, 'arrived');
  const dep = await call('POST', `/api/v1/driver/trips/${tripId}/stops/${stop1.stopId}`, { token: t, body: { action: 'departed' } });
  assert.equal(dep.status, 200);
  const inc = await call('POST', `/api/v1/driver/trips/${tripId}/incidents`, { token: t, body: { type: 'traffic', notifyParents: true } });
  assert.equal(inc.status, 201);
  const other = await call('GET', `/api/v1/driver/trips/${ids.route1Trip}`, { token: t });
  assert.equal(other.status, 403);
  const end = await call('POST', `/api/v1/driver/trips/${tripId}/end`, { token: t });
  assert.equal(end.body.status, 'completed');
});

test('parent flow over HTTP: overview, trip view, absence', async () => {
  const t = tok(ids.parentRoute1, 'guardian');
  const me = await call('GET', '/api/v1/parent/me', { token: t });
  assert.equal(me.status, 200);
  const view = await call('GET', `/api/v1/parent/trips/${ids.route1Trip}`, { token: t });
  assert.equal(view.status, 200);
  const notMine = await call('GET', `/api/v1/parent/trips/${ids.route1Trip}`, { token: tok(ids.parentRoute3, 'guardian') });
  assert.equal(notMine.status, 404);
  const prefs = await call('PATCH', '/api/v1/parent/preferences', { token: t, body: {} });
  assert.equal(prefs.status, 400);
  const date = new Date(Date.now() + 2 * 86400000).toISOString().slice(0, 10);
  const abs = await call('POST', '/api/v1/parent/absences', { token: t, body: { studentId: me.body.children[0].id, date } });
  assert.equal(abs.status, 201);
});

test('socket: auth required; driver location ack; parents can watch only their child\'s trip', async () => {
  await assert.rejects(io.connect('nonsense'), /unauthorized/);

  const admin = await io.connect(tok(ids.admin, 'admin'));
  assert.ok(admin.joined.has('fleet'));

  const parent = await io.connect(tok(ids.parentRoute1, 'guardian'));
  const watch = await parent.call('trip:watch', { tripId: ids.route1Trip });
  assert.equal(watch.ok, true);
  assert.ok(parent.joined.has(`trip:${ids.route1Trip}`));
  assert.ok(watch.view.bus);

  const stranger = await io.connect(tok(ids.parentRoute3, 'guardian'));
  const denied = await stranger.call('trip:watch', { tripId: ids.route1Trip });
  assert.equal(denied.ok, false);
  assert.equal(denied.error.code, 'forbidden');

  const driver1 = (await pool.query("SELECT driver_id FROM trips WHERE status = 'active' LIMIT 1")).rows[0].driver_id;
  const drv = await io.connect(tok(driver1, 'driver'));
  const pos = { lat: -1.2193, lng: 36.7097, speedMps: 8, accuracyM: 6, recordedAt: new Date().toISOString() };
  const ack = await drv.call('location', { tripId: ids.route1Trip, points: [pos] });
  assert.equal(ack.ok, true, JSON.stringify(ack));
  assert.equal(ack.accepted, 1);
  assert.ok(io.emitted.some((e) => e.room === `trip:${ids.route1Trip}` && e.event === 'bus:location'));
  assert.ok(io.emitted.some((e) => e.room === 'fleet' && e.event === 'bus:location'));

  const invalid = await drv.call('location', { tripId: ids.route1Trip, points: [] });
  assert.equal(invalid.error.code, 'validation_failed');
  const wrongTrip = await drv.call('location', { tripId: '00000000-0000-0000-0000-000000000000', points: [pos] });
  assert.equal(wrongTrip.ok, false);
});
