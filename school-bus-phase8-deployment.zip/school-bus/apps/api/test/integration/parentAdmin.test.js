'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { freshDatabase, fakeBroadcaster, pgHasher, quietLogger } = require('../support/context');
const { createSettingsService } = require('../../src/services/settingsService');
const { createTripService } = require('../../src/services/tripService');
const { createParentService } = require('../../src/services/parentService');
const { createAdminService } = require('../../src/services/admin/adminService');
const { importStudentsCsv } = require('../../src/services/admin/importStudents');

let pool;
let db;
let settings;
let parents;
let admin;
let trips;
let adminId;
let parentA; // guardian of children on Route 1 Stage 2
let parentB; // guardian on Route 3
let route1Trip;

test.before(async () => {
  ({ pool, db } = await freshDatabase('schoolbus_test_parent_admin'));
  settings = createSettingsService({ db });
  parents = createParentService({ db, settings });
  admin = createAdminService({ db, hasher: pgHasher(db), settings });
  trips = createTripService({ db, settings, broadcaster: fakeBroadcaster(), logger: quietLogger });
  adminId = (await db.one("SELECT id FROM users WHERE role = 'admin'")).id;
  parentA = (await db.one("SELECT id FROM users WHERE phone = '+254711000004'")).id; // student 4 -> Route 1, Stage 2
  parentB = (await db.one("SELECT id FROM users WHERE phone = '+254711000061'")).id; // student 61 -> Route 3
  route1Trip = (await db.one("SELECT id FROM trips WHERE status = 'active'")).id;   // seeded live trip (Route 1 AM)
});
test.after(() => pool.end());

const ctx = () => ({ actorId: adminId, ip: '127.0.0.1', userAgent: 'test' });

// ---------- parent ----------
test('parent overview lists only their children and today\'s rides', async () => {
  const o = await parents.getOverview(parentA);
  assert.equal(o.children.length, 1);
  assert.equal(o.children[0].fullName, 'Student 4');
  assert.equal(o.children[0].today.length, 2, 'morning + afternoon');
  const am = o.children[0].today.find((r) => r.direction === 'to_school');
  assert.equal(am.tripStatus, 'active');
  assert.equal(am.stopName, 'Kikuyu Town Stage 2');
});

test('parents can watch only trips carrying their own child, and see only their children', async () => {
  assert.equal(await parents.canWatchTrip(parentA, route1Trip), true);
  assert.equal(await parents.canWatchTrip(parentB, route1Trip), false);
  const view = await parents.getTripView(parentA, route1Trip);
  assert.ok(view.bus, 'bus position visible during an active trip');
  assert.equal(view.stops.length, 11);
  assert.deepEqual(view.myStops.flatMap((s) => s.children.map((c) => c.fullName)), ['Student 4']);
  assert.match(view.trip.serviceDate, /^\d{4}-\d{2}-\d{2}$/);
  await assert.rejects(parents.getTripView(parentB, route1Trip), { status: 404 });
});

test('absences: own child only, not in the past, no duplicates, removable', async () => {
  const child = (await parents.getOverview(parentA)).children[0];
  const tomorrow = (await db.one("SELECT ((now() AT TIME ZONE 'Africa/Nairobi')::date + 1)::text AS d")).d;
  const yesterday = (await db.one("SELECT ((now() AT TIME ZONE 'Africa/Nairobi')::date - 1)::text AS d")).d;
  const a = await parents.createAbsence(parentA, { studentId: child.id, date: tomorrow, reason: 'Clinic visit' });
  await assert.rejects(parents.createAbsence(parentA, { studentId: child.id, date: tomorrow }), { code: 'already_reported' });
  await assert.rejects(parents.createAbsence(parentA, { studentId: child.id, date: yesterday }), { code: 'date_in_past' });
  await assert.rejects(parents.createAbsence(parentB, { studentId: child.id, date: tomorrow }), { code: 'not_your_child' });
  assert.equal((await parents.listAbsences(parentA)).length, 1);
  await assert.rejects(parents.deleteAbsence(parentB, a.id), { status: 404 });
  assert.deepEqual(await parents.deleteAbsence(parentA, a.id), { deleted: true });
});

test('overview carries what the parent home screen needs: plate, stops away, today\'s absence id', async () => {
  const o = await parents.getOverview(parentA);
  assert.match(o.serviceDate, /^\d{4}-\d{2}-\d{2}$/);
  assert.deepEqual(o.school, { name: 'Greenfield Academy', phone: null });
  await settings.update({ school_phone: '0720 000 111' });
  assert.equal((await parents.getOverview(parentA)).school.phone, '+254720000111');
  await assert.rejects(settings.update({ school_phone: '12345' }), { code: 'invalid_setting' });
  await settings.update({ school_phone: '' });
  const [child] = o.children;
  const am = child.today.find((r) => r.direction === 'to_school');
  const pm = child.today.find((r) => r.direction === 'from_school');
  assert.match(am.plateNumber, /^K[A-Z]{2} /);
  assert.equal(typeof am.stopsAway, 'number', 'active trip: count of stops still to serve before theirs');
  assert.equal(pm.stopsAway, null, 'no count before the trip starts');
  assert.equal(pm.plateNumber, am.plateNumber, 'not-started rides fall back to the route\'s usual bus');
  assert.equal(am.absent, false);
  assert.equal(am.childEvent, null);

  const sid = child.id;
  await db.query("INSERT INTO student_trip_events (trip_id, student_id, status) VALUES ($1, $2, 'boarded')", [am.tripId, sid]);
  const boarded = (await parents.getOverview(parentA)).children[0].today.find((r) => r.direction === 'to_school');
  assert.equal(boarded.childEvent, 'boarded');
  assert.ok(boarded.childEventAt);
  const tv = await parents.getTripView(parentA, am.tripId);
  assert.equal(tv.myStops[0].children[0].event, 'boarded');
  await db.query('DELETE FROM student_trip_events WHERE trip_id = $1 AND student_id = $2', [am.tripId, sid]);

  const today = o.serviceDate;
  const ab = await parents.createAbsence(parentA, { studentId: child.id, date: today, scheduleId: pm.scheduleId });
  const after = (await parents.getOverview(parentA)).children[0].today;
  const pm2 = after.find((r) => r.direction === 'from_school');
  assert.equal(pm2.absent, true);
  assert.equal(pm2.absenceId, ab.id, 'the app can undo "not riding" with this id');
  assert.equal(pm2.absentAllDay, false);
  assert.equal(after.find((r) => r.direction === 'to_school').absent, false, 'only that ride');
  await parents.deleteAbsence(parentA, ab.id);
});

test('alert history shows one row per alert, with the channels that reached the parent', async () => {
  const trip = route1Trip;
  const g = parentA;
  const ins = (channel, status, key, at) => db.query(
    `INSERT INTO notifications (dedupe_key, channel, guardian_id, trip_id, event_type, to_address, title, body, status, created_at)
     VALUES ($1, $2, $3, $4, 'approaching', $5, 'Bus approaching', 'Bus KDA 101A is ~5 min from Kikuyu Town Stage 2.', $6, $7)`,
    [key, channel, g, trip, channel === 'sms' ? '+254711000004' : 'fcm-token-abcdef', status, at],
  );
  await ins('push', 'failed', 'k1', '2026-11-16T04:00:00Z');
  await ins('sms', 'delivered', 'k1', '2026-11-16T04:00:01Z');
  await ins('push', 'sent', 'k2', '2026-11-16T04:10:00Z');
  await ins('push', 'skipped', 'k3', '2026-11-16T04:20:00Z'); // quiet hours: never shown
  const list = await parents.listNotifications(g, { limit: 10 });
  assert.equal(list.length, 2);
  assert.deepEqual(list[0].channels, ['push']);
  assert.deepEqual(list[1].channels, ['sms'], 'push failed, the SMS fallback got through');
  assert.equal(list[1].status, 'sent');
  assert.equal(list[1].eventType, 'approaching');
  assert.equal(list[1].tripId, trip);
  await db.query("DELETE FROM notifications WHERE dedupe_key IN ('k1','k2','k3')");
});

test('preferences and consent update', async () => {
  const p = await parents.updatePreferences(parentA, { channelMode: 'sms', quietHours: { start: '21:00', end: '05:30' } });
  assert.equal(p.channelMode, 'sms');
  assert.equal(p.quietHoursStart, '21:00:00');
  const c = await parents.recordConsent(parentA, '2026-11');
  assert.equal(c.consentVersion, '2026-11');
});

// ---------- admin ----------
test('admin CRUD: create, update (audited), list with search, deactivate', async () => {
  const bus = await admin.crud.buses.create({ plateNumber: 'KDB 777Z', capacity: 33 }, ctx());
  const upd = await admin.crud.buses.update(bus.id, { capacity: 29 }, ctx());
  assert.equal(upd.capacity, 29);
  const list = await admin.crud.buses.list({ search: '777' });
  assert.equal(list.total, 1);
  await admin.crud.buses.remove(bus.id, ctx());
  assert.equal((await admin.crud.buses.get(bus.id)).isActive, false);
  const audit = await admin.listAudit({ entity: 'buses', entityId: bus.id });
  assert.deepEqual(audit.map((a) => a.action).sort(), ['bus.create', 'bus.deactivate', 'bus.update']);
  assert.deepEqual(audit.find((a) => a.action === 'bus.update').changes, { capacity: [33, 29] });
});

test('admin: guardians and drivers are created with normalised phones; duplicates refused', async () => {
  const g = await admin.createGuardian({ fullName: 'Wanjiru Kamau', phone: '0722 111 222' }, ctx());
  assert.equal(g.phone, '+254722111222');
  await assert.rejects(admin.createGuardian({ fullName: 'Dup', phone: '+254722111222' }, ctx()), { code: 'phone_in_use' });
  const d = await admin.createDriver({ fullName: 'Otieno Driver', phone: '0733000111', pin: '4321' }, ctx());
  const stored = await db.one('SELECT crypt($1, pin_hash) = pin_hash AS ok FROM users WHERE id = $2', ['4321', d.id]);
  assert.equal(stored.ok, true, 'PIN stored as bcrypt hash');
  await admin.resetDriverPin(d.id, '8765', ctx());
  const drivers = await admin.listDrivers();
  assert.ok(drivers.some((x) => x.id === d.id && x.deviceRegistered === false));
  const guardians = await admin.listGuardians({ search: 'Wanjiru' });
  assert.equal(guardians.total, 1);
});

test('admin: stops get default radius/sequence and can be reordered', async () => {
  const sched = await db.one("SELECT sc.id FROM schedules sc JOIN routes r ON r.id = sc.route_id WHERE r.name LIKE 'Route 6%' AND sc.direction = 'to_school'");
  const stop = await admin.createStop({ scheduleId: sched.id, name: 'New Estate Gate', lat: -1.25, lng: 36.67 }, ctx());
  assert.equal(stop.sequence, 12);
  assert.equal(stop.radiusM, 120);
  const ids = (await db.many('SELECT id FROM stops WHERE schedule_id = $1 ORDER BY sequence', [sched.id])).map((r) => r.id);
  const reversed = [...ids].reverse();
  const out = await admin.reorderStops(sched.id, reversed, ctx());
  assert.equal(out[0].id, reversed[0]);
  await assert.rejects(admin.reorderStops(sched.id, ids.slice(1), ctx()), { code: 'stop_list_mismatch' });
});

test('admin: trips list, fleet and capacity read models', async () => {
  const list = await admin.listTrips({});
  assert.ok(list.some((t) => t.id === route1Trip && t.stopsTotal === 11));
  const fleet = await admin.fleet();
  assert.equal(fleet.length, 1);
  const load = await admin.scheduleLoad();
  assert.equal(load.length, 12);
});

test('settings: validated updates only', async () => {
  const s = await settings.update({ delay_threshold_minutes: 15 });
  assert.equal(s.delay_threshold_minutes, 15);
  await assert.rejects(settings.update({ delay_escalation_minutes: [20, 10] }), { code: 'invalid_setting' });
  await assert.rejects(settings.update({ timezone: 'UTC' }), { code: 'setting_not_editable' });
});

// ---------- CSV import ----------
const CSV = [
  'Admission No,Student Name,Class Name,Guardian Name,Guardian Phone,Relationship,Guardian2 Name,Guardian2 Phone,Route,AM Stop,PM Stop',
  'NEW001,Achieng Otieno,Grade 3,Mary Otieno,0745 000 001,mother,John Otieno,0745000002,Route 4 - Muguga,Muguga Stage 3,Muguga Stage 3',
  'NEW002,"Kiprop, Brian",Grade 5,Mary Otieno,+254745000001,mother,,,Route 4 - Muguga,Muguga Stage 1,',
  'ADM0001,Student One (renamed),Grade 2,Parent 1,0711000001,father,,,,,',
].join('\r\n');

test('CSV import: bad rows are reported with line numbers and nothing is written', async () => {
  const bad = `${CSV}\nNEW003,No Phone,Grade 1,Someone,12345,,,,Route 9,Nowhere,`;
  const r = await importStudentsCsv({ db }, bad, { ctx: ctx() });
  assert.equal(r.ok, false);
  assert.ok(r.errors.some((e) => e.line === 5 && e.field === 'guardian_phone'));
  assert.ok(r.errors.some((e) => e.line === 5 && e.field === 'route'));
  assert.equal((await db.one("SELECT count(*)::int AS n FROM students WHERE admission_no LIKE 'NEW%'")).n, 0);
});

test('CSV import: dry run validates; real run creates, updates and assigns; re-import is idempotent', async () => {
  const dry = await importStudentsCsv({ db }, CSV, { dryRun: true });
  assert.deepEqual([dry.ok, dry.dryRun], [true, true]);
  const r = await importStudentsCsv({ db }, CSV, { ctx: ctx() });
  assert.equal(r.ok, true);
  assert.deepEqual(r.summary, { studentsCreated: 2, studentsUpdated: 1, guardiansCreated: 2, links: 4, assignments: 3 });
  const kiprop = await db.one("SELECT id, full_name FROM students WHERE admission_no = 'NEW002'");
  assert.equal(kiprop.fullName, 'Kiprop, Brian');
  const sibling = await db.one(
    `SELECT count(DISTINCT sg.student_id)::int AS n FROM student_guardians sg JOIN users u ON u.id = sg.guardian_id
     WHERE u.phone = '+254745000001'`,
  );
  assert.equal(sibling.n, 2, 'one guardian account linked to both siblings');
  assert.equal((await db.one("SELECT full_name FROM students WHERE admission_no = 'ADM0001'")).fullName, 'Student One (renamed)');
  const again = await importStudentsCsv({ db }, CSV, { ctx: ctx() });
  assert.deepEqual(again.summary, { studentsCreated: 0, studentsUpdated: 3, guardiansCreated: 0, links: 4, assignments: 3 });
});

test('CSV import: phone belonging to a driver is rejected; missing columns are reported', async () => {
  const r = await importStudentsCsv({ db }, 'admission_no,student_name,guardian_name,guardian_phone\nX1,Kid,Dad,0700000001');
  assert.equal(r.ok, false);
  assert.match(r.errors[0].message, /driver account/);
  await assert.rejects(importStudentsCsv({ db }, 'admission_no,student_name\nX,Y'), { code: 'missing_columns' });
});
