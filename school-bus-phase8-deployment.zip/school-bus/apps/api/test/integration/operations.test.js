'use strict';
/**
 * Phase 8 production health: worker heartbeat, SMS credit check, backup freshness,
 * GET /health/jobs (uptime monitor) and GET /admin/system (dashboard warnings).
 */
const test = require('node:test');
const assert = require('node:assert/strict');
const fake = require('../support/fakeFramework');

fake.install();

const { freshDatabase, fakeTokens, fakeSms, pgHasher, quietLogger } = require('../support/context');
const { createAuthService } = require('../../src/services/authService');
const { main: createAdminCli, oneTimePassword } = require('../../db/scripts/create-admin');
const { createSettingsService } = require('../../src/services/settingsService');
const { createAdminService } = require('../../src/services/admin/adminService');
const { createMonitors } = require('../../src/monitors');
const { createApp } = require('../../src/http/app');

let pool; let db; let settings; let admin;
let credit = { currency: 'KES', amount: 300 };
let balanceFails = false;
const sms = {
  send: async () => [],
  balance: async () => { if (balanceFails) throw new Error('HTTP 502'); return credit; },
};

const appWith = (config = {}) => createApp({
  services: { db, settings, adminService: createAdminService({ db, hasher: null, settings }) },
  tokens: fakeTokens,
  config: { corsOrigins: [], trustProxy: false, sms: { dryRun: false }, ...config },
  logger: quietLogger,
});
const get = (app, url) => fake.request(app, { method: 'GET', url, headers: { Authorization: `Bearer access:${admin}:admin` } });
const forgetJob = (name) => db.query('DELETE FROM job_runs WHERE name = $1', [name]);

test.before(async () => {
  ({ pool, db } = await freshDatabase('schoolbus_test_operations'));
  settings = createSettingsService({ db });
  admin = (await db.one("SELECT id FROM users WHERE role = 'admin'")).id;
});
test.after(() => pool.end());

test('worker heartbeat: every monitor run marks the worker alive; a stale heartbeat fails the health check', async () => {
  const app = appWith();
  const before = await get(app, '/health/jobs');
  assert.equal(before.status, 503, 'no heartbeat yet = worker down');
  assert.equal(before.body.checks.worker, false);

  await createMonitors({ db, settings, logger: quietLogger }).runAll();
  const after = await get(app, '/health/jobs');
  assert.equal(after.status, 200);
  assert.deepEqual(after.body, { ok: true, checks: { worker: true, backup: true, smsCredit: true } });

  await db.query("UPDATE job_runs SET last_run_at = now() - interval '10 minutes' WHERE name = 'monitors'");
  const stale = await get(app, '/api/v1/admin/system');
  assert.equal(stale.body.worker.ok, false);
  assert.equal(stale.body.worker.minutesAgo, 10);
  await createMonitors({ db, settings, logger: quietLogger }).runAll();
});

test('SMS credit: hourly check, days left from last week\'s spend, low credit fails health', async () => {
  const g = (await db.one("SELECT id FROM users WHERE phone = '+254711000001'")).id;
  // 2 school days of SMS: 100 + 50 = KES 150 over 2 days -> KES 75 a day.
  for (const [i, ago, cost] of [[1, '1 day', 100], [2, '2 days', 50]]) {
    await db.query(
      `INSERT INTO notifications (dedupe_key, channel, guardian_id, event_type, to_address, body, status, cost_kes, created_at)
       VALUES ($1, 'sms', $2, 'approaching', '+254711000001', 'x', 'sent', $3, now() - $4::interval)`,
      [`spend${i}`, g, cost, ago],
    );
  }
  const monitors = createMonitors({ db, settings, logger: quietLogger, sms });
  const run = await monitors.smsBalance();
  assert.equal(run.ran, true);
  assert.equal((await monitors.smsBalance()).ran, false, 'at most once an hour');

  const app = appWith();
  const st = (await get(app, '/api/v1/admin/system')).body.sms;
  assert.equal(st.status, 'ok');
  assert.equal(st.amount, 300);
  assert.equal(st.dailySpendKes, 75);
  assert.equal(st.daysLeft, 4);
  assert.equal(st.lowThresholdKes, 500);
  assert.equal(st.ok, false, 'KES 300 is below the KES 500 warning level');
  const h = await get(app, '/health/jobs');
  assert.equal(h.status, 503);
  assert.equal(h.body.checks.smsCredit, false);

  // Office lowers the warning level from the dashboard settings.
  await settings.update({ sms_low_balance_kes: 200 });
  assert.equal((await get(app, '/api/v1/admin/system')).body.sms.ok, true);
  await settings.update({ sms_low_balance_kes: 500 });

  // Topped up.
  credit = { currency: 'KES', amount: 2500 };
  await forgetJob('sms_balance');
  await monitors.smsBalance();
  assert.equal((await get(app, '/api/v1/admin/system')).body.sms.ok, true);
});

test('SMS credit: a failed check is "unknown", never a false low-credit alarm', async () => {
  balanceFails = true;
  await forgetJob('sms_balance');
  await createMonitors({ db, settings, logger: quietLogger, sms }).smsBalance();
  const st = (await get(appWith(), '/api/v1/admin/system')).body.sms;
  assert.equal(st.status, 'unknown');
  assert.equal(st.ok, true);
  balanceFails = false;
});

test('backups: judged only when BACKUPS_EXPECTED; must be recent and successful', async () => {
  const prod = appWith({ backupsExpected: true });
  assert.equal((await get(appWith(), '/health/jobs')).body.checks.backup, true, 'dev: backups not expected');
  assert.equal((await get(prod, '/health/jobs')).body.checks.backup, false, 'never ran');

  const record = (ago, result) => db.query(
    `INSERT INTO job_runs (name, last_run_at, last_result) VALUES ('backup', now() - $1::interval, $2::jsonb)
     ON CONFLICT (name) DO UPDATE SET last_run_at = EXCLUDED.last_run_at, last_result = EXCLUDED.last_result`,
    [ago, JSON.stringify(result)],
  );
  await record('3 hours', { status: 'ok', file: 'schoolbus-2026-11-17.dump', bytes: 4200000, offsite: true });
  const ok = (await get(prod, '/api/v1/admin/system')).body.backup;
  assert.deepEqual([ok.ok, ok.hoursAgo, ok.offsite, ok.file], [true, 3, true, 'schoolbus-2026-11-17.dump']);

  await record('30 hours', { status: 'ok', file: 'old.dump', bytes: 1, offsite: true });
  assert.equal((await get(prod, '/health/jobs')).status, 503);
  await record('1 hour', { status: 'failed', error: 'pg_dump: connection refused' });
  assert.equal((await get(prod, '/health/jobs')).body.checks.backup, false);
});

test('public health exposes no details; /admin/system needs an admin', async () => {
  const app = appWith();
  const h = await fake.request(app, { method: 'GET', url: '/health/jobs' });
  assert.deepEqual(Object.keys(h.body).sort(), ['checks', 'ok']);
  const anon = await fake.request(app, { method: 'GET', url: '/api/v1/admin/system' });
  assert.equal(anon.status, 401);
});

test('first admin on a fresh server: create-admin script, sign in with the one-time password, change it', async () => {
  const hasher = pgHasher(db);
  const auth = createAuthService({ db, hasher, tokens: fakeTokens, sms: fakeSms(), settings, otpPepper: 'pepper-for-tests-123' });
  const out = [];
  const origLog = console.log; const origErr = console.error;
  console.log = (m) => out.push(String(m)); console.error = (m) => out.push(String(m));
  let code; let again; let bad;
  try {
    code = await createAdminCli(['Lucy Wairimu', 'Lucy@School.ac.ke'], { db, hasher });
    again = await createAdminCli(['Lucy Wairimu', 'lucy@school.ac.ke'], { db, hasher });
    bad = await createAdminCli(['Lucy'], { db, hasher });
  } finally { console.log = origLog; console.error = origErr; }
  assert.deepEqual([code, again, bad], [0, 1, 2]);
  assert.match(out.join('\n'), /already exists/);
  const temp = out.find((l) => l.startsWith('One-time password: ')).split(': ')[1];
  assert.match(temp, /^[a-km-zA-HJ-NP-Z2-9]{14}$/, 'no look-alike characters');
  assert.notEqual(oneTimePassword(), oneTimePassword());

  const session = await auth.adminLogin({ email: 'lucy@school.ac.ke', password: temp, device: { deviceUid: 'web-1' } });
  const lucy = session.user.id;

  const app = createApp({
    services: { db, settings, authService: auth, adminService: createAdminService({ db, hasher, settings }) },
    tokens: fakeTokens, config: { corsOrigins: [], trustProxy: false }, logger: quietLogger,
  });
  const change = (body) => fake.request(app, { method: 'POST', url: '/api/v1/admin/me/password', body, headers: { Authorization: `Bearer access:${lucy}:admin` } });
  assert.equal((await change({ currentPassword: 'wrong', newPassword: 'Kikuyu-Road-2026' })).body.error.code, 'wrong_password');
  assert.equal((await change({ currentPassword: temp, newPassword: 'short' })).status, 400);
  assert.equal((await change({ currentPassword: temp, newPassword: temp })).status, 400, 'must differ');
  const ok = await change({ currentPassword: temp, newPassword: 'Kikuyu-Road-2026' });
  assert.deepEqual([ok.status, ok.body], [200, { ok: true }]);

  await assert.rejects(auth.adminLogin({ email: 'lucy@school.ac.ke', password: temp, device: { deviceUid: 'web-1' } }), /incorrect/);
  await auth.adminLogin({ email: 'lucy@school.ac.ke', password: 'Kikuyu-Road-2026', device: { deviceUid: 'web-1' } });
  const audit = await db.one("SELECT count(*)::int AS n FROM audit_logs WHERE action = 'admin.change_password' AND actor_id = $1", [lucy]);
  assert.equal(audit.n, 1);
});
