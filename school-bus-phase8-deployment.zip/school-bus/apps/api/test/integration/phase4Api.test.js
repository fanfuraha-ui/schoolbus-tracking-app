'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fake = require('../support/fakeFramework');

fake.install();

const { freshDatabase, fakeBroadcaster, fakeSms, fakeTokens, pgHasher, quietLogger } = require('../support/context');
const { createSettingsService } = require('../../src/services/settingsService');
const { createAuthService } = require('../../src/services/authService');
const { createTripService } = require('../../src/services/tripService');
const { createParentService } = require('../../src/services/parentService');
const { createAdminService } = require('../../src/services/admin/adminService');
const { importStudentsCsv } = require('../../src/services/admin/importStudents');
const { createDeliveryReportService } = require('../../src/notifications/deliveryReports');
const { createMonitors } = require('../../src/monitors');
const { createApp } = require('../../src/http/app');

let pool;
let db;
let app;
let admin;
let monitors;
const SECRET = 'webhook-secret-0123456789';
const call = (method, url, { body, query } = {}) => fake.request(app, {
  method, url, body, query, headers: { Authorization: `Bearer access:${admin}:admin` },
});

test.before(async () => {
  ({ pool, db } = await freshDatabase('schoolbus_test_phase4_api'));
  const settings = createSettingsService({ db });
  const hasher = pgHasher(db);
  const services = {
    db, settings,
    authService: createAuthService({ db, hasher, tokens: fakeTokens, sms: fakeSms(), settings, otpPepper: 'pepper-for-tests-123' }),
    tripService: createTripService({ db, settings, broadcaster: fakeBroadcaster(), logger: quietLogger }),
    parentService: createParentService({ db, settings }),
    adminService: createAdminService({ db, hasher, settings }),
    importStudents: (csv, opts) => importStudentsCsv({ db }, csv, opts),
    deliveryReports: createDeliveryReportService({ db }),
  };
  app = createApp({ services, tokens: fakeTokens, config: { corsOrigins: [], trustProxy: false, atWebhookSecret: SECRET }, logger: quietLogger });
  monitors = createMonitors({ db, settings, logger: quietLogger });
  admin = (await db.one("SELECT id FROM users WHERE role = 'admin'")).id;
});
test.after(() => pool.end());

test('delivery-report webhook: wrong secret is 404; Success marks delivered; Failed records the reason', async () => {
  const g = (await db.one("SELECT id FROM users WHERE phone = '+254711000001'")).id;
  const mk = (key, msgId) => db.query(
    `INSERT INTO notifications (dedupe_key, channel, guardian_id, event_type, to_address, body, status, provider_message_id, sent_at)
     VALUES ($1, 'sms', $2, 'approaching', '+254711000001', 'x', 'sent', $3, now())`, [key, g, msgId],
  );
  await mk('w1', 'ATXid_ok');
  await mk('w2', 'ATXid_bad');
  const bad = await fake.request(app, { method: 'POST', url: '/webhooks/africastalking/delivery/wrong', body: { id: 'ATXid_ok', status: 'Success' } });
  assert.equal(bad.status, 404);
  const url = `/webhooks/africastalking/delivery/${SECRET}`;
  const ok = await fake.request(app, { method: 'POST', url, body: { id: 'ATXid_ok', status: 'Success', phoneNumber: '+254711000001', networkCode: '63902' } });
  assert.deepEqual(ok.body, { ok: true, matched: 1, status: 'Success' });
  await fake.request(app, { method: 'POST', url, body: { id: 'ATXid_bad', status: 'Buffered' } });
  await fake.request(app, { method: 'POST', url, body: { id: 'ATXid_bad', status: 'Failed', failureReason: 'AbsentSubscriber' } });
  const rows = await db.many("SELECT dedupe_key, status, error, delivered_at IS NOT NULL AS d FROM notifications WHERE dedupe_key IN ('w1','w2') ORDER BY dedupe_key");
  assert.deepEqual(rows.map((r) => [r.status, r.d, r.error]), [['delivered', true, null], ['failed', false, 'delivery Failed: AbsentSubscriber']]);
  assert.equal((await db.one('SELECT count(*)::int AS n FROM sms_delivery_reports')).n, 3);
  const invalid = await fake.request(app, { method: 'POST', url, body: {} });
  assert.equal(invalid.status, 400);
});

test('no-service day cancels planned trips (optionally alerting parents) and stops planning', async () => {
  await db.query("UPDATE schedules SET start_time = ((now() AT TIME ZONE 'Africa/Nairobi') + interval '1 hour')::time");
  const planned = await monitors.planTrips();
  assert.ok(planned.created > 0);
  const today = (await db.one("SELECT (now() AT TIME ZONE 'Africa/Nairobi')::date::text AS d")).d;
  const r = await call('POST', '/api/v1/admin/no-service-days', { body: { date: today, reason: 'Heavy rains - school closed', notifyParents: true } });
  assert.equal(r.status, 201, JSON.stringify(r.body));
  assert.equal(r.body.cancelledTrips, planned.created);
  const ev = await db.one("SELECT count(*)::int AS n FROM trip_events WHERE event_type = 'trip_cancelled' AND is_critical");
  assert.equal(ev.n, planned.created);
  const dup = await call('POST', '/api/v1/admin/no-service-days', { body: { date: today, reason: 'again' } });
  assert.equal(dup.status, 409);
  assert.equal((await call('GET', '/api/v1/admin/no-service-days')).body.days.length, 1);
  assert.equal((await call('DELETE', `/api/v1/admin/no-service-days/${today}`)).status, 200);
  assert.equal((await call('GET', '/api/v1/admin/no-service-days')).body.days.length, 0);
});

test('reassign a not-yet-started trip; started trips cannot be reassigned', async () => {
  const tomorrow = (await db.one("SELECT ((now() AT TIME ZONE 'Africa/Nairobi')::date + 1)::text AS d")).d;
  const sched = (await db.one("SELECT sc.id FROM schedules sc JOIN routes r ON r.id = sc.route_id WHERE r.name LIKE 'Route 5%' AND sc.direction = 'to_school'")).id;
  const created = await call('POST', '/api/v1/admin/trips', { body: { scheduleId: sched, serviceDate: tomorrow } });
  assert.equal(created.status, 201);
  const spareDriver = (await db.one("SELECT id FROM users WHERE phone = '+254700000006'")).id;
  const r = await call('PATCH', `/api/v1/admin/trips/${created.body.id}`, { body: { driverId: spareDriver } });
  assert.equal(r.body.driverId, spareDriver);
  const active = (await db.one("SELECT id FROM trips WHERE status = 'active'")).id;
  const no = await call('PATCH', `/api/v1/admin/trips/${active}`, { body: { driverId: spareDriver } });
  assert.equal(no.status, 409);
  assert.equal((await call('PATCH', `/api/v1/admin/trips/${active}`, { body: {} })).status, 400);
});

test('notification summary and manual retry', async () => {
  const s = await call('GET', '/api/v1/admin/notifications/summary');
  assert.equal(s.status, 200);
  assert.ok(s.body.total >= 2);
  const failed = (await db.one("SELECT id FROM notifications WHERE status = 'failed' LIMIT 1")).id;
  const r = await call('POST', `/api/v1/admin/notifications/${failed}/retry`);
  assert.equal(r.status, 200);
  assert.equal((await db.one('SELECT status, attempts FROM notifications WHERE id = $1', [failed])).status, 'queued');
  const again = await call('POST', `/api/v1/admin/notifications/${failed}/retry`);
  assert.equal(again.status, 409);
});

test('reports: on-time %, delays, cancellations per route and day', async () => {
  const fixture = async (route, daysAgo, status, delayLevel) => {
    const t = await db.one(
      `INSERT INTO trips (schedule_id, service_date, bus_id, driver_id, status, scheduled_start_at, started_at, ended_at, distance_m, cancelled_reason)
       SELECT sc.id, (now() AT TIME ZONE 'Africa/Nairobi')::date - $2::int, r.default_bus_id, r.default_driver_id, $3::trip_status,
              now() - make_interval(days => $2::int), CASE WHEN $3 <> 'cancelled' THEN now() - make_interval(days => $2::int) + interval '4 minutes' END,
              CASE WHEN $3 = 'completed' THEN now() - make_interval(days => $2::int) + interval '1 hour' END,
              CASE WHEN $3 = 'completed' THEN 12000 END, CASE WHEN $3 = 'cancelled' THEN 'Rain' END
       FROM schedules sc JOIN routes r ON r.id = sc.route_id
       WHERE r.name LIKE $1 AND sc.direction = 'from_school' RETURNING id`,
      [`${route}%`, daysAgo, status],
    );
    if (delayLevel) await db.query("INSERT INTO trip_events (trip_id, event_type, escalation) VALUES ($1, 'delay', $2)", [t.id, delayLevel]);
  };
  await fixture('Route 6', 3, 'completed', 0);
  await fixture('Route 6', 4, 'completed', 2);
  await fixture('Route 6', 5, 'cancelled', 0);
  await fixture('Route 5', 3, 'completed', 0);
  const from = (await db.one("SELECT ((now() AT TIME ZONE 'Africa/Nairobi')::date - 6)::text AS d")).d;
  const to = (await db.one("SELECT ((now() AT TIME ZONE 'Africa/Nairobi')::date - 1)::text AS d")).d;
  const r = await call('GET', '/api/v1/admin/reports', { query: { from, to } });
  assert.equal(r.status, 200, JSON.stringify(r.body));
  assert.deepEqual([r.body.totals.trips, r.body.totals.completed, r.body.totals.cancelled, r.body.totals.onTime, r.body.totals.onTimePct], [4, 3, 1, 2, 67]);
  const r6 = r.body.byRoute.find((x) => x.routeName.startsWith('Route 6'));
  assert.deepEqual([r6.completed, r6.onTime, r6.delayed, r6.onTimePct, r6.distanceM, r6.avgStartLateMin], [2, 1, 1, 50, 24000, 4]);
  assert.equal(r.body.byDay.length, 3);
  const bad = await call('GET', '/api/v1/admin/reports', { query: { from: to, to: from } });
  assert.equal(bad.status, 400);
  const dflt = await call('GET', '/api/v1/admin/reports');
  assert.equal(dflt.status, 200);
});
