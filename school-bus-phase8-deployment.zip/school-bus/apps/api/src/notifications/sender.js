'use strict';
/**
 * Sends due notifications.
 *  - Claims rows with FOR UPDATE SKIP LOCKED + locked_until (safe with several workers;
 *    a crashed worker's claim simply expires).
 *  - SMS with identical text are sent in one Africa's Talking request (up to 100 numbers).
 *  - Retries with exponential backoff (30 s, 60 s, 120 s ... max 10 min).
 *  - Push failures fall back to SMS for push_then_sms guardians; dead FCM tokens are forgotten.
 *  - Non-critical alerts that are no longer useful are skipped as 'expired'
 *    (e.g. "bus is 5 min away" queued 20 minutes ago).
 */
const MAX_ATTEMPTS = { sms: 5, push: 3 };
const TTL_MINUTES = { approaching: 10, arrived: 15, boarded: 30, dropped_off: 30, delay: 20 };
// Africa's Talking per-recipient statusCodes worth retrying: 405 insufficient balance, 5xx gateway issues.
const RETRYABLE_SMS_CODES = new Set([405, 500, 501, 502]);
const SMS_BATCH = 100;

const backoffSeconds = (attempts) => Math.min(30 * 2 ** Math.max(0, attempts - 1), 600);

function createSender({ db, sms, push, logger }) {
  const markSent = (id, { messageId = null, cost = null } = {}) => db.query(
    `UPDATE notifications SET status = 'sent', sent_at = now(), provider_message_id = $2, cost_kes = $3,
            error = NULL, locked_until = NULL WHERE id = $1`,
    [id, messageId, cost],
  );
  const markFailed = (id, error) => db.query(
    "UPDATE notifications SET status = 'failed', error = $2, locked_until = NULL WHERE id = $1",
    [id, String(error).slice(0, 500)],
  );
  const markSkipped = (id, reason) => db.query(
    "UPDATE notifications SET status = 'skipped', error = $2, locked_until = NULL WHERE id = $1",
    [id, reason],
  );
  const reschedule = (row, error) => db.query(
    `UPDATE notifications SET next_attempt_at = now() + make_interval(secs => $2::int), error = $3, locked_until = NULL
     WHERE id = $1`,
    [row.id, backoffSeconds(row.attempts), String(error).slice(0, 500)],
  );

  async function retryOrFail(row, error) {
    if (row.attempts < MAX_ATTEMPTS[row.channel]) return reschedule(row, error);
    await markFailed(row.id, error);
    if (row.channel === 'push') await fallbackToSms(row);
    return undefined;
  }

  async function fallbackToSms(row) {
    const p = row.payload || {};
    if (!p.fallbackToSms || !p.phone) return;
    await db.query(
      `INSERT INTO notifications (dedupe_key, channel, guardian_id, trip_id, stop_id, student_id, event_type,
                                  is_critical, to_address, title, body, trip_event_id)
       VALUES ($1, 'sms', $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
       ON CONFLICT ON CONSTRAINT notifications_dedupe_uq DO NOTHING`,
      [row.dedupeKey, row.guardianId, row.tripId, row.stopId, row.studentId, row.eventType,
        row.isCritical, p.phone, row.title, p.smsBody || row.body, row.tripEventId],
    );
  }

  async function claim(limit) {
    return db.many(
      `UPDATE notifications n SET locked_until = now() + interval '2 minutes', attempts = n.attempts + 1
       WHERE n.id IN (
         SELECT id FROM notifications
         WHERE status = 'queued' AND next_attempt_at <= now()
           AND (locked_until IS NULL OR locked_until < now())
         ORDER BY is_critical DESC, created_at
         LIMIT $1 FOR UPDATE SKIP LOCKED)
       RETURNING n.*, (n.created_at < now() - make_interval(mins => COALESCE(($2::jsonb ->> n.event_type::text)::int, 1000000))
                       AND NOT n.is_critical) AS expired`,
      [limit, JSON.stringify(TTL_MINUTES)],
    );
  }

  async function sendPush(row) {
    try {
      const r = await push.send({ token: row.toAddress, title: row.title, body: row.body, data: row.payload?.data, critical: row.isCritical });
      await markSent(row.id, { messageId: r.messageId });
      return 'sent';
    } catch (err) {
      if (err.unregistered) {
        await db.query('UPDATE devices SET fcm_token = NULL WHERE fcm_token = $1', [row.toAddress]);
        await markFailed(row.id, `unregistered: ${err.message}`);
        await fallbackToSms(row);
        return 'failed';
      }
      if (err.retryable) { await retryOrFail(row, err.message); return 'retry'; }
      await markFailed(row.id, err.message);
      await fallbackToSms(row);
      return 'failed';
    }
  }

  async function sendSmsGroup(body, rows) {
    const out = { sent: 0, retry: 0, failed: 0 };
    let results;
    try {
      results = await sms.send({ to: rows.map((r) => r.toAddress), message: body });
    } catch (err) {
      logger?.warn({ err: err.message, count: rows.length }, 'SMS request failed; will retry');
      for (const r of rows) await retryOrFail(r, err.message);
      out.retry += rows.length;
      return out;
    }
    const byNumber = new Map(results.map((x) => [x.number, x]));
    for (const r of rows) {
      const res = byNumber.get(r.toAddress);
      if (res && res.accepted) {
        await markSent(r.id, { messageId: res.messageId, cost: res.cost });
        out.sent += 1;
      } else if (!res || RETRYABLE_SMS_CODES.has(res.statusCode)) {
        await retryOrFail(r, res ? `${res.statusCode} ${res.status}` : 'no result for number');
        out.retry += 1;
      } else {
        await markFailed(r.id, `${res.statusCode} ${res.status}`);
        out.failed += 1;
      }
    }
    return out;
  }

  /** Send up to `limit` due notifications. Returns counts. */
  async function sendDue(limit = 50) {
    const rows = await claim(limit);
    const counts = { claimed: rows.length, sent: 0, retry: 0, failed: 0, expired: 0 };
    const smsGroups = new Map();
    for (const row of rows) {
      if (row.expired) { await markSkipped(row.id, 'expired'); counts.expired += 1; continue; }
      if (row.channel === 'push') {
        counts[await sendPush(row)] += 1;
      } else {
        if (!smsGroups.has(row.body)) smsGroups.set(row.body, []);
        smsGroups.get(row.body).push(row);
      }
    }
    for (const [body, group] of smsGroups) {
      for (let i = 0; i < group.length; i += SMS_BATCH) {
        const r = await sendSmsGroup(body, group.slice(i, i + SMS_BATCH));
        counts.sent += r.sent; counts.retry += r.retry; counts.failed += r.failed;
      }
    }
    return counts;
  }

  return { sendDue };
}

module.exports = { createSender, backoffSeconds, TTL_MINUTES };
