'use strict';
/**
 * Outbox processor: turns each unprocessed trip_events row into per-guardian notification
 * rows (the send queue). Runs in one transaction; each event is isolated by a SAVEPOINT
 * so one bad event can't block the rest. Events are claimed with FOR UPDATE SKIP LOCKED,
 * so several worker instances can run side by side.
 *
 * Who gets what:
 *   approaching / arrived (stop)   guardians of children assigned to that stop (absences excluded)
 *   arrived (school gate, morning) guardians of children actually on the bus
 *   boarded / dropped_off          guardians of that child
 *   delay                          guardians of children still waiting (stop pending/approaching)
 *   breakdown                      guardians of children on the bus or still waiting
 *   trip_cancelled                 every guardian on the trip
 *
 * Channel policy per guardian:
 *   critical event (+ critical_events_force_sms)  push (if app installed) AND sms; ignores quiet hours
 *   channel_mode = sms                            sms
 *   channel_mode = push                           push; sms only if no app installed
 *   channel_mode = push_then_sms (default)        push; sms if push fails or no app installed
 *   quiet hours (non-critical)                    recorded as skipped, nothing sent
 */
const { renderAlert } = require('./templates');

const MAX_EVENT_ATTEMPTS = 5;
const ADMIN_ONLY = new Set(['stalled', 'trip_not_started']);

function inQuietHours(localTime, start, end) {
  if (!start || !end) return false;
  const t = localTime.slice(0, 8);
  const s = String(start).slice(0, 8);
  const e = String(end).slice(0, 8);
  return s <= e ? t >= s && t < e : t >= s || t < e; // handles windows that cross midnight
}

function createOutboxProcessor({ db, settings, logger }) {
  async function recipientsFor(t, ev, trip, stop) {
    if (ev.eventType === 'boarded' || ev.eventType === 'dropped_off') {
      return t.many(
        `SELECT u.id AS guardian_id, u.phone, g.channel_mode, g.preferred_language,
                g.quiet_hours_start, g.quiet_hours_end, s.full_name AS student_name
         FROM student_guardians sg
         JOIN guardians g ON g.user_id = sg.guardian_id
         JOIN users u ON u.id = g.user_id AND u.is_active
         JOIN students s ON s.id = sg.student_id
         WHERE sg.student_id = $1 AND sg.receives_alerts`,
        [ev.studentId],
      );
    }
    const rows = await t.many(
      `SELECT r.*, e.status AS stop_status
       FROM trip_stop_recipients r
       LEFT JOIN trip_stop_events e ON e.trip_id = r.trip_id AND e.stop_id = r.stop_id
       WHERE r.trip_id = $1`,
      [ev.tripId],
    );
    const waiting = (r) => !r.stopStatus || r.stopStatus === 'pending' || r.stopStatus === 'approaching';

    switch (ev.eventType) {
      case 'approaching':
      case 'arrived': {
        if (!stop) return [];
        if (!stop.isSchool) return rows.filter((r) => r.stopId === ev.stopId);
        // Morning arrival at school: only children who were actually picked up.
        const marks = await t.many('SELECT student_id, status FROM student_trip_events WHERE trip_id = $1', [ev.tripId]);
        const boarded = new Set(marks.filter((m) => m.status === 'boarded').map((m) => m.studentId));
        const missing = new Set(marks.filter((m) => m.status === 'absent' || m.status === 'no_show').map((m) => m.studentId));
        return rows.filter((r) => r.stopStatus !== 'skipped' && !missing.has(r.studentId)
          && (boarded.size === 0 || boarded.has(r.studentId)));
      }
      case 'delay':
        return rows.filter(waiting);
      case 'breakdown':
        return trip.direction === 'to_school'
          ? rows.filter((r) => r.stopStatus !== 'skipped')
          : rows.filter((r) => waiting(r) || r.stopStatus === 'arrived');
      case 'trip_cancelled':
        return rows;
      default:
        return [];
    }
  }

  function groupByGuardian(rows) {
    const map = new Map();
    for (const r of rows) {
      if (!map.has(r.guardianId)) map.set(r.guardianId, { ...r, children: [] });
      map.get(r.guardianId).children.push(r.studentName);
    }
    return [...map.values()];
  }

  async function expandEvent(t, ev, cfg) {
    if (ADMIN_ONLY.has(ev.eventType)) return 0;
    const trip = await t.one(
      `SELECT t.id, t.service_date, b.plate_number, sc.direction, sc.name AS schedule_name
       FROM trips t JOIN buses b ON b.id = t.bus_id JOIN schedules sc ON sc.id = t.schedule_id
       WHERE t.id = $1`,
      [ev.tripId],
    );
    if (!trip) return 0;
    const stop = ev.stopId ? await t.one('SELECT id, name, is_school FROM stops WHERE id = $1', [ev.stopId]) : null;
    const guardians = groupByGuardian(await recipientsFor(t, ev, trip, stop));
    if (!guardians.length) return 0;

    const tokens = new Map((await t.many(
      `SELECT DISTINCT ON (user_id) user_id, fcm_token FROM devices
       WHERE user_id = ANY($1::uuid[]) AND app = 'parent' AND fcm_token IS NOT NULL
       ORDER BY user_id, last_seen_at DESC`,
      [guardians.map((g) => g.guardianId)],
    )).map((d) => [d.userId, d.fcmToken]));

    const p = ev.payload || {};
    const rows = [];
    for (const g of guardians) {
      const { title, body } = renderAlert({
        eventType: ev.eventType,
        isSchool: Boolean(stop && stop.isSchool),
        lang: g.preferredLanguage,
        plate: trip.plateNumber,
        stopName: stop ? stop.name : '',
        schoolName: cfg.schoolName,
        children: g.children,
        etaMinutes: p.etaMinutes,
        delayMinutes: p.delayMinutes,
        reasonType: p.reason,
        reasonText: ev.eventType === 'trip_cancelled' ? p.reason : null,
        incidentType: p.type,
        direction: trip.direction,
      });
      const critical = ev.isCritical;
      const quiet = !critical && inQuietHours(cfg.localTime, g.quietHoursStart, g.quietHoursEnd);
      const token = tokens.get(g.guardianId);
      const base = {
        dedupe_key: `te:${ev.id}:${g.guardianId}`, guardian_id: g.guardianId, trip_id: ev.tripId, stop_id: ev.stopId,
        student_id: ev.studentId, event_type: ev.eventType, is_critical: critical, title, trip_event_id: ev.id,
        status: quiet ? 'skipped' : 'queued', error: quiet ? 'quiet_hours' : null,
      };
      const pushRow = () => ({
        ...base, channel: 'push', to_address: token, body,
        payload: {
          data: { type: ev.eventType, tripId: ev.tripId, stopId: ev.stopId ?? '' },
          fallbackToSms: g.channelMode === 'push_then_sms', phone: g.phone, smsBody: body,
        },
      });
      const smsRow = () => ({ ...base, channel: 'sms', to_address: g.phone, body, payload: {} });

      if (critical && cfg.forceSms) {
        if (token) rows.push({ ...pushRow(), payload: { ...pushRow().payload, fallbackToSms: false } });
        rows.push(smsRow());
      } else if (g.channelMode === 'sms' || !token) {
        rows.push(smsRow());
      } else {
        rows.push(pushRow());
      }
    }

    const inserted = await t.many(
      `INSERT INTO notifications (dedupe_key, channel, guardian_id, trip_id, stop_id, student_id, event_type,
                                  is_critical, to_address, title, body, payload, status, error, trip_event_id)
       SELECT x.dedupe_key, x.channel, x.guardian_id, x.trip_id, x.stop_id, x.student_id, x.event_type,
              x.is_critical, x.to_address, x.title, x.body, COALESCE(x.payload, '{}'::jsonb), x.status, x.error, x.trip_event_id
       FROM jsonb_to_recordset($1::jsonb) AS x(
         dedupe_key text, channel notification_channel, guardian_id uuid, trip_id uuid, stop_id uuid, student_id uuid,
         event_type notification_event, is_critical boolean, to_address text, title text, body text, payload jsonb,
         status notification_status, error text, trip_event_id bigint)
       ON CONFLICT ON CONSTRAINT notifications_dedupe_uq DO NOTHING
       RETURNING id`,
      [JSON.stringify(rows)],
    );
    return inserted.length;
  }

  /** Process up to `limit` events. Returns { events, notifications, failed }. */
  async function processBatch(limit = 20) {
    const s = await settings.all();
    const tz = s.timezone || 'Africa/Nairobi';
    return db.tx(async (t) => {
      const cfg = {
        schoolName: s.school_name || 'School',
        forceSms: s.critical_events_force_sms !== false,
        localTime: (await t.one("SELECT to_char(now() AT TIME ZONE $1, 'HH24:MI:SS') AS t", [tz])).t,
      };
      const events = await t.many(
        `SELECT * FROM trip_events WHERE processed_at IS NULL AND attempts < $2
         ORDER BY is_critical DESC, occurred_at LIMIT $1 FOR UPDATE SKIP LOCKED`,
        [limit, MAX_EVENT_ATTEMPTS],
      );
      let notifications = 0;
      let failed = 0;
      for (const ev of events) {
        await t.query('SAVEPOINT ev');
        try {
          notifications += await expandEvent(t, ev, cfg);
          await t.query('UPDATE trip_events SET processed_at = now(), attempts = attempts + 1, last_error = NULL WHERE id = $1', [ev.id]);
          await t.query('RELEASE SAVEPOINT ev');
        } catch (err) {
          failed += 1;
          await t.query('ROLLBACK TO SAVEPOINT ev');
          await t.query('UPDATE trip_events SET attempts = attempts + 1, last_error = $2 WHERE id = $1', [ev.id, String(err.message).slice(0, 500)]);
          logger?.error({ err, eventId: ev.id }, 'Failed to expand trip event');
        }
      }
      return { events: events.length, notifications, failed };
    });
  }

  return { processBatch };
}

module.exports = { createOutboxProcessor, inQuietHours };
