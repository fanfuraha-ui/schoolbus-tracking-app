'use strict';
/**
 * Africa's Talking SMS delivery reports (POSTed form-encoded to our callback URL):
 *   id, status, phoneNumber, networkCode, failureReason, retryCount
 * Success -> delivered. Sent/Submitted/Buffered -> still in progress (no change).
 * Anything else (Failed, Rejected, Expired, ...) -> failed with the carrier's reason.
 * Every report is also stored raw in sms_delivery_reports for audit/cost reconciliation.
 */
const { badRequest } = require('../lib/errors');

const IN_PROGRESS = new Set(['Sent', 'Submitted', 'Buffered']);

function createDeliveryReportService({ db }) {
  async function apply(report) {
    const id = report.id && String(report.id);
    const status = report.status && String(report.status);
    if (!id || !status) throw badRequest('invalid_report', 'Delivery report needs id and status');
    const failureReason = report.failureReason ? String(report.failureReason).slice(0, 200) : null;

    await db.query(
      `INSERT INTO sms_delivery_reports (provider_message_id, status, failure_reason, network_code, payload)
       VALUES ($1, $2, $3, $4, $5::jsonb)`,
      [id, status, failureReason, report.networkCode ? String(report.networkCode) : null, JSON.stringify(report)],
    );

    let updated = [];
    if (status === 'Success') {
      updated = await db.many(
        `UPDATE notifications SET status = 'delivered', delivered_at = now()
         WHERE provider_message_id = $1 AND channel = 'sms' AND status IN ('sent', 'failed') RETURNING id`,
        [id],
      );
    } else if (!IN_PROGRESS.has(status)) {
      updated = await db.many(
        `UPDATE notifications SET status = 'failed', error = $2
         WHERE provider_message_id = $1 AND channel = 'sms' AND status = 'sent' RETURNING id`,
        [id, `delivery ${status}${failureReason ? `: ${failureReason}` : ''}`],
      );
    }
    return { matched: updated.length, status };
  }

  return { apply };
}

module.exports = { createDeliveryReportService };
