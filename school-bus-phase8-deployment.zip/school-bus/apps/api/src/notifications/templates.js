'use strict';
/**
 * Parent alert wording, English + Kiswahili. Every SMS is fitted to ONE GSM-7 segment
 * (160 chars); long names/reasons are shortened rather than paying for a 2nd segment.
 * Push uses the same text plus a short title.
 */
const { fitSms } = require('./gsm');

/** Ensure exactly one full stop at the end (also tidies a truncated '...'). */
const endSentence = (s) => `${String(s || '').replace(/[.\s]+$/, '')}.`;

const firstName = (full) => String(full || '').trim().split(/\s+/)[0] || '';

/** "Amina" / "Amina & Brian" / "Amina, Brian & Chao" */
function joinNames(names) {
  const n = [...new Set(names.map(firstName).filter(Boolean))];
  if (n.length <= 1) return n[0] || '';
  return `${n.slice(0, -1).join(', ')} & ${n[n.length - 1]}`;
}

const REASONS = {
  en: { traffic: 'heavy traffic', weather: 'bad weather', road_closure: 'a road closure', breakdown: 'a breakdown', accident: 'an accident', other: 'an unexpected issue' },
  sw: { traffic: 'msongamano wa magari', weather: 'hali mbaya ya hewa', road_closure: 'barabara kufungwa', breakdown: 'hitilafu ya basi', accident: 'ajali', other: 'tatizo lisilotarajiwa' },
};
const PROBLEM = {
  en: { breakdown: 'has broken down', accident: 'has been in an accident', other: 'has a problem' },
  sw: { breakdown: 'limeharibika', accident: 'limepata ajali', other: 'limepata tatizo' },
};
const PERIOD = { en: { to_school: 'morning', from_school: 'afternoon' }, sw: { to_school: 'asubuhi', from_school: 'jioni' } };

// Each entry: (v) => { title, sms, flex } where flex lists variables that may be shortened.
const T = {
  en: {
    approaching: (v) => ({ title: `Bus is ${v.eta} min away`, sms: (x) => `Bus ${x.plate} is about ${x.eta} min from ${x.stop}. -${x.school}`, flex: ['stop'] }),
    arrived: (v) => ({ title: 'Bus has arrived', sms: (x) => `Bus ${x.plate} has arrived at ${x.stop}. -${x.school}`, flex: ['stop'] }),
    arrived_school: () => ({ title: 'Arrived at school', sms: (x) => `${x.names} arrived at school on bus ${x.plate}. -${x.school}`, flex: ['names'] }),
    boarded: () => ({ title: 'On the bus', sms: (x) => `${x.names} boarded bus ${x.plate} at ${x.stop}. -${x.school}`, flex: ['stop', 'names'] }),
    dropped_off: () => ({ title: 'Dropped off', sms: (x) => `${x.names} got off bus ${x.plate} at ${x.stop}. -${x.school}`, flex: ['stop', 'names'] }),
    delay: (v) => (v.delay
      ? { title: 'Bus running late', sms: (x) => `Bus ${x.plate} is running about ${x.delay} min late. We'll keep you updated. -${x.school}`, flex: [] }
      : { title: 'Bus delayed', sms: (x) => `Bus ${x.plate} is delayed by ${x.reason}. We'll keep you updated. -${x.school}`, flex: ['reason'] }),
    breakdown: () => ({ title: 'Important: bus problem', sms: (x) => `IMPORTANT: Bus ${x.plate} ${x.problem}. The school is handling it and will update you shortly. -${x.school}`, flex: [] }),
    trip_cancelled: () => ({ title: 'Bus trip cancelled', sms: (x) => `IMPORTANT: Today's ${x.period} bus (${x.plate}) is cancelled. Reason: ${endSentence(x.reason)} -${x.school}`, flex: ['reason'] }),
  },
  sw: {
    approaching: (v) => ({ title: `Basi liko dakika ${v.eta}`, sms: (x) => `Basi ${x.plate} litafika ${x.stop} baada ya takriban dakika ${x.eta}. -${x.school}`, flex: ['stop'] }),
    arrived: () => ({ title: 'Basi limefika', sms: (x) => `Basi ${x.plate} limefika ${x.stop}. -${x.school}`, flex: ['stop'] }),
    arrived_school: (v) => ({ title: 'Wamefika shuleni', sms: (x) => `${x.names} ${v.many ? 'wamefika' : 'amefika'} shuleni kwa basi ${x.plate}. -${x.school}`, flex: ['names'] }),
    boarded: (v) => ({ title: 'Amepanda basi', sms: (x) => `${x.names} ${v.many ? 'wamepanda' : 'amepanda'} basi ${x.plate} kituo cha ${x.stop}. -${x.school}`, flex: ['stop', 'names'] }),
    dropped_off: (v) => ({ title: 'Ameshuka', sms: (x) => `${x.names} ${v.many ? 'wameshuka' : 'ameshuka'} kutoka basi ${x.plate} kituo cha ${x.stop}. -${x.school}`, flex: ['stop', 'names'] }),
    delay: (v) => (v.delay
      ? { title: 'Basi limechelewa', sms: (x) => `Basi ${x.plate} limechelewa kwa takriban dakika ${x.delay}. Tutawajulisha zaidi. -${x.school}`, flex: [] }
      : { title: 'Basi limechelewa', sms: (x) => `Basi ${x.plate} limechelewa kwa sababu ya ${x.reason}. Tutawajulisha zaidi. -${x.school}`, flex: ['reason'] }),
    breakdown: () => ({ title: 'Muhimu: tatizo la basi', sms: (x) => `MUHIMU: Basi ${x.plate} ${x.problem}. Shule inashughulikia suala hili na itawajulisha hivi punde. -${x.school}`, flex: [] }),
    trip_cancelled: () => ({ title: 'Safari imesitishwa', sms: (x) => `MUHIMU: Basi la ${x.period} la leo (${x.plate}) limesitishwa. Sababu: ${endSentence(x.reason)} -${x.school}`, flex: ['reason'] }),
  },
};

/**
 * Render an alert.
 * ctx: { eventType, isSchool, lang, plate, stopName, schoolName, children: [names],
 *        etaMinutes, delayMinutes, reasonType, reasonText, incidentType, direction }
 * Returns { title, body } (body is a single-segment GSM-7 SMS).
 */
function renderAlert(ctx) {
  const lang = T[ctx.lang] ? ctx.lang : 'en';
  const key = ctx.eventType === 'arrived' && ctx.isSchool ? 'arrived_school' : ctx.eventType;
  const build = T[lang][key];
  if (!build) throw new Error(`No template for ${key}`);
  const many = new Set((ctx.children || []).map(firstName)).size > 1;
  const reason = ctx.reasonText || REASONS[lang][ctx.reasonType] || REASONS[lang].other;
  const vars = {
    plate: ctx.plate,
    stop: ctx.stopName,
    school: ctx.schoolName,
    names: joinNames(ctx.children || []),
    eta: ctx.etaMinutes,
    delay: ctx.delayMinutes,
    reason,
    problem: PROBLEM[lang][ctx.incidentType] || PROBLEM[lang].other,
    period: PERIOD[lang][ctx.direction] || PERIOD[lang].to_school,
  };
  const t = build({ ...vars, many });
  return { title: t.title, body: fitSms(t.sms, vars, { flex: t.flex }) };
}

module.exports = { renderAlert, joinNames, firstName };
