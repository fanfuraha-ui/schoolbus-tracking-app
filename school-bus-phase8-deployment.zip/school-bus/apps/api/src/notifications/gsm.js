'use strict';
/**
 * GSM-7 helpers. A single SMS holds 160 GSM-7 characters, but just ONE character outside
 * that alphabet (an emoji, a curly quote) switches the whole message to UCS-2 = 70 chars,
 * which can double or triple the cost. So every SMS is normalised to GSM-7 before sending.
 */
const BASIC = new Set(
  '@£$¥èéùìòÇ\nØø\rÅåΔ_ΦΓΛΩΠΨΣΘΞÆæßÉ !"#¤%&\'()*+,-./0123456789:;<=>?¡ABCDEFGHIJKLMNOPQRSTUVWXYZÄÖÑÜ§¿abcdefghijklmnopqrstuvwxyzäöñüà',
);
const EXTENDED = new Set('^{}\\[~]|€'); // each costs 2 characters

const REPLACEMENTS = [
  [/[‘’‚′]/g, "'"],
  [/[“”„″]/g, '"'],
  [/[–—−]/g, '-'],
  [/…/g, '...'],
  [/[   ]/g, ' '],
];

/** Convert text to GSM-7 only: normalise punctuation, strip accents, drop anything else. */
function toGsm7(input) {
  let s = String(input);
  for (const [re, rep] of REPLACEMENTS) s = s.replace(re, rep);
  let out = '';
  for (const ch of s) {
    if (BASIC.has(ch) || EXTENDED.has(ch)) { out += ch; continue; }
    const base = ch.normalize('NFD').replace(/[̀-ͯ]/g, '');
    out += [...base].filter((c) => BASIC.has(c)).join('');
  }
  return out.replace(/ {2,}/g, ' ').trim();
}

/** Length in GSM-7 septets (extended characters count double). */
function gsmLength(s) {
  let n = 0;
  for (const ch of s) n += EXTENDED.has(ch) ? 2 : 1;
  return n;
}

function truncate(s, max) {
  if (max <= 0) return '';
  if (gsmLength(s) <= max) return s;
  let out = '';
  for (const ch of s) {
    if (gsmLength(out) + (EXTENDED.has(ch) ? 2 : 1) > max - 3) break;
    out += ch;
  }
  // Prefer cutting at a word boundary, unless that would throw away more than a third.
  const lastSpace = out.lastIndexOf(' ');
  if (lastSpace > out.length * 0.66) out = out.slice(0, lastSpace);
  return `${out.replace(/[\s,;:.-]+$/, '')}...`;
}

/**
 * Build a single-segment SMS from a template function. `flex` names the variable that may
 * be shortened (e.g. a list of children's names or a free-text reason) to fit `limit`.
 */
function fitSms(render, vars, { flex = [], limit = 160 } = {}) {
  const clean = Object.fromEntries(Object.entries(vars).map(([k, v]) => [k, v == null ? v : toGsm7(String(v))]));
  let text = toGsm7(render(clean));
  for (const key of flex) {
    if (gsmLength(text) <= limit) break;
    const over = gsmLength(text) - limit;
    const current = clean[key] || '';
    clean[key] = truncate(current, Math.max(8, gsmLength(current) - over));
    text = toGsm7(render(clean));
  }
  return gsmLength(text) <= limit ? text : truncate(text, limit);
}

module.exports = { toGsm7, gsmLength, fitSms, truncate };
