'use strict';
/**
 * Generic, whitelisted CRUD for simple admin tables. Table and column names come only from
 * the static config below (never from user input); values are always bound parameters.
 * Every write is audited in the same transaction.
 */
const { notFound } = require('../../lib/errors');
const { writeAudit, diff } = require('../audit');

function createCrud({ db, entity, table, fields, softDeleteField = null, orderBy = 'created_at DESC', filters = {} }) {
  const columnOf = (key) => fields[key];

  function buildWhere(query) {
    const where = [];
    const params = [];
    for (const [key, def] of Object.entries(filters)) {
      const value = query[key];
      if (value === undefined || value === null || value === '') continue;
      if (def.op === 'ilike') {
        params.push(`%${String(value).replace(/[%_\\]/g, (m) => `\\${m}`)}%`);
        const cols = Array.isArray(def.column) ? def.column : [def.column];
        where.push(`(${cols.map((c) => `${c} ILIKE $${params.length}`).join(' OR ')})`);
      } else {
        params.push(value);
        where.push(`${def.column} = $${params.length}`);
      }
    }
    return { sql: where.length ? `WHERE ${where.join(' AND ')}` : '', params };
  }

  async function list({ limit = 50, offset = 0, ...query } = {}) {
    const { sql, params } = buildWhere(query);
    const total = await db.one(`SELECT count(*)::int AS n FROM ${table} ${sql}`, params);
    const rows = await db.many(
      `SELECT * FROM ${table} ${sql} ORDER BY ${orderBy} LIMIT $${params.length + 1} OFFSET $${params.length + 2}`,
      [...params, Math.min(limit, 500), offset],
    );
    return { total: total.n, limit, offset, items: rows };
  }

  async function get(id) {
    const row = await db.one(`SELECT * FROM ${table} WHERE id = $1`, [id]);
    if (!row) throw notFound(entity);
    return row;
  }

  async function create(data, ctx = {}) {
    const keys = Object.keys(data).filter((k) => columnOf(k) && data[k] !== undefined);
    const cols = keys.map(columnOf);
    const values = keys.map((k) => data[k]);
    return db.tx(async (t) => {
      const row = await t.one(
        `INSERT INTO ${table} (${cols.join(', ')}) VALUES (${cols.map((_, i) => `$${i + 1}`).join(', ')}) RETURNING *`,
        values,
      );
      await writeAudit(t, { ...ctx, action: `${entity.toLowerCase()}.create`, entity: table, entityId: row.id, changes: diff(null, pick(row, keys)) });
      return row;
    });
  }

  async function update(id, data, ctx = {}) {
    const keys = Object.keys(data).filter((k) => columnOf(k) && data[k] !== undefined);
    if (!keys.length) return get(id);
    return db.tx(async (t) => {
      const before = await t.one(`SELECT * FROM ${table} WHERE id = $1 FOR UPDATE`, [id]);
      if (!before) throw notFound(entity);
      const sets = keys.map((k, i) => `${columnOf(k)} = $${i + 2}`);
      const row = await t.one(
        `UPDATE ${table} SET ${sets.join(', ')} WHERE id = $1 RETURNING *`,
        [id, ...keys.map((k) => data[k])],
      );
      const changes = diff(pick(before, keys), pick(row, keys));
      if (Object.keys(changes).length) {
        await writeAudit(t, { ...ctx, action: `${entity.toLowerCase()}.update`, entity: table, entityId: id, changes });
      }
      return row;
    });
  }

  async function remove(id, ctx = {}) {
    return db.tx(async (t) => {
      let row;
      if (softDeleteField) {
        row = await t.one(`UPDATE ${table} SET ${softDeleteField} = false WHERE id = $1 RETURNING id`, [id]);
      } else {
        row = await t.one(`DELETE FROM ${table} WHERE id = $1 RETURNING id`, [id]);
      }
      if (!row) throw notFound(entity);
      await writeAudit(t, { ...ctx, action: `${entity.toLowerCase()}.${softDeleteField ? 'deactivate' : 'delete'}`, entity: table, entityId: id });
      return { id, deleted: !softDeleteField, deactivated: Boolean(softDeleteField) };
    });
  }

  return { list, get, create, update, remove };
}

function pick(row, keys) {
  const out = {};
  for (const k of keys) out[k] = row[k];
  return out;
}

/** Simple resources managed through the generic CRUD. Keys are API (camelCase) names. */
const RESOURCES = {
  buses: {
    entity: 'Bus', table: 'buses', softDeleteField: 'is_active', orderBy: 'plate_number',
    fields: { plateNumber: 'plate_number', capacity: 'capacity', isActive: 'is_active' },
    filters: { isActive: { column: 'is_active' }, search: { column: 'plate_number', op: 'ilike' } },
  },
  routes: {
    entity: 'Route', table: 'routes', softDeleteField: 'is_active', orderBy: 'name',
    fields: { name: 'name', description: 'description', defaultBusId: 'default_bus_id', defaultDriverId: 'default_driver_id', isActive: 'is_active' },
    filters: { isActive: { column: 'is_active' }, search: { column: 'name', op: 'ilike' } },
  },
  schedules: {
    entity: 'Schedule', table: 'schedules', softDeleteField: 'is_active', orderBy: 'start_time',
    fields: { routeId: 'route_id', name: 'name', direction: 'direction', daysOfWeek: 'days_of_week', startTime: 'start_time', isActive: 'is_active' },
    filters: { routeId: { column: 'route_id' }, isActive: { column: 'is_active' } },
  },
  stops: {
    entity: 'Stop', table: 'stops', softDeleteField: null, orderBy: 'schedule_id, sequence',
    fields: {
      scheduleId: 'schedule_id', sequence: 'sequence', name: 'name', landmark: 'landmark', lat: 'lat', lng: 'lng',
      radiusM: 'radius_m', approachMinutes: 'approach_minutes', scheduledTime: 'scheduled_time', isSchool: 'is_school', isActive: 'is_active',
    },
    filters: { scheduleId: { column: 'schedule_id' }, isActive: { column: 'is_active' } },
  },
  students: {
    entity: 'Student', table: 'students', softDeleteField: 'is_active', orderBy: 'full_name',
    fields: { admissionNo: 'admission_no', fullName: 'full_name', className: 'class_name', isActive: 'is_active', notes: 'notes' },
    filters: {
      isActive: { column: 'is_active' }, className: { column: 'class_name' },
      search: { column: ['full_name', 'admission_no'], op: 'ilike' },
    },
  },
};

module.exports = { createCrud, RESOURCES };
