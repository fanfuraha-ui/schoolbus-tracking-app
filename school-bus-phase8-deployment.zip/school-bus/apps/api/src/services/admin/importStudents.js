'use strict';
/**
 * Bulk import / update of students, guardians and stop assignments from a CSV export
 * (e.g. the school's spreadsheet). All-or-nothing: every row is validated first and
 * nothing is written if any row has an error. Re-importing the same file is safe.
 *
 * Columns (header names are case-insensitive; order doesn't matter):
 *   admission_no*, student_name*, class_name,
 *   guardian_name*, guardian_phone*, relationship,
 *   guardian2_name, guardian2_phone, guardian2_relationship,
 *   route, am_stop, pm_stop
 * route + am_stop/pm_stop are matched by name against the route's morning (to_school)
 * and afternoon (from_school) schedules.
 */
const { parseCsvObjects } = require('../../lib/csv');
const { normalizeKenyanPhone } = require('../../domain/phone');
const { badRequest } = require('../../lib/errors');
const { writeAudit } = require('../audit');

const REQUIRED = ['admission_no', 'student_name', 'guardian_name', 'guardian_phone'];
const RELATIONSHIPS = new Set(['mother', 'father', 'guardian', 'other']);
const MAX_ROWS = 2000;
const key = (s) => s.trim().toLowerCase().replace(/\s+/g, ' ');

async function importStudentsCsv({ db }, csvText, { dryRun = false, ctx = {} } = {}) {
  let parsed;
  try {
    parsed = parseCsvObjects(csvText);
  } catch (err) {
    throw badRequest('invalid_csv', err.message);
  }
  const { headers, records } = parsed;
  const missing = REQUIRED.filter((h) => !headers.includes(h));
  if (missing.length) throw badRequest('missing_columns', `Missing column(s): ${missing.join(', ')}`, { missing });
  if (!records.length) throw badRequest('empty_csv', 'The file has no data rows');
  if (records.length > MAX_ROWS) throw badRequest('too_many_rows', `Import at most ${MAX_ROWS} rows at a time`);

  // ---------- reference data ----------
  const routeRows = await db.many(
    `SELECT r.id AS route_id, r.name AS route_name, sc.id AS schedule_id, sc.direction, st.id AS stop_id, st.name AS stop_name
     FROM routes r JOIN schedules sc ON sc.route_id = r.id AND sc.is_active
     JOIN stops st ON st.schedule_id = sc.id AND st.is_active AND NOT st.is_school
     WHERE r.is_active`,
  );
  const routes = new Map(); // routeKey -> { to_school: Map(stopKey -> [{scheduleId, stopId}]), from_school: ... }
  for (const r of routeRows) {
    const rk = key(r.routeName);
    if (!routes.has(rk)) routes.set(rk, { to_school: new Map(), from_school: new Map() });
    const byStop = routes.get(rk)[r.direction];
    const sk = key(r.stopName);
    if (!byStop.has(sk)) byStop.set(sk, []);
    byStop.get(sk).push({ scheduleId: r.scheduleId, stopId: r.stopId });
  }

  const allPhones = [];
  for (const rec of records) {
    for (const p of [rec.guardian_phone, rec.guardian2_phone]) {
      const n = normalizeKenyanPhone(p || '');
      if (n) allPhones.push(n);
    }
  }
  const existingUsers = await db.many('SELECT id, phone, role FROM users WHERE phone = ANY($1::text[])', [allPhones]);
  const userByPhone = new Map(existingUsers.map((u) => [u.phone, u]));

  // ---------- validate ----------
  const errors = [];
  const warnings = [];
  const seenAdmission = new Map();
  const rows = [];
  for (const rec of records) {
    const line = rec._line;
    const err = (field, message) => errors.push({ line, field, message });
    for (const f of REQUIRED) if (!rec[f]) err(f, 'Required');
    if (rec.admission_no) {
      if (seenAdmission.has(rec.admission_no)) err('admission_no', `Duplicate of line ${seenAdmission.get(rec.admission_no)}`);
      seenAdmission.set(rec.admission_no, line);
    }
    const guardians = [];
    for (const [nameF, phoneF, relF] of [
      ['guardian_name', 'guardian_phone', 'relationship'],
      ['guardian2_name', 'guardian2_phone', 'guardian2_relationship'],
    ]) {
      if (!rec[phoneF] && !rec[nameF]) continue;
      const phone = normalizeKenyanPhone(rec[phoneF] || '');
      if (!phone) { err(phoneF, `"${rec[phoneF] || ''}" is not a valid Kenyan mobile number`); continue; }
      if (!rec[nameF]) err(nameF, 'Required when a phone is given');
      const relationship = (rec[relF] || 'guardian').toLowerCase();
      if (!RELATIONSHIPS.has(relationship)) err(relF, 'Use mother, father, guardian or other');
      const existing = userByPhone.get(phone);
      if (existing && existing.role !== 'guardian') err(phoneF, `Phone belongs to a ${existing.role} account`);
      guardians.push({ name: rec[nameF], phone, relationship });
    }
    if (guardians.length === 2 && guardians[0].phone === guardians[1].phone) err('guardian2_phone', 'Same as the first guardian');

    const assignments = [];
    if (rec.route) {
      const route = routes.get(key(rec.route));
      if (!route) err('route', `No active route named "${rec.route}"`);
      else {
        for (const [field, direction] of [['am_stop', 'to_school'], ['pm_stop', 'from_school']]) {
          if (!rec[field]) continue;
          const matches = route[direction].get(key(rec[field]));
          if (!matches) err(field, `No stop named "${rec[field]}" on ${rec.route} (${direction === 'to_school' ? 'morning' : 'afternoon'})`);
          else assignments.push(...matches);
        }
      }
    } else if (rec.am_stop || rec.pm_stop) {
      err('route', 'Route is required when a stop is given');
    }
    rows.push({ line, admissionNo: rec.admission_no, fullName: rec.student_name, className: rec.class_name || null, guardians, assignments });
  }

  if (errors.length) return { ok: false, dryRun, errors, warnings, rows: records.length };
  if (dryRun) return { ok: true, dryRun: true, errors: [], warnings, rows: records.length };

  // ---------- write ----------
  const summary = { studentsCreated: 0, studentsUpdated: 0, guardiansCreated: 0, links: 0, assignments: 0 };
  await db.tx(async (t) => {
    const guardianIds = new Map(existingUsers.filter((u) => u.role === 'guardian').map((u) => [u.phone, u.id]));
    for (const row of rows) {
      const student = await t.one(
        `INSERT INTO students (admission_no, full_name, class_name, is_active) VALUES ($1, $2, $3, true)
         ON CONFLICT (admission_no) DO UPDATE
           SET full_name = EXCLUDED.full_name, class_name = EXCLUDED.class_name, is_active = true
         RETURNING id, (xmax = 0) AS inserted`,
        [row.admissionNo, row.fullName, row.className],
      );
      summary[student.inserted ? 'studentsCreated' : 'studentsUpdated'] += 1;

      for (const [i, g] of row.guardians.entries()) {
        let gid = guardianIds.get(g.phone);
        if (!gid) {
          const u = await t.one("INSERT INTO users (role, full_name, phone) VALUES ('guardian', $1, $2) RETURNING id", [g.name, g.phone]);
          await t.query('INSERT INTO guardians (user_id) VALUES ($1)', [u.id]);
          gid = u.id;
          guardianIds.set(g.phone, gid);
          summary.guardiansCreated += 1;
        }
        await t.query(
          `INSERT INTO student_guardians (student_id, guardian_id, relationship) VALUES ($1, $2, $3)
           ON CONFLICT (student_id, guardian_id) DO UPDATE SET relationship = EXCLUDED.relationship`,
          [student.id, gid, g.relationship],
        );
        if (i === 0) {
          await t.query('UPDATE student_guardians SET is_primary = (guardian_id = $2) WHERE student_id = $1', [student.id, gid]);
        }
        summary.links += 1;
      }

      for (const a of row.assignments) {
        await t.query(
          `INSERT INTO student_stops (student_id, schedule_id, stop_id) VALUES ($1, $2, $3)
           ON CONFLICT (student_id, schedule_id) DO UPDATE SET stop_id = EXCLUDED.stop_id`,
          [student.id, a.scheduleId, a.stopId],
        );
        summary.assignments += 1;
      }
    }
    await writeAudit(t, { ...ctx, action: 'student.import_csv', entity: 'students', changes: { summary: [null, summary] } });
  });

  const over = await db.many('SELECT route_name, schedule_name, assigned_students, capacity FROM schedule_load WHERE over_capacity');
  for (const o of over) {
    warnings.push({ message: `${o.routeName} ${o.scheduleName}: ${o.assignedStudents} students for ${o.capacity} seats` });
  }
  return { ok: true, dryRun: false, errors: [], warnings, rows: records.length, summary };
}

module.exports = { importStudentsCsv };
