'use strict';
/**
 * Production health from the job_runs heartbeats:
 *   monitors     written by the worker every minute     -> is the alert worker alive?
 *   backup       written by deploy/backup/backup.sh     -> did last night's backup run (and go offsite)?
 *   sms_balance  written by the worker every hour       -> is there Africa's Talking credit left?
 *
 * status() is the full picture for the dashboard; public health only exposes ok/not-ok per check.
 */
const WORKER_STALE_MIN = 5;          // monitors run every minute
const BACKUP_STALE_MIN = 26 * 60;    // nightly, with two hours' slack
const SMS_STALE_MIN = 3 * 60;        // hourly check

function createSystemService({ db, settings, config = {}, now = () => Date.now() }) {
  async function status() {
    const rows = await db.many('SELECT name, last_run_at, last_result FROM job_runs');
    const by = Object.fromEntries(rows.map((r) => [r.name, r]));
    const minutesAgo = (r) => (r ? Math.round((now() - new Date(r.lastRunAt).getTime()) / 60000) : null);
    const s = await settings.all();

    const hb = by.monitors;
    const workerAge = minutesAgo(hb);
    const worker = {
      lastRunAt: hb ? hb.lastRunAt : null,
      minutesAgo: workerAge,
      failedMonitors: (hb && hb.lastResult && hb.lastResult.failed) || [],
      ok: workerAge != null && workerAge <= WORKER_STALE_MIN,
    };

    const b = by.backup;
    const br = (b && b.lastResult) || {};
    const backupAge = minutesAgo(b);
    const backupsExpected = Boolean(config.backupsExpected);
    const backup = {
      expected: backupsExpected,
      lastRunAt: b ? b.lastRunAt : null,
      hoursAgo: backupAge == null ? null : Math.round(backupAge / 6) / 10,
      status: br.status || null,
      file: br.file || null,
      bytes: br.bytes ?? null,
      offsite: br.offsite ?? null,
      // Only judged once the backup job is switched on (BACKUPS_EXPECTED), so dev stays green.
      ok: !backupsExpected || (backupAge != null && backupAge <= BACKUP_STALE_MIN && br.status === 'ok'),
    };

    const c = by.sms_balance;
    const cr = (c && c.lastResult) || {};
    const lowThresholdKes = Number(s.sms_low_balance_kes ?? 500);
    const known = cr.status === 'ok' && minutesAgo(c) <= SMS_STALE_MIN;
    const daily = Number(cr.dailySpendKes || 0);
    const sms = {
      dryRun: Boolean(config.sms && config.sms.dryRun),
      status: c ? (known ? 'ok' : cr.status === 'ok' ? 'stale' : cr.status) : 'not_checked',
      currency: cr.currency || null,
      amount: cr.amount ?? null,
      lowThresholdKes,
      dailySpendKes: daily,
      daysLeft: known && daily > 0 ? Math.floor(cr.amount / daily) : null,
      checkedAt: c ? c.lastRunAt : null,
      // "unknown" (the check itself failed) is shown on the dashboard but is not an outage.
      ok: !known || cr.amount >= lowThresholdKes,
    };

    return { ok: worker.ok && backup.ok && sms.ok, worker, backup, sms };
  }

  /** For uptime monitors: no details, just which checks fail. */
  async function publicHealth() {
    const st = await status();
    return { ok: st.ok, checks: { worker: st.worker.ok, backup: st.backup.ok, smsCredit: st.sms.ok } };
  }

  return { status, publicHealth };
}

module.exports = { createSystemService, WORKER_STALE_MIN, BACKUP_STALE_MIN };
