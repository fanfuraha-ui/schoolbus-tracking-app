'use strict';
/**
 * Parent-facing reads and actions. Every query is scoped by guardian_id, so a parent can
 * only ever see their own children, and bus location only while that child's trip is active.
 */
const { notFound, forbidden, badRequest, conflict } = require('../lib/errors');

function createParentService({ db, settings }) {
  async function canWatchTrip(guardianId, tripId) {
    const row = await db.one(
      `SELECT EXISTS (
         SELECT 1 FROM trips t
         JOIN student_stops ss ON ss.schedule_id = t.schedule_id
         JOIN students s ON s.id = ss.student_id AND s.is_active
         JOIN student_guardians sg ON sg.student_id = s.id
         WHERE t.id = $1 AND t.status = 'active' AND sg.guardian_id = $2) AS ok`,
      [tripId, guardianId],
    );
    return Boolean(row && row.ok);
  }

  async function getOverview(guardianId) {
    const { timezone, schoolName, schoolPhone } = await settings.tracking();
    const profile = await db.one(
      `SELECT u.id, u.full_name, u.phone, g.channel_mode, g.preferred_language,
              g.quiet_hours_start, g.quiet_hours_end, g.consent_at, g.consent_version
       FROM users u JOIN guardians g ON g.user_id = u.id WHERE u.id = $1`,
      [guardianId],
    );
    if (!profile) throw notFound('Guardian');
    const children = await db.many(
      `SELECT s.id, s.full_name, s.class_name FROM student_guardians sg
       JOIN students s ON s.id = sg.student_id AND s.is_active
       WHERE sg.guardian_id = $1 ORDER BY s.full_name`,
      [guardianId],
    );
    const rides = await db.many(
      `WITH today AS (SELECT (now() AT TIME ZONE $2)::date AS d)
       SELECT ss.student_id, sc.id AS schedule_id, sc.name AS schedule_name, sc.direction, sc.start_time,
              r.name AS route_name, st.id AS stop_id, st.name AS stop_name, st.landmark,
              st.scheduled_time, st.lat, st.lng,
              t.id AS trip_id, COALESCE(t.status::text, 'not_started') AS trip_status, t.cancelled_reason,
              COALESCE(tb.plate_number, rb.plate_number) AS plate_number,
              e.status AS stop_status, e.eta_at, e.arrived_at,
              ab.id AS absence_id, ab.schedule_id IS NULL AS absent_all_day, ab.id IS NOT NULL AS absent,
              -- Stops the bus still has to serve before this child's stop (active trips only).
              CASE WHEN t.status = 'active' THEN (
                SELECT count(*)::int FROM trip_stop_events e2 JOIN stops s2 ON s2.id = e2.stop_id
                WHERE e2.trip_id = t.id AND s2.sequence < st.sequence AND e2.status IN ('pending', 'approaching')
              ) END AS stops_away,
              (SELECT bp.recorded_at FROM bus_positions bp WHERE bp.trip_id = t.id AND t.status = 'active') AS bus_seen_at,
              ce.status AS child_event, ce.recorded_at AS child_event_at
       FROM student_guardians sg
       JOIN students s ON s.id = sg.student_id AND s.is_active
       JOIN student_stops ss ON ss.student_id = s.id
       JOIN schedules sc ON sc.id = ss.schedule_id AND sc.is_active
       JOIN routes r ON r.id = sc.route_id
       JOIN stops st ON st.id = ss.stop_id
       CROSS JOIN today
       LEFT JOIN trips t ON t.schedule_id = sc.id AND t.service_date = today.d
       LEFT JOIN trip_stop_events e ON e.trip_id = t.id AND e.stop_id = st.id
       LEFT JOIN buses tb ON tb.id = t.bus_id
       LEFT JOIN buses rb ON rb.id = r.default_bus_id
       LEFT JOIN LATERAL (
         SELECT a.id, a.schedule_id FROM absences a
         WHERE a.student_id = ss.student_id AND a.service_date = today.d
           AND (a.schedule_id IS NULL OR a.schedule_id = sc.id)
         ORDER BY a.schedule_id NULLS LAST LIMIT 1
       ) ab ON true
       -- What the driver last recorded for this child on this trip (boarded, dropped off, no-show).
       LEFT JOIN LATERAL (
         SELECT x.status::text, x.recorded_at FROM student_trip_events x
         WHERE x.trip_id = t.id AND x.student_id = ss.student_id ORDER BY x.recorded_at DESC LIMIT 1
       ) ce ON true
       WHERE sg.guardian_id = $1 AND extract(isodow FROM today.d)::int = ANY(sc.days_of_week)
       ORDER BY sc.start_time`,
      [guardianId, timezone],
    );
    return {
      profile,
      school: { name: schoolName, phone: schoolPhone },
      serviceDate: (await db.one('SELECT (now() AT TIME ZONE $1)::date::text AS d', [timezone])).d,
      children: children.map((c) => ({ ...c, today: rides.filter((r) => r.studentId === c.id) })),
    };
  }

  /** Live view of a trip: bus position + every stop's progress (for the map), plus which stops are theirs. */
  async function getTripView(guardianId, tripId) {
    const trip = await db.one(
      `SELECT t.id, t.status, t.service_date::text AS service_date, t.started_at, t.ended_at, t.cancelled_reason,
              sc.name AS schedule_name, sc.direction,
              r.name AS route_name, b.plate_number
       FROM trips t JOIN schedules sc ON sc.id = t.schedule_id JOIN routes r ON r.id = sc.route_id
       JOIN buses b ON b.id = t.bus_id
       WHERE t.id = $1`,
      [tripId],
    );
    const mine = await db.many(
      `SELECT ss.stop_id, s.id AS student_id, s.full_name,
              (SELECT x.status::text FROM student_trip_events x WHERE x.trip_id = t.id AND x.student_id = s.id
               ORDER BY x.recorded_at DESC LIMIT 1) AS event
       FROM trips t
       JOIN student_stops ss ON ss.schedule_id = t.schedule_id
       JOIN students s ON s.id = ss.student_id AND s.is_active
       JOIN student_guardians sg ON sg.student_id = s.id AND sg.guardian_id = $2
       WHERE t.id = $1`,
      [tripId, guardianId],
    );
    if (!trip || !mine.length) throw notFound('Trip');

    const stops = await db.many(
      `SELECT st.id AS stop_id, st.sequence, st.name, st.lat, st.lng, st.is_school, st.scheduled_time,
              e.status, e.eta_at, e.arrived_at, e.departed_at
       FROM trip_stop_events e JOIN stops st ON st.id = e.stop_id
       WHERE e.trip_id = $1 ORDER BY st.sequence`,
      [tripId],
    );
    const bus = trip.status === 'active'
      ? await db.one(
        `SELECT bp.lat, bp.lng, bp.speed_mps, bp.heading_deg, bp.recorded_at
         FROM bus_positions bp WHERE bp.trip_id = $1`,
        [tripId],
      )
      : null;
    const myStopIds = [...new Set(mine.map((m) => m.stopId))];
    return {
      trip,
      bus, // null unless the trip is active
      stops,
      myStops: myStopIds.map((stopId) => ({
        stopId,
        children: mine.filter((m) => m.stopId === stopId).map((m) => ({ studentId: m.studentId, fullName: m.fullName, event: m.event })),
      })),
    };
  }

  async function updatePreferences(guardianId, { channelMode, preferredLanguage, quietHours }) {
    const sets = [];
    const params = [guardianId];
    if (channelMode !== undefined) { params.push(channelMode); sets.push(`channel_mode = $${params.length}`); }
    if (preferredLanguage !== undefined) { params.push(preferredLanguage); sets.push(`preferred_language = $${params.length}`); }
    if (quietHours !== undefined) {
      params.push(quietHours ? quietHours.start : null);
      sets.push(`quiet_hours_start = $${params.length}`);
      params.push(quietHours ? quietHours.end : null);
      sets.push(`quiet_hours_end = $${params.length}`);
    }
    if (!sets.length) throw badRequest('nothing_to_update', 'No preferences supplied');
    return db.one(
      `UPDATE guardians SET ${sets.join(', ')} WHERE user_id = $1
       RETURNING channel_mode, preferred_language, quiet_hours_start, quiet_hours_end`,
      params,
    );
  }

  async function recordConsent(guardianId, version) {
    return db.one(
      'UPDATE guardians SET consent_at = now(), consent_version = $2 WHERE user_id = $1 RETURNING consent_at, consent_version',
      [guardianId, version],
    );
  }

  async function assertOwnChild(guardianId, studentId) {
    const ok = await db.one(
      'SELECT 1 AS ok FROM student_guardians sg JOIN students s ON s.id = sg.student_id AND s.is_active WHERE sg.guardian_id = $1 AND sg.student_id = $2',
      [guardianId, studentId],
    );
    if (!ok) throw forbidden('not_your_child', 'You can only manage your own children');
  }

  async function createAbsence(guardianId, { studentId, date, scheduleId, reason }) {
    const { timezone } = await settings.tracking();
    await assertOwnChild(guardianId, studentId);
    const check = await db.one(
      `SELECT $1::date >= (now() AT TIME ZONE $2)::date AS not_past,
              $1::date <= (now() AT TIME ZONE $2)::date + 60 AS not_too_far`,
      [date, timezone],
    );
    if (!check.notPast) throw badRequest('date_in_past', 'Absences can only be reported for today or later');
    if (!check.notTooFar) throw badRequest('date_too_far', 'Absences can be reported up to 60 days ahead');
    if (scheduleId) {
      const rides = await db.one('SELECT 1 AS ok FROM student_stops WHERE student_id = $1 AND schedule_id = $2', [studentId, scheduleId]);
      if (!rides) throw badRequest('not_on_schedule', 'Your child does not ride on that trip');
    }
    try {
      return await db.one(
        `INSERT INTO absences (student_id, service_date, schedule_id, reason, reported_by)
         VALUES ($1, $2::date, $3, $4, $5) RETURNING *`,
        [studentId, date, scheduleId ?? null, reason ?? null, guardianId],
      );
    } catch (err) {
      if (err.code === '23505') throw conflict('already_reported', 'This absence has already been reported');
      throw err;
    }
  }

  async function deleteAbsence(guardianId, absenceId) {
    const { timezone } = await settings.tracking();
    const row = await db.one(
      `DELETE FROM absences a USING student_guardians sg
       WHERE a.id = $1 AND sg.student_id = a.student_id AND sg.guardian_id = $2
         AND a.service_date >= (now() AT TIME ZONE $3)::date
       RETURNING a.id`,
      [absenceId, guardianId, timezone],
    );
    if (!row) throw notFound('Absence');
    return { deleted: true };
  }

  async function listAbsences(guardianId) {
    const { timezone } = await settings.tracking();
    return db.many(
      `SELECT a.id, a.student_id, s.full_name, a.service_date::text AS service_date, a.schedule_id, a.reason
       FROM absences a JOIN student_guardians sg ON sg.student_id = a.student_id AND sg.guardian_id = $1
       JOIN students s ON s.id = a.student_id
       WHERE a.service_date >= (now() AT TIME ZONE $2)::date
       ORDER BY a.service_date`,
      [guardianId, timezone],
    );
  }

  /**
   * One row per alert, not per channel: a push and its fallback SMS share a dedupe_key, so they are
   * folded together and `channels` says how it reached the parent. Quiet-hours skips are left out
   * because the parent was never told; failed rows stay so "why didn't I get an SMS?" has an answer.
   */
  async function listNotifications(guardianId, { limit = 50 } = {}) {
    return db.many(
      `SELECT (array_agg(n.id ORDER BY n.channel))[1] AS id,
              min(n.event_type::text) AS event_type, bool_or(n.is_critical) AS is_critical,
              min(n.title) AS title, (array_agg(n.body ORDER BY n.channel))[1] AS body,
              min(n.trip_id::text)::uuid AS trip_id, min(s.full_name) AS student_name,
              min(n.created_at) AS created_at,
              array_agg(DISTINCT n.channel::text) FILTER (WHERE n.status IN ('sent', 'delivered')) AS channels,
              CASE WHEN bool_or(n.status IN ('sent', 'delivered')) THEN 'sent'
                   WHEN bool_or(n.status = 'queued') THEN 'queued' ELSE 'failed' END AS status
       FROM notifications n LEFT JOIN students s ON s.id = n.student_id
       WHERE n.guardian_id = $1 AND n.status <> 'skipped'
       GROUP BY n.dedupe_key
       ORDER BY min(n.created_at) DESC LIMIT $2`,
      [guardianId, Math.min(limit, 200)],
    ).then((rows) => rows.map((r) => ({ ...r, channels: r.channels || [] })));
  }

  return {
    canWatchTrip, getOverview, getTripView, updatePreferences, recordConsent,
    createAbsence, deleteAbsence, listAbsences, listNotifications,
  };
}

module.exports = { createParentService };
