'use strict';

/**
 * Record an admin/driver action. `db` may be a transaction handle so the audit row
 * commits (or rolls back) together with the change it describes.
 */
async function writeAudit(db, { actorId = null, action, entity, entityId = null, changes = null, ip = null, userAgent = null }) {
  await db.query(
    `INSERT INTO audit_logs (actor_id, action, entity, entity_id, changes, ip, user_agent)
     VALUES ($1, $2, $3, $4, $5::jsonb, $6::inet, $7)`,
    [actorId, action, entity, entityId == null ? null : String(entityId),
      changes == null ? null : JSON.stringify(changes), ip, userAgent],
  );
}

/** Field-level diff for audit logs: {field: [old, new]} for changed keys only. */
function diff(before, after) {
  const out = {};
  for (const key of Object.keys(after)) {
    const a = before ? before[key] : undefined;
    const b = after[key];
    if (JSON.stringify(a) !== JSON.stringify(b)) out[key] = [a ?? null, b ?? null];
  }
  return out;
}

module.exports = { writeAudit, diff };
