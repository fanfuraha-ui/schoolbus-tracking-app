'use strict';
/**
 * Trip lifecycle + GPS ingestion.
 *
 * Every mutating call runs in one transaction holding a per-trip advisory lock, so the
 * live socket stream and an HTTP backlog upload for the same trip can never interleave.
 * Alert-worthy events go to the trip_events outbox inside that same transaction;
 * broadcasts to sockets happen only after commit.
 *
 * broadcaster: { toTrip(tripId, event, data), toFleet(event, data), closeTrip(tripId) }
 */
const engine = require('../domain/tripEngine');
const { legKey } = require('../domain/eta');
const { notFound, forbidden, conflict, AppError } = require('../lib/errors');
const { writeAudit } = require('./audit');

const FUTURE_TOLERANCE_MS = 60 * 1000;
const BEFORE_START_TOLERANCE_MS = 5 * 60 * 1000;
const MAX_ACCURACY_FOR_HISTORY_M = 100;

function createTripService({ db, settings, broadcaster, logger, clock = () => new Date() }) {
  // ---------- helpers ----------
  const lockTrip = (t, tripId) => t.query('SELECT pg_advisory_xact_lock(hashtext($1))', [`trip:${tripId}`]);

  async function loadTrip(t, tripId) {
    const trip = await t.one(
      `SELECT t.*, sc.direction, sc.route_id
       FROM trips t JOIN schedules sc ON sc.id = t.schedule_id WHERE t.id = $1`,
      [tripId],
    );
    if (!trip) throw notFound('Trip');
    return trip;
  }

  function assertDriver(trip, driverId) {
    if (trip.driverId !== driverId) throw forbidden('not_your_trip', 'This trip is assigned to another driver');
  }

  function assertActive(trip) {
    if (trip.status !== 'active') throw conflict('trip_not_active', `This trip is ${trip.status}`);
  }

  async function loadContext(t, trip, { timezone, withHistory = false }) {
    const rows = await t.many(
      `SELECT st.id, st.sequence, st.name, st.lat, st.lng, st.radius_m, st.approach_minutes, st.is_school,
              e.status, e.eta_at, e.approaching_at, e.arrived_at, e.departed_at, e.skipped_reason
       FROM trip_stop_events e JOIN stops st ON st.id = e.stop_id
       WHERE e.trip_id = $1 ORDER BY st.sequence`,
      [trip.id],
    );
    const stops = rows.map((r) => ({
      id: r.id, sequence: r.sequence, name: r.name, lat: r.lat, lng: r.lng,
      radiusM: r.radiusM, approachMinutes: r.approachMinutes, isSchool: r.isSchool,
    }));
    const states = rows.map((r) => ({
      stopId: r.id, status: r.status, etaAt: r.etaAt, approachingAt: r.approachingAt,
      arrivedAt: r.arrivedAt, departedAt: r.departedAt, skippedReason: r.skippedReason,
    }));

    let recentPoints = [];
    const segmentStats = new Map();
    if (withHistory) {
      if (trip.lastPointAt) {
        recentPoints = await t.many(
          `SELECT lat, lng, speed_mps, accuracy_m, recorded_at FROM location_points
           WHERE trip_id = $1 AND recorded_at <= $2 AND recorded_at > $2::timestamptz - interval '180 seconds'
             AND (accuracy_m IS NULL OR accuracy_m <= $3)
           ORDER BY recorded_at`,
          [trip.id, trip.lastPointAt, MAX_ACCURACY_FOR_HISTORY_M],
        );
      }
      if (stops.length) {
        const stats = await t.many(
          `SELECT from_stop_id, to_stop_id, median_seconds FROM segment_stats
           WHERE from_stop_id = ANY($1::uuid[]) AND hour_bucket = extract(hour FROM now() AT TIME ZONE $2)::int`,
          [stops.map((s) => s.id), timezone],
        );
        for (const s of stats) segmentStats.set(legKey(s.fromStopId, s.toStopId), s.medianSeconds);
      }
    }
    return engine.createTripContext({
      trip: { id: trip.id, direction: trip.direction },
      stops,
      states,
      recentPoints: recentPoints.map((p) => ({
        lat: p.lat, lng: p.lng, speedMps: p.speedMps, accuracyM: p.accuracyM, recordedAt: p.recordedAt,
      })),
      segmentStats,
    });
  }

  async function persistStates(t, tripId, changed) {
    if (!changed.length) return;
    await t.query(
      `UPDATE trip_stop_events e
         SET status = x.status, eta_at = x.eta_at, approaching_at = x.approaching_at,
             arrived_at = x.arrived_at, departed_at = x.departed_at, skipped_reason = x.skipped_reason
       FROM jsonb_to_recordset($2::jsonb) AS x(
         stop_id uuid, status stop_event_status, eta_at timestamptz, approaching_at timestamptz,
         arrived_at timestamptz, departed_at timestamptz, skipped_reason text)
       WHERE e.trip_id = $1 AND e.stop_id = x.stop_id`,
      [tripId, JSON.stringify(changed.map((c) => ({
        stop_id: c.stopId, status: c.status, eta_at: c.etaAt, approaching_at: c.approachingAt,
        arrived_at: c.arrivedAt, departed_at: c.departedAt, skipped_reason: c.skippedReason,
      })))],
    );
  }

  async function persistSegments(t, tripId, segments, timezone) {
    if (!segments.length) return;
    await t.query(
      `INSERT INTO trip_segment_times (trip_id, from_stop_id, to_stop_id, seconds, hour_bucket)
       SELECT $1, x.from_stop_id, x.to_stop_id, x.seconds,
              extract(hour FROM x.started_at AT TIME ZONE $3)::smallint
       FROM jsonb_to_recordset($2::jsonb) AS x(from_stop_id uuid, to_stop_id uuid, seconds int, started_at timestamptz)
       ON CONFLICT (trip_id, from_stop_id) DO NOTHING`,
      [tripId, JSON.stringify(segments.map((s) => ({
        from_stop_id: s.fromStopId, to_stop_id: s.toStopId, seconds: s.seconds, started_at: s.startedAt,
      }))), timezone],
    );
  }

  /** Insert into the outbox; duplicates are silently ignored (each event happens once per trip). */
  async function insertEvents(t, tripId, events) {
    if (!events.length) return [];
    return t.many(
      `INSERT INTO trip_events (trip_id, stop_id, student_id, event_type, escalation, is_critical, payload, occurred_at)
       SELECT $1, x.stop_id, x.student_id, x.event_type, COALESCE(x.escalation, 0),
              COALESCE(x.is_critical, false), COALESCE(x.payload, '{}'::jsonb), COALESCE(x.occurred_at, now())
       FROM jsonb_to_recordset($2::jsonb) AS x(
         stop_id uuid, student_id uuid, event_type notification_event, escalation smallint,
         is_critical boolean, payload jsonb, occurred_at timestamptz)
       ON CONFLICT ON CONSTRAINT trip_events_once_uq DO NOTHING
       RETURNING id, event_type, stop_id, student_id`,
      [tripId, JSON.stringify(events.map((e) => ({
        stop_id: e.stopId ?? null, student_id: e.studentId ?? null, event_type: e.eventType,
        escalation: e.escalation ?? 0, is_critical: e.isCritical ?? false,
        payload: e.payload ?? {}, occurred_at: e.occurredAt ?? null,
      })))],
    );
  }

  const engineEventToOutbox = (e) => ({
    stopId: e.stopId,
    eventType: e.type,
    occurredAt: e.at,
    payload: e.etaMinutes ? { etaMinutes: e.etaMinutes } : {},
  });

  const stopsPayload = (tripId, changed) => ({
    tripId,
    stops: changed.map((c) => ({
      stopId: c.stopId, status: c.status, etaAt: c.etaAt, arrivedAt: c.arrivedAt, departedAt: c.departedAt,
    })),
  });

  function safeBroadcast(fn) {
    try { fn(); } catch (err) { logger?.error({ err }, 'broadcast failed'); }
  }

  function mapBusyError(err) {
    if (err && err.code === '23505') {
      if (err.constraint === 'trips_one_active_per_bus_uq') {
        return conflict('bus_busy', 'This bus is already on another active trip');
      }
      if (err.constraint === 'trips_one_active_per_driver_uq') {
        return conflict('driver_busy', 'You already have another active trip. End it first.');
      }
    }
    return err;
  }

  // ---------- queries ----------
  async function listDriverToday(driverId) {
    const { timezone } = await settings.tracking();
    return db.many(
      `WITH today AS (SELECT (now() AT TIME ZONE $2)::date AS d)
       SELECT sc.id AS schedule_id, sc.name AS schedule_name, sc.direction, sc.start_time,
              r.id AS route_id, r.name AS route_name,
              t.id AS trip_id, COALESCE(t.status::text, 'not_started') AS trip_status,
              COALESCE(tb.plate_number, rb.plate_number) AS plate_number,
              (SELECT count(*) FROM student_stops ss JOIN students s ON s.id = ss.student_id AND s.is_active
                WHERE ss.schedule_id = sc.id)::int AS students
       FROM schedules sc
       JOIN routes r ON r.id = sc.route_id AND r.is_active
       CROSS JOIN today
       LEFT JOIN trips t ON t.schedule_id = sc.id AND t.service_date = today.d
       LEFT JOIN buses rb ON rb.id = r.default_bus_id
       LEFT JOIN buses tb ON tb.id = t.bus_id
       WHERE sc.is_active
         AND extract(isodow FROM today.d)::int = ANY(sc.days_of_week)
         AND (t.driver_id = $1 OR (t.id IS NULL AND r.default_driver_id = $1))
       ORDER BY sc.start_time`,
      [driverId, timezone],
    );
  }

  /** Full trip view for the driver app: stops with progress + rider counts, and riders per stop. */
  async function getTripDetail(tripId, { driverId } = {}, runner = db) {
    const trip = await runner.one(
      `SELECT t.id, t.status, t.service_date, t.started_at, t.ended_at, t.scheduled_start_at,
              t.schedule_id, t.driver_id, t.bus_id, t.cancelled_reason, t.distance_m,
              sc.name AS schedule_name, sc.direction, r.name AS route_name, b.plate_number,
              u.full_name AS driver_name
       FROM trips t
       JOIN schedules sc ON sc.id = t.schedule_id
       JOIN routes r ON r.id = sc.route_id
       JOIN buses b ON b.id = t.bus_id
       JOIN users u ON u.id = t.driver_id
       WHERE t.id = $1`,
      [tripId],
    );
    if (!trip) throw notFound('Trip');
    if (driverId) assertDriver(trip, driverId);

    const stops = await runner.many(
      `SELECT m.stop_id, m.sequence, m.name, m.lat, m.lng, m.scheduled_time, m.is_school,
              m.assigned, m.absent, m.expected, m.can_skip,
              e.status, e.eta_at, e.arrived_at, e.departed_at, e.skipped_reason
       FROM trip_stop_manifest m
       JOIN trip_stop_events e ON e.trip_id = m.trip_id AND e.stop_id = m.stop_id
       WHERE m.trip_id = $1
       ORDER BY m.sequence`,
      [tripId],
    );
    const riders = await runner.many(
      `SELECT ss.stop_id, s.id AS student_id, s.full_name, s.class_name,
              EXISTS (SELECT 1 FROM absences a
                      WHERE a.student_id = s.id AND a.service_date = t.service_date
                        AND (a.schedule_id IS NULL OR a.schedule_id = t.schedule_id)) AS absent,
              COALESCE((SELECT array_agg(ste.status::text ORDER BY ste.recorded_at)
                        FROM student_trip_events ste
                        WHERE ste.trip_id = t.id AND ste.student_id = s.id), '{}'::text[]) AS events
       FROM trips t
       JOIN student_stops ss ON ss.schedule_id = t.schedule_id
       JOIN students s ON s.id = ss.student_id AND s.is_active
       WHERE t.id = $1
       ORDER BY s.full_name`,
      [tripId],
    );
    const byStop = new Map();
    for (const r of riders) {
      if (!byStop.has(r.stopId)) byStop.set(r.stopId, []);
      byStop.get(r.stopId).push({
        studentId: r.studentId, fullName: r.fullName, className: r.className, absent: r.absent, events: r.events,
      });
    }
    return { ...trip, stops: stops.map((s) => ({ ...s, riders: byStop.get(s.stopId) || [] })) };
  }

  // ---------- commands ----------
  async function startTrip({ scheduleId, driverId }) {
    const { timezone } = await settings.tracking();
    let created;
    const tripId = await db.tx(async (t) => {
      const sched = await t.one(
        `SELECT sc.id, sc.direction, sc.start_time, sc.is_active, r.is_active AS route_active,
                r.default_bus_id, r.default_driver_id, (now() AT TIME ZONE $2)::date AS today
         FROM schedules sc JOIN routes r ON r.id = sc.route_id WHERE sc.id = $1`,
        [scheduleId, timezone],
      );
      if (!sched || !sched.isActive || !sched.routeActive) throw notFound('Schedule');
      await t.query('SELECT pg_advisory_xact_lock(hashtext($1))', [`schedule:${scheduleId}:${sched.today}`]);

      let trip = await t.one('SELECT * FROM trips WHERE schedule_id = $1 AND service_date = $2::date', [scheduleId, sched.today]);
      try {
        if (trip) {
          assertDriver(trip, driverId);
          if (trip.status === 'active') { created = false; return trip.id; }
          if (trip.status !== 'scheduled') throw conflict('trip_already_finished', `Today's trip is already ${trip.status}`);
          trip = await t.one("UPDATE trips SET status = 'active', started_at = now() WHERE id = $1 RETURNING *", [trip.id]);
        } else {
          if (sched.defaultDriverId !== driverId) throw forbidden('not_your_route', 'You are not the assigned driver for this route');
          if (!sched.defaultBusId) throw conflict('route_has_no_bus', 'No bus is assigned to this route');
          trip = await t.one(
            `INSERT INTO trips (schedule_id, service_date, bus_id, driver_id, status, scheduled_start_at, started_at)
             VALUES ($1, $2::date, $3, $4, 'active', ($2::date + $5::time) AT TIME ZONE $6, now())
             RETURNING *`,
            [scheduleId, sched.today, sched.defaultBusId, driverId, sched.startTime, timezone],
          );
        }
      } catch (err) {
        throw mapBusyError(err);
      }
      created = true;

      await t.query(
        `INSERT INTO trip_stop_events (trip_id, schedule_id, stop_id)
         SELECT $1, $2, id FROM stops WHERE schedule_id = $2 AND is_active
         ON CONFLICT DO NOTHING`,
        [trip.id, scheduleId],
      );
      if (sched.direction === 'from_school') {
        // Afternoon trips begin at the school gate: mark it arrived so departure is detected normally.
        await t.query(
          `UPDATE trip_stop_events e SET status = 'arrived', arrived_at = now(), eta_at = now()
           FROM stops st
           WHERE e.trip_id = $1 AND st.id = e.stop_id AND st.is_school AND e.status = 'pending'
             AND st.sequence = (SELECT min(sequence) FROM stops WHERE schedule_id = $2 AND is_active)`,
          [trip.id, scheduleId],
        );
      }
      return trip.id;
    });

    const detail = await getTripDetail(tripId, { driverId });
    if (created) {
      safeBroadcast(() => broadcaster.toFleet('trip:started', {
        tripId, routeName: detail.routeName, scheduleName: detail.scheduleName, plateNumber: detail.plateNumber,
      }));
    }
    return { created, trip: detail };
  }

  /**
   * Store GPS points and run new ones through the trip engine.
   * points: [{lat, lng, recordedAt: Date, speedMps?, headingDeg?, accuracyM?}]
   * Safe to call repeatedly with overlapping batches (live + backlog).
   */
  async function ingestPoints({ tripId, driverId, points, source = 'live' }) {
    const { timezone, staleMaxAgeS } = await settings.tracking();
    const now = clock();

    const outcome = await db.tx(async (t) => {
      await lockTrip(t, tripId);
      const trip = await loadTrip(t, tripId);
      assertDriver(trip, driverId);
      assertActive(trip);

      const startedMs = new Date(trip.startedAt).getTime();
      const seen = new Set();
      const valid = [];
      let rejected = 0;
      for (const p of points) {
        const ms = p.recordedAt.getTime();
        if (ms > now.getTime() + FUTURE_TOLERANCE_MS || ms < startedMs - BEFORE_START_TOLERANCE_MS || seen.has(ms)) {
          rejected += 1;
          continue;
        }
        seen.add(ms);
        valid.push(p);
      }
      valid.sort((a, b) => a.recordedAt - b.recordedAt);
      if (!valid.length) return { accepted: 0, duplicates: 0, rejected, processed: 0, events: [], changed: [], newest: null };

      const inserted = await t.many(
        `INSERT INTO location_points (trip_id, recorded_at, lat, lng, speed_mps, heading_deg, accuracy_m, source)
         SELECT $1, x.recorded_at, x.lat, x.lng, x.speed_mps, x.heading_deg, x.accuracy_m, $3::point_source
         FROM jsonb_to_recordset($2::jsonb) AS x(
           recorded_at timestamptz, lat numeric, lng numeric, speed_mps real, heading_deg real, accuracy_m real)
         ON CONFLICT ON CONSTRAINT location_points_trip_time_uq DO NOTHING
         RETURNING recorded_at`,
        [tripId, JSON.stringify(valid.map((p) => ({
          recorded_at: p.recordedAt, lat: p.lat, lng: p.lng, speed_mps: p.speedMps ?? null,
          heading_deg: p.headingDeg ?? null, accuracy_m: p.accuracyM ?? null,
        }))), source],
      );
      const insertedMs = new Set(inserted.map((r) => new Date(r.recordedAt).getTime()));
      const fresh = valid.filter((p) => insertedMs.has(p.recordedAt.getTime()));
      const lastMs = trip.lastPointAt ? new Date(trip.lastPointAt).getTime() : -Infinity;
      const toProcess = fresh.filter((p) => p.recordedAt.getTime() > lastMs);

      let changed = [];
      let events = [];
      if (toProcess.length) {
        const ctx = await loadContext(t, trip, { timezone, withHistory: true });
        const engineEvents = [];
        const segments = [];
        for (const p of toProcess) {
          const silent = now - p.recordedAt > staleMaxAgeS * 1000;
          const r = engine.processPoint(ctx, p, { silent });
          engineEvents.push(...r.events);
          segments.push(...r.segments);
        }
        changed = engine.changedStates(ctx);
        await persistStates(t, tripId, changed);
        await persistSegments(t, tripId, segments, timezone);
        events = await insertEvents(t, tripId, engineEvents.map(engineEventToOutbox));
        await t.query('UPDATE trips SET last_point_at = $2 WHERE id = $1', [tripId, toProcess[toProcess.length - 1].recordedAt]);
      }

      const newest = fresh.length ? fresh[fresh.length - 1] : null;
      if (newest) {
        await t.query(
          `INSERT INTO bus_positions (bus_id, trip_id, lat, lng, speed_mps, heading_deg, accuracy_m, recorded_at, updated_at)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, now())
           ON CONFLICT (bus_id) DO UPDATE
             SET trip_id = EXCLUDED.trip_id, lat = EXCLUDED.lat, lng = EXCLUDED.lng, speed_mps = EXCLUDED.speed_mps,
                 heading_deg = EXCLUDED.heading_deg, accuracy_m = EXCLUDED.accuracy_m,
                 recorded_at = EXCLUDED.recorded_at, updated_at = now()
           WHERE bus_positions.recorded_at < EXCLUDED.recorded_at
              OR bus_positions.trip_id IS DISTINCT FROM EXCLUDED.trip_id`,
          [trip.busId, tripId, newest.lat, newest.lng, newest.speedMps ?? null, newest.headingDeg ?? null,
            newest.accuracyM ?? null, newest.recordedAt],
        );
      }
      return {
        accepted: valid.length,
        duplicates: valid.length - fresh.length,
        rejected,
        processed: toProcess.length,
        events,
        changed,
        newest: newest && newest.recordedAt.getTime() > lastMs ? newest : null,
        busId: trip.busId,
      };
    });

    if (outcome.newest) {
      const loc = {
        tripId,
        busId: outcome.busId,
        lat: outcome.newest.lat,
        lng: outcome.newest.lng,
        speedMps: outcome.newest.speedMps ?? null,
        headingDeg: outcome.newest.headingDeg ?? null,
        recordedAt: outcome.newest.recordedAt,
      };
      safeBroadcast(() => { broadcaster.toTrip(tripId, 'bus:location', loc); broadcaster.toFleet('bus:location', loc); });
    }
    if (outcome.changed.length) {
      const payload = stopsPayload(tripId, outcome.changed);
      safeBroadcast(() => { broadcaster.toTrip(tripId, 'trip:stops', payload); broadcaster.toFleet('trip:stops', payload); });
    }
    return {
      accepted: outcome.accepted,
      duplicates: outcome.duplicates,
      rejected: outcome.rejected,
      processed: outcome.processed,
      eventsCreated: outcome.events.length,
    };
  }

  async function markStop({ tripId, driverId, stopId, action, reason }) {
    const { timezone } = await settings.tracking();
    const out = await db.tx(async (t) => {
      await lockTrip(t, tripId);
      const trip = await loadTrip(t, tripId);
      assertDriver(trip, driverId);
      assertActive(trip);
      const ctx = await loadContext(t, trip, { timezone });
      const { events, segments } = engine.applyManualAction(ctx, stopId, action, { at: clock(), reason });
      const changed = engine.changedStates(ctx);
      await persistStates(t, tripId, changed);
      await persistSegments(t, tripId, segments, timezone);
      const created = await insertEvents(t, tripId, events.map(engineEventToOutbox));
      await writeAudit(t, { actorId: driverId, action: `stop.${action}`, entity: 'trips', entityId: tripId, changes: { stopId, reason: reason ?? null } });
      return { changed, eventsCreated: created.length };
    });
    if (out.changed.length) {
      const payload = stopsPayload(tripId, out.changed);
      safeBroadcast(() => { broadcaster.toTrip(tripId, 'trip:stops', payload); broadcaster.toFleet('trip:stops', payload); });
    }
    return { stops: out.changed, eventsCreated: out.eventsCreated };
  }

  async function recordStudentEvent({ tripId, driverId, studentId, status, stopId, lat, lng }) {
    return db.tx(async (t) => {
      await lockTrip(t, tripId);
      const trip = await loadTrip(t, tripId);
      assertDriver(trip, driverId);
      assertActive(trip);
      const assignment = await t.one(
        'SELECT stop_id FROM student_stops WHERE schedule_id = $1 AND student_id = $2',
        [trip.scheduleId, studentId],
      );
      if (!assignment) throw notFound('Student on this trip');
      const row = await t.one(
        `INSERT INTO student_trip_events (trip_id, student_id, stop_id, status, recorded_by, lat, lng)
         VALUES ($1, $2, $3, $4, $5, $6, $7)
         ON CONFLICT (trip_id, student_id, status) DO NOTHING
         RETURNING id, recorded_at`,
        [tripId, studentId, stopId ?? assignment.stopId, status, driverId, lat ?? null, lng ?? null],
      );
      let eventsCreated = 0;
      if (row && (status === 'boarded' || status === 'dropped_off')) {
        const created = await insertEvents(t, tripId, [{
          studentId, stopId: stopId ?? assignment.stopId, eventType: status, occurredAt: row.recordedAt,
        }]);
        eventsCreated = created.length;
      }
      return { recorded: Boolean(row), duplicate: !row, eventsCreated };
    });
  }

  async function reportIncident({ tripId, driverId, type, severity = 'medium', note, lat, lng, notifyParents = false }) {
    const incident = await db.tx(async (t) => {
      await lockTrip(t, tripId);
      const trip = await loadTrip(t, tripId);
      assertDriver(trip, driverId);
      assertActive(trip);
      const inc = await t.one(
        `INSERT INTO incidents (trip_id, reported_by, type, severity, note, lat, lng, notify_parents)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *`,
        [tripId, driverId, type, severity, note ?? null, lat ?? null, lng ?? null, notifyParents],
      );
      const critical = type === 'breakdown' || type === 'accident' || severity === 'critical';
      if (critical) {
        await insertEvents(t, tripId, [{
          eventType: 'breakdown', isCritical: true, payload: { incidentId: inc.id, type, note: note ?? null },
        }]);
      } else if (notifyParents) {
        // Driver-reported delay (escalation level 0). Automatic delay levels come from the worker.
        await insertEvents(t, tripId, [{
          eventType: 'delay', escalation: 0, payload: { incidentId: inc.id, reason: type, note: note ?? null },
        }]);
      }
      return { ...inc, critical };
    });
    safeBroadcast(() => broadcaster.toFleet('incident:new', incident));
    return incident;
  }

  async function endTrip({ tripId, driverId }) {
    const trip = await db.tx(async (t) => {
      await lockTrip(t, tripId);
      const current = await loadTrip(t, tripId);
      assertDriver(current, driverId);
      assertActive(current);
      const { distanceM } = await t.one(
        `SELECT COALESCE(round(sum(d)), 0)::int AS distance_m FROM (
           SELECT 2 * 6371008.8 * asin(sqrt(
                    power(sin(radians((lat - lag(lat) OVER w)::float8) / 2), 2) +
                    cos(radians((lag(lat) OVER w)::float8)) * cos(radians(lat::float8)) *
                    power(sin(radians((lng - lag(lng) OVER w)::float8) / 2), 2))) AS d
           FROM location_points
           WHERE trip_id = $1 AND (accuracy_m IS NULL OR accuracy_m <= $2)
           WINDOW w AS (ORDER BY recorded_at)) legs`,
        [tripId, MAX_ACCURACY_FOR_HISTORY_M],
      );
      await t.query(
        `UPDATE trip_stop_events
           SET status = CASE WHEN status = 'arrived' THEN 'departed'::stop_event_status ELSE 'skipped'::stop_event_status END,
               departed_at = CASE WHEN status = 'arrived' THEN now() ELSE departed_at END,
               skipped_reason = CASE WHEN status = 'arrived' THEN skipped_reason ELSE 'trip_ended' END
         WHERE trip_id = $1 AND status IN ('pending', 'approaching', 'arrived')`,
        [tripId],
      );
      const ended = await t.one(
        "UPDATE trips SET status = 'completed', ended_at = now(), distance_m = $2 WHERE id = $1 RETURNING *",
        [tripId, distanceM],
      );
      await t.query('UPDATE bus_positions SET trip_id = NULL WHERE trip_id = $1', [tripId]);
      return ended;
    });
    safeBroadcast(() => {
      broadcaster.toTrip(tripId, 'trip:ended', { tripId, status: 'completed' });
      broadcaster.toFleet('trip:ended', { tripId, status: 'completed' });
      broadcaster.closeTrip(tripId);
    });
    return { id: trip.id, status: trip.status, endedAt: trip.endedAt, distanceM: trip.distanceM };
  }

  /** actor: {id, role}. Drivers may cancel only their own trips; admins any. */
  async function cancelTrip({ tripId, actor, reason }) {
    const trip = await db.tx(async (t) => {
      await lockTrip(t, tripId);
      const current = await loadTrip(t, tripId);
      if (actor.role === 'driver') assertDriver(current, actor.id);
      if (!['scheduled', 'active'].includes(current.status)) {
        throw conflict('trip_not_cancellable', `This trip is already ${current.status}`);
      }
      const cancelled = await t.one(
        `UPDATE trips SET status = 'cancelled', cancelled_reason = $2,
                ended_at = CASE WHEN started_at IS NOT NULL THEN now() END
         WHERE id = $1 RETURNING *`,
        [tripId, reason],
      );
      await insertEvents(t, tripId, [{ eventType: 'trip_cancelled', isCritical: true, payload: { reason } }]);
      await t.query('UPDATE bus_positions SET trip_id = NULL WHERE trip_id = $1', [tripId]);
      await writeAudit(t, { actorId: actor.id, action: 'trip.cancel', entity: 'trips', entityId: tripId, changes: { status: [current.status, 'cancelled'], reason } });
      return cancelled;
    });
    safeBroadcast(() => {
      broadcaster.toTrip(tripId, 'trip:ended', { tripId, status: 'cancelled', reason });
      broadcaster.toFleet('trip:ended', { tripId, status: 'cancelled', reason });
      broadcaster.closeTrip(tripId);
    });
    return { id: trip.id, status: trip.status, cancelledReason: trip.cancelledReason };
  }

  /** Admin pre-creates a trip (e.g. to swap bus/driver for a day, or to cancel before it starts). */
  async function createScheduledTrip({ scheduleId, serviceDate, busId, driverId, actorId }) {
    const { timezone } = await settings.tracking();
    return db.tx(async (t) => {
      const sched = await t.one(
        `SELECT sc.id, sc.start_time, r.default_bus_id, r.default_driver_id
         FROM schedules sc JOIN routes r ON r.id = sc.route_id WHERE sc.id = $1 AND sc.is_active`,
        [scheduleId],
      );
      if (!sched) throw notFound('Schedule');
      const bus = busId ?? sched.defaultBusId;
      const driver = driverId ?? sched.defaultDriverId;
      if (!bus || !driver) throw new AppError(400, 'bus_and_driver_required', 'Choose a bus and a driver for this trip');
      const trip = await t.one(
        `INSERT INTO trips (schedule_id, service_date, bus_id, driver_id, status, scheduled_start_at)
         VALUES ($1, $2::date, $3, $4, 'scheduled', ($2::date + $5::time) AT TIME ZONE $6)
         RETURNING *`,
        [scheduleId, serviceDate, bus, driver, sched.startTime, timezone],
      );
      await writeAudit(t, { actorId, action: 'trip.create', entity: 'trips', entityId: trip.id, changes: { scheduleId, serviceDate, busId: bus, driverId: driver } });
      return trip;
    });
  }

  return {
    listDriverToday, getTripDetail, startTrip, ingestPoints, markStop, recordStudentEvent,
    reportIncident, endTrip, cancelTrip, createScheduledTrip,
  };
}

module.exports = { createTripService };
