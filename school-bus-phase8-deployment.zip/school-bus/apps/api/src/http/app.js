'use strict';
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const { requireAuth, notFoundHandler, errorHandler } = require('./middleware');
const authRoutes = require('./routes/auth');
const driverRoutes = require('./routes/driver');
const parentRoutes = require('./routes/parent');
const adminRoutes = require('./routes/admin');
const webhookRoutes = require('./routes/webhooks');
const { createSystemService } = require('../services/systemService');

function requestLogger(logger) {
  return (req, res, next) => {
    const start = process.hrtime.bigint();
    res.on('finish', () => {
      const ms = Number(process.hrtime.bigint() - start) / 1e6;
      const level = res.statusCode >= 500 ? 'error' : res.statusCode >= 400 ? 'warn' : 'info';
      logger[level]({ method: req.method, path: req.path, status: res.statusCode, ms: Math.round(ms), user: req.user?.id }, 'request');
    });
    next();
  };
}

/**
 * services: { db, settings, authService, tripService, parentService, adminService, importStudents }
 */
function createApp({ services, tokens, config, logger }) {
  const app = express();
  app.disable('x-powered-by');
  if (config.trustProxy) app.set('trust proxy', 1);

  app.use(helmet());
  app.use(cors({ origin: config.corsOrigins, maxAge: 600 }));
  app.use(express.json({ limit: '1mb' }));
  app.use(requestLogger(logger));

  app.get('/health', async (_req, res) => {
    await services.db.query('SELECT 1');
    res.json({ ok: true, time: new Date().toISOString() });
  });

  // For an uptime monitor (e.g. UptimeRobot): 200 when the worker is alive, last night's backup ran
  // and SMS credit is above the warning level; 503 with the failing check names otherwise.
  const system = services.system || createSystemService({ db: services.db, settings: services.settings, config });
  app.get('/health/jobs', async (_req, res) => {
    const h = await system.publicHealth();
    res.status(h.ok ? 200 : 503).json(h);
  });

  app.use('/webhooks', webhookRoutes({ ...services, config }));

  const api = express.Router();
  api.use('/auth', authRoutes(services));
  api.use('/driver', requireAuth(tokens, 'driver'), driverRoutes(services));
  api.use('/parent', requireAuth(tokens, 'guardian'), parentRoutes(services));
  api.use('/admin', requireAuth(tokens, 'admin'), adminRoutes({ ...services, system }));
  app.use('/api/v1', api);

  app.use(notFoundHandler);
  app.use(errorHandler(logger));
  return app;
}

module.exports = { createApp };
