'use strict';
const express = require('express');
const { safeEqual } = require('../../lib/crypto');

/**
 * Africa's Talking does not sign callbacks, so the URL carries a long random secret:
 *   https://<host>/webhooks/africastalking/delivery/<AT_WEBHOOK_SECRET>
 * Register that URL in the AT dashboard under SMS -> Delivery Reports.
 */
module.exports = function webhookRoutes({ deliveryReports, config }) {
  const r = express.Router();
  r.post('/africastalking/delivery/:secret', express.urlencoded({ extended: false, limit: '64kb' }), async (req, res) => {
    if (!config.atWebhookSecret || !safeEqual(req.params.secret, config.atWebhookSecret)) {
      return res.status(404).json({ error: { code: 'not_found', message: 'Not found' } });
    }
    const out = await deliveryReports.apply(req.body || {});
    return res.json({ ok: true, ...out });
  });
  return r;
};
