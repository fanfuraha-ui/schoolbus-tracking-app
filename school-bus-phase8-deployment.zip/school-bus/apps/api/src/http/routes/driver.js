'use strict';
const express = require('express');
const { validate } = require('../middleware');
const S = require('../schemas').driver;

module.exports = function driverRoutes({ tripService, authService }) {
  const r = express.Router();
  const me = (req) => req.user.id;

  r.get('/today', async (req, res) => res.json({ schedules: await tripService.listDriverToday(me(req)) }));

  r.post('/schedules/:scheduleId/start', validate({ params: S.scheduleParam }), async (req, res) => {
    const out = await tripService.startTrip({ scheduleId: req.valid.params.scheduleId, driverId: me(req) });
    res.status(out.created ? 201 : 200).json(out);
  });

  r.get('/trips/:tripId', validate({ params: S.tripParam }),
    async (req, res) => res.json(await tripService.getTripDetail(req.valid.params.tripId, { driverId: me(req) })));

  // Backlog upload (points buffered while offline). Live points normally go over Socket.IO.
  r.post('/trips/:tripId/locations', validate({ params: S.tripParam, body: S.locations }), async (req, res) => {
    res.json(await tripService.ingestPoints({
      tripId: req.valid.params.tripId, driverId: me(req), points: req.valid.body.points, source: 'backlog',
    }));
  });

  r.post('/trips/:tripId/stops/:stopId', validate({ params: S.tripStopParam, body: S.stopAction }), async (req, res) => {
    const { tripId, stopId } = req.valid.params;
    res.json(await tripService.markStop({ tripId, stopId, driverId: me(req), ...req.valid.body }));
  });

  r.post('/trips/:tripId/students/:studentId', validate({ params: S.tripStudentParam, body: S.studentEvent }), async (req, res) => {
    const { tripId, studentId } = req.valid.params;
    res.json(await tripService.recordStudentEvent({ tripId, studentId, driverId: me(req), ...req.valid.body }));
  });

  r.post('/trips/:tripId/incidents', validate({ params: S.tripParam, body: S.incident }), async (req, res) => {
    res.status(201).json(await tripService.reportIncident({ tripId: req.valid.params.tripId, driverId: me(req), ...req.valid.body }));
  });

  r.post('/trips/:tripId/end', validate({ params: S.tripParam }),
    async (req, res) => res.json(await tripService.endTrip({ tripId: req.valid.params.tripId, driverId: me(req) })));

  r.post('/trips/:tripId/cancel', validate({ params: S.tripParam, body: S.cancel }), async (req, res) => {
    res.json(await tripService.cancelTrip({
      tripId: req.valid.params.tripId, actor: req.user, reason: req.valid.body.reason,
    }));
  });

  r.put('/device', validate({ body: S.device }),
    async (req, res) => res.json(await authService.registerPushToken(me(req), 'driver', req.valid.body)));

  return r;
};
