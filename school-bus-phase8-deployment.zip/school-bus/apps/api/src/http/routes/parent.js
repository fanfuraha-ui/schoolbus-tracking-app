'use strict';
const express = require('express');
const { validate } = require('../middleware');
const S = require('../schemas').parent;

module.exports = function parentRoutes({ parentService, authService }) {
  const r = express.Router();
  const me = (req) => req.user.id;

  r.get('/me', async (req, res) => res.json(await parentService.getOverview(me(req))));
  r.patch('/preferences', validate({ body: S.preferences }),
    async (req, res) => res.json(await parentService.updatePreferences(me(req), req.valid.body)));
  r.post('/consent', validate({ body: S.consent }),
    async (req, res) => res.json(await parentService.recordConsent(me(req), req.valid.body.version)));
  r.put('/device', validate({ body: S.device }),
    async (req, res) => res.json(await authService.registerPushToken(me(req), 'parent', req.valid.body)));

  r.get('/trips/:tripId', validate({ params: S.tripParam }),
    async (req, res) => res.json(await parentService.getTripView(me(req), req.valid.params.tripId)));

  r.get('/absences', async (req, res) => res.json({ absences: await parentService.listAbsences(me(req)) }));
  r.post('/absences', validate({ body: S.absence }),
    async (req, res) => res.status(201).json(await parentService.createAbsence(me(req), req.valid.body)));
  r.delete('/absences/:id', validate({ params: require('../schemas').admin.idParam }),
    async (req, res) => res.json(await parentService.deleteAbsence(me(req), req.valid.params.id)));

  r.get('/notifications', validate({ query: S.notificationsQuery }),
    async (req, res) => res.json({ notifications: await parentService.listNotifications(me(req), req.valid.query) }));
  return r;
};
