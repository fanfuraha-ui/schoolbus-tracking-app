'use strict';
const express = require('express');
const { rateLimit } = require('express-rate-limit');
const { validate } = require('../middleware');
const S = require('../schemas');

const limiter = (limit, windowMinutes) => rateLimit({
  windowMs: windowMinutes * 60 * 1000,
  limit,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: { error: { code: 'rate_limited', message: 'Too many attempts. Please wait and try again.' } },
});

module.exports = function authRoutes({ authService }) {
  const r = express.Router();
  const login = limiter(20, 15);   // per IP; per-account lockout is enforced in the service
  const otp = limiter(10, 15);

  r.post('/admin/login', login, validate({ body: S.auth.adminLogin }),
    async (req, res) => res.json(await authService.adminLogin(req.valid.body)));
  r.post('/driver/login', login, validate({ body: S.auth.driverLogin }),
    async (req, res) => res.json(await authService.driverLogin(req.valid.body)));
  r.post('/otp/request', otp, validate({ body: S.auth.otpRequest }),
    async (req, res) => res.status(202).json(await authService.requestOtp(req.valid.body)));
  r.post('/otp/verify', login, validate({ body: S.auth.otpVerify }),
    async (req, res) => res.json(await authService.verifyOtp(req.valid.body)));
  r.post('/refresh', limiter(60, 15), validate({ body: S.auth.refresh }),
    async (req, res) => res.json(await authService.refresh(req.valid.body)));
  r.post('/logout', validate({ body: S.auth.refresh }),
    async (req, res) => res.json(await authService.logout(req.valid.body)));
  return r;
};
