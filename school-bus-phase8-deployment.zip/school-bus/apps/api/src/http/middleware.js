'use strict';
const { AppError, unauthorized, forbidden, badRequest, fromPgError } = require('../lib/errors');

/** Validate req.params/query/body with zod schemas; parsed values land on req.valid. */
const validate = (schemas) => (req, _res, next) => {
  const valid = {};
  for (const part of ['params', 'query', 'body']) {
    if (!schemas[part]) continue;
    const result = schemas[part].safeParse(req[part] ?? {});
    if (!result.success) {
      return next(badRequest('validation_failed', 'Some fields are missing or invalid',
        result.error.issues.map((i) => ({ field: [part, ...i.path].join('.'), message: i.message }))));
    }
    valid[part] = result.data;
  }
  req.valid = valid;
  return next();
};

/** Require a valid access token; optionally restrict to roles. Sets req.user = {id, role}. */
const requireAuth = (tokens, ...roles) => (req, _res, next) => {
  const match = /^Bearer (.+)$/.exec(req.headers.authorization || '');
  if (!match) return next(unauthorized());
  try {
    req.user = tokens.verifyAccess(match[1]);
  } catch {
    return next(unauthorized('token_invalid', 'Your session has expired. Please sign in again.'));
  }
  if (roles.length && !roles.includes(req.user.role)) return next(forbidden());
  return next();
};

/** Context passed to services for audit logging. */
const auditCtx = (req) => ({ actorId: req.user?.id ?? null, ip: req.ip ?? null, userAgent: req.get('user-agent')?.slice(0, 300) ?? null });

const notFoundHandler = (req, _res, next) => next(new AppError(404, 'route_not_found', `No route for ${req.method} ${req.path}`));

const errorHandler = (logger) => (err, req, res, _next) => {
  let e = err instanceof AppError ? err : fromPgError(err);
  if (!e && err && err.type === 'entity.parse.failed') e = badRequest('invalid_json', 'Request body is not valid JSON');
  if (!e && err && err.type === 'entity.too.large') e = new AppError(413, 'payload_too_large', 'Request body is too large');
  if (!e) {
    logger.error({ err, method: req.method, path: req.path }, 'Unhandled error');
    e = new AppError(500, 'internal_error', 'Something went wrong. Please try again.');
  } else if (e.status >= 500) {
    logger.error({ err }, e.message);
  }
  res.status(e.status).json({ error: { code: e.code, message: e.message, ...(e.details ? { details: e.details } : {}) } });
};

module.exports = { validate, requireAuth, auditCtx, notFoundHandler, errorHandler };
