'use strict';
/**
 * Time-based checks, run by the worker every minute (nightly maintenance once a day).
 * Each check runs in its own transaction under a try-lock, so with several worker
 * instances only one performs a given check at a time.
 *
 *  planTrips       create today's 'scheduled' trips (+ stop rows) for every active schedule,
 *                  skipping no-service days. Lets "late"/"not started" be detected even before
 *                  the driver taps Start.
 *  checkDelays     next unreached stop vs its scheduled time -> parent delay alerts at each
 *                  escalation level (default 10/20/30 min), once per level per trip.
 *  checkNotStarted trip still 'scheduled' N min after its start time -> admin incident.
 *  checkGps        active trip with no GPS for 5 min -> admin incident (auto-resolves).
 *  checkStalled    bus parked > N min away from any stop -> admin incident (auto-resolves).
 *                  Parents are NOT told automatically; the office decides.
 *  nightly         segment ETA medians, GPS retention purge, auth housekeeping.
 */
const { distanceM } = require('../domain/geo');

const GPS_SILENCE_MINUTES = 5;
const PLAN_LOOKBACK_MINUTES = 30;
const NOT_STARTED_ALERT_WINDOW_MINUTES = 90;
const NIGHTLY_HOUR = 2; // 02:00 local

async function notifyFleet(t, event, data) {
  await t.query('SELECT pg_notify($1, $2)', ['fleet_events', JSON.stringify({ event, data }).slice(0, 7900)]);
}

function createMonitors({ db, settings, logger, sms = null }) {
  async function locked(name, fn) {
    return db.tx(async (t) => {
      const { ok } = await t.one('SELECT pg_try_advisory_xact_lock(hashtext($1)) AS ok', [`monitor:${name}`]);
      if (!ok) return { skipped: 'locked' };
      return fn(t);
    });
  }

  async function cfg() {
    const s = await settings.all();
    return {
      tz: s.timezone || 'Africa/Nairobi',
      levels: (Array.isArray(s.delay_escalation_minutes) ? s.delay_escalation_minutes : [10, 20, 30]).map(Number).sort((a, b) => a - b),
      notStartedGrace: Number(s.not_started_grace_minutes ?? 10),
      stalledMinutes: Number(s.stalled_minutes ?? 8),
      stalledRadius: Number(s.stalled_radius_m ?? 50),
    };
  }

  async function raiseIncident(t, { tripId, type, note, lat = null, lng = null, severity = 'medium' }) {
    const exists = await t.one(
      "SELECT 1 AS x FROM incidents WHERE trip_id = $1 AND type = $2::incident_type AND resolved_at IS NULL",
      [tripId, type],
    );
    if (exists) return null;
    const inc = await t.one(
      `INSERT INTO incidents (trip_id, type, severity, note, lat, lng, auto_detected)
       VALUES ($1, $2::incident_type, $3, $4, $5, $6, true) RETURNING *`,
      [tripId, type, severity, note, lat, lng],
    );
    await notifyFleet(t, 'incident:new', inc);
    return inc;
  }

  async function autoResolve(t, ids) {
    if (!ids.length) return 0;
    const rows = await t.many(
      'UPDATE incidents SET resolved_at = now() WHERE id = ANY($1::uuid[]) AND resolved_at IS NULL RETURNING id, trip_id, type',
      [ids],
    );
    for (const r of rows) await notifyFleet(t, 'incident:resolved', r);
    return rows.length;
  }

  const planTrips = () => locked('plan', async (t) => {
    const { tz } = await cfg();
    const created = await t.many(
      `WITH d AS (SELECT (now() AT TIME ZONE $1)::date AS today)
       INSERT INTO trips (schedule_id, service_date, bus_id, driver_id, status, scheduled_start_at)
       SELECT sc.id, d.today, r.default_bus_id, r.default_driver_id, 'scheduled', (d.today + sc.start_time) AT TIME ZONE $1
       FROM schedules sc
       JOIN routes r ON r.id = sc.route_id AND r.is_active
       CROSS JOIN d
       WHERE sc.is_active AND r.default_bus_id IS NOT NULL AND r.default_driver_id IS NOT NULL
         AND extract(isodow FROM d.today)::int = ANY(sc.days_of_week)
         AND NOT EXISTS (SELECT 1 FROM no_service_days n WHERE n.service_date = d.today)
         -- Never plan runs that should already be over (e.g. worker started mid-day).
         AND (d.today + sc.start_time) AT TIME ZONE $1 > now() - make_interval(mins => $2::int)
       ON CONFLICT (schedule_id, service_date) DO NOTHING
       RETURNING id`,
      [tz, PLAN_LOOKBACK_MINUTES],
    );
    await t.query(
      `INSERT INTO trip_stop_events (trip_id, schedule_id, stop_id)
       SELECT tr.id, tr.schedule_id, st.id FROM trips tr
       JOIN stops st ON st.schedule_id = tr.schedule_id AND st.is_active
       WHERE tr.status = 'scheduled' AND tr.service_date = (now() AT TIME ZONE $1)::date
       ON CONFLICT DO NOTHING`,
      [tz],
    );
    return { created: created.length };
  });

  const checkDelays = () => locked('delays', async (t) => {
    const { tz, levels } = await cfg();
    if (!levels.length) return { alerts: 0 };
    const rows = await t.many(
      `SELECT DISTINCT ON (tr.id) tr.id AS trip_id, st.id AS stop_id,
              round(extract(epoch FROM greatest(COALESCE(e.eta_at, now()), now())
                    - ((tr.service_date + st.scheduled_time) AT TIME ZONE $1)) / 60)::int AS late_minutes
       FROM trips tr
       JOIN trip_stop_events e ON e.trip_id = tr.id
       JOIN stops st ON st.id = e.stop_id
       WHERE (tr.status = 'active'
              -- A bus that hasn't started yet: tell parents for the first 90 min only;
              -- after that it's an office problem (not_started incident), not a running delay.
              OR (tr.status = 'scheduled' AND tr.scheduled_start_at < now()
                  AND tr.scheduled_start_at > now() - make_interval(mins => $2::int)))
         AND tr.service_date = (now() AT TIME ZONE $1)::date
         AND e.status IN ('pending', 'approaching')
         AND st.scheduled_time IS NOT NULL AND NOT st.is_school
       ORDER BY tr.id, st.sequence`,
      [tz, NOT_STARTED_ALERT_WINDOW_MINUTES],
    );
    let alerts = 0;
    for (const r of rows) {
      const level = levels.filter((m) => r.lateMinutes >= m).length;
      if (level === 0) continue;
      const created = await t.one(
        `INSERT INTO trip_events (trip_id, event_type, escalation, payload)
         SELECT $1, 'delay', $2, $3::jsonb
         WHERE NOT EXISTS (SELECT 1 FROM trip_events WHERE trip_id = $1 AND event_type = 'delay' AND escalation >= $2)
         ON CONFLICT ON CONSTRAINT trip_events_once_uq DO NOTHING
         RETURNING id`,
        [r.tripId, level, JSON.stringify({ delayMinutes: Math.max(r.lateMinutes, levels[level - 1]), level, stopId: r.stopId })],
      );
      if (created) {
        alerts += 1;
        await notifyFleet(t, 'trip:delay', { tripId: r.tripId, delayMinutes: r.lateMinutes, level });
      }
    }
    return { checked: rows.length, alerts };
  });

  const checkNotStarted = () => locked('not_started', async (t) => {
    const { tz, notStartedGrace } = await cfg();
    const late = await t.many(
      `SELECT tr.id, r.name AS route_name, sc.name AS schedule_name,
              round(extract(epoch FROM now() - tr.scheduled_start_at) / 60)::int AS minutes
       FROM trips tr JOIN schedules sc ON sc.id = tr.schedule_id JOIN routes r ON r.id = sc.route_id
       WHERE tr.status = 'scheduled' AND tr.service_date = (now() AT TIME ZONE $1)::date
         AND tr.scheduled_start_at + make_interval(mins => $2::int) < now()`,
      [tz, notStartedGrace],
    );
    let raised = 0;
    for (const trip of late) {
      const inc = await raiseIncident(t, {
        tripId: trip.id, type: 'not_started',
        note: `${trip.routeName} ${trip.scheduleName} has not started (${trip.minutes} min after scheduled time)`,
      });
      if (inc) raised += 1;
    }
    // Close not-started incidents once the trip starts or is cancelled.
    const fixed = await t.many(
      `SELECT i.id FROM incidents i JOIN trips tr ON tr.id = i.trip_id
       WHERE i.type = 'not_started' AND i.auto_detected AND i.resolved_at IS NULL AND tr.status <> 'scheduled'`,
    );
    return { raised, resolved: await autoResolve(t, fixed.map((f) => f.id)) };
  });

  const checkGps = () => locked('gps', async (t) => {
    const silent = await t.many(
      `SELECT tr.id, r.name AS route_name, b.plate_number,
              round(extract(epoch FROM now() - COALESCE(tr.last_point_at, tr.started_at)) / 60)::int AS minutes
       FROM trips tr JOIN schedules sc ON sc.id = tr.schedule_id JOIN routes r ON r.id = sc.route_id
       JOIN buses b ON b.id = tr.bus_id
       WHERE tr.status = 'active'
         AND COALESCE(tr.last_point_at, tr.started_at) < now() - make_interval(mins => $1::int)`,
      [GPS_SILENCE_MINUTES],
    );
    let raised = 0;
    for (const trip of silent) {
      const inc = await raiseIncident(t, {
        tripId: trip.id, type: 'gps_lost',
        note: `No GPS from ${trip.plateNumber} (${trip.routeName}) for ${trip.minutes} min. Driver app may be closed or phone offline.`,
      });
      if (inc) raised += 1;
    }
    const back = await t.many(
      `SELECT i.id FROM incidents i JOIN trips tr ON tr.id = i.trip_id
       WHERE i.type = 'gps_lost' AND i.auto_detected AND i.resolved_at IS NULL
         AND (tr.status <> 'active' OR tr.last_point_at > i.created_at)`,
    );
    return { raised, resolved: await autoResolve(t, back.map((b) => b.id)) };
  });

  const checkStalled = () => locked('stalled', async (t) => {
    const { stalledMinutes, stalledRadius } = await cfg();
    const trips = await t.many(
      `SELECT tr.id, b.plate_number, r.name AS route_name FROM trips tr
       JOIN buses b ON b.id = tr.bus_id JOIN schedules sc ON sc.id = tr.schedule_id JOIN routes r ON r.id = sc.route_id
       WHERE tr.status = 'active' AND tr.last_point_at > now() - interval '2 minutes'
         AND tr.started_at < now() - make_interval(mins => $1::int)`,
      [stalledMinutes],
    );
    let raised = 0;
    const stillStalled = new Set();
    for (const trip of trips) {
      const pts = await t.many(
        `SELECT lat, lng, recorded_at FROM location_points
         WHERE trip_id = $1 AND recorded_at > now() - make_interval(mins => $2::int)
           AND (accuracy_m IS NULL OR accuracy_m <= 100)
         ORDER BY recorded_at`,
        [trip.id, stalledMinutes],
      );
      if (pts.length < 3) continue;
      const spanMs = new Date(pts[pts.length - 1].recordedAt) - new Date(pts[0].recordedAt);
      if (spanMs < (stalledMinutes - 1) * 60000) continue; // window not covered yet
      const last = pts[pts.length - 1];
      if (pts.some((p) => distanceM(p, last) > stalledRadius)) continue; // it moved
      const stops = await t.many(
        'SELECT st.lat, st.lng, st.radius_m FROM trip_stop_events e JOIN stops st ON st.id = e.stop_id WHERE e.trip_id = $1',
        [trip.id],
      );
      if (stops.some((s) => distanceM(s, last) <= s.radiusM + 30)) continue; // waiting at a stop is normal
      stillStalled.add(trip.id);
      const inc = await raiseIncident(t, {
        tripId: trip.id, type: 'stalled', lat: last.lat, lng: last.lng,
        note: `${trip.plateNumber} (${trip.routeName}) has not moved for ${stalledMinutes}+ min away from any stop.`,
      });
      if (inc) raised += 1;
    }
    const open = await t.many(
      `SELECT i.id, i.trip_id, tr.status FROM incidents i JOIN trips tr ON tr.id = i.trip_id
       WHERE i.type = 'stalled' AND i.auto_detected AND i.resolved_at IS NULL`,
    );
    const moved = open.filter((i) => i.status !== 'active' || (!stillStalled.has(i.tripId) && trips.some((tr) => tr.id === i.tripId)));
    return { checked: trips.length, raised, resolved: await autoResolve(t, moved.map((m) => m.id)) };
  });

  /** Once per local day after 02:00. */
  const nightly = () => locked('nightly', async (t) => {
    const { tz } = await cfg();
    const due = await t.one(
      `SELECT extract(hour FROM now() AT TIME ZONE $1)::int >= $2
              AND NOT EXISTS (SELECT 1 FROM job_runs WHERE name = 'nightly'
                              AND (last_run_at AT TIME ZONE $1)::date = (now() AT TIME ZONE $1)::date) AS due`,
      [tz, NIGHTLY_HOUR],
    );
    if (!due.due) return { ran: false };
    const segments = (await t.one('SELECT refresh_segment_stats() AS n')).n;
    const purged = (await t.one('SELECT purge_old_location_points() AS n')).n;
    const otps = (await t.query("DELETE FROM otp_codes WHERE created_at < now() - interval '1 day' RETURNING id")).rowCount;
    const tokens = (await t.query(
      "DELETE FROM refresh_tokens WHERE expires_at < now() - interval '7 days' OR revoked_at < now() - interval '30 days' RETURNING id",
    )).rowCount;
    // Close trips left open from previous days, silently (no parent alerts).
    const notRun = (await t.query(
      `UPDATE trips SET status = 'cancelled', cancelled_reason = 'Not run (closed automatically)'
       WHERE status = 'scheduled' AND service_date < (now() AT TIME ZONE $1)::date RETURNING id`,
      [tz],
    )).rowCount;
    const forgotten = await t.many(
      `UPDATE trips SET status = 'completed', ended_at = COALESCE(last_point_at, started_at)
       WHERE status = 'active' AND service_date < (now() AT TIME ZONE $1)::date RETURNING id`,
      [tz],
    );
    if (forgotten.length) {
      await t.query('UPDATE bus_positions SET trip_id = NULL WHERE trip_id = ANY($1::uuid[])', [forgotten.map((f) => f.id)]);
    }
    const result = { segments, purgedPoints: purged, otps, tokens, closedNotRun: notRun, closedForgotten: forgotten.length };
    await t.query(
      `INSERT INTO job_runs (name, last_run_at, last_result) VALUES ('nightly', now(), $1::jsonb)
       ON CONFLICT (name) DO UPDATE SET last_run_at = now(), last_result = EXCLUDED.last_result`,
      [JSON.stringify(result)],
    );
    logger?.info(result, 'Nightly maintenance done');
    return { ran: true, ...result };
  });

  /**
   * Hourly: Africa's Talking prepaid credit, plus the average SMS spend per school day over the
   * last week, so the dashboard can say "about 3 school days left". When credit runs out, alerts
   * fail one by one with nobody noticing; this is the early warning.
   */
  const smsBalance = () => locked('sms_balance', async (t) => {
    if (!sms || typeof sms.balance !== 'function') return { ran: false };
    const { tz } = await cfg();
    const due = await t.one(
      "SELECT NOT EXISTS (SELECT 1 FROM job_runs WHERE name = 'sms_balance' AND last_run_at > now() - interval '55 minutes') AS due",
    );
    if (!due.due) return { ran: false };
    let result;
    try {
      const b = await sms.balance();
      result = b ? { status: 'ok', currency: b.currency, amount: b.amount } : { status: 'dry_run' };
    } catch (err) {
      logger?.warn({ err: err.message }, 'SMS balance check failed');
      result = { status: 'unknown', error: String(err.message).slice(0, 200) };
    }
    const spend = await t.one(
      `SELECT COALESCE(sum(cost_kes), 0)::float AS kes,
              count(DISTINCT (created_at AT TIME ZONE $1)::date)::int AS days
       FROM notifications
       WHERE channel = 'sms' AND status IN ('sent', 'delivered') AND created_at > now() - interval '7 days'`,
      [tz],
    );
    result.dailySpendKes = spend.days ? Math.round((spend.kes / spend.days) * 100) / 100 : 0;
    await t.query(
      `INSERT INTO job_runs (name, last_run_at, last_result) VALUES ('sms_balance', now(), $1::jsonb)
       ON CONFLICT (name) DO UPDATE SET last_run_at = now(), last_result = EXCLUDED.last_result`,
      [JSON.stringify(result)],
    );
    return { ran: true, ...result };
  });

  async function runAll() {
    const out = {};
    const failed = [];
    for (const [name, fn] of Object.entries({ planTrips, checkDelays, checkNotStarted, checkGps, checkStalled, nightly, smsBalance })) {
      try {
        out[name] = await fn();
      } catch (err) {
        logger?.error({ err, monitor: name }, 'Monitor failed');
        out[name] = { error: err.message };
        failed.push(name);
      }
    }
    // Heartbeat: /health/jobs and the dashboard treat a stale row as "the worker is down".
    await db.query(
      `INSERT INTO job_runs (name, last_run_at, last_result) VALUES ('monitors', now(), $1::jsonb)
       ON CONFLICT (name) DO UPDATE SET last_run_at = now(), last_result = EXCLUDED.last_result`,
      [JSON.stringify({ failed })],
    ).catch((err) => logger?.error({ err }, 'Heartbeat write failed'));
    return out;
  }

  return { planTrips, checkDelays, checkNotStarted, checkGps, checkStalled, nightly, smsBalance, runAll };
}

module.exports = { createMonitors, notifyFleet };
