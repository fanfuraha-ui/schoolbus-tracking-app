'use strict';
/**
 * The worker is a separate process, so it can't emit to Socket.IO directly. It publishes
 * with Postgres NOTIFY on channel "fleet_events"; the API LISTENs on one dedicated
 * connection and forwards allowed events to the admins' "fleet" room. No Redis needed.
 * Reconnects automatically if the LISTEN connection drops.
 */
const ALLOWED = new Set(['incident:new', 'incident:resolved', 'trip:delay']);

function createFleetEventRelay({ pool, broadcaster, logger, channel = 'fleet_events', retryMs = 5000 }) {
  let client = null;
  let stopped = false;
  let timer = null;

  function handle(payload) {
    try {
      const { event, data } = JSON.parse(payload);
      if (!ALLOWED.has(event)) return false;
      broadcaster.toFleet(event, data);
      return true;
    } catch (err) {
      logger?.warn({ err: err.message }, 'Bad fleet event payload');
      return false;
    }
  }

  function scheduleReconnect() {
    if (stopped) return;
    if (client) { try { client.release(true); } catch { /* already gone */ } client = null; }
    clearTimeout(timer);
    timer = setTimeout(connect, retryMs);
  }

  async function connect() {
    if (stopped) return;
    try {
      client = await pool.connect();
      client.on('notification', (msg) => { if (msg.channel === channel) handle(msg.payload); });
      client.on('error', (err) => { logger?.warn({ err: err.message }, 'Fleet relay connection error; reconnecting'); scheduleReconnect(); });
      await client.query(`LISTEN ${channel}`);
      logger?.info({ channel }, 'Listening for worker fleet events');
    } catch (err) {
      logger?.warn({ err: err.message }, 'Fleet relay could not connect; retrying');
      scheduleReconnect();
    }
  }

  async function stop() {
    stopped = true;
    clearTimeout(timer);
    if (client) {
      await client.query(`UNLISTEN ${channel}`).catch(() => {});
      client.release();
      client = null;
    }
  }

  return { start: connect, stop, handle };
}

module.exports = { createFleetEventRelay };
