'use strict';
/**
 * Late-bound broadcaster: services are created before Socket.IO exists, so they get this
 * object and it starts forwarding once attach(io) is called. Before that, calls are no-ops.
 *
 * Rooms:  trip:<tripId>  parents watching that trip (and the driver)
 *         fleet          all connected admins
 */
function createBroadcaster() {
  let io = null;
  return {
    attach(server) { io = server; },
    toTrip(tripId, event, data) { if (io) io.to(`trip:${tripId}`).emit(event, data); },
    toFleet(event, data) { if (io) io.to('fleet').emit(event, data); },
    closeTrip(tripId) { if (io) io.in(`trip:${tripId}`).socketsLeave(`trip:${tripId}`); },
  };
}

module.exports = { createBroadcaster };
