'use strict';
/**
 * Socket.IO server.
 *
 * Auth:   io(url, { auth: { token: <access JWT> } })
 * Driver: emit('location', { tripId, points: [...] }, ack)   -> ack({ ok, accepted, duplicates, ... })
 *           The driver app removes points from its offline buffer only after ok: true.
 * Parent: emit('trip:watch', { tripId }, ack)   -> ack({ ok, view }) and joins trip:<tripId>
 *         emit('trip:unwatch', { tripId })
 *         receives 'bus:location', 'trip:stops', 'trip:ended'
 * Admin:  joins 'fleet' automatically; receives 'bus:location', 'trip:stops', 'trip:started',
 *         'trip:ended', 'incident:new'
 */
const { Server } = require('socket.io');
const { driver: D } = require('../http/schemas');
const { AppError, fromPgError } = require('../lib/errors');

const LOCATION_RATE = { tokens: 5, refillPerSec: 1 }; // bursts of 5, steady 1 msg/s per socket

function toAckError(err, logger) {
  const e = err instanceof AppError ? err : fromPgError(err);
  if (e) return { ok: false, error: { code: e.code, message: e.message } };
  logger.error({ err }, 'socket handler error');
  return { ok: false, error: { code: 'internal_error', message: 'Something went wrong' } };
}

function attachRealtime({ server, tokens, services, broadcaster, config, logger }) {
  const io = new Server(server, {
    cors: { origin: config.corsOrigins },
    pingInterval: 25000,
    pingTimeout: 20000,
    maxHttpBufferSize: 256 * 1024,
  });

  io.use((socket, next) => {
    try {
      socket.data.user = tokens.verifyAccess(socket.handshake.auth?.token);
      next();
    } catch {
      next(new Error('unauthorized'));
    }
  });

  io.on('connection', (socket) => {
    const user = socket.data.user;
    const ack = (cb, payload) => { if (typeof cb === 'function') cb(payload); };

    if (user.role === 'admin') socket.join('fleet');

    if (user.role === 'driver') {
      const bucket = { tokens: LOCATION_RATE.tokens, at: Date.now() };
      socket.on('location', async (payload, cb) => {
        const now = Date.now();
        bucket.tokens = Math.min(LOCATION_RATE.tokens, bucket.tokens + ((now - bucket.at) / 1000) * LOCATION_RATE.refillPerSec);
        bucket.at = now;
        if (bucket.tokens < 1) return ack(cb, { ok: false, error: { code: 'rate_limited', message: 'Slow down' } });
        bucket.tokens -= 1;

        const parsed = D.socketLocations.safeParse(payload);
        if (!parsed.success) return ack(cb, { ok: false, error: { code: 'validation_failed', message: parsed.error.issues[0]?.message } });
        try {
          const result = await services.tripService.ingestPoints({
            tripId: parsed.data.tripId, driverId: user.id, points: parsed.data.points, source: 'live',
          });
          return ack(cb, { ok: true, ...result });
        } catch (err) {
          return ack(cb, toAckError(err, logger));
        }
      });
    }

    if (user.role === 'guardian' || user.role === 'admin') {
      socket.on('trip:watch', async (payload, cb) => {
        const tripId = payload && typeof payload.tripId === 'string' ? payload.tripId : null;
        if (!tripId || !/^[0-9a-f-]{36}$/i.test(tripId)) return ack(cb, { ok: false, error: { code: 'validation_failed', message: 'tripId required' } });
        try {
          if (user.role === 'guardian') {
            const allowed = await services.parentService.canWatchTrip(user.id, tripId);
            if (!allowed) return ack(cb, { ok: false, error: { code: 'forbidden', message: 'This trip is not active or not your child\'s' } });
            socket.join(`trip:${tripId}`);
            return ack(cb, { ok: true, view: await services.parentService.getTripView(user.id, tripId) });
          }
          socket.join(`trip:${tripId}`);
          return ack(cb, { ok: true, view: await services.tripService.getTripDetail(tripId) });
        } catch (err) {
          return ack(cb, toAckError(err, logger));
        }
      });
      socket.on('trip:unwatch', (payload) => {
        if (payload && typeof payload.tripId === 'string') socket.leave(`trip:${payload.tripId}`);
      });
    }
  });

  broadcaster.attach(io);
  return io;
}

module.exports = { attachRealtime };
