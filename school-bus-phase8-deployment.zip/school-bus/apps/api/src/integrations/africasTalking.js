'use strict';
/**
 * Africa's Talking SMS client (REST, no SDK).
 * POST {host}/version1/messaging  form-encoded: username, to, message, [from]
 * Header: apiKey. Sandbox host when username === 'sandbox'.
 * Response: { SMSMessageData: { Message, Recipients: [{ number, status, statusCode, messageId, cost }] } }
 * statusCode 100 (Processed), 101 (Sent), 102 (Queued) mean accepted.
 *
 * GET {host}/version1/user?username=...  -> { UserData: { balance: "KES 1785.5000" } }
 * (the "application data" call the official SDKs use for the account balance)
 */
const { maskPhone } = require('../domain/phone');

const ACCEPTED_CODES = new Set([100, 101, 102]);

/** "KES 0.8000" -> 0.8 ; anything unparseable -> null */
function parseCost(cost) {
  const m = typeof cost === 'string' ? cost.match(/([\d.]+)/) : null;
  return m ? Number(m[1]) : null;
}

function createSmsClient({ username, apiKey, senderId, dryRun = false, logText = false, logger, fetchImpl = globalThis.fetch, timeoutMs = 10000 }) {
  const host = username === 'sandbox' ? 'https://api.sandbox.africastalking.com' : 'https://api.africastalking.com';

  /**
   * Send one message to one or more numbers.
   * Returns [{ number, accepted, status, statusCode, messageId, cost }]
   */
  async function send({ to, message }) {
    const numbers = Array.isArray(to) ? to : [to];
    if (dryRun || !apiKey) {
      // logText (DEV_LOG_SMS, refused in production) shows the text so a developer can read sign-in codes.
      logger?.info({ to: numbers.map(maskPhone), chars: message.length, ...(logText ? { text: message } : {}) }, 'SMS dry run (not sent)');
      return numbers.map((number) => ({
        number, accepted: true, status: 'DryRun', statusCode: 100, messageId: `dry-${Date.now()}-${number}`, cost: 0,
      }));
    }
    const body = new URLSearchParams({ username, to: numbers.join(','), message });
    if (senderId) body.set('from', senderId);

    const res = await fetchImpl(`${host}/version1/messaging`, {
      method: 'POST',
      headers: { apiKey, Accept: 'application/json', 'Content-Type': 'application/x-www-form-urlencoded' },
      body,
      signal: AbortSignal.timeout(timeoutMs),
    });
    const text = await res.text();
    if (!res.ok) throw new Error(`Africa's Talking HTTP ${res.status}: ${text.slice(0, 300)}`);
    let json;
    try { json = JSON.parse(text); } catch { throw new Error(`Africa's Talking returned non-JSON: ${text.slice(0, 200)}`); }
    const recipients = json?.SMSMessageData?.Recipients ?? [];
    return recipients.map((r) => ({
      number: r.number,
      accepted: ACCEPTED_CODES.has(Number(r.statusCode)),
      status: r.status,
      statusCode: Number(r.statusCode),
      messageId: r.messageId && r.messageId !== 'None' ? r.messageId : null,
      cost: parseCost(r.cost),
    }));
  }

  /**
   * Prepaid credit left on the account: { currency, amount }, or null in dry-run mode.
   * Throws on HTTP errors or an unexpected shape; the caller records "unknown" rather than "low",
   * so a change on Africa's Talking's side can never raise a false low-credit alarm.
   */
  async function balance() {
    if (dryRun || !apiKey) return null;
    const res = await fetchImpl(`${host}/version1/user?username=${encodeURIComponent(username)}`, {
      headers: { apiKey, Accept: 'application/json' },
      signal: AbortSignal.timeout(timeoutMs),
    });
    const text = await res.text();
    if (!res.ok) throw new Error(`Africa's Talking HTTP ${res.status}: ${text.slice(0, 200)}`);
    let json;
    try { json = JSON.parse(text); } catch { throw new Error(`Africa's Talking returned non-JSON: ${text.slice(0, 200)}`); }
    return parseBalance(json?.UserData?.balance);
  }

  return { send, balance };
}

/** "KES 1,785.5000" -> { currency: 'KES', amount: 1785.5 }; throws on anything else. */
function parseBalance(raw) {
  const m = typeof raw === 'string' ? raw.trim().match(/^([A-Z]{3})\s*(-?[\d,]+(?:\.\d+)?)$/) : null;
  if (!m) throw new Error(`Unexpected balance format: ${String(raw).slice(0, 40)}`);
  return { currency: m[1], amount: Number(m[2].replace(/,/g, '')) };
}

module.exports = { createSmsClient, parseCost, parseBalance };
