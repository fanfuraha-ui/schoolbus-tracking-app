'use strict';
/**
 * Firebase Cloud Messaging (HTTP v1) without firebase-admin.
 *  1. Sign a service-account JWT (RS256) with Node's crypto.
 *  2. Exchange it at Google's OAuth endpoint for an access token (cached ~55 min).
 *  3. POST https://fcm.googleapis.com/v1/projects/<project>/messages:send
 *
 * send() resolves { messageId } or throws PushError { retryable, unregistered }.
 * unregistered = the app was uninstalled / token is dead -> caller should forget the token.
 */
const crypto = require('crypto');

const TOKEN_URL = 'https://oauth2.googleapis.com/token';
const SCOPE = 'https://www.googleapis.com/auth/firebase.messaging';

class PushError extends Error {
  constructor(message, { retryable = false, unregistered = false, status } = {}) {
    super(message);
    this.name = 'PushError';
    this.retryable = retryable;
    this.unregistered = unregistered;
    this.status = status;
  }
}

const b64url = (obj) => Buffer.from(JSON.stringify(obj)).toString('base64url');

/** Accepts the service-account JSON as a string (raw or base64) or an object. */
function parseServiceAccount(input) {
  if (!input) return null;
  if (typeof input === 'object') return input;
  const text = input.trim().startsWith('{') ? input : Buffer.from(input, 'base64').toString('utf8');
  const sa = JSON.parse(text);
  if (!sa.project_id || !sa.client_email || !sa.private_key) throw new Error('FCM service account JSON is missing project_id/client_email/private_key');
  return sa;
}

function createFcmClient({ serviceAccount, dryRun = false, logger, fetchImpl = globalThis.fetch, timeoutMs = 10000, now = () => Date.now() }) {
  const sa = parseServiceAccount(serviceAccount);
  let cached = null; // { token, expiresAt }

  async function accessToken() {
    if (cached && cached.expiresAt - 60000 > now()) return cached.token;
    const iat = Math.floor(now() / 1000);
    const unsigned = `${b64url({ alg: 'RS256', typ: 'JWT' })}.${b64url({ iss: sa.client_email, scope: SCOPE, aud: TOKEN_URL, iat, exp: iat + 3600 })}`;
    const signature = crypto.createSign('RSA-SHA256').update(unsigned).sign(sa.private_key, 'base64url');
    const res = await fetchImpl(TOKEN_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer', assertion: `${unsigned}.${signature}` }),
      signal: AbortSignal.timeout(timeoutMs),
    });
    const json = await res.json().catch(() => ({}));
    if (!res.ok || !json.access_token) {
      throw new PushError(`FCM auth failed (${res.status}): ${json.error_description || json.error || 'unknown'}`, { retryable: res.status >= 500, status: res.status });
    }
    cached = { token: json.access_token, expiresAt: now() + (json.expires_in || 3600) * 1000 };
    return cached.token;
  }

  /**
   * token: device FCM token; data: flat object (values stringified); critical: louder channel.
   */
  async function send({ token, title, body, data = {}, critical = false }) {
    if (dryRun || !sa) {
      logger?.info({ title, critical }, 'Push dry run (not sent)');
      return { messageId: `dry-push-${now()}` };
    }
    const message = {
      token,
      notification: { title, body },
      data: Object.fromEntries(Object.entries(data).filter(([, v]) => v != null).map(([k, v]) => [k, String(v)])),
      android: { priority: 'HIGH', notification: { channel_id: critical ? 'critical_alerts' : 'bus_alerts' } },
      apns: { headers: { 'apns-priority': '10' }, payload: { aps: { sound: 'default' } } },
    };
    let res;
    try {
      res = await fetchImpl(`https://fcm.googleapis.com/v1/projects/${sa.project_id}/messages:send`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${await accessToken()}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ message }),
        signal: AbortSignal.timeout(timeoutMs),
      });
    } catch (err) {
      if (err instanceof PushError) throw err;
      throw new PushError(`FCM network error: ${err.message}`, { retryable: true });
    }
    const json = await res.json().catch(() => ({}));
    if (res.ok) return { messageId: json.name };

    const status = json.error?.status;
    const fcmCode = (json.error?.details || []).map((d) => d.errorCode).find(Boolean);
    const unregistered = res.status === 404 || fcmCode === 'UNREGISTERED' || (res.status === 400 && fcmCode === 'INVALID_ARGUMENT' && /token/i.test(json.error?.message || ''));
    if (res.status === 401) cached = null; // force a fresh access token next time
    throw new PushError(`FCM ${res.status} ${fcmCode || status || ''}: ${json.error?.message || ''}`.trim(), {
      unregistered,
      retryable: !unregistered && (res.status === 401 || res.status === 429 || res.status >= 500),
      status: res.status,
    });
  }

  return { send, enabled: Boolean(sa) && !dryRun };
}

module.exports = { createFcmClient, PushError, parseServiceAccount };
