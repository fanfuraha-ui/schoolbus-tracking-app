'use strict';
/** Worker process entry point:  npm run worker */
const { loadConfig } = require('./config');
const { createLogger } = require('./lib/logger');
const { createDb, createPgPool } = require('./db');
const { createSettingsService } = require('./services/settingsService');
const { createSmsClient } = require('./integrations/africasTalking');
const { createFcmClient } = require('./integrations/fcm');
const { createWorker } = require('./worker');

async function main() {
  const config = loadConfig();
  const logger = createLogger(config).child({ process: 'worker' });
  const pool = createPgPool(config.databaseUrl, { max: 5 });
  const db = createDb(pool);
  await db.query('SELECT 1');

  const worker = createWorker({
    db,
    settings: createSettingsService({ db }),
    sms: createSmsClient({ ...config.sms, logger }),
    push: createFcmClient({ serviceAccount: config.push.serviceAccount, dryRun: config.push.dryRun, logger }),
    logger,
  });
  worker.start();
  logger.info({ smsDryRun: config.sms.dryRun, pushDryRun: config.push.dryRun || !config.push.serviceAccount }, 'Worker running');

  const shutdown = async (signal) => {
    logger.info({ signal }, 'Worker shutting down');
    worker.stop();
    setTimeout(async () => { await pool.end().catch(() => {}); process.exit(0); }, 3000).unref();
  };
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

main().catch((err) => {
  // eslint-disable-next-line no-console
  console.error(err);
  process.exit(1);
});
