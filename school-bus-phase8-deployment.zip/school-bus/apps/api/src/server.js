'use strict';
/**
 * API process entry point.  Run migrations first:  npm run db:migrate && npm start
 */
const http = require('http');
const { loadConfig } = require('./config');
const { createLogger } = require('./lib/logger');
const { createDb, createPgPool } = require('./db');
const { createTokenService } = require('./lib/tokens');
const { createPasswordHasher } = require('./lib/passwords');
const { createSmsClient } = require('./integrations/africasTalking');
const { createSettingsService } = require('./services/settingsService');
const { createAuthService } = require('./services/authService');
const { createTripService } = require('./services/tripService');
const { createParentService } = require('./services/parentService');
const { createAdminService } = require('./services/admin/adminService');
const { importStudentsCsv } = require('./services/admin/importStudents');
const { createBroadcaster } = require('./realtime/broadcaster');
const { attachRealtime } = require('./realtime/socket');
const { createApp } = require('./http/app');
const { createDeliveryReportService } = require('./notifications/deliveryReports');
const { createFleetEventRelay } = require('./realtime/fleetEventRelay');

async function main() {
  const config = loadConfig();
  const logger = createLogger(config);
  const pool = createPgPool(config.databaseUrl, { max: config.dbPoolMax });
  const db = createDb(pool);
  await db.query('SELECT 1');

  const settings = createSettingsService({ db });
  const tokens = createTokenService({ secret: config.jwtSecret, accessTtl: config.accessTtl });
  const hasher = createPasswordHasher();
  const sms = createSmsClient({ ...config.sms, logger });
  const broadcaster = createBroadcaster();

  const services = {
    db,
    settings,
    authService: createAuthService({
      db, hasher, tokens, sms, settings, otpPepper: config.otpPepper, refreshTtlDays: config.refreshTtlDays, logger,
    }),
    tripService: createTripService({ db, settings, broadcaster, logger }),
    parentService: createParentService({ db, settings }),
    adminService: createAdminService({ db, hasher, settings }),
    importStudents: (csv, opts) => importStudentsCsv({ db }, csv, opts),
    deliveryReports: createDeliveryReportService({ db }),
  };

  const app = createApp({ services, tokens, config, logger });
  const server = http.createServer(app);
  const io = attachRealtime({ server, tokens, services, broadcaster, config, logger });

  const relay = createFleetEventRelay({ pool, broadcaster, logger });
  await relay.start();

  server.listen(config.port, () => logger.info({ port: config.port, env: config.env, smsDryRun: config.sms.dryRun }, 'API listening'));

  let closing = false;
  const shutdown = (signal) => {
    if (closing) return;
    closing = true;
    logger.info({ signal }, 'Shutting down');
    relay.stop().catch(() => {});
    io.close();
    server.close(async () => {
      await pool.end().catch(() => {});
      process.exit(0);
    });
    setTimeout(() => process.exit(1), 10000).unref();
  };
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

main().catch((err) => {
  // eslint-disable-next-line no-console
  console.error(err);
  process.exit(1);
});
