'use strict';
/**
 * Database access. Services receive a `db` object with:
 *   db.query(sql, params) -> { rows, rowCount }     rows are camelCased
 *   db.one(sql, params)   -> first row or null
 *   db.many(sql, params)  -> rows
 *   db.tx(async (t) => …) -> runs in a transaction; `t` has the same methods
 *
 * createDb() takes any pg-compatible pool ({ query, connect }), which lets tests
 * run the same services against a real database through a different driver.
 */

const camel = (s) => s.replace(/_([a-z0-9])/g, (_, c) => c.toUpperCase());

function camelizeRow(row) {
  const out = {};
  for (const key of Object.keys(row)) out[camel(key)] = row[key];
  return out;
}

function wrap(runner) {
  const query = async (sql, params = []) => {
    const res = await runner.query(sql, params);
    return { rows: res.rows.map(camelizeRow), rowCount: res.rowCount };
  };
  return {
    query,
    one: async (sql, params) => (await query(sql, params)).rows[0] ?? null,
    many: async (sql, params) => (await query(sql, params)).rows,
  };
}

function createDb(pool) {
  const base = wrap(pool);

  async function tx(fn) {
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const result = await fn(wrap(client));
      await client.query('COMMIT');
      return result;
    } catch (err) {
      await client.query('ROLLBACK').catch(() => {});
      throw err;
    } finally {
      client.release();
    }
  }

  return { ...base, tx, pool };
}

/** Production pool using node-postgres, with type parsers matching how the app uses values. */
function createPgPool(connectionString, { max = 10 } = {}) {
  const { Pool, types } = require('pg');
  types.setTypeParser(20, (v) => Number(v));   // int8 (count(*), identity ids) -> number
  types.setTypeParser(1700, (v) => Number(v)); // numeric (lat/lng, costs) -> number
  types.setTypeParser(1082, (v) => v);         // date -> 'YYYY-MM-DD' (no timezone shifting)
  return new Pool({ connectionString, max, idleTimeoutMillis: 30000 });
}

module.exports = { createDb, createPgPool, camelizeRow };
