'use strict';

const { distanceM, pathLengthM } = require('./geo');

const DEFAULTS = Object.freeze({
  speedWindowS: 180,   // rolling speed over the last 3 minutes
  minSpeedMps: 3,      // ~11 km/h: Nairobi crawl; stops ETAs exploding while parked in traffic
  maxSpeedMps: 20,     // ~72 km/h cap against GPS jumps
  fallbackSpeedMps: 5.5, // ~20 km/h before we have enough points
  roadFactor: 1.3,     // straight-line -> road distance
  dwellS: 30,          // average time spent at each intermediate stop
});

/**
 * Average speed (m/s) over recent points, clamped to a sane range.
 * points: [{lat, lng, recordedAt: Date}] sorted ascending.
 */
function rollingSpeed(points, nowMs, opts = {}) {
  const o = { ...DEFAULTS, ...opts };
  const recent = points.filter((p) => nowMs - p.recordedAt.getTime() <= o.speedWindowS * 1000);
  if (recent.length < 2) return o.fallbackSpeedMps;
  const elapsedS = (recent[recent.length - 1].recordedAt - recent[0].recordedAt) / 1000;
  if (elapsedS < 10) return o.fallbackSpeedMps;
  const speed = pathLengthM(recent) / elapsedS;
  return Math.min(o.maxSpeedMps, Math.max(o.minSpeedMps, speed));
}

const legKey = (fromId, toId) => `${fromId}:${toId}`;

/**
 * Estimated seconds from `position` to each stop from stops[startIndex] onward.
 *
 * For each leg we prefer the learned median (segmentStats) and fall back to
 * road-adjusted distance / current speed. For the partially completed first leg,
 * the learned median is scaled by the fraction of that leg still remaining.
 *
 * stops: ordered [{id, lat, lng}]; segmentStats: Map(`${from}:${to}` -> seconds)
 * Returns [{stopId, secondsAway}].
 */
function computeEtas({ position, stops, startIndex, speedMps, segmentStats = new Map(), opts = {} }) {
  const o = { ...DEFAULTS, ...opts };
  const out = [];
  if (startIndex < 0 || startIndex >= stops.length) return out;

  const first = stops[startIndex];
  const distToFirst = distanceM(position, first);
  let seconds;
  const prev = startIndex > 0 ? stops[startIndex - 1] : null;
  const learnedFirst = prev ? segmentStats.get(legKey(prev.id, first.id)) : undefined;
  if (learnedFirst && prev) {
    const legLen = distanceM(prev, first);
    const fraction = legLen > 0 ? Math.min(1, distToFirst / legLen) : 1;
    seconds = fraction * learnedFirst;
  } else {
    seconds = (distToFirst * o.roadFactor) / speedMps;
  }
  out.push({ stopId: first.id, secondsAway: Math.round(seconds) });

  for (let i = startIndex + 1; i < stops.length; i += 1) {
    const learned = segmentStats.get(legKey(stops[i - 1].id, stops[i].id));
    const leg = learned ?? (distanceM(stops[i - 1], stops[i]) * o.roadFactor) / speedMps;
    seconds += o.dwellS + leg;
    out.push({ stopId: stops[i].id, secondsAway: Math.round(seconds) });
  }
  return out;
}

module.exports = { rollingSpeed, computeEtas, legKey, ETA_DEFAULTS: DEFAULTS };
