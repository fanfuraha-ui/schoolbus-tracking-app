'use strict';

/**
 * Normalise a Kenyan mobile number to E.164 (+2547XXXXXXXX / +2541XXXXXXXX).
 * Accepts 0712345678, 712345678, 254712345678, +254 712 345 678, 0112-345-678, etc.
 * Returns null if the input is not a valid Kenyan mobile number.
 */
function normalizeKenyanPhone(input) {
  if (typeof input !== 'string' && typeof input !== 'number') return null;
  let digits = String(input).trim().replace(/[\s\-().]/g, '');
  if (digits.startsWith('+')) digits = digits.slice(1);
  if (digits.startsWith('254')) digits = digits.slice(3);
  else if (digits.startsWith('0')) digits = digits.slice(1);
  if (!/^[17]\d{8}$/.test(digits)) return null;
  return `+254${digits}`;
}

/** Mask a phone for logs: +254712***678 */
function maskPhone(phone) {
  if (typeof phone !== 'string' || phone.length < 9) return '***';
  return `${phone.slice(0, 7)}***${phone.slice(-3)}`;
}

module.exports = { normalizeKenyanPhone, maskPhone };
