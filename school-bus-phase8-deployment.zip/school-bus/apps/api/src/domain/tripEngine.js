'use strict';
/**
 * Trip engine: pure logic that turns GPS points into stop progress and alert events.
 * No I/O. The trip service loads a context from the DB, feeds points through
 * processPoint() in time order, then persists ctx.changed stops + returned events.
 *
 * Stop lifecycle: pending -> approaching -> arrived -> departed   (or -> skipped)
 *
 * Rules (v2 design):
 *  - Arrival: point inside the stop radius AND (previous point also inside OR speed < 1.4 m/s).
 *    One noisy point inside the circle is never enough.
 *  - Departure: two consecutive points outside, the latest beyond radius + 30 m hysteresis.
 *  - Bypass: arriving at a later stop (lookahead 3) closes earlier ones
 *    (arrived -> departed, pending/approaching -> skipped 'bypassed').
 *  - Approaching: ETA <= stop.approachMinutes.
 *  - Silent mode (stale/backlog points): state still advances, but no alert events.
 *  - School gate on a from_school trip never produces parent alerts.
 *  - Points with accuracy worse than 100 m are ignored by the engine (still stored).
 */
const { distanceM } = require('./geo');
const { rollingSpeed, computeEtas } = require('./eta');
const { AppError } = require('../lib/errors');

const ENGINE_DEFAULTS = Object.freeze({
  arrivalSpeedMps: 1.4,
  departHysteresisM: 30,
  lookahead: 3,
  maxAccuracyM: 100,
  etaChangeThresholdS: 30,
  recentWindowS: 180,
});

const DONE = new Set(['departed', 'skipped']);

function createTripContext({ trip, stops, states, recentPoints = [], segmentStats = new Map(), settings = {} }) {
  const stateMap = new Map();
  for (const s of states) {
    stateMap.set(s.stopId, {
      status: s.status,
      etaAt: s.etaAt ? new Date(s.etaAt) : null,
      approachingAt: s.approachingAt ? new Date(s.approachingAt) : null,
      arrivedAt: s.arrivedAt ? new Date(s.arrivedAt) : null,
      departedAt: s.departedAt ? new Date(s.departedAt) : null,
      skippedReason: s.skippedReason ?? null,
    });
  }
  const ordered = [...stops].sort((a, b) => a.sequence - b.sequence);
  for (const stop of ordered) {
    if (!stateMap.has(stop.id)) {
      throw new Error(`Trip ${trip.id} has no state row for stop ${stop.id}`);
    }
  }
  const points = recentPoints.map((p) => ({ ...p, recordedAt: new Date(p.recordedAt) }));
  return {
    trip,
    stops: ordered,
    states: stateMap,
    recentPoints: points,
    lastPoint: points.length ? points[points.length - 1] : null,
    segmentStats,
    opts: { ...ENGINE_DEFAULTS, ...settings },
    changed: new Set(),
  };
}

function activeIndex(ctx) {
  return ctx.stops.findIndex((s) => !DONE.has(ctx.states.get(s.id).status));
}

function alertsSuppressed(ctx, stop) {
  return stop.isSchool && ctx.trip.direction === 'from_school';
}

function patch(ctx, stopId, fields) {
  Object.assign(ctx.states.get(stopId), fields);
  ctx.changed.add(stopId);
}

/** Close every unfinished stop before index `idx` (bus has moved past them). */
function closeEarlier(ctx, idx, at) {
  for (let j = 0; j < idx; j += 1) {
    const s = ctx.stops[j];
    const st = ctx.states.get(s.id);
    if (st.status === 'arrived') patch(ctx, s.id, { status: 'departed', departedAt: at });
    else if (!DONE.has(st.status)) patch(ctx, s.id, { status: 'skipped', skippedReason: 'bypassed' });
  }
}

function legSegment(ctx, k, at) {
  if (k === 0) return null;
  const prevStop = ctx.stops[k - 1];
  const ps = ctx.states.get(prevStop.id);
  if (ps.status !== 'departed' || !ps.departedAt) return null;
  const seconds = Math.round((at - ps.departedAt) / 1000);
  if (seconds <= 0) return null;
  return { fromStopId: prevStop.id, toStopId: ctx.stops[k].id, seconds, startedAt: ps.departedAt };
}

/**
 * Feed one GPS point. point: {lat, lng, speedMps?, accuracyM?, recordedAt: Date}
 * Returns {events: [{type, stopId, at, etaMinutes?}], segments: [...], ignored}
 */
function processPoint(ctx, point, { silent = false } = {}) {
  const result = { events: [], segments: [], ignored: false };
  const o = ctx.opts;
  if (point.accuracyM != null && point.accuracyM > o.maxAccuracyM) {
    result.ignored = true;
    return result;
  }

  const at = point.recordedAt;
  const prev = ctx.lastPoint;
  ctx.recentPoints.push(point);
  while (ctx.recentPoints.length && at - ctx.recentPoints[0].recordedAt > o.recentWindowS * 1000) {
    ctx.recentPoints.shift();
  }
  ctx.lastPoint = point;

  let t = activeIndex(ctx);
  if (t === -1) return result;

  // 1. Departure from the stop the bus is sitting at.
  {
    const stop = ctx.stops[t];
    const st = ctx.states.get(stop.id);
    if (st.status === 'arrived') {
      const farNow = distanceM(point, stop) > stop.radiusM + o.departHysteresisM;
      const prevOutside = !prev || distanceM(prev, stop) > stop.radiusM;
      if (farNow && prevOutside) {
        patch(ctx, stop.id, { status: 'departed', departedAt: at });
        t = activeIndex(ctx);
        if (t === -1) return result;
      }
    }
  }

  // 2. Arrival at the active stop, or a later one within the lookahead (bypass).
  for (let k = t; k < Math.min(ctx.stops.length, t + o.lookahead); k += 1) {
    const stop = ctx.stops[k];
    if (ctx.states.get(stop.id).status === 'arrived') continue;
    if (distanceM(point, stop) > stop.radiusM) continue;
    const prevInside = prev ? distanceM(prev, stop) <= stop.radiusM : false;
    const slow = point.speedMps != null && point.speedMps < o.arrivalSpeedMps;
    if (!prevInside && !slow) continue;

    closeEarlier(ctx, k, at);
    const segment = legSegment(ctx, k, at);
    if (segment) result.segments.push(segment);
    patch(ctx, stop.id, { status: 'arrived', arrivedAt: at, etaAt: at });
    if (!silent && !alertsSuppressed(ctx, stop)) {
      result.events.push({ type: 'arrived', stopId: stop.id, at });
    }
    break;
  }

  // 3. ETAs for upcoming stops, and "approaching" alerts.
  t = activeIndex(ctx);
  if (t === -1) return result;
  const start = ctx.states.get(ctx.stops[t].id).status === 'arrived' ? t + 1 : t;
  if (start >= ctx.stops.length) return result;

  const speedMps = rollingSpeed(ctx.recentPoints, at.getTime(), o);
  const etas = computeEtas({
    position: point, stops: ctx.stops, startIndex: start, speedMps, segmentStats: ctx.segmentStats, opts: o,
  });
  for (const { stopId, secondsAway } of etas) {
    const st = ctx.states.get(stopId);
    if (DONE.has(st.status) || st.status === 'arrived') continue;
    const etaAt = new Date(at.getTime() + secondsAway * 1000);
    if (!st.etaAt || Math.abs(etaAt - st.etaAt) >= o.etaChangeThresholdS * 1000) {
      patch(ctx, stopId, { etaAt });
    }
    const stop = ctx.stops.find((s) => s.id === stopId);
    if (st.status === 'pending' && secondsAway <= stop.approachMinutes * 60) {
      patch(ctx, stopId, { status: 'approaching', approachingAt: at });
      if (!silent && !alertsSuppressed(ctx, stop)) {
        result.events.push({
          type: 'approaching', stopId, at, etaMinutes: Math.max(1, Math.round(secondsAway / 60)),
        });
      }
    }
  }
  return result;
}

/**
 * Driver taps a stop button. action: 'arrived' | 'departed' | 'skipped'.
 * Idempotent: repeating an action that already happened is a no-op.
 */
function applyManualAction(ctx, stopId, action, { at, reason } = {}) {
  const idx = ctx.stops.findIndex((s) => s.id === stopId);
  if (idx === -1) throw new AppError(404, 'stop_not_on_trip', 'That stop is not part of this trip');
  const stop = ctx.stops[idx];
  const st = ctx.states.get(stopId);
  const events = [];
  const segments = [];

  const arrive = () => {
    closeEarlier(ctx, idx, at);
    const segment = legSegment(ctx, idx, at);
    if (segment) segments.push(segment);
    patch(ctx, stopId, { status: 'arrived', arrivedAt: at, etaAt: at });
    if (!alertsSuppressed(ctx, stop)) events.push({ type: 'arrived', stopId, at });
  };

  if (DONE.has(st.status)) return { events, segments };

  if (action === 'arrived') {
    if (st.status !== 'arrived') arrive();
  } else if (action === 'departed') {
    if (st.status !== 'arrived') arrive();
    patch(ctx, stopId, { status: 'departed', departedAt: at });
  } else if (action === 'skipped') {
    if (st.status === 'arrived') {
      throw new AppError(409, 'stop_already_arrived', 'The bus already arrived at this stop; mark it departed instead');
    }
    patch(ctx, stopId, { status: 'skipped', skippedReason: reason || 'skipped_by_driver' });
  } else {
    throw new AppError(400, 'invalid_action', `Unknown stop action "${action}"`);
  }
  return { events, segments };
}

/** Serialisable list of changed stop states, for persistence and broadcasting. */
function changedStates(ctx) {
  return [...ctx.changed].map((stopId) => {
    const s = ctx.states.get(stopId);
    return {
      stopId,
      status: s.status,
      etaAt: s.etaAt,
      approachingAt: s.approachingAt,
      arrivedAt: s.arrivedAt,
      departedAt: s.departedAt,
      skippedReason: s.skippedReason,
    };
  });
}

module.exports = {
  createTripContext, processPoint, applyManualAction, changedStates, activeIndex, ENGINE_DEFAULTS,
};
