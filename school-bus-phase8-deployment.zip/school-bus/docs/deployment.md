# Deployment and go-live runbook

How to take the system from this repository to a school running it every day: one server, one domain, three apps, SMS and push live, backups that have been tested.

Who does what:
- **Technical contact** (you): server, deploys, backups, app builds.
- **Transport office**: the dashboard, SMS top-ups, student lists.
- **School management**: registrations and sign-offs.

---

## 1. Start these first: they have waiting times

| Item | Who | Lead time | Notes |
|---|---|---|---|
| **ODPC registration** (Office of the Data Protection Commissioner) | School management | Days to weeks | Schools must register as a data controller regardless of size. The system processes children's names, classes, stops and parents' phone numbers. Register at odpc.go.ke before parents' data goes in. A short data protection impact assessment is wise because the data is about children. |
| **Africa's Talking live account + sender ID** | School + you | Safaricom: up to ~1 week. Other networks: 7–14 working days | Apply in the AT dashboard with the school's registration documents. Ask for a **transactional** sender ID (e.g. `GREENFIELD`, max 11 characters). AT submits to Safaricom on Mondays and Thursdays before noon. There is a one-time fee. Until approved, messages go out from a shared number, which works but is less trusted. |
| **Google Play developer account** | School | 1–3 weeks | Register it as an **organization** (needs a D-U-N-S number). A new *personal* account must first run a closed test with 12 testers for 14 days before it can publish. |
| **Domain / subdomain** | School ICT | Same day | e.g. `bus.yourschool.ac.ke` |
| **Firebase project** | You | Same day | Push notifications for both apps |

---

## 2. What it costs to run

| Item | Cost | Notes |
|---|---|---|
| Server (VPS) | Monthly | 2 vCPU, 4 GB RAM, 40 GB SSD, Ubuntu 24.04. Six buses report a position every 5 seconds: a light load. |
| SMS | Per message, roughly KES 0.50–0.80 | Up to ~5 alerts per family per school day (approaching, boarded, arrived at school, approaching home, dropped off). 150 families on SMS only is about 15,000 SMS a month. **Families using the parent app get free push instead.** At 70% app use, SMS volume drops by about two thirds. Push the app at the parents' meeting. |
| Sender ID | One-time | Via Africa's Talking |
| Off-site backup storage | Small | A few MB per night (compressed). Any S3-compatible or Google Drive storage works. |
| Google Play | One-time fee | Apple is only needed for iPhone push. iPhone parents get SMS without it. |

The dashboard shows SMS cost per day and month (Parent alerts, Reports). It warns when credit is low (section 9).

---

## 3. Server setup (once)

1. Create an Ubuntu 24.04 VPS and add your SSH public key.
2. Point the domain's **A record** at the server's IP. Wait until `ping bus.yourschool.ac.ke` shows that IP.
3. As root, read and run `deploy/scripts/server-setup.sh`. It does all of the following:
   - updates and automatic security updates
   - installs Docker
   - creates a `deploy` user with SSH-key login only
   - sets the firewall to SSH, 80 and 443 only
   - installs fail2ban
   - adds swap
   - sets the Nairobi time zone
   - creates the backup folder
4. As `deploy`:
   ```bash
   git clone <repo URL> /opt/schoolbus && cd /opt/schoolbus
   deploy/scripts/gen-secrets.sh        # creates deploy/.env with random secrets (mode 600)
   nano deploy/.env                     # DOMAIN, ACME_EMAIL, CORS_ORIGINS; leave SMS_DRY_RUN=true for now
   deploy/scripts/deploy.sh
   ```
5. Open `https://bus.yourschool.ac.ke`. Caddy fetches the HTTPS certificate on first start, which takes about 30 seconds.
6. Create the first office admin. A production database starts with no users:
   ```bash
   docker compose -f deploy/docker-compose.prod.yml exec api node db/scripts/create-admin.js "Lucy Wairimu" lucy@yourschool.ac.ke
   ```
   It prints a one-time password. Sign in, then change it under Settings > Your password. Further office users: run the same command once per person, so nobody shares a login.
7. **Store `deploy/.env` in the school's password manager.** Without it you can still restore the data, but every secret must be regenerated and everyone signs in again.

### What runs
| Container | Job |
|---|---|
| `caddy` | HTTPS (Let's Encrypt, auto-renewed), serves the dashboard, forwards `/api`, `/socket.io`, `/webhooks`, `/health` to the API |
| `api` | REST + live updates |
| `worker` | Arrival detection, ETAs, delays, SMS and push sending, automatic checks, SMS-credit check |
| `db` | PostgreSQL 16. Not reachable from the internet. |
| `migrate` | Runs at each deploy, applies new database migrations, then exits |
| `backup` | Nightly backup at 02:30 |

---

## 4. Going live with SMS (Africa's Talking)

1. In the AT dashboard, switch from Sandbox to your **live** app and generate an API key.
2. Top up. AT supports paying from an M-Pesa business account (paybill).
3. Set the delivery-report callback: SMS > Callback URLs > Delivery reports. The URL is `https://bus.yourschool.ac.ke/webhooks/africastalking/delivery/<AT_WEBHOOK_SECRET from deploy/.env>`.
4. In `deploy/.env`, set:
   - `AT_USERNAME` (live app name)
   - `AT_API_KEY`
   - `AT_SENDER_ID`, once it is approved; leave it empty until then
   - `SMS_DRY_RUN=false`
5. Run `deploy/scripts/deploy.sh --no-pull`.
6. **Test with your own phone**: add yourself as a parent of a test student on Route 1. Sign in to the parent app (the code arrives by SMS), then run a trip with the driver app.
7. **Check the credit reading** within an hour. Look at Dashboard > Live > "Needs attention", or run:
   ```bash
   docker compose -f deploy/docker-compose.prod.yml exec db psql -U schoolbus -c "SELECT last_result FROM job_runs WHERE name='sms_balance'"
   ```
   `"status":"ok"` with your balance means it works. `"status":"unknown"` means AT's balance endpoint answered differently than expected. Alerts still send in that case; only the low-credit warning is off. Send the `error` text to your developer.

## 5. Push notifications (Firebase)

1. Create a Firebase project. Add two Android apps with the package ids from `apps/driver/app.config.js` and `apps/parent/app.config.js`. Change them from `ke.schoolbus.*` to your school's domain first.
2. Download each app's `google-services.json` into that app's folder, or store it as an EAS file secret named `GOOGLE_SERVICES_JSON`.
3. Project settings > Service accounts > Generate new private key. Then put it in `deploy/.env` as one line: `FCM_SERVICE_ACCOUNT=$(base64 -w0 key.json)`. Delete the downloaded key afterwards.
4. Redeploy. The parent app's Settings shows "App notifications: On" when it works.

## 6. Mobile apps

| App | Build | Distribution |
|---|---|---|
| Driver | `cd apps/driver && npm run build:apk` (set the production API URL in `eas.json` first) | Install the APK on each bus phone from the EAS link. No store needed: the phones belong to the school. |
| Parent | `cd apps/parent && npm run build:store` | Google Play. Internal testing → closed testing (12 testers × 14 days if the account is personal) → production. Complete the Data safety form: phone number and name collected, not shared, encrypted in transit, deletion on request. Link a privacy policy, which can be the same text as the in-app notice. |

In both apps' `eas.json`, the production API URL is simply `https://bus.yourschool.ac.ke`.

## 7. First week: pilot one route

1. Import students and parents (Dashboard > Students > Import, CSV dry run first). Check every stop's pin on the map.
2. **Pilot Route 1 for a week**, with its families told in advance. The driver runs the app on every trip.
3. Watch each day for:
   - parents who say alerts came too early or too late: adjust that stop's "alert minutes" or radius
   - stops the bus "missed": the pin is in the wrong place
4. Then roll out to all six routes. Send a parents' letter with the Play Store link and the line "No smartphone? You'll get SMS automatically".

---

## 8. Backups

- Every night at 02:30 the database is dumped, checked as readable, and kept: 14 nightly copies and 8 weekly (Sunday) copies, in `/var/backups/schoolbus`.
- **Off-site (do this):** the server's disk is not a backup of the server.
  1. On the server, run `docker run --rm -it -v /opt/schoolbus/deploy/rclone:/config/rclone rclone/rclone config`.
  2. Create a remote for your storage (Backblaze B2, AWS S3, Google Drive, ...).
  3. Create a **crypt** remote on top of it, so files are encrypted before they leave the server. Keep the crypt passwords in the password manager.
  4. Set `RCLONE_REMOTE=offsite:schoolbus` (your crypt remote's name) in `deploy/.env` and redeploy.
  5. Files are copied, never synced. A wiped server can't wipe the off-site copies. Off-site files older than `OFFSITE_KEEP_DAYS` are removed.
- **Take one now:** `docker compose -f deploy/docker-compose.prod.yml exec backup backup.sh`
- **Restore drill, once a term (10 minutes):** `deploy/scripts/restore.sh drill`
  It restores the newest backup into a scratch database, prints student, parent and trip counts, and removes it. A backup you haven't restored is a hope.
- **Real restore:** `deploy/scripts/restore.sh replace /var/backups/schoolbus/daily/<file>.dump`
  It takes a safety backup first, asks you to type REPLACE, stops the API and worker, restores, applies newer migrations and restarts.
- **New server from scratch:** run section 3, copy `deploy/.env` from the password manager, `deploy/scripts/deploy.sh`, then copy a dump from off-site and `restore.sh replace` it.

## 9. Monitoring

| What | How |
|---|---|
| Is it all working? | `https://DOMAIN/health/jobs` returns 200 when the worker ran in the last 5 minutes, last night's backup succeeded, and SMS credit is above the warning level. Otherwise it returns 503 with the failing check: `{"ok":false,"checks":{"worker":true,"backup":true,"smsCredit":false}}`. Point a free uptime monitor (e.g. UptimeRobot, every 5 minutes, alerts to your phone) at it. |
| The office sees problems | Dashboard > Live > "Needs attention" shows, in plain language: alerts stopped (worker down), SMS credit low with days left, backup missed, backup not off-site. The warning level is in Settings ("Warn when SMS credit falls below"). |
| Logs | `docker compose -f deploy/docker-compose.prod.yml logs -f --tail 100 api worker` (rotated, about 50 MB per service) |
| Disk | `df -h /` monthly. Old GPS points are purged after `location_retention_days` (90). |

## 10. Updates

- `deploy/scripts/deploy.sh` pulls `main`, builds, migrates, restarts and health-checks.
- It refuses while buses are on the road (`FORCE=1` to override). Deploy after the afternoon run.
- **Automatic:** set up the GitHub Actions secrets listed at the top of `.github/workflows/ci.yml`. Then every push to `main` that passes the tests deploys itself. Add a required reviewer on the `production` environment to approve each one.
- **Roll back:** `git checkout <previous tag> && deploy/scripts/deploy.sh --no-pull`. Migrations only add things, so older code runs on the newer schema.
- **Server updates:** security patches install automatically. Reboot in the holidays: `sudo reboot`. Everything restarts by itself.

## 11. When something goes wrong

| Symptom | Likely cause | Fix |
|---|---|---|
| "Parent alerts have stopped" on the dashboard | Worker crashed or the server restarted badly | `docker compose -f deploy/docker-compose.prod.yml ps`, then `... logs --tail 100 worker`, then `... up -d worker` |
| "SMS credit is low / has run out" | Prepaid credit used up | Top up AT (M-Pesa). App users keep getting push meanwhile. |
| Parents say they get no SMS but others do | Wrong number, or DND / blocked on their line | Dashboard > Parent alerts: filter by parent and read the failure reason (e.g. `AbsentSubscriber`, `UserInBlacklist`) |
| A bus shows "No GPS" | Driver app closed, phone off, or no signal | Call the driver. The app catches up by itself when signal returns. If it happens daily, check the phone's battery optimisation setting (driver app README). |
| Whole site down | Server down, DNS, or certificate | Check the uptime monitor, then `ssh deploy@server` and `docker compose ... ps`. Caddy renews certificates by itself; `caddy` logs show why if it can't. |
| Something was deleted by mistake | | Dashboard > Activity shows who did what and when. Restore only that data: run `restore.sh drill`, but edit it to keep the scratch database, and copy the rows across. Ask your developer. |
| Data breach suspected | | Rotate secrets (`JWT_ACCESS_SECRET` signs everyone out). Report to ODPC within 72 hours as the Data Protection Act requires. |

## 12. Security checklist (before go-live)
- [ ] `deploy/.env` is mode 600, not in git, and copied to the password manager
- [ ] SSH is key-only and root login is off (server-setup.sh does this once `deploy` has a key)
- [ ] The first admin's temporary password has been changed; each office member has their own account
- [ ] `SMS_DRY_RUN=false`, `BACKUPS_EXPECTED=true`, `NODE_ENV=production` (forced by compose)
- [ ] Off-site backups configured, and one restore drill passed
- [ ] Uptime monitor on `/health/jobs`
- [ ] ODPC registration certificate received; privacy notice text matches what the apps collect
- [ ] Driver phones: school-owned, screen lock on, driver app only
