# How parent alerts work (Phase 4)

```
GPS / driver taps / admin ──► API writes trip_events (same transaction as the change)
monitors (every 60 s) ──────► trip_events (delays) + incidents (office alerts)
                                   │
worker: outbox (every 2 s) ────────┘──► notifications (one row per guardian per channel)
worker: sender (every 2 s) ──► FCM push / Africa's Talking SMS ──► delivery-report webhook
```

## Who gets what
| Event | Recipients | Critical |
|---|---|---|
| Approaching (ETA ≤ stop's minutes, default 5) | Guardians of children at that stop (absences excluded) | |
| Arrived at stop | Same | |
| Arrived at school (morning) | Guardians of children actually on the bus (checked-on children if the driver uses check-on; otherwise everyone whose stop wasn't skipped) | |
| Boarded / got off | That child's guardians | |
| Delay 10 / 20 / 30 min (one alert per level) | Guardians of children still waiting for the bus | |
| Driver-reported delay | Same | |
| Breakdown / accident | Children on the bus or still waiting | ✔ |
| Trip cancelled / no-service day with notify | Everyone on the trip | ✔ |
| Not started, GPS lost, bus stalled | **Office only**: dashboard incident that resolves itself when the condition clears | |

Siblings are merged into one alert per guardian, e.g. "Amina & Baraka got off…".

## Channel rules (per guardian setting)
| Setting | Behaviour |
|---|---|
| `push_then_sms` (default) | Push if the app is installed; SMS if push fails, the token is dead, or there's no app |
| `push` | Push only; SMS only when there's no app installed |
| `sms` | SMS only |
| Critical events | Push **and** SMS, always, even during quiet hours |
| Quiet hours | Routine alerts are recorded as `skipped` (`quiet_hours`) and not sent |

## Reliability
- **At most once.** Each event can occur once per trip, and each guardian gets one message per channel per event. Both are enforced by unique constraints. Replays and restarts can't double-send.
- **Retries.** Send failures retry with backoff (30 s, 1 min, 2 min … up to 10 min): 5 attempts for SMS, 3 for push. Dead FCM tokens are removed.
- **Stale alerts are skipped as `expired`.** Approaching after 10 min, arrived after 15, delay after 20, boarded/got off after 30. Nobody gets "5 min away" half an hour late.
- **Cheap SMS.** Every SMS is GSM-7 and one segment (≤160 characters). Emoji and curly quotes are normalised away, and long names or reasons are shortened. Identical SMS texts are sent in a single Africa's Talking request.
- **Several workers can run safely.** Rows are claimed with `SKIP LOCKED` and monitors use advisory locks.

## Planner & calendar
- **Daily planning.** Each minute, today's trips are created as `scheduled` for every active schedule, so a bus that never starts is noticed. Runs that should already be over are never planned, so restarting the worker mid-day is safe.
- **School calendar.** Mark holidays and closures in `POST /admin/no-service-days`. That cancels any trips already planned for the day, and can optionally alert parents.
- **Not-started trips.** Parents get delay alerts for a trip that hasn't started only during its first 90 minutes. After that it's an office matter (`not_started` incident).
- **Nightly at 02:00 local:** learned stop-to-stop ETA medians, 90-day GPS purge, OTP/refresh-token cleanup. Previous days' trips are also closed silently: never-run trips become "Not run", and forgotten active trips are ended.

## Setup checklist
1. **Africa's Talking:** set the sender ID (`AT_SENDER_ID`, approval required) and `AT_API_KEY`, then set `SMS_DRY_RUN=false`. Register the delivery-report URL with `AT_WEBHOOK_SECRET`.
2. **Firebase:** add the service-account JSON to `FCM_SERVICE_ACCOUNT`. The parent app must create Android notification channels `bus_alerts` and `critical_alerts`.
3. **Run the worker** alongside the API: `npm run worker` (or the `worker` service in docker-compose).
4. **Quick trial:** in the sandbox, use the Africa's Talking simulator to receive test SMS.
