# Database ERD

Key columns only. The full definitions are in `apps/api/db/migrations/`.
This renders on GitHub, or paste it into https://mermaid.live.

```mermaid
erDiagram
  USERS ||--o| GUARDIANS : "is (role=guardian)"
  USERS ||--o| DRIVERS : "is (role=driver)"
  USERS ||--o{ DEVICES : "signs in on"
  USERS ||--o{ REFRESH_TOKENS : has
  GUARDIANS ||--o{ STUDENT_GUARDIANS : "cares for"
  STUDENTS ||--o{ STUDENT_GUARDIANS : "has"
  BUSES ||--o| ROUTES : "default bus"
  DRIVERS ||--o{ ROUTES : "default driver"
  ROUTES ||--o{ SCHEDULES : "runs as"
  SCHEDULES ||--o{ STOPS : "ordered stops"
  STUDENTS ||--o{ STUDENT_STOPS : "boards at"
  STOPS ||--o{ STUDENT_STOPS : ""
  SCHEDULES ||--o{ TRIPS : "one per day"
  BUSES ||--o{ TRIPS : ""
  DRIVERS ||--o{ TRIPS : ""
  TRIPS ||--o{ TRIP_STOP_EVENTS : "progress"
  STOPS ||--o{ TRIP_STOP_EVENTS : ""
  TRIPS ||--o{ STUDENT_TRIP_EVENTS : "check on/off"
  STUDENTS ||--o{ ABSENCES : "not riding"
  TRIPS ||--o{ LOCATION_POINTS : "GPS trail"
  BUSES ||--o| BUS_POSITIONS : "latest position"
  TRIPS ||--o{ TRIP_SEGMENT_TIMES : "leg durations"
  STOPS ||--o{ SEGMENT_STATS : "median leg time"
  GUARDIANS ||--o{ NOTIFICATIONS : receives
  TRIPS ||--o{ NOTIFICATIONS : triggers
  TRIPS ||--o{ INCIDENTS : reported

  USERS {
    uuid id PK
    user_role role
    text full_name
    ke_phone phone UK
    text email UK
  }
  GUARDIANS {
    uuid user_id PK,FK
    channel_mode channel_mode
    text preferred_language
    timestamptz consent_at
  }
  DRIVERS {
    uuid user_id PK,FK
    uuid registered_device_id FK
  }
  STUDENTS {
    uuid id PK
    text admission_no UK
    text full_name
    text class_name
  }
  STUDENT_GUARDIANS {
    uuid student_id PK,FK
    uuid guardian_id PK,FK
    bool is_primary
    bool receives_alerts
  }
  BUSES {
    uuid id PK
    text plate_number UK
    smallint capacity
  }
  ROUTES {
    uuid id PK
    text name UK
    uuid default_bus_id FK
    uuid default_driver_id FK
  }
  SCHEDULES {
    uuid id PK
    uuid route_id FK
    schedule_direction direction
    smallint_array days_of_week
    time start_time
  }
  STOPS {
    uuid id PK
    uuid schedule_id FK
    smallint sequence
    numeric lat
    numeric lng
    smallint radius_m
    smallint approach_minutes
  }
  STUDENT_STOPS {
    uuid student_id PK,FK
    uuid schedule_id PK,FK
    uuid stop_id FK
  }
  TRIPS {
    uuid id PK
    uuid schedule_id FK
    date service_date
    uuid bus_id FK
    uuid driver_id FK
    trip_status status
  }
  TRIP_STOP_EVENTS {
    uuid trip_id PK,FK
    uuid stop_id PK,FK
    stop_event_status status
    timestamptz eta_at
  }
  STUDENT_TRIP_EVENTS {
    bigint id PK
    uuid trip_id FK
    uuid student_id FK
    student_event_status status
  }
  ABSENCES {
    uuid id PK
    uuid student_id FK
    date service_date
    uuid schedule_id FK
  }
  LOCATION_POINTS {
    bigint id PK
    uuid trip_id FK
    timestamptz recorded_at
    numeric lat
    numeric lng
    point_source source
  }
  BUS_POSITIONS {
    uuid bus_id PK,FK
    uuid trip_id FK
    timestamptz recorded_at
  }
  TRIP_SEGMENT_TIMES {
    uuid trip_id PK,FK
    uuid from_stop_id PK,FK
    uuid to_stop_id FK
    int seconds
  }
  SEGMENT_STATS {
    uuid from_stop_id PK,FK
    uuid to_stop_id PK,FK
    smallint hour_bucket PK
    int median_seconds
  }
  NOTIFICATIONS {
    uuid id PK
    text dedupe_key UK
    notification_channel channel UK
    notification_event event_type
    notification_status status
    text provider_message_id
  }
  INCIDENTS {
    uuid id PK
    uuid trip_id FK
    incident_type type
    incident_severity severity
  }
```

Also in the schema but not drawn: `otp_codes`, `app_settings`, `sms_delivery_reports`, `audit_logs`, `ussd_sessions`, and the views `trip_stop_recipients`, `trip_stop_manifest`, `schedule_load`, `active_fleet`.
