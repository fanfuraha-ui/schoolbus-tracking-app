'use strict';

/**
 * Stable per-install id sent at login (the API binds a driver's account to one phone).
 * store: { getItem(key), setItem(key, value) } (e.g. expo-secure-store); randomUUID: () => string
 */
async function getOrCreateDeviceUid(store, randomUUID, key = 'device_uid') {
  const existing = await store.getItem(key);
  if (existing && existing.length >= 8) return existing;
  const id = randomUUID();
  await store.setItem(key, id);
  return id;
}

module.exports = { getOrCreateDeviceUid };
