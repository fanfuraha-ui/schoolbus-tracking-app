'use strict';
/**
 * Small fetch-based API client shared by the driver and parent apps.
 *
 *  - Adds the access token; on 401 refreshes once (single-flight: ten parallel requests
 *    trigger ONE refresh) and retries the request.
 *  - If refresh fails, clears the session and calls onSessionExpired (app shows login).
 *  - Converts every failure into ApiError with a `retryable` flag.
 *  - Times out requests (default 15 s) so a dead mobile connection doesn't hang the UI.
 *
 * tokenStore: { get(): Promise<{accessToken, refreshToken}|null>, set(tokens), clear() }
 */
const { ApiError } = require('./errors');

function createApiClient({ baseUrl, tokenStore, fetchImpl = globalThis.fetch, timeoutMs = 15000, onSessionExpired = () => {} }) {
  const root = baseUrl.replace(/\/+$/, '');
  let refreshing = null;

  function buildUrl(path, query) {
    const url = `${root}${path}`;
    if (!query) return url;
    const qs = Object.entries(query).filter(([, v]) => v !== undefined && v !== null)
      .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(String(v))}`).join('&');
    return qs ? `${url}?${qs}` : url;
  }

  async function rawFetch(method, path, { body, query, token, timeout = timeoutMs, contentType } = {}) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeout);
    const headers = { Accept: 'application/json' };
    if (token) headers.Authorization = `Bearer ${token}`;
    let payload;
    if (body !== undefined) {
      if (typeof body === 'string') { payload = body; headers['Content-Type'] = contentType || 'text/plain'; } else { payload = JSON.stringify(body); headers['Content-Type'] = 'application/json'; }
    }
    let res;
    try {
      res = await fetchImpl(buildUrl(path, query), { method, headers, body: payload, signal: controller.signal });
    } catch (err) {
      const aborted = err && (err.name === 'AbortError' || controller.signal.aborted);
      throw new ApiError({ status: 0, code: aborted ? 'timeout' : 'network_error', message: aborted ? 'The server took too long to respond' : 'No internet connection' });
    } finally {
      clearTimeout(timer);
    }
    const text = await res.text();
    let json = null;
    if (text) { try { json = JSON.parse(text); } catch { json = null; } }
    if (!res.ok) {
      const e = json && json.error ? json.error : {};
      throw new ApiError({ status: res.status, code: e.code, message: e.message, details: e.details ?? (json && json.errors) });
    }
    return json;
  }

  async function refresh() {
    if (!refreshing) {
      refreshing = (async () => {
        const tokens = await tokenStore.get();
        if (!tokens || !tokens.refreshToken) throw new ApiError({ status: 401, code: 'not_signed_in', message: 'Please sign in' });
        try {
          const next = await rawFetch('POST', '/auth/refresh', { body: { refreshToken: tokens.refreshToken } });
          await tokenStore.set({ accessToken: next.accessToken, refreshToken: next.refreshToken });
          return next.accessToken;
        } catch (err) {
          if (err.status === 401) { await tokenStore.clear(); onSessionExpired(err); }
          throw err;
        }
      })().finally(() => { refreshing = null; });
    }
    return refreshing;
  }

  async function request(method, path, opts = {}) {
    const { auth = true } = opts;
    if (!auth) return rawFetch(method, path, opts);
    const tokens = await tokenStore.get();
    if (!tokens) { onSessionExpired(); throw new ApiError({ status: 401, code: 'not_signed_in', message: 'Please sign in' }); }
    try {
      return await rawFetch(method, path, { ...opts, token: tokens.accessToken });
    } catch (err) {
      if (err.status !== 401) throw err;
      const fresh = await refresh();
      return rawFetch(method, path, { ...opts, token: fresh });
    }
  }

  /** Current access token, refreshing if there is none (used for the Socket.IO handshake). */
  async function accessToken() {
    const tokens = await tokenStore.get();
    return tokens ? tokens.accessToken : null;
  }

  return {
    request,
    refresh,
    accessToken,
    get: (path, opts) => request('GET', path, opts),
    post: (path, body, opts) => request('POST', path, { ...opts, body }),
    put: (path, body, opts) => request('PUT', path, { ...opts, body }),
    patch: (path, body, opts) => request('PATCH', path, { ...opts, body }),
    del: (path, opts) => request('DELETE', path, opts),
  };
}

module.exports = { createApiClient };
