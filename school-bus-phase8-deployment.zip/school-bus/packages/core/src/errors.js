'use strict';

/**
 * Error from the school-bus API (or the network). `retryable` tells offline queues whether
 * to keep the request and try again later (network down, timeout, 5xx, 429) or give up.
 */
class ApiError extends Error {
  constructor({ status, code, message, details }) {
    super(message || code || `HTTP ${status}`);
    this.name = 'ApiError';
    this.status = status;
    this.code = code || (status ? `http_${status}` : 'network_error');
    this.details = details;
    this.retryable = status === 0 || status === 408 || status === 429 || status >= 500;
  }
}

const isNetworkError = (err) => err instanceof ApiError && err.status === 0;

module.exports = { ApiError, isNetworkError };
