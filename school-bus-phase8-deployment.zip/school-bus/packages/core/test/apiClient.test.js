'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { createApiClient, ApiError, getOrCreateDeviceUid } = require('../src');

function memoryTokens(initial) {
  let t = initial;
  return { get: async () => t, set: async (v) => { t = v; }, clear: async () => { t = null; }, peek: () => t };
}
const json = (status, body) => ({ ok: status < 400, status, text: async () => (body === undefined ? '' : JSON.stringify(body)) });

test('adds bearer token, query string and JSON body', async () => {
  const calls = [];
  const api = createApiClient({
    baseUrl: 'https://api.example/api/v1/',
    tokenStore: memoryTokens({ accessToken: 'A1', refreshToken: 'R1' }),
    fetchImpl: async (url, init) => { calls.push({ url, init }); return json(200, { ok: true }); },
  });
  await api.post('/driver/trips/t1/incidents', { type: 'traffic' }, { query: { a: 1, b: undefined } });
  assert.equal(calls[0].url, 'https://api.example/api/v1/driver/trips/t1/incidents?a=1');
  assert.equal(calls[0].init.headers.Authorization, 'Bearer A1');
  assert.equal(calls[0].init.body, '{"type":"traffic"}');
});

test('401 triggers ONE refresh for many parallel requests, then retries each', async () => {
  const tokens = memoryTokens({ accessToken: 'old', refreshToken: 'R1' });
  let refreshes = 0;
  const api = createApiClient({
    baseUrl: 'https://x/api/v1', tokenStore: tokens,
    fetchImpl: async (url, init) => {
      if (url.endsWith('/auth/refresh')) { refreshes += 1; await new Promise((r) => setTimeout(r, 10)); return json(200, { accessToken: 'new', refreshToken: 'R2' }); }
      return init.headers.Authorization === 'Bearer new' ? json(200, { url }) : json(401, { error: { code: 'token_invalid' } });
    },
  });
  const results = await Promise.all([1, 2, 3, 4, 5].map((i) => api.get(`/r/${i}`)));
  assert.equal(refreshes, 1);
  assert.equal(results.length, 5);
  assert.deepEqual(tokens.peek(), { accessToken: 'new', refreshToken: 'R2' });
});

test('failed refresh clears the session and reports it', async () => {
  const tokens = memoryTokens({ accessToken: 'old', refreshToken: 'stolen' });
  let expired = 0;
  const api = createApiClient({
    baseUrl: 'https://x', tokenStore: tokens, onSessionExpired: () => { expired += 1; },
    fetchImpl: async (url) => (url.endsWith('/auth/refresh') ? json(401, { error: { code: 'refresh_reused' } }) : json(401, {})),
  });
  await assert.rejects(api.get('/driver/today'), (e) => e.code === 'refresh_reused');
  assert.equal(tokens.peek(), null);
  assert.equal(expired, 1);
});

test('errors are classified: network/timeout/5xx/429 retryable, 4xx not', async () => {
  const mk = (impl, timeoutMs) => createApiClient({ baseUrl: 'https://x', tokenStore: memoryTokens({ accessToken: 'a', refreshToken: 'r' }), fetchImpl: impl, timeoutMs });
  await assert.rejects(mk(async () => { throw new TypeError('Network request failed'); }).get('/a'), (e) => e.code === 'network_error' && e.retryable);
  await assert.rejects(mk((url, init) => new Promise((_, rej) => init.signal.addEventListener('abort', () => rej(Object.assign(new Error('aborted'), { name: 'AbortError' })))), 20).get('/a'),
    (e) => e.code === 'timeout' && e.retryable);
  await assert.rejects(mk(async () => json(503, {})).get('/a'), (e) => e.retryable && e.code === 'http_503');
  await assert.rejects(mk(async () => json(429, { error: { code: 'rate_limited' } })).get('/a'), (e) => e.retryable);
  await assert.rejects(mk(async () => json(409, { error: { code: 'trip_not_active', message: 'This trip is completed' } })).get('/a'),
    (e) => e instanceof ApiError && !e.retryable && e.code === 'trip_not_active' && e.message === 'This trip is completed');
});

test('unauthenticated calls skip the token; no session -> not_signed_in', async () => {
  let auth;
  const api = createApiClient({ baseUrl: 'https://x', tokenStore: memoryTokens(null), fetchImpl: async (u, init) => { auth = init.headers.Authorization; return json(200, { ok: 1 }); } });
  await api.post('/auth/driver/login', { phone: '1' }, { auth: false });
  assert.equal(auth, undefined);
  await assert.rejects(api.get('/driver/today'), { code: 'not_signed_in' });
});

test('device uid is created once and reused', async () => {
  const m = new Map();
  const store = { getItem: async (k) => m.get(k) ?? null, setItem: async (k, v) => { m.set(k, v); } };
  let n = 0;
  const gen = () => `uuid-000000-${(n += 1)}`;
  const a = await getOrCreateDeviceUid(store, gen);
  const b = await getOrCreateDeviceUid(store, gen);
  assert.equal(a, b);
  assert.equal(n, 1);
});
