#!/bin/sh
# Creates deploy/.env from .env.production.example with fresh random secrets.
# Refuses to overwrite an existing deploy/.env (losing POSTGRES_PASSWORD locks you out of the data).
set -eu
DEPLOY="$(cd "$(dirname "$0")/.." && pwd)"
out="$DEPLOY/.env"
[ -e "$out" ] && { echo "gen-secrets: $out already exists, not touching it" >&2; exit 1; }
command -v openssl >/dev/null || { echo "gen-secrets: needs openssl" >&2; exit 1; }
umask 077
tmp="$(mktemp)"
cp "$DEPLOY/.env.production.example" "$tmp"
for key in POSTGRES_PASSWORD JWT_ACCESS_SECRET OTP_PEPPER AT_WEBHOOK_SECRET; do
  value="$(openssl rand -hex 32)"
  sed -i "s|^$key=__generated__|$key=$value|" "$tmp"
done
mv "$tmp" "$out"
chmod 600 "$out"
echo "gen-secrets: wrote $out (mode 600). Now edit DOMAIN, ACME_EMAIL, CORS_ORIGINS and the Africa's Talking / Firebase values."
echo "gen-secrets: keep a copy of this file in the school's password manager. Losing it means new secrets and everyone signing in again."
