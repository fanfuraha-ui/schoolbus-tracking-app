#!/bin/sh
# Restore a backup.
#
#   deploy/scripts/restore.sh drill [file]     Restore into a scratch database, show what's in it, drop it.
#                                              Safe at any time. Do this once a term: an untested backup
#                                              is a hope, not a backup.
#   deploy/scripts/restore.sh replace <file>   Replace the LIVE database with <file>. Takes a safety backup
#                                              first, stops the API and worker, restores, runs any newer
#                                              migrations, starts them again. Asks you to type REPLACE.
#
# [file] defaults to the newest daily backup in BACKUP_DIR (/var/backups/schoolbus).
# Run from the server, in the repository checkout.
set -eu

ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
COMPOSE="${COMPOSE:-docker compose -f $ROOT/deploy/docker-compose.prod.yml}"
DBX="${DBX-$COMPOSE exec -T db}"          # prefix for psql / pg_restore beside the database
BACKUP_DIR="${BACKUP_DIR:-/var/backups/schoolbus}"
DB="${RESTORE_DB:-schoolbus}"
DBUSER="${RESTORE_USER:-schoolbus}"

say() { echo "restore: $*"; }
die() { echo "restore: $*" >&2; exit 1; }
sql() { $DBX env PGOPTIONS="-c client_min_messages=warning" psql -X -q -v ON_ERROR_STOP=1 -U "$DBUSER" "$@"; }

latest() { ls -1t "$BACKUP_DIR"/daily/schoolbus-*.dump 2>/dev/null | head -n 1; }

check() { # check <database>: the numbers a person can sanity-check against what they know
  sql -d "$1" -At -F ' | ' -c "
    SELECT 'students ' || (SELECT count(*) FROM students WHERE is_active),
           'parents '  || (SELECT count(*) FROM guardians),
           'trips '    || (SELECT count(*) FROM trips),
           'last trip ' || COALESCE((SELECT max(service_date)::text FROM trips), 'none')"
}

mode="${1:-}"
file="${2:-$(latest)}"
[ -n "$file" ] || die "no backup file given and none found in $BACKUP_DIR/daily"
[ -r "$file" ] || die "cannot read $file"

case "$mode" in
  drill)
    scratch="restore_drill"
    say "restoring $(basename "$file") into scratch database '$scratch'"
    sql -d postgres -c "DROP DATABASE IF EXISTS $scratch WITH (FORCE)" -c "CREATE DATABASE $scratch"
    $DBX pg_restore -U "$DBUSER" -d "$scratch" --no-owner --exit-on-error < "$file" \
      || { sql -d postgres -c "DROP DATABASE IF EXISTS $scratch"; die "restore FAILED: this backup is not usable"; }
    contents="$(check "$scratch")" || die "restored, but the data can't be read: this backup is not usable"
    say "restored OK. Contents: $contents"
    sql -d postgres -c "DROP DATABASE $scratch"
    say "scratch database removed. Drill passed."
    ;;

  replace)
    [ -n "${2:-}" ] || die "replace needs an explicit file (it overwrites the live data)"
    say "this REPLACES the live database '$DB' with $(basename "$file")."
    say "everything recorded after that backup was taken will be lost."
    if [ "${FORCE:-}" != "1" ]; then
      printf 'restore: type REPLACE to continue: '; read -r answer
      [ "$answer" = "REPLACE" ] || die "cancelled"
    fi
    if [ "${SAFETY_BACKUP:-1}" = "1" ]; then
      say "taking a safety backup of the current data first"
      $COMPOSE exec -T backup backup.sh || die "safety backup failed; nothing was changed"
    fi
    say "stopping API and worker"
    $COMPOSE stop api worker
    sql -d postgres -c "DROP DATABASE IF EXISTS $DB WITH (FORCE)" -c "CREATE DATABASE $DB OWNER $DBUSER"
    $DBX pg_restore -U "$DBUSER" -d "$DB" --no-owner --exit-on-error < "$file" || die "restore FAILED. The database is incomplete: restore the safety backup the same way."
    contents="$(check "$DB")" || die "restored, but the data can't be read. Restore the safety backup the same way."
    say "restored. Contents: $contents"
    say "applying any newer migrations and starting API + worker"
    $COMPOSE up -d migrate api worker
    say "done. Check the dashboard, then tell drivers to reopen their apps."
    ;;

  *)
    sed -n '2,13p' "$0"; exit 2 ;;
esac
