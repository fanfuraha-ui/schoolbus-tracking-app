#!/bin/sh
# Deploy or update on the server (run as the deploy user, from anywhere):
#   deploy/scripts/deploy.sh            pull main, build, migrate, restart changed services, health check
#   deploy/scripts/deploy.sh --no-pull  deploy what is checked out (e.g. after switching to a tag)
#
# Rolling back: git checkout <previous tag or commit> && deploy/scripts/deploy.sh --no-pull
# (migrations are forward-only and additive, so older code runs on a newer schema).
set -eu
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT"
COMPOSE="docker compose -f deploy/docker-compose.prod.yml"

[ -f deploy/.env ] || { echo "deploy: deploy/.env is missing. Run deploy/scripts/gen-secrets.sh first." >&2; exit 1; }
if grep -q '__generated__' deploy/.env; then echo "deploy: deploy/.env still has __generated__ placeholders" >&2; exit 1; fi

# Restarting the API mid-run is survivable (driver apps buffer GPS offline), but parents see a gap
# and alerts pause for a minute. Don't do it while buses are out unless you mean to.
if $COMPOSE ps --status running db 2>/dev/null | grep -q db; then
  active="$($COMPOSE exec -T db psql -U schoolbus -d schoolbus -Atc "SELECT count(*) FROM trips WHERE status = 'active'" 2>/dev/null || echo 0)"
  if [ "${active:-0}" -gt 0 ] && [ "${FORCE:-}" != "1" ]; then
    echo "deploy: $active bus(es) on the road right now. Deploy after the run, or FORCE=1 $0 $*" >&2
    exit 1
  fi
fi

if [ "${1:-}" != "--no-pull" ]; then
  git fetch --quiet origin
  git merge --ff-only origin/main
fi
echo "deploy: $(git log -1 --format='%h %s')"

$COMPOSE build --pull
$COMPOSE up -d --remove-orphans          # migrate runs first; api/worker wait for it to succeed

echo "deploy: waiting for the API"
i=0
until $COMPOSE exec -T api wget -qO- http://127.0.0.1:4000/health >/dev/null 2>&1; do
  i=$((i + 1))
  if [ "$i" -ge 30 ]; then
    echo "deploy: API not healthy after 60 s. Recent logs:" >&2
    $COMPOSE logs --tail 50 migrate api >&2
    exit 1
  fi
  sleep 2
done
echo "deploy: API healthy"

# The worker writes its heartbeat once a minute; give it a moment, then show the full picture.
sleep 65
$COMPOSE exec -T api wget -qO- http://127.0.0.1:4000/health/jobs || true
echo
docker image prune -f >/dev/null
echo "deploy: done. https://$(grep '^DOMAIN=' deploy/.env | cut -d= -f2 | cut -d' ' -f1)/"
