#!/bin/sh
# One-time setup of a fresh Ubuntu 24.04 LTS server. Run as root:
#   curl -fsSL https://raw.githubusercontent.com/<you>/<repo>/main/deploy/scripts/server-setup.sh -o setup.sh
#   less setup.sh        # read it first
#   sh setup.sh
#
# Does: updates + automatic security updates, Docker, a 'deploy' user (SSH key only, in the docker
# group), firewall (SSH, 80, 443 only), fail2ban, swap, Nairobi time zone, Docker log rotation,
# the backup folder. Safe to run twice.
set -eu
[ "$(id -u)" = "0" ] || { echo "run as root" >&2; exit 1; }
. /etc/os-release
[ "${ID:-}" = "ubuntu" ] || echo "WARNING: written for Ubuntu 24.04; this is ${PRETTY_NAME:-unknown}"

export DEBIAN_FRONTEND=noninteractive
apt-get update -q
apt-get upgrade -yq
apt-get install -yq ca-certificates curl git ufw fail2ban unattended-upgrades openssl
dpkg-reconfigure -f noninteractive unattended-upgrades

timedatectl set-timezone Africa/Nairobi

# Docker Engine + compose plugin from Docker's own repository.
if ! command -v docker >/dev/null; then
  install -m 0755 -d /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
  chmod a+r /etc/apt/keyrings/docker.asc
  echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu ${VERSION_CODENAME} stable" \
    > /etc/apt/sources.list.d/docker.list
  apt-get update -q
  apt-get install -yq docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
fi
mkdir -p /etc/docker
[ -f /etc/docker/daemon.json ] || echo '{ "log-driver": "json-file", "log-opts": { "max-size": "10m", "max-file": "5" } }' > /etc/docker/daemon.json
systemctl enable --now docker
systemctl restart docker

# deploy user: SSH key login only, can run docker.
if ! id deploy >/dev/null 2>&1; then
  adduser --disabled-password --gecos "" deploy
fi
usermod -aG docker deploy
install -d -m 700 -o deploy -g deploy /home/deploy/.ssh
if [ -f /root/.ssh/authorized_keys ] && [ ! -s /home/deploy/.ssh/authorized_keys ]; then
  install -m 600 -o deploy -g deploy /root/.ssh/authorized_keys /home/deploy/.ssh/authorized_keys
fi

# SSH: keys only, no root login. Only applied if deploy has a key, so you can't lock yourself out.
if [ -s /home/deploy/.ssh/authorized_keys ]; then
  cat > /etc/ssh/sshd_config.d/90-schoolbus.conf <<'CONF'
PasswordAuthentication no
KbdInteractiveAuthentication no
PermitRootLogin no
CONF
  systemctl reload ssh || systemctl reload sshd || true
else
  echo "NOTE: /home/deploy/.ssh/authorized_keys is empty: add your public key, then re-run to lock SSH down."
fi

# Firewall. Docker publishes only 80/443 (Postgres is internal), so these rules are the whole surface.
ufw default deny incoming
ufw default allow outgoing
ufw allow OpenSSH
ufw allow 80/tcp
ufw allow 443/tcp
ufw allow 443/udp
ufw --force enable
systemctl enable --now fail2ban

# 2 GB swap on small servers (helps the dashboard build on a 2 GB machine).
if ! swapon --show | grep -q .; then
  fallocate -l 2G /swapfile && chmod 600 /swapfile && mkswap /swapfile && swapon /swapfile
  grep -q '^/swapfile' /etc/fstab || echo '/swapfile none swap sw 0 0' >> /etc/fstab
fi

install -d -m 750 -o deploy -g deploy /var/backups/schoolbus
install -d -m 755 -o deploy -g deploy /opt/schoolbus

echo
echo "Server ready. Next, as deploy:"
echo "  ssh deploy@<server>"
echo "  git clone <your repo URL> /opt/schoolbus && cd /opt/schoolbus"
echo "  deploy/scripts/gen-secrets.sh && nano deploy/.env"
echo "  deploy/scripts/deploy.sh"
