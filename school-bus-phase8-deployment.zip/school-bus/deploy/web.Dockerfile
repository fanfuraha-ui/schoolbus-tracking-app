# Caddy serving the admin dashboard and proxying the API. Build context: repository root.
FROM node:22-alpine AS build
WORKDIR /app
COPY package.json package-lock.json* ./
COPY apps/api/package.json apps/api/
COPY apps/admin/package.json apps/admin/
COPY apps/driver/package.json apps/driver/
COPY apps/parent/package.json apps/parent/
COPY packages/core/package.json packages/core/
RUN if [ -f package-lock.json ]; then npm ci -w apps/admin --no-audit --no-fund; \
    else npm install -w apps/admin --no-audit --no-fund; fi
COPY packages/core packages/core
COPY apps/admin apps/admin
# Empty = same origin as the dashboard (the single-domain setup). Map tiles are optional.
ARG VITE_API_ORIGIN=""
ARG VITE_MAP_TILES=""
ARG VITE_MAP_ATTRIBUTION=""
RUN npm run build -w apps/admin

FROM caddy:2-alpine
COPY deploy/Caddyfile /etc/caddy/Caddyfile
COPY --from=build /app/apps/admin/dist /srv/admin
