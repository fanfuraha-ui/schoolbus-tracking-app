# deploy/

Production stack for one school on one server. **The full guide is `docs/deployment.md`.**

| File | What |
|---|---|
| `docker-compose.prod.yml` | db, migrate (one-shot), api, worker, caddy (HTTPS + dashboard), backup |
| `Caddyfile` | One domain: dashboard at `/`, API at `/api`, live updates at `/socket.io`, webhooks, health |
| `api.Dockerfile`, `web.Dockerfile` | Images (build context: repo root) |
| `backup/` | Nightly `pg_dump` at 02:30: verified, rotated (14 daily, 8 weekly), optional encrypted off-site copy with rclone, result recorded for the dashboard |
| `.env.production.example` | Every setting, explained. `scripts/gen-secrets.sh` turns it into `deploy/.env` |
| `scripts/server-setup.sh` | Fresh Ubuntu 24.04: Docker, firewall, deploy user, SSH hardening, swap |
| `scripts/deploy.sh` | Pull, build, migrate, restart, health check. Refuses while buses are on the road |
| `scripts/restore.sh` | `drill` (safe test restore) and `replace` (real restore with a safety backup first) |

```bash
deploy/scripts/gen-secrets.sh && nano deploy/.env
deploy/scripts/deploy.sh
docker compose -f deploy/docker-compose.prod.yml exec api node db/scripts/create-admin.js "Name" email@school.ac.ke
```
