#!/bin/sh
# One backup run:
#   1. pg_dump (custom format, compressed) to /backups/daily, written to .part then renamed
#   2. verified: pg_restore --list must read the whole archive
#   3. Sundays: also kept in /backups/weekly
#   4. rotation: KEEP_DAILY newest dailies, KEEP_WEEKLY newest weeklies
#   5. off-site (if RCLONE_REMOTE is set): new files copied, remote files older than OFFSITE_KEEP_DAYS removed
#   6. result written to job_runs ('backup'), which the dashboard and /health/jobs read
# Connection comes from the standard PGHOST / PGUSER / PGPASSWORD / PGDATABASE variables.
set -eu

DIR="${BACKUP_DIR:-/backups}"
KEEP_DAILY="${KEEP_DAILY:-14}"
KEEP_WEEKLY="${KEEP_WEEKLY:-8}"
OFFSITE_KEEP_DAYS="${OFFSITE_KEEP_DAYS:-90}"
RCLONE_REMOTE="${RCLONE_REMOTE:-}"
DB="${PGDATABASE:-schoolbus}"

log() { echo "$(date '+%Y-%m-%d %H:%M:%S') backup: $*"; }

# job_runs upsert. The JSON goes in as a psql variable, so quotes in error text can't break the SQL.
record() {
  printf '%s\n' "INSERT INTO job_runs (name, last_run_at, last_result) VALUES ('backup', now(), :'result'::jsonb)
    ON CONFLICT (name) DO UPDATE SET last_run_at = now(), last_result = EXCLUDED.last_result;" \
    | psql -X -q -v ON_ERROR_STOP=1 -v result="$1" -d "$DB" >/dev/null \
    || log "WARNING: could not record the result in job_runs"
}
json_str() { printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n\r\t' '   '; }

fail() {
  log "FAILED: $1"
  record "{\"status\":\"failed\",\"error\":\"$(json_str "$1")\"}"
  exit 1
}

mkdir -p "$DIR/daily" "$DIR/weekly" 2>/dev/null && [ -w "$DIR/daily" ] || fail "backup folder $DIR is not writable (disk full or volume not mounted?)"
stamp="$(date +%Y-%m-%d_%H%M%S)"
name="schoolbus-$stamp.dump"
file="$DIR/daily/$name"

log "dumping $DB to $file"
pg_dump -Fc -Z 6 --no-owner -d "$DB" -f "$file.part" 2>/tmp/pg_dump.err || fail "pg_dump: $(tail -n 3 /tmp/pg_dump.err)"
pg_restore --list "$file.part" >/dev/null 2>/tmp/pg_restore.err || fail "archive unreadable: $(tail -n 3 /tmp/pg_restore.err)"
mv "$file.part" "$file"
bytes="$(wc -c < "$file" | tr -d ' ')"
log "ok, $bytes bytes"

if [ "$(date +%u)" = "7" ]; then
  cp "$file" "$DIR/weekly/$name"
  log "kept as this week's copy"
fi

prune() { # prune <dir> <keep>
  ls -1t "$1"/schoolbus-*.dump 2>/dev/null | tail -n +"$(( $2 + 1 ))" | while read -r old; do
    rm -f "$old"; log "removed old $(basename "$old")"
  done
}
prune "$DIR/daily" "$KEEP_DAILY"
prune "$DIR/weekly" "$KEEP_WEEKLY"
rm -f "$DIR"/daily/*.part

offsite="null"
if [ -n "$RCLONE_REMOTE" ]; then
  # copy, not sync: a wiped or compromised server can't delete the off-site history.
  if rclone copy "$DIR" "$RCLONE_REMOTE" --include 'daily/*.dump' --include 'weekly/*.dump' --quiet \
     && rclone delete "$RCLONE_REMOTE" --min-age "${OFFSITE_KEEP_DAYS}d" --include '*.dump' --quiet; then
    offsite="true"; log "copied off-site to $RCLONE_REMOTE"
  else
    offsite="false"; log "WARNING: off-site copy failed (local backup is fine)"
  fi
fi

record "{\"status\":\"ok\",\"file\":\"$name\",\"bytes\":$bytes,\"offsite\":$offsite}"
log "done"
