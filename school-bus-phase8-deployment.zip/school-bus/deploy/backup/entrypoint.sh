#!/bin/sh
# Runs backup.sh on BACKUP_SCHEDULE (cron syntax, container time zone = TZ) with busybox crond.
#   docker compose exec backup backup.sh     # take a backup right now
set -eu
SCHEDULE="${BACKUP_SCHEDULE:-30 2 * * *}"
mkdir -p /etc/crontabs
# crond starts jobs with an empty environment: hand the settings over explicitly.
env | grep -E '^(PG|TZ=|KEEP_|RCLONE_|OFFSITE_|BACKUP_DIR=)' | sed 's/^/export /; s/=\(.*\)$/="\1"/' > /etc/backup.env
echo "$SCHEDULE . /etc/backup.env; /usr/local/bin/backup.sh > /proc/1/fd/1 2>&1" > /etc/crontabs/root
echo "backup: scheduled '$SCHEDULE' ($TZ). Backups in /backups; off-site: ${RCLONE_REMOTE:-not configured}"
exec crond -f -l 8
