# API + worker image (same code, different command). Build context: repository root.
FROM node:22-alpine
WORKDIR /app
ENV NODE_ENV=production
# Workspace manifests first so the dependency layer is cached between code-only deploys.
# npm ci needs every workspace's package.json to match the root lockfile.
COPY package.json package-lock.json* ./
COPY apps/api/package.json apps/api/
COPY apps/admin/package.json apps/admin/
COPY apps/driver/package.json apps/driver/
COPY apps/parent/package.json apps/parent/
COPY packages/core/package.json packages/core/
RUN if [ -f package-lock.json ]; then npm ci -w apps/api --omit=dev --no-audit --no-fund; \
    else npm install -w apps/api --omit=dev --no-audit --no-fund; fi \
 && npm cache clean --force
COPY apps/api/src apps/api/src
COPY apps/api/db apps/api/db
WORKDIR /app/apps/api
USER node
EXPOSE 4000
HEALTHCHECK --interval=15s --timeout=5s --start-period=20s CMD wget -qO- http://127.0.0.1:4000/health || exit 1
CMD ["sh", "-c", "node db/migrate.js && node src/server.js"]
