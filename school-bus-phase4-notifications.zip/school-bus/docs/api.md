# API reference (v1)

Base URL: `https://<host>/api/v1`. All bodies are JSON unless noted. Times are ISO 8601 UTC; dates are `YYYY-MM-DD` in Africa/Nairobi.

**Auth:** send `Authorization: Bearer <accessToken>`. Access tokens last 15 minutes. When one expires, call `POST /auth/refresh` with the refresh token, which rotates (every call returns a new one). If an old refresh token is replayed, every session for that user is ended.

**Errors:**
```json
{ "error": { "code": "validation_failed", "message": "Some fields are missing or invalid",
             "details": [{ "field": "body.pin", "message": "PIN is 4 digits" }] } }
```
| Status | Common codes |
|---|---|
| 400 | `validation_failed`, `invalid_phone`, `invalid_value`, `constraint_failed` |
| 401 | `unauthorized`, `token_invalid`, `invalid_credentials`, `otp_invalid`, `refresh_invalid`, `refresh_reused` |
| 403 | `forbidden`, `device_not_registered`, `not_your_trip`, `not_your_route`, `not_your_child` |
| 404 | `not_found`, `route_not_found` |
| 409 | `already_exists`, `reference_error`, `trip_not_active`, `bus_busy`, `driver_busy`, `trip_already_finished`, `phone_in_use` |
| 422 | CSV import with row errors (body lists them) |
| 429 | `rate_limited`, `account_locked`, `otp_rate_limited`, `otp_attempts_exceeded` |

`device` object (all logins): `{ "deviceUid": "stable-install-id", "platform": "android|ios|web", "fcmToken"?: "...", "appVersion"?: "1.0.0" }`

---

## Auth — `/auth`
| Method | Path | Body | Returns |
|---|---|---|---|
| POST | `/admin/login` | `{ email, password, device }` | `{ accessToken, refreshToken, user }` |
| POST | `/driver/login` | `{ phone, pin (4 digits), device }` | same. First login binds the phone; other phones get 403 until an admin resets it |
| POST | `/otp/request` | `{ phone }` | `202 { sent: true, expiresInSeconds: 300 }`. The response is identical for unregistered numbers. Max 3 per 15 min |
| POST | `/otp/verify` | `{ phone, code (6 digits), device }` | `{ accessToken, refreshToken, user, consentRequired }` |
| POST | `/refresh` | `{ refreshToken }` | new token pair |
| POST | `/logout` | `{ refreshToken }` | `{ ok: true }` |

Lockouts: 5 wrong passwords/PINs lock the account for 15 minutes. 5 wrong OTPs invalidate the code.

## Driver — `/driver` (role: driver)
| Method | Path | Body | Notes |
|---|---|---|---|
| GET | `/today` | – | Today's schedules for this driver with `tripStatus` (`not_started`, `active`, …) |
| POST | `/schedules/:scheduleId/start` | – | `201` new / `200` already running. Returns `{ created, trip }` (trip detail below) |
| GET | `/trips/:tripId` | – | Trip + ordered `stops[]` (status, etaAt, expected/absent counts, `canSkip`, `riders[]`) |
| POST | `/trips/:tripId/locations` | `{ points: [GpsPoint] }` (≤500) | **Backlog upload** after being offline. Returns `{ accepted, duplicates, rejected, processed, eventsCreated }`. Safe to resend |
| POST | `/trips/:tripId/stops/:stopId` | `{ action: arrived\|departed\|skipped, reason? }` | Manual override buttons |
| POST | `/trips/:tripId/students/:studentId` | `{ status: boarded\|dropped_off\|absent\|no_show, stopId? }` | Check-on / check-off. Repeats return `duplicate: true` |
| POST | `/trips/:tripId/incidents` | `{ type, severity?, note?, lat?, lng?, notifyParents? }` | `breakdown`/`accident`/`critical` always alert parents (SMS + push). Otherwise `notifyParents: true` sends one delay alert |
| POST | `/trips/:tripId/end` | – | Completes the trip, records distance, and stops sharing location |
| POST | `/trips/:tripId/cancel` | `{ reason }` | Critical alert to all parents on the trip |
| PUT | `/device` | `device` | Update the FCM token |

`GpsPoint`: `{ lat, lng, recordedAt (ISO or epoch ms), speedMps?, headingDeg?, accuracyM? }`

Server rules for points:
- Points more than 60 s in the future, or more than 5 min before the trip started, are rejected.
- Duplicate timestamps are ignored.
- Points worse than 100 m accuracy are stored but don't move the trip forward.
- Points more than 120 s old update progress silently and never trigger alerts.

## Parent — `/parent` (role: guardian)
| Method | Path | Body | Notes |
|---|---|---|---|
| GET | `/me` | – | Profile + `children[]` each with `today[]` rides: stop, scheduled time, trip status, ETA, absent flag |
| PATCH | `/preferences` | `{ channelMode?: push\|sms\|push_then_sms, preferredLanguage?: en\|sw, quietHours?: {start,end}\|null }` | |
| POST | `/consent` | `{ version }` | Data-protection consent (needed when `consentRequired` was true) |
| PUT | `/device` | `device` | Register/refresh the FCM token |
| GET | `/trips/:tripId` | – | `{ trip, bus (null unless active), stops[], myStops[] }`. Shows only the parent's own children |
| GET | `/absences` | – | Upcoming absences |
| POST | `/absences` | `{ studentId, date, scheduleId?, reason? }` | Leave out `scheduleId` to cover the whole day. Allowed from today up to 60 days ahead |
| DELETE | `/absences/:id` | – | |
| GET | `/notifications?limit=50` | – | Alert history |

## Admin — `/admin` (role: admin)
Standard resources support `GET /x` (list: `limit`, `offset`, filters), `GET /x/:id`, `POST /x`, `PATCH /x/:id`, `DELETE /x/:id`. DELETE deactivates buses, routes, schedules and students, and hard-deletes stops. All writes are audited.

| Resource | Filters | Create fields |
|---|---|---|
| `/buses` | `search`, `isActive` | `plateNumber`, `capacity` (default 33) |
| `/routes` | `search`, `isActive` | `name`, `description`, `defaultBusId`, `defaultDriverId` |
| `/schedules` | `routeId`, `isActive` | `routeId`, `name`, `direction` (`to_school`/`from_school`), `daysOfWeek` (1=Mon), `startTime` |
| `/stops` | `scheduleId`, `isActive` | `scheduleId`, `name`, `lat`, `lng`, `sequence?` (default: last), `radiusM?`, `approachMinutes?`, `scheduledTime?`, `landmark?`, `isSchool?` |
| `/students` | `search`, `isActive`, `className` | `admissionNo`, `fullName`, `className?`, `notes?`. `GET /students/:id` includes guardians + stops |

| Method | Path | Body |
|---|---|---|
| PUT | `/schedules/:id/stop-order` | `{ stopIds: [...] }`: every stop, in the new order |
| PUT | `/students/:id/guardians` | `{ guardianId, relationship?, isPrimary?, receivesAlerts? }` |
| DELETE | `/students/:id/guardians/:guardianId` | |
| PUT | `/students/:id/stops` | `{ scheduleId, stopId }` |
| DELETE | `/students/:id/stops/:scheduleId` | |
| POST | `/import/students?dryRun=true` | CSV body (`Content-Type: text/csv`). `200` summary or `422 { errors: [{line, field, message}] }`. Nothing is written if any row fails |
| GET/POST/PATCH | `/guardians`, `/guardians/:id` | `{ fullName, phone, channelMode?, preferredLanguage? }`; PATCH also `isActive` (deactivating ends their sessions) |
| GET/POST/PATCH | `/drivers`, `/drivers/:id` | `{ fullName, phone, pin, licenceNumber? }` |
| POST | `/drivers/:id/reset-pin` | `{ pin }` |
| POST | `/drivers/:id/reset-device` | lets the driver sign in on a new phone |
| POST | `/admins` | `{ fullName, email, password (≥10) }` |
| GET | `/trips?date=YYYY-MM-DD` | the day's trips with progress |
| POST | `/trips` | `{ scheduleId, serviceDate, busId?, driverId? }`: pre-create a trip, e.g. to swap the bus or driver for a day |
| GET | `/trips/:id` | full trip detail |
| POST | `/trips/:id/cancel` | `{ reason }` |
| GET | `/fleet` | buses on active trips with their latest position |
| GET | `/schedule-load` | seats assigned vs capacity |
| GET | `/notifications?tripId&status` | delivery log |
| GET | `/incidents?open=true`, POST `/incidents/:id/resolve` | |
| GET | `/audit-logs?entity&entityId` | |
| GET / PATCH | `/settings` | e.g. `{ "default_approach_minutes": 7, "delay_escalation_minutes": [10, 20, 30] }` |

CSV columns for `/import/students`: `admission_no*, student_name*, class_name, guardian_name*, guardian_phone*, relationship, guardian2_name, guardian2_phone, guardian2_relationship, route, am_stop, pm_stop` (* = required). Stops are matched by name within the route's morning and afternoon schedules.

---

## Realtime (Socket.IO)
Connect: `io("https://<host>", { auth: { token: accessToken } })`. Invalid or expired tokens are refused with `unauthorized`. When that happens, refresh the token and reconnect.

| Who | Emit | Ack / receive |
|---|---|---|
| Driver | `location` `{ tripId, points: [GpsPoint] }` (≤100, ~every 5 s) | ack `{ ok: true, accepted, duplicates, rejected, processed }` or `{ ok: false, error }`. **Delete buffered points only after `ok: true`.** Rate limit: bursts of 5, then 1 per second |
| Parent | `trip:watch` `{ tripId }` | ack `{ ok, view }` (same as `GET /parent/trips/:id`), then receives events below. Refused unless the trip is active and carries their child |
| Parent | `trip:unwatch` `{ tripId }` | |
| Admin | (auto-joined to fleet) | all fleet events; may also `trip:watch` any trip |

Server events:

| Event | Payload | Sent to |
|---|---|---|
| `bus:location` | `{ tripId, busId, lat, lng, speedMps, headingDeg, recordedAt }` | trip room + fleet |
| `trip:stops` | `{ tripId, stops: [{ stopId, status, etaAt, arrivedAt, departedAt }] }` (changed stops only) | trip room + fleet |
| `trip:started` | `{ tripId, routeName, scheduleName, plateNumber }` | fleet |
| `trip:ended` | `{ tripId, status: completed\|cancelled, reason? }` (room is then closed) | trip room + fleet |
| `incident:new` | incident row | fleet |

## Alerts (handled by the Phase 4 worker)
The API never sends alerts directly. It writes them to the `trip_events` table in the same transaction as the trip change:

`approaching` · `arrived` · `boarded` · `dropped_off` · `delay` · `breakdown` (critical) · `trip_cancelled` (critical)

Each event happens at most once per trip/stop/student. The worker turns each event into push and/or SMS messages for the right guardians.

---

## Phase 4 additions

### Admin
| Method | Path | Body / query | Notes |
|---|---|---|---|
| GET | `/admin/notifications/summary?date=` | | Counts by channel/status and SMS cost (KES) for the day |
| POST | `/admin/notifications/:id/retry` | | Re-queue a failed notification |
| PATCH | `/admin/trips/:id` | `{ busId?, driverId? }` | Swap bus/driver on a trip that hasn't started |
| GET | `/admin/no-service-days?from=` | | Upcoming holidays/closures |
| POST | `/admin/no-service-days` | `{ date, reason, notifyParents? }` | Cancels trips already planned for that day. `notifyParents` sends the cancellation alert |
| DELETE | `/admin/no-service-days/:date` | | |

### Webhook
`POST /webhooks/africastalking/delivery/<AT_WEBHOOK_SECRET>` (form-encoded, from Africa's Talking).
- `Success` sets the SMS to `delivered`.
- `Sent`, `Buffered` and `Submitted` leave it unchanged.
- Any other status sets it to `failed`, with the carrier's reason.

### Extra admin socket events (from the worker via Postgres NOTIFY)
| Event | When |
|---|---|
| `incident:new` | The worker auto-detects `not_started`, `gps_lost` or `stalled` |
| `incident:resolved` | That condition cleared by itself |
| `trip:delay` | A delay escalation level was reached `{ tripId, delayMinutes, level }` |
