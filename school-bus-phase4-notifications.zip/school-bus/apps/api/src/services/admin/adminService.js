'use strict';
/**
 * Admin operations that span more than one table (people, assignments, ordering)
 * plus read models for the dashboard.
 */
const { createCrud, RESOURCES } = require('./crud');
const { normalizeKenyanPhone } = require('../../domain/phone');
const { badRequest, notFound, conflict } = require('../../lib/errors');
const { writeAudit, diff } = require('../audit');

function createAdminService({ db, hasher, settings }) {
  const crud = Object.fromEntries(
    Object.entries(RESOURCES).map(([name, cfg]) => [name, createCrud({ db, ...cfg })]),
  );

  const phoneOrThrow = (phone) => {
    const p = normalizeKenyanPhone(phone);
    if (!p) throw badRequest('invalid_phone', 'Enter a valid Kenyan mobile number');
    return p;
  };

  const phoneTaken = (err) => err && err.code === '23505' && err.constraint === 'users_phone_key';

  // ---------- stops ----------
  async function createStop(data, ctx) {
    let { sequence } = data;
    if (sequence == null) {
      const next = await db.one('SELECT COALESCE(max(sequence), 0) + 1 AS n FROM stops WHERE schedule_id = $1', [data.scheduleId]);
      sequence = next.n;
    }
    const defaults = await settings.all();
    return crud.stops.create({
      radiusM: Number(defaults.default_stop_radius_m ?? 120),
      approachMinutes: Number(defaults.default_approach_minutes ?? 5),
      ...data,
      sequence,
    }, ctx);
  }

  async function reorderStops(scheduleId, stopIds, ctx) {
    return db.tx(async (t) => {
      const existing = await t.many('SELECT id FROM stops WHERE schedule_id = $1 FOR UPDATE', [scheduleId]);
      const have = new Set(existing.map((r) => r.id));
      if (existing.length !== stopIds.length || stopIds.some((id) => !have.has(id)) || new Set(stopIds).size !== stopIds.length) {
        throw badRequest('stop_list_mismatch', 'Send every stop of this schedule exactly once, in the new order');
      }
      await t.query('SET CONSTRAINTS stops_schedule_sequence_uq DEFERRED');
      await t.query(
        `UPDATE stops s SET sequence = x.seq
         FROM jsonb_to_recordset($2::jsonb) AS x(id uuid, seq smallint)
         WHERE s.id = x.id AND s.schedule_id = $1`,
        [scheduleId, JSON.stringify(stopIds.map((id, i) => ({ id, seq: i + 1 })))],
      );
      await t.query('SET CONSTRAINTS stops_schedule_sequence_uq IMMEDIATE');
      await writeAudit(t, { ...ctx, action: 'route.reorder_stops', entity: 'schedules', entityId: scheduleId, changes: { order: [null, stopIds] } });
      return t.many('SELECT id, sequence, name FROM stops WHERE schedule_id = $1 ORDER BY sequence', [scheduleId]);
    });
  }

  // ---------- guardians ----------
  async function listGuardians({ search, limit = 50, offset = 0 } = {}) {
    const params = [];
    let where = "WHERE u.role = 'guardian'";
    if (search) {
      params.push(`%${search}%`);
      where += ` AND (u.full_name ILIKE $1 OR u.phone ILIKE $1)`;
    }
    const total = await db.one(`SELECT count(*)::int AS n FROM users u ${where}`, params);
    const items = await db.many(
      `SELECT u.id, u.full_name, u.phone, u.is_active, g.channel_mode, g.preferred_language, g.consent_at,
              COALESCE(json_agg(json_build_object('studentId', s.id, 'fullName', s.full_name, 'relationship', sg.relationship))
                       FILTER (WHERE s.id IS NOT NULL), '[]') AS children,
              EXISTS (SELECT 1 FROM devices d WHERE d.user_id = u.id AND d.fcm_token IS NOT NULL) AS has_app
       FROM users u JOIN guardians g ON g.user_id = u.id
       LEFT JOIN student_guardians sg ON sg.guardian_id = u.id
       LEFT JOIN students s ON s.id = sg.student_id
       ${where}
       GROUP BY u.id, g.user_id
       ORDER BY u.full_name LIMIT $${params.length + 1} OFFSET $${params.length + 2}`,
      [...params, Math.min(limit, 500), offset],
    );
    return { total: total.n, limit, offset, items };
  }

  async function createGuardian({ fullName, phone, channelMode = 'push_then_sms', preferredLanguage = 'en' }, ctx) {
    const p = phoneOrThrow(phone);
    try {
      return await db.tx(async (t) => {
        const u = await t.one(
          "INSERT INTO users (role, full_name, phone) VALUES ('guardian', $1, $2) RETURNING id, full_name, phone",
          [fullName, p],
        );
        await t.query('INSERT INTO guardians (user_id, channel_mode, preferred_language) VALUES ($1, $2, $3)', [u.id, channelMode, preferredLanguage]);
        await writeAudit(t, { ...ctx, action: 'guardian.create', entity: 'users', entityId: u.id, changes: { fullName: [null, fullName], phone: [null, p] } });
        return { ...u, channelMode, preferredLanguage };
      });
    } catch (err) {
      if (phoneTaken(err)) throw conflict('phone_in_use', 'Another account already uses this phone number');
      throw err;
    }
  }

  async function updatePerson(userId, role, { fullName, phone, isActive }, extra, ctx) {
    try {
      return await db.tx(async (t) => {
        const before = await t.one('SELECT id, full_name, phone, is_active FROM users WHERE id = $1 AND role = $2 FOR UPDATE', [userId, role]);
        if (!before) throw notFound(role === 'guardian' ? 'Guardian' : 'Driver');
        const after = {
          fullName: fullName ?? before.fullName,
          phone: phone !== undefined ? phoneOrThrow(phone) : before.phone,
          isActive: isActive ?? before.isActive,
        };
        await t.query('UPDATE users SET full_name = $2, phone = $3, is_active = $4 WHERE id = $1', [userId, after.fullName, after.phone, after.isActive]);
        if (extra) await extra(t);
        if (after.isActive === false) {
          await t.query('UPDATE refresh_tokens SET revoked_at = now() WHERE user_id = $1 AND revoked_at IS NULL', [userId]);
        }
        await writeAudit(t, { ...ctx, action: `${role}.update`, entity: 'users', entityId: userId, changes: diff(before, after) });
        return { id: userId, ...after };
      });
    } catch (err) {
      if (phoneTaken(err)) throw conflict('phone_in_use', 'Another account already uses this phone number');
      throw err;
    }
  }

  const updateGuardian = (id, data, ctx) => updatePerson(id, 'guardian', data, async (t) => {
    if (data.channelMode || data.preferredLanguage) {
      await t.query(
        `UPDATE guardians SET channel_mode = COALESCE($2, channel_mode), preferred_language = COALESCE($3, preferred_language)
         WHERE user_id = $1`,
        [id, data.channelMode ?? null, data.preferredLanguage ?? null],
      );
    }
  }, ctx);

  async function linkGuardian(studentId, guardianId, { relationship = 'guardian', isPrimary = false, receivesAlerts = true }, ctx) {
    return db.tx(async (t) => {
      if (isPrimary) await t.query('UPDATE student_guardians SET is_primary = false WHERE student_id = $1', [studentId]);
      const row = await t.one(
        `INSERT INTO student_guardians (student_id, guardian_id, relationship, is_primary, receives_alerts)
         VALUES ($1, $2, $3, $4, $5)
         ON CONFLICT (student_id, guardian_id) DO UPDATE
           SET relationship = EXCLUDED.relationship, is_primary = EXCLUDED.is_primary, receives_alerts = EXCLUDED.receives_alerts
         RETURNING *`,
        [studentId, guardianId, relationship, isPrimary, receivesAlerts],
      );
      await writeAudit(t, { ...ctx, action: 'student.link_guardian', entity: 'students', entityId: studentId, changes: { guardianId: [null, guardianId], relationship: [null, relationship] } });
      return row;
    });
  }

  async function unlinkGuardian(studentId, guardianId, ctx) {
    return db.tx(async (t) => {
      const row = await t.one('DELETE FROM student_guardians WHERE student_id = $1 AND guardian_id = $2 RETURNING student_id', [studentId, guardianId]);
      if (!row) throw notFound('Guardian link');
      await writeAudit(t, { ...ctx, action: 'student.unlink_guardian', entity: 'students', entityId: studentId, changes: { guardianId: [guardianId, null] } });
      return { deleted: true };
    });
  }

  // ---------- drivers & admins ----------
  async function listDrivers() {
    return db.many(
      `SELECT u.id, u.full_name, u.phone, u.is_active, u.last_login_at, d.licence_number,
              d.registered_device_id IS NOT NULL AS device_registered,
              (SELECT string_agg(r.name, ', ' ORDER BY r.name) FROM routes r WHERE r.default_driver_id = u.id AND r.is_active) AS routes
       FROM users u JOIN drivers d ON d.user_id = u.id ORDER BY u.full_name`,
    );
  }

  async function createDriver({ fullName, phone, pin, licenceNumber }, ctx) {
    const p = phoneOrThrow(phone);
    const pinHash = await hasher.hash(pin);
    try {
      return await db.tx(async (t) => {
        const u = await t.one(
          "INSERT INTO users (role, full_name, phone, pin_hash) VALUES ('driver', $1, $2, $3) RETURNING id, full_name, phone",
          [fullName, p, pinHash],
        );
        await t.query('INSERT INTO drivers (user_id, licence_number) VALUES ($1, $2)', [u.id, licenceNumber ?? null]);
        await writeAudit(t, { ...ctx, action: 'driver.create', entity: 'users', entityId: u.id, changes: { fullName: [null, fullName], phone: [null, p] } });
        return { ...u, licenceNumber: licenceNumber ?? null };
      });
    } catch (err) {
      if (phoneTaken(err)) throw conflict('phone_in_use', 'Another account already uses this phone number');
      throw err;
    }
  }

  const updateDriver = (id, data, ctx) => updatePerson(id, 'driver', data, async (t) => {
    if (data.licenceNumber !== undefined) await t.query('UPDATE drivers SET licence_number = $2 WHERE user_id = $1', [id, data.licenceNumber]);
  }, ctx);

  async function resetDriverPin(driverId, pin, ctx) {
    const pinHash = await hasher.hash(pin);
    return db.tx(async (t) => {
      const row = await t.one(
        `UPDATE users SET pin_hash = $2, failed_login_count = 0, locked_until = NULL
         WHERE id = $1 AND role = 'driver' RETURNING id`,
        [driverId, pinHash],
      );
      if (!row) throw notFound('Driver');
      await t.query('UPDATE refresh_tokens SET revoked_at = now() WHERE user_id = $1 AND revoked_at IS NULL', [driverId]);
      await writeAudit(t, { ...ctx, action: 'driver.reset_pin', entity: 'users', entityId: driverId });
      return { ok: true };
    });
  }

  async function resetDriverDevice(driverId, ctx) {
    return db.tx(async (t) => {
      const row = await t.one('UPDATE drivers SET registered_device_id = NULL WHERE user_id = $1 RETURNING user_id', [driverId]);
      if (!row) throw notFound('Driver');
      await t.query('UPDATE refresh_tokens SET revoked_at = now() WHERE user_id = $1 AND revoked_at IS NULL', [driverId]);
      await writeAudit(t, { ...ctx, action: 'driver.reset_device', entity: 'drivers', entityId: driverId });
      return { ok: true };
    });
  }

  async function createAdmin({ fullName, email, password }, ctx) {
    const hash = await hasher.hash(password);
    try {
      return await db.tx(async (t) => {
        const u = await t.one(
          "INSERT INTO users (role, full_name, email, password_hash) VALUES ('admin', $1, $2, $3) RETURNING id, full_name, email",
          [fullName, email.toLowerCase(), hash],
        );
        await writeAudit(t, { ...ctx, action: 'admin.create', entity: 'users', entityId: u.id, changes: { email: [null, u.email] } });
        return u;
      });
    } catch (err) {
      if (err.code === '23505') throw conflict('email_in_use', 'Another admin already uses this email');
      throw err;
    }
  }

  // ---------- assignments ----------
  async function assignStudentStop(studentId, scheduleId, stopId, ctx) {
    return db.tx(async (t) => {
      const row = await t.one(
        `INSERT INTO student_stops (student_id, schedule_id, stop_id) VALUES ($1, $2, $3)
         ON CONFLICT (student_id, schedule_id) DO UPDATE SET stop_id = EXCLUDED.stop_id
         RETURNING *`,
        [studentId, scheduleId, stopId],
      );
      await writeAudit(t, { ...ctx, action: 'student.assign_stop', entity: 'students', entityId: studentId, changes: { scheduleId: [null, scheduleId], stopId: [null, stopId] } });
      return row;
    });
  }

  async function removeStudentStop(studentId, scheduleId, ctx) {
    return db.tx(async (t) => {
      const row = await t.one('DELETE FROM student_stops WHERE student_id = $1 AND schedule_id = $2 RETURNING student_id', [studentId, scheduleId]);
      if (!row) throw notFound('Assignment');
      await writeAudit(t, { ...ctx, action: 'student.unassign_stop', entity: 'students', entityId: studentId, changes: { scheduleId: [scheduleId, null] } });
      return { deleted: true };
    });
  }

  async function getStudentDetail(studentId) {
    const student = await crud.students.get(studentId);
    const guardians = await db.many(
      `SELECT u.id, u.full_name, u.phone, sg.relationship, sg.is_primary, sg.receives_alerts
       FROM student_guardians sg JOIN users u ON u.id = sg.guardian_id WHERE sg.student_id = $1
       ORDER BY sg.is_primary DESC, u.full_name`,
      [studentId],
    );
    const stops = await db.many(
      `SELECT ss.schedule_id, sc.name AS schedule_name, sc.direction, r.name AS route_name, st.id AS stop_id, st.name AS stop_name
       FROM student_stops ss JOIN schedules sc ON sc.id = ss.schedule_id JOIN routes r ON r.id = sc.route_id
       JOIN stops st ON st.id = ss.stop_id WHERE ss.student_id = $1 ORDER BY sc.start_time`,
      [studentId],
    );
    return { ...student, guardians, stops };
  }

  // ---------- read models ----------
  async function listTrips({ date }) {
    const { timezone } = await settings.tracking();
    return db.many(
      `SELECT t.id, t.status, t.service_date::text AS service_date, t.scheduled_start_at, t.started_at, t.ended_at,
              t.distance_m, t.cancelled_reason, sc.name AS schedule_name, sc.direction, r.name AS route_name,
              b.plate_number, u.full_name AS driver_name,
              (SELECT count(*) FROM trip_stop_events e WHERE e.trip_id = t.id AND e.status IN ('arrived', 'departed'))::int AS stops_done,
              (SELECT count(*) FROM trip_stop_events e WHERE e.trip_id = t.id)::int AS stops_total
       FROM trips t JOIN schedules sc ON sc.id = t.schedule_id JOIN routes r ON r.id = sc.route_id
       JOIN buses b ON b.id = t.bus_id JOIN users u ON u.id = t.driver_id
       WHERE t.service_date = COALESCE($1::date, (now() AT TIME ZONE $2)::date)
       ORDER BY t.scheduled_start_at`,
      [date ?? null, timezone],
    );
  }

  const fleet = () => db.many('SELECT * FROM active_fleet ORDER BY route_name');
  const scheduleLoad = () => db.many('SELECT * FROM schedule_load ORDER BY route_name, schedule_name');

  async function listNotifications({ tripId, status, limit = 100, offset = 0 }) {
    return db.many(
      `SELECT n.id, n.event_type, n.channel, n.status, n.to_address, n.body, n.error, n.cost_kes,
              n.created_at, n.sent_at, n.delivered_at, u.full_name AS guardian_name
       FROM notifications n LEFT JOIN users u ON u.id = n.guardian_id
       WHERE ($1::uuid IS NULL OR n.trip_id = $1) AND ($2::notification_status IS NULL OR n.status = $2)
       ORDER BY n.created_at DESC LIMIT $3 OFFSET $4`,
      [tripId ?? null, status ?? null, Math.min(limit, 500), offset],
    );
  }

  async function listIncidents({ open }) {
    return db.many(
      `SELECT i.*, r.name AS route_name, b.plate_number, u.full_name AS reported_by_name
       FROM incidents i JOIN trips t ON t.id = i.trip_id JOIN schedules sc ON sc.id = t.schedule_id
       JOIN routes r ON r.id = sc.route_id JOIN buses b ON b.id = t.bus_id
       LEFT JOIN users u ON u.id = i.reported_by
       WHERE ($1::boolean IS NULL OR (i.resolved_at IS NULL) = $1)
       ORDER BY i.created_at DESC LIMIT 200`,
      [open ?? null],
    );
  }

  async function resolveIncident(id, ctx) {
    return db.tx(async (t) => {
      const row = await t.one(
        'UPDATE incidents SET resolved_at = now(), resolved_by = $2 WHERE id = $1 AND resolved_at IS NULL RETURNING *',
        [id, ctx.actorId],
      );
      if (!row) throw notFound('Open incident');
      await writeAudit(t, { ...ctx, action: 'incident.resolve', entity: 'incidents', entityId: id });
      return row;
    });
  }

  async function listAudit({ entity, entityId, limit = 100 }) {
    return db.many(
      `SELECT a.*, u.full_name AS actor_name FROM audit_logs a LEFT JOIN users u ON u.id = a.actor_id
       WHERE ($1::text IS NULL OR a.entity = $1) AND ($2::text IS NULL OR a.entity_id = $2)
       ORDER BY a.created_at DESC LIMIT $3`,
      [entity ?? null, entityId ?? null, Math.min(limit, 500)],
    );
  }

  // ---------- school calendar ----------
  async function listNoServiceDays({ from } = {}) {
    const { timezone } = await settings.tracking();
    return db.many(
      `SELECT service_date::text AS service_date, reason, created_at FROM no_service_days
       WHERE service_date >= COALESCE($1::date, (now() AT TIME ZONE $2)::date) ORDER BY service_date`,
      [from ?? null, timezone],
    );
  }

  /**
   * Mark a day as no-service. Any trips already planned for that day are cancelled so they
   * don't raise "not started"/delay alerts. notifyParents sends the cancellation alert too.
   */
  async function addNoServiceDay({ date, reason, notifyParents = false }, ctx) {
    return db.tx(async (t) => {
      try {
        await t.query('INSERT INTO no_service_days (service_date, reason, created_by) VALUES ($1::date, $2, $3)', [date, reason, ctx.actorId]);
      } catch (err) {
        if (err.code === '23505') throw conflict('already_exists', 'That day is already marked as no service');
        throw err;
      }
      const cancelled = await t.many(
        `UPDATE trips SET status = 'cancelled', cancelled_reason = $2
         WHERE service_date = $1::date AND status = 'scheduled' RETURNING id`,
        [date, reason],
      );
      if (notifyParents && cancelled.length) {
        await t.query(
          `INSERT INTO trip_events (trip_id, event_type, is_critical, payload)
           SELECT id, 'trip_cancelled', true, jsonb_build_object('reason', $2::text) FROM unnest($1::uuid[]) AS id
           ON CONFLICT ON CONSTRAINT trip_events_once_uq DO NOTHING`,
          [cancelled.map((c) => c.id), reason],
        );
      }
      await writeAudit(t, { ...ctx, action: 'calendar.no_service', entity: 'no_service_days', entityId: date, changes: { reason: [null, reason], cancelledTrips: [null, cancelled.length] } });
      return { date, reason, cancelledTrips: cancelled.length, parentsNotified: Boolean(notifyParents && cancelled.length) };
    });
  }

  async function removeNoServiceDay(date, ctx) {
    return db.tx(async (t) => {
      const row = await t.one('DELETE FROM no_service_days WHERE service_date = $1::date RETURNING service_date', [date]);
      if (!row) throw notFound('No-service day');
      await writeAudit(t, { ...ctx, action: 'calendar.service_restored', entity: 'no_service_days', entityId: date });
      return { deleted: true };
    });
  }

  // ---------- notifications ----------
  async function notificationSummary({ date } = {}) {
    const { timezone } = await settings.tracking();
    const rows = await db.many(
      `SELECT channel, status, count(*)::int AS count, COALESCE(sum(cost_kes), 0)::numeric(12,4) AS cost_kes
       FROM notifications
       WHERE (created_at AT TIME ZONE $2)::date = COALESCE($1::date, (now() AT TIME ZONE $2)::date)
       GROUP BY channel, status ORDER BY channel, status`,
      [date ?? null, timezone],
    );
    const total = rows.reduce((a, r) => a + r.count, 0);
    const smsCost = rows.filter((r) => r.channel === 'sms').reduce((a, r) => a + Number(r.costKes), 0);
    return { date: date ?? null, total, smsCostKes: Math.round(smsCost * 100) / 100, breakdown: rows };
  }

  async function retryNotification(id, ctx) {
    return db.tx(async (t) => {
      const row = await t.one(
        `UPDATE notifications SET status = 'queued', attempts = 0, next_attempt_at = now(), locked_until = NULL, error = NULL
         WHERE id = $1 AND status = 'failed' RETURNING id, channel, to_address`,
        [id],
      );
      if (!row) throw conflict('not_retryable', 'Only failed notifications can be retried');
      await writeAudit(t, { ...ctx, action: 'notification.retry', entity: 'notifications', entityId: id });
      return row;
    });
  }

  // ---------- trips ----------
  /** Swap the bus and/or driver of a trip that hasn't started yet. */
  async function reassignTrip(tripId, { busId, driverId }, ctx) {
    return db.tx(async (t) => {
      const before = await t.one('SELECT id, status, bus_id, driver_id FROM trips WHERE id = $1 FOR UPDATE', [tripId]);
      if (!before) throw notFound('Trip');
      if (before.status !== 'scheduled') throw conflict('trip_not_scheduled', 'Only trips that have not started can be reassigned');
      const after = await t.one(
        'UPDATE trips SET bus_id = COALESCE($2, bus_id), driver_id = COALESCE($3, driver_id) WHERE id = $1 RETURNING id, status, bus_id, driver_id',
        [tripId, busId ?? null, driverId ?? null],
      );
      await writeAudit(t, { ...ctx, action: 'trip.reassign', entity: 'trips', entityId: tripId, changes: diff({ busId: before.busId, driverId: before.driverId }, { busId: after.busId, driverId: after.driverId }) });
      return after;
    });
  }

  return {
    listNoServiceDays, addNoServiceDay, removeNoServiceDay, notificationSummary, retryNotification, reassignTrip,
    crud, createStop, reorderStops,
    listGuardians, createGuardian, updateGuardian, linkGuardian, unlinkGuardian,
    listDrivers, createDriver, updateDriver, resetDriverPin, resetDriverDevice, createAdmin,
    assignStudentStop, removeStudentStop, getStudentDetail,
    listTrips, fleet, scheduleLoad, listNotifications, listIncidents, resolveIncident, listAudit,
  };
}

module.exports = { createAdminService };
