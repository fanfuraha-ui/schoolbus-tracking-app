# School bus tracking and parent alerts

Live GPS tracking for the school's 6 buses (33 seats each, up to 180 students), with automatic SMS and push alerts to parents when the bus is approaching their stop, has arrived, is running late or is cancelled.

| Part | Folder | Stack | For |
|---|---|---|---|
| API + realtime | `apps/api` | Node.js, Express 5, Socket.IO, PostgreSQL 16 | Everything else talks to this |
| Alert worker | `apps/api` (`npm run worker`) | Same codebase, separate process | Geofences, ETAs, delays, SMS (Africa's Talking) and push (FCM) |
| Driver app | `apps/driver` | Expo / React Native | The phone mounted in each bus: background GPS, works offline |
| Admin dashboard | `apps/admin` | React, Vite, Tailwind CSS | Transport office: live fleet, students, routes, alerts, reports |
| Parent app | `apps/parent` | Expo / React Native | Countdown to the bus, live map, "not riding", alert history |
| Shared client | `packages/core` | Plain JS | API client with token refresh, used by all three apps |

## Quick start (local)
```bash
npm install
docker compose up -d db                      # Postgres 16
cp apps/api/.env.example apps/api/.env       # SMS stays in dry-run mode until you set SMS_DRY_RUN=false
set -a; . apps/api/.env; set +a              # the API reads plain environment variables, so load the file
npm run db:migrate -w apps/api && npm run db:seed -w apps/api
npm start -w apps/api                        # http://localhost:4000
npm run worker -w apps/api                   # second terminal: alerts and monitors
npm run dev -w apps/admin                    # http://localhost:5173  admin@school.test / ChangeMe!2026
```
Driver app: phone `0700000001`, PIN `1234`. Parent app: phone `0711000004`, code from the API log. Each folder's README has the details. `docs/` has the API reference, data model and alert rules.

## Tests
`npm test -ws` runs every package's tests. The database tests expect a throwaway Postgres; see `apps/api/db/README.md`.
