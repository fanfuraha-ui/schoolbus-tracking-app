/**
 * Builds the web demo as ONE self-contained HTML file: the real parent app screens, running on
 * demo/rnWeb.js (React Native -> DOM) and the mock server. Usage: node scripts/build-demo.mjs <outDir>
 */
import { createRequire } from 'module';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const require = createRequire(import.meta.url);
const MODS = process.env.NODE_PATH || '/opt/npm-tools/node_modules';
const esbuild = require(path.join(MODS, 'esbuild'));
const ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
const SHIM = path.join(ROOT, 'demo/rnWeb.js');
const out = path.resolve(process.argv[2] || path.join(ROOT, 'dist-demo'));

const result = await esbuild.build({
  entryPoints: [path.join(ROOT, 'demo/main.js')], bundle: true, write: false, format: 'iife', minify: true,
  loader: { '.js': 'jsx' }, jsx: 'automatic', target: 'es2019', logLevel: 'warning',
  nodePaths: [MODS],
  alias: { 'react-native': SHIM, 'react-native-safe-area-context': SHIM, 'react-native-webview': SHIM },
  define: { 'process.env.NODE_ENV': '"production"' },
});
const js = result.outputFiles[0].text.replace(/<\/script/gi, '<\\/script');

const css = `
*{box-sizing:border-box} html,body{margin:0;height:100%;background:#E6E9EF;font-family:Barlow,system-ui,sans-serif;color:#1A2238}
@keyframes rnspin{to{transform:rotate(360deg)}}
.page{min-height:100%;display:flex;gap:48px;align-items:center;justify-content:center;padding:32px 24px;flex-wrap:wrap}
.notes{max-width:300px;font-size:16px;line-height:1.45}
.notes h1{font-family:"Barlow Condensed",Barlow,sans-serif;font-weight:700;font-size:34px;line-height:1.05;margin:0 0 12px}
.notes p{margin:0 0 12px;color:#3A4460}
.restart{font:600 15px Barlow,sans-serif;background:#fff;color:#1A2238;border:1.5px solid #B9C1CF;border-radius:12px;padding:10px 16px;cursor:pointer}
.restart:focus-visible,[role=button]:focus-visible,input:focus-visible{outline:3px solid #FFB400;outline-offset:2px}
.link-note{font-size:14px;color:#1F7A51}
.phone{position:relative;width:390px;height:844px;border-radius:46px;border:12px solid #23262D;background:#F3F5F8;overflow:hidden;display:flex;flex-direction:column;transform:translateZ(0);box-shadow:0 24px 60px rgba(26,34,56,.25);flex:none}
.statusbar{height:30px;flex:none;display:flex;justify-content:space-between;align-items:center;padding:0 22px;font:600 13px Barlow,sans-serif;position:relative;z-index:5}
.screen{flex:1;display:flex;flex-direction:column;min-height:0;position:relative}
.rn-scroll::-webkit-scrollbar{display:none} .rn-scroll{scrollbar-width:none}
.headsup{position:absolute;top:38px;left:10px;right:10px;z-index:2000;background:#fff;border-radius:18px;padding:12px 40px 14px 16px;box-shadow:0 10px 30px rgba(0,0,0,.25);cursor:pointer;animation:hu .35s ease-out;font-family:system-ui,sans-serif}
@keyframes hu{from{transform:translateY(-120%)}to{transform:none}}
.hu-app{font-size:12px;color:#666;margin-bottom:2px}.hu-title{font-weight:600;font-size:15px;color:#111}.hu-body{font-size:14px;color:#333;margin-top:2px}
.hu-x{position:absolute;right:10px;top:8px;border:0;background:none;font-size:22px;color:#888;cursor:pointer}
@media (prefers-reduced-motion: reduce){.headsup{animation:none}}
@media (max-width:460px){.page{padding:0;gap:16px}.phone{width:100vw;height:100vh;border:0;border-radius:0}.notes{padding:16px 16px 0}}
`;

const html = `<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>School bus: parent app demo</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600&family=Barlow+Condensed:wght@600;700&display=swap" rel="stylesheet">
<style>${css}</style></head>
<body><div id="root"></div><script>${js}</script></body></html>`;

fs.mkdirSync(out, { recursive: true });
fs.writeFileSync(path.join(out, 'index.html'), html);
console.log(`wrote ${path.join(out, 'index.html')} (${Math.round(html.length / 1024)} KB)`);
