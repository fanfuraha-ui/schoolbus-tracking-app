'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { parseCsv, parseCsvObjects } = require('../../src/lib/csv');
const { createSmsClient, parseCost } = require('../../src/integrations/africasTalking');
const { loadConfig } = require('../../src/config');
const { fromPgError } = require('../../src/lib/errors');
const S = require('../../src/http/schemas');

test('csv: quotes, escaped quotes, embedded commas/newlines, CRLF, BOM, blank lines', () => {
  const rows = parseCsv('﻿a,b,c\r\n"x, y","say ""hi""","multi\nline"\r\n\r\n1,,3\n');
  assert.deepEqual(rows, [['a', 'b', 'c'], ['x, y', 'say "hi"', 'multi\nline'], ['1', '', '3']]);
  assert.throws(() => parseCsv('a,"unclosed'), /unclosed quote/);
  const { headers, records } = parseCsvObjects('Admission No, Student Name\nA1,  Jane  ');
  assert.deepEqual(headers, ['admission_no', 'student_name']);
  assert.deepEqual(records[0], { _line: 2, admission_no: 'A1', student_name: 'Jane' });
});

test("Africa's Talking: request format and response parsing", async () => {
  let captured;
  const fetchImpl = async (url, init) => {
    captured = { url, init };
    return {
      ok: true,
      text: async () => JSON.stringify({
        SMSMessageData: {
          Message: 'Sent to 1/2 Total Cost: KES 0.8000',
          Recipients: [
            { number: '+254711000001', status: 'Success', statusCode: 101, messageId: 'ATXid_1', cost: 'KES 0.8000' },
            { number: '+254711000002', status: 'InvalidPhoneNumber', statusCode: 403, messageId: 'None', cost: '0' },
          ],
        },
      }),
    };
  };
  const sms = createSmsClient({ username: 'myschool', apiKey: 'k-123', senderId: 'SCHOOLBUS', fetchImpl });
  const out = await sms.send({ to: ['+254711000001', '+254711000002'], message: 'Hello' });
  assert.equal(captured.url, 'https://api.africastalking.com/version1/messaging');
  assert.equal(captured.init.headers.apiKey, 'k-123');
  const body = new URLSearchParams(captured.init.body);
  assert.deepEqual([body.get('username'), body.get('to'), body.get('message'), body.get('from')],
    ['myschool', '+254711000001,+254711000002', 'Hello', 'SCHOOLBUS']);
  assert.deepEqual(out.map((r) => [r.accepted, r.messageId, r.cost]), [[true, 'ATXid_1', 0.8], [false, null, 0]]);
  assert.equal(parseCost('KES 1.2000'), 1.2);

  const sandbox = createSmsClient({ username: 'sandbox', apiKey: 'k', fetchImpl });
  await sandbox.send({ to: '+254711000001', message: 'x' });
  assert.equal(captured.url, 'https://api.sandbox.africastalking.com/version1/messaging');

  const failing = createSmsClient({ username: 'u', apiKey: 'k', fetchImpl: async () => ({ ok: false, status: 401, text: async () => 'Invalid key' }) });
  await assert.rejects(failing.send({ to: '+254711000001', message: 'x' }), /HTTP 401/);

  const dry = createSmsClient({ username: 'u', apiKey: 'k', dryRun: true, logger: { info() {} } });
  assert.equal((await dry.send({ to: '+254711000001', message: 'x' }))[0].accepted, true);
});

test('config: validates required secrets and parses lists/booleans', () => {
  const base = { DATABASE_URL: 'postgres://x', JWT_ACCESS_SECRET: 'a'.repeat(32), OTP_PEPPER: 'p'.repeat(16) };
  const c = loadConfig({ ...base, CORS_ORIGINS: 'https://admin.school.ke, http://localhost:5173', SMS_DRY_RUN: 'false', AT_API_KEY: 'k' });
  assert.deepEqual(c.corsOrigins, ['https://admin.school.ke', 'http://localhost:5173']);
  assert.equal(c.sms.dryRun, false);
  assert.equal(loadConfig(base).sms.dryRun, true, 'SMS is dry-run unless explicitly enabled');
  assert.throws(() => loadConfig({ ...base, JWT_ACCESS_SECRET: 'short' }), /JWT_ACCESS_SECRET/);
  assert.throws(() => loadConfig({ ...base, NODE_ENV: 'production', SMS_DRY_RUN: 'false' }), /AT_API_KEY/);
  assert.equal(loadConfig(base).sms.logText, false, 'SMS text is never logged by default');
  assert.equal(loadConfig({ ...base, DEV_LOG_SMS: 'true' }).sms.logText, true);
  assert.throws(() => loadConfig({ ...base, NODE_ENV: 'production', DEV_LOG_SMS: 'true' }), /DEV_LOG_SMS/);
});

test('SMS dry run logs the text only when DEV_LOG_SMS is on', async () => {
  const logs = [];
  const logger = { info: (o) => logs.push(o), warn() {}, error() {} };
  await createSmsClient({ dryRun: true, logger }).send({ to: '+254711000001', message: 'Code 123456' });
  await createSmsClient({ dryRun: true, logText: true, logger }).send({ to: '+254711000001', message: 'Code 123456' });
  assert.equal(logs[0].text, undefined);
  assert.equal(logs[1].text, 'Code 123456');
});

test('pg error mapping', () => {
  assert.equal(fromPgError({ code: '23505', message: 'duplicate key value violates unique constraint "buses_plate_number_key"' }).details.constraint, 'buses_plate_number_key');
  assert.equal(fromPgError({ code: '23503', message: 'x' }).status, 409);
  assert.equal(fromPgError({ code: '22P02', message: 'x' }).status, 400);
  assert.equal(fromPgError({ code: '57014', message: 'timeout' }), null);
  assert.equal(fromPgError(new Error('plain')), null);
});

test('schemas: GPS points coerce timestamps and reject nonsense', () => {
  const ok = S.driver.locations.parse({ points: [{ lat: -1.2, lng: 36.7, recordedAt: '2026-11-17T06:00:00Z', speedMps: null }] });
  assert.ok(ok.points[0].recordedAt instanceof Date);
  assert.ok(S.driver.locations.parse({ points: [{ lat: 0, lng: 0, recordedAt: 1763359200000 }] }).points[0].recordedAt instanceof Date);
  assert.equal(S.driver.locations.safeParse({ points: [{ lat: 95, lng: 0, recordedAt: '2026-11-17T06:00:00Z' }] }).success, false);
  assert.equal(S.driver.locations.safeParse({ points: [{ lat: 0, lng: 0, recordedAt: 'not a date' }] }).success, false);
  assert.equal(S.driver.locations.safeParse({ points: [] }).success, false);
  assert.equal(S.driver.locations.safeParse({ points: Array(501).fill({ lat: 0, lng: 0, recordedAt: 0 }) }).success, false);
});

test('schemas: admin inputs', () => {
  assert.equal(S.admin.bus.parse({ plateNumber: ' kda 123x ' }).plateNumber, 'KDA 123X');
  assert.equal(S.admin.bus.parse({ plateNumber: 'KDA 123X' }).capacity, 33);
  assert.equal(S.admin.schedule.safeParse({ routeId: '00000000-0000-0000-0000-000000000000', name: 'AM', direction: 'to_school', startTime: '25:00' }).success, false);
  assert.deepEqual(S.admin.schedule.parse({ routeId: '00000000-0000-0000-0000-000000000000', name: 'AM', direction: 'to_school', startTime: '06:30' }).daysOfWeek, [1, 2, 3, 4, 5]);
  assert.equal(S.admin.studentsQuery.parse({ isActive: 'false', limit: '20' }).isActive, false);
  assert.equal(S.auth.driverLogin.safeParse({ phone: '0700000001', pin: '12345', device: { deviceUid: 'abcdefgh', platform: 'android' } }).success, false);
  assert.equal(S.parent.preferences.safeParse({}).success, false);
});
