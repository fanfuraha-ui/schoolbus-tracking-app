'use strict';
/** Request validation (zod). Shared by HTTP routes and Socket.IO handlers. */
const { z } = require('zod');

const uuid = z.string().uuid();
const phone = z.string().trim().min(9).max(20);
const time = z.string().regex(/^([01]\d|2[0-3]):[0-5]\d(:[0-5]\d)?$/, 'Use HH:MM');
const isoDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Use YYYY-MM-DD');
const name = z.string().trim().min(1).max(120);
const boolish = z.union([z.boolean(), z.enum(['true', 'false']).transform((v) => v === 'true')]);

const device = z.object({
  deviceUid: z.string().min(8).max(128),
  platform: z.enum(['android', 'ios', 'web']),
  fcmToken: z.string().min(10).max(4096).optional(),
  appVersion: z.string().max(32).optional(),
  // false = the user turned notifications off on the phone. FCM would still accept messages
  // that Android then silently drops, so the token is removed and alerts fall back to SMS.
  pushEnabled: z.boolean().optional(),
});

const idParam = z.object({ id: uuid });
const pagination = z.object({
  limit: z.coerce.number().int().min(1).max(500).default(50),
  offset: z.coerce.number().int().min(0).default(0),
});

// ---------- auth ----------
const auth = {
  adminLogin: z.object({ email: z.string().trim().email().max(200), password: z.string().min(1).max(200), device }),
  driverLogin: z.object({ phone, pin: z.string().regex(/^\d{4}$/, 'PIN is 4 digits'), device }),
  otpRequest: z.object({ phone }),
  otpVerify: z.object({ phone, code: z.string().regex(/^\d{6}$/, 'Code is 6 digits'), device }),
  refresh: z.object({ refreshToken: z.string().min(20).max(200) }),
};

// ---------- driver ----------
const gpsPoint = z.object({
  lat: z.number().min(-90).max(90),
  lng: z.number().min(-180).max(180),
  recordedAt: z.coerce.date(),
  speedMps: z.number().min(0).max(70).nullish(),
  headingDeg: z.number().min(0).max(360).nullish(),
  accuracyM: z.number().min(0).max(10000).nullish(),
}).refine((p) => !Number.isNaN(p.recordedAt.getTime()), { message: 'Invalid recordedAt', path: ['recordedAt'] });

const driver = {
  scheduleParam: z.object({ scheduleId: uuid }),
  tripParam: z.object({ tripId: uuid }),
  tripStopParam: z.object({ tripId: uuid, stopId: uuid }),
  tripStudentParam: z.object({ tripId: uuid, studentId: uuid }),
  locations: z.object({ points: z.array(gpsPoint).min(1).max(500) }),
  socketLocations: z.object({ tripId: uuid, points: z.array(gpsPoint).min(1).max(100) }),
  stopAction: z.object({ action: z.enum(['arrived', 'departed', 'skipped']), reason: z.string().trim().max(200).optional() }),
  studentEvent: z.object({
    status: z.enum(['boarded', 'dropped_off', 'absent', 'no_show']),
    stopId: uuid.optional(),
    lat: z.number().min(-90).max(90).optional(),
    lng: z.number().min(-180).max(180).optional(),
  }),
  incident: z.object({
    type: z.enum(['traffic', 'breakdown', 'accident', 'weather', 'road_closure', 'other']),
    severity: z.enum(['low', 'medium', 'critical']).default('medium'),
    note: z.string().trim().max(500).optional(),
    lat: z.number().min(-90).max(90).optional(),
    lng: z.number().min(-180).max(180).optional(),
    notifyParents: z.boolean().default(false),
  }),
  cancel: z.object({ reason: z.string().trim().min(3).max(200) }),
  device,
};

// ---------- parent ----------
const parent = {
  tripParam: z.object({ tripId: uuid }),
  preferences: z.object({
    channelMode: z.enum(['push', 'sms', 'push_then_sms']).optional(),
    preferredLanguage: z.enum(['en', 'sw']).optional(),
    quietHours: z.object({ start: time, end: time }).nullable().optional(),
  }).refine((v) => Object.keys(v).length > 0, 'Send at least one preference'),
  consent: z.object({ version: z.string().trim().min(1).max(20) }),
  absence: z.object({ studentId: uuid, date: isoDate, scheduleId: uuid.optional(), reason: z.string().trim().max(200).optional() }),
  device,
  notificationsQuery: z.object({ limit: z.coerce.number().int().min(1).max(200).default(50) }),
};

// ---------- admin ----------
const plate = z.string().trim().toUpperCase().regex(/^[A-Z0-9 ]{3,12}$/, 'Plate like KDA 123X');
const bus = z.object({ plateNumber: plate, capacity: z.number().int().min(1).max(100).default(33), isActive: z.boolean().optional() });
const route = z.object({
  name, description: z.string().trim().max(500).nullish(),
  defaultBusId: uuid.nullish(), defaultDriverId: uuid.nullish(), isActive: z.boolean().optional(),
});
const schedule = z.object({
  routeId: uuid, name, direction: z.enum(['to_school', 'from_school']),
  daysOfWeek: z.array(z.number().int().min(1).max(7)).min(1).max(7).default([1, 2, 3, 4, 5]),
  startTime: time, isActive: z.boolean().optional(),
});
const stop = z.object({
  scheduleId: uuid, sequence: z.number().int().min(1).max(500).optional(), name, landmark: z.string().trim().max(200).nullish(),
  lat: z.number().min(-90).max(90), lng: z.number().min(-180).max(180),
  radiusM: z.number().int().min(20).max(1000).optional(), approachMinutes: z.number().int().min(1).max(30).optional(),
  scheduledTime: time.nullish(), isSchool: z.boolean().optional(), isActive: z.boolean().optional(),
});
const student = z.object({
  admissionNo: z.string().trim().min(1).max(40), fullName: name, className: z.string().trim().max(40).nullish(),
  isActive: z.boolean().optional(), notes: z.string().trim().max(1000).nullish(),
});

const admin = {
  idParam,
  pagination,
  listQuery: pagination.extend({ search: z.string().trim().max(100).optional(), isActive: boolish.optional() }),
  stopsQuery: pagination.extend({ scheduleId: uuid.optional(), isActive: boolish.optional() }),
  schedulesQuery: pagination.extend({ routeId: uuid.optional(), isActive: boolish.optional() }),
  studentsQuery: pagination.extend({ search: z.string().trim().max(100).optional(), isActive: boolish.optional(), className: z.string().max(40).optional() }),
  bus, busUpdate: bus.partial(),
  route, routeUpdate: route.partial(),
  schedule, scheduleUpdate: schedule.omit({ routeId: true }).partial(),
  stop, stopUpdate: stop.omit({ scheduleId: true }).partial(),
  student, studentUpdate: student.partial(),
  guardianCreate: z.object({
    fullName: name, phone, channelMode: z.enum(['push', 'sms', 'push_then_sms']).optional(), preferredLanguage: z.enum(['en', 'sw']).optional(),
  }),
  guardianUpdate: z.object({
    fullName: name.optional(), phone: phone.optional(), isActive: z.boolean().optional(),
    channelMode: z.enum(['push', 'sms', 'push_then_sms']).optional(), preferredLanguage: z.enum(['en', 'sw']).optional(),
  }),
  driverCreate: z.object({ fullName: name, phone, pin: z.string().regex(/^\d{4}$/), licenceNumber: z.string().trim().max(40).optional() }),
  driverUpdate: z.object({ fullName: name.optional(), phone: phone.optional(), isActive: z.boolean().optional(), licenceNumber: z.string().trim().max(40).nullish() }),
  pinReset: z.object({ pin: z.string().regex(/^\d{4}$/) }),
  adminCreate: z.object({ fullName: name, email: z.string().trim().email(), password: z.string().min(10).max(200) }),
  linkGuardian: z.object({
    guardianId: uuid, relationship: z.enum(['mother', 'father', 'guardian', 'other']).default('guardian'),
    isPrimary: z.boolean().default(false), receivesAlerts: z.boolean().default(true),
  }),
  studentGuardianParam: z.object({ id: uuid, guardianId: uuid }),
  assignStop: z.object({ scheduleId: uuid, stopId: uuid }),
  studentScheduleParam: z.object({ id: uuid, scheduleId: uuid }),
  reorderStops: z.object({ stopIds: z.array(uuid).min(1).max(500) }),
  tripsQuery: z.object({ date: isoDate.optional() }),
  tripCreate: z.object({ scheduleId: uuid, serviceDate: isoDate, busId: uuid.optional(), driverId: uuid.optional() }),
  cancel: z.object({ reason: z.string().trim().min(3).max(200) }),
  notificationsQuery: pagination.extend({ tripId: uuid.optional(), status: z.enum(['queued', 'sent', 'delivered', 'failed', 'skipped']).optional() }),
  incidentsQuery: z.object({ open: boolish.optional() }),
  auditQuery: z.object({ entity: z.string().max(60).optional(), entityId: z.string().max(80).optional(), limit: z.coerce.number().int().min(1).max(500).default(100) }),
  settingsPatch: z.record(z.string(), z.unknown()),
  importQuery: z.object({ dryRun: boolish.default(false) }),
  dateParam: z.object({ date: isoDate }),
  noServiceDay: z.object({ date: isoDate, reason: z.string().trim().min(3).max(120), notifyParents: z.boolean().default(false) }),
  noServiceQuery: z.object({ from: isoDate.optional() }),
  summaryQuery: z.object({ date: isoDate.optional() }),
  reportsQuery: z.object({ from: isoDate.optional(), to: isoDate.optional() }),
  tripReassign: z.object({ busId: uuid.optional(), driverId: uuid.optional() })
    .refine((v) => v.busId || v.driverId, 'Send busId and/or driverId'),
};

module.exports = { auth, driver, parent, admin, gpsPoint };
