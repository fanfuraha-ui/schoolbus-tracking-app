/**
 * The dashboard against the REAL backend (routes, validation, services, PostgreSQL):
 *  1. the demo mock returns no field the real API lacks (so the demo can't drift), and
 *  2. the dashboard's own loaders + views render real responses.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const require = createRequire(import.meta.url);
const API = path.resolve(here, '../../api');
const MODS = '/opt/npm-tools/node_modules';

const fake = require(`${API}/test/support/fakeFramework`);
fake.install();
const { freshDatabase, fakeBroadcaster, fakeSms, fakeTokens, pgHasher, quietLogger } = require(`${API}/test/support/context`);
const { createSettingsService } = require(`${API}/src/services/settingsService`);
const { createAuthService } = require(`${API}/src/services/authService`);
const { createTripService } = require(`${API}/src/services/tripService`);
const { createParentService } = require(`${API}/src/services/parentService`);
const { createAdminService } = require(`${API}/src/services/admin/adminService`);
const { importStudentsCsv } = require(`${API}/src/services/admin/importStudents`);
const { createDeliveryReportService } = require(`${API}/src/notifications/deliveryReports`);
const { createApp } = require(`${API}/src/http/app`);

const { createMockServer } = await import('../src/demo/mockServer.js');

let pool; let db; let app; let adminId; let realApi; let mock;

test.before(async () => {
  ({ pool, db } = await freshDatabase('schoolbus_test_admin_ui'));
  const settings = createSettingsService({ db });
  const hasher = pgHasher(db);
  const tripService = createTripService({ db, settings, broadcaster: fakeBroadcaster(), logger: quietLogger });
  app = createApp({
    services: {
      db, settings, tripService,
      authService: createAuthService({ db, hasher, tokens: fakeTokens, sms: fakeSms(), settings, otpPepper: 'pepper-for-tests-123' }),
      parentService: createParentService({ db, settings }),
      adminService: createAdminService({ db, hasher, settings }),
      importStudents: (csv, o) => importStudentsCsv({ db }, csv, o),
      deliveryReports: createDeliveryReportService({ db }),
    },
    tokens: fakeTokens, config: { corsOrigins: [], trustProxy: false }, logger: quietLogger,
  });
  adminId = (await db.one("SELECT id FROM users WHERE role = 'admin'")).id;
  const active = await db.one("SELECT t.id, t.driver_id FROM trips t WHERE status = 'active'");
  await tripService.reportIncident({ tripId: active.id, driverId: active.driverId, type: 'traffic', note: 'Jam', notifyParents: true });
  const g = await db.one("SELECT id FROM users WHERE phone = '+254711000001'");
  await db.query("INSERT INTO notifications (dedupe_key, channel, guardian_id, trip_id, event_type, to_address, body, status, cost_kes) VALUES ('c1', 'sms', $1, $2, 'approaching', '+254711000001', 'Bus is near', 'sent', 0.8)", [g.id, active.id]);

  const str = (q) => (q ? Object.fromEntries(Object.entries(q).filter(([, v]) => v !== undefined).map(([k, v]) => [k, String(v)])) : {});
  const request = async (method, p, opts = {}) => {
    const r = await fake.request(app, { method, url: `/api/v1${p}`, body: opts.body, query: str(opts.query), headers: { Authorization: `Bearer access:${adminId}:admin` } });
    if (r.status === 'unhandled') throw r.err;
    if (r.status >= 400) throw Object.assign(new Error(r.body?.error?.message || `HTTP ${r.status}`), { status: r.status, code: r.body?.error?.code });
    return r.body;
  };
  realApi = { request, get: (p, o) => request('GET', p, o), post: (p, b, o) => request('POST', p, { ...o, body: b }) };
  await realApi.post('/admin/no-service-days', { date: '2030-01-02', reason: 'Test closure' });
  mock = createMockServer();
});
test.after(() => pool.end());

const MOCK_ONLY = new Set(['household', 'frac']);
// The first stop with riders: an afternoon run starts at the school gate, where nobody boards.
const firstRider = (detail) => detail.stops.find((s) => s.riders?.length)?.riders[0];
function missingKeys(mockObj, realObj, where) {
  assert.ok(mockObj && realObj, `${where}: sample missing (mock ${Boolean(mockObj)}, real ${Boolean(realObj)})`);
  const real = new Set(Object.keys(realObj));
  return Object.keys(mockObj).filter((k) => !MOCK_ONLY.has(k) && !real.has(k)).map((k) => `${where}.${k}`);
}

test('demo mock never returns a field the real API lacks', async () => {
  const both = async (p, query, pick = (x) => x) => [pick(await mock.api.get(p, { query })), pick(await realApi.get(p, { query }))];
  const problems = [];
  const cmp = async (label, p, query, pick) => { const [m, r] = await both(p, query, pick); problems.push(...missingKeys(m, r, label)); return [m, r]; };

  await cmp('trips', '/admin/trips', {}, (x) => x.trips[0]);
  const realTrip = (await realApi.get('/admin/trips')).trips.find((t) => t.status === 'active');
  const mockTrip = (await mock.api.get('/admin/trips')).trips.find((t) => t.status === 'active');
  const [md, rd] = [await mock.api.get(`/admin/trips/${mockTrip.id}`), await realApi.get(`/admin/trips/${realTrip.id}`)];
  problems.push(...missingKeys(md, rd, 'tripDetail'), ...missingKeys(md.stops[0], rd.stops[0], 'tripDetail.stops'), ...missingKeys(firstRider(md), firstRider(rd), 'tripDetail.riders'));
  await cmp('fleet', '/admin/fleet', {}, (x) => x.buses[0]);
  await cmp('incidents', '/admin/incidents', { open: true }, (x) => x.incidents[0]);
  await cmp('notificationSummary', '/admin/notifications/summary', {}, (x) => x);
  await cmp('notificationSummary.breakdown', '/admin/notifications/summary', {}, (x) => x.breakdown[0]);
  await cmp('notifications', '/admin/notifications', {}, (x) => x.notifications[0]);
  await cmp('students', '/admin/students', {}, (x) => x.items[0]);
  const ms = (await mock.api.get('/admin/students')).items[0];
  const rs = (await realApi.get('/admin/students')).items[0];
  const [msd, rsd] = [await mock.api.get(`/admin/students/${ms.id}`), await realApi.get(`/admin/students/${rs.id}`)];
  problems.push(...missingKeys(msd, rsd, 'student'), ...missingKeys(msd.guardians[0], rsd.guardians[0], 'student.guardians'), ...missingKeys(msd.stops[0], rsd.stops[0], 'student.stops'));
  await cmp('guardians', '/admin/guardians', {}, (x) => x.items[0]);
  await cmp('guardians.children', '/admin/guardians', {}, (x) => x.items[0].children[0]);
  await cmp('drivers', '/admin/drivers', {}, (x) => x.items[0]);
  for (const r of ['routes', 'schedules', 'buses']) await cmp(r, `/admin/${r}`, {}, (x) => x.items[0]);
  const [mSched, rSched] = [(await mock.api.get('/admin/schedules')).items[0].id, (await realApi.get('/admin/schedules')).items[0].id];
  problems.push(...missingKeys((await mock.api.get('/admin/stops', { query: { scheduleId: mSched } })).items[0], (await realApi.get('/admin/stops', { query: { scheduleId: rSched } })).items[0], 'stops'));
  await cmp('scheduleLoad', '/admin/schedule-load', {}, (x) => x.schedules[0]);
  await cmp('noServiceDays', '/admin/no-service-days', {}, (x) => x.days[0]);
  await cmp('reports', '/admin/reports', {}, (x) => x);
  await cmp('reports.totals', '/admin/reports', {}, (x) => x.totals);
  await cmp('reports.byRoute', '/admin/reports', {}, (x) => x.byRoute[0]);
  await cmp('auditLogs', '/admin/audit-logs', {}, (x) => x.entries[0]);
  await cmp('settings', '/admin/settings', {}, (x) => x);
  assert.deepEqual(problems, []);
});

// ---------- render real data with the real view components ----------
const OUT = fs.mkdtempSync(path.join(os.tmpdir(), 'adm-render-'));
async function bundle(file) {
  const esbuild = require(`${MODS}/esbuild`);
  const stub = path.join(OUT, 'stub.js');
  fs.writeFileSync(stub, 'module.exports = {};');
  const outfile = path.join(OUT, `${path.basename(file)}.cjs`);
  esbuild.buildSync({
    entryPoints: [path.join(here, '..', file)], bundle: true, outfile, platform: 'node', format: 'cjs', logLevel: 'silent',
    loader: { '.js': 'jsx', '.jsx': 'jsx', '.css': 'empty' }, jsx: 'automatic', external: ['react', 'react/jsx-runtime', 'react-dom'],
    alias: { leaflet: stub, 'leaflet/dist/leaflet.css': stub, 'socket.io-client': stub }, define: { 'import.meta.env': '{}' },
  });
  const Module = require('node:module');
  const m = new Module(outfile);
  m.paths = [MODS, path.join(here, '../node_modules')];
  m._compile(fs.readFileSync(outfile, 'utf8'), outfile);
  return m.exports;
}

test('dashboard views render real backend data', async () => {
  const React = require(`${MODS}/react`);
  const { renderToStaticMarkup } = require(`${MODS}/react-dom/server`);
  const text = (h) => h.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ');
  const Live = await bundle('src/pages/Live.jsx');
  const Trips = await bundle('src/pages/Trips.jsx');
  const Office = await bundle('src/pages/Office.jsx');
  const { fleetReducer, initialFleet } = await import('../src/lib/fleet.js');

  const snapshot = await Live.loadFleetSnapshot(realApi);
  assert.ok(snapshot.trips.length >= 1);
  const fleet = fleetReducer(initialFleet, { type: 'snapshot', ...snapshot });
  const incidents = (await realApi.get('/admin/incidents', { query: { open: true } })).incidents;
  const alerts = await realApi.get('/admin/notifications/summary');
  const live = text(renderToStaticMarkup(React.createElement(Live.LiveView, { fleet, incidents, alerts, now: Date.now(), onOpenTrip() {}, onResolve() {} })));
  assert.match(live, /buses? (is|are) on the road|No bus is on the road/);
  assert.match(live, /1 Kikuyu Town/);
  assert.match(live, /KDA 101A/);
  assert.match(live, /Heavy traffic on Route 1 - Kikuyu Town/);
  assert.match(live, /KES 0\.80/);

  const active = snapshot.trips.find((t) => t.status === 'active');
  const detail = text(renderToStaticMarkup(React.createElement(Trips.TripDetailView, { trip: active })));
  assert.match(detail, /On the road/);
  assert.match(detail, /Kikuyu Town Stage 10/);
  assert.match(detail, /School gate/);
  const list = text(renderToStaticMarkup(React.createElement(Trips.TripsTable, { trips: (await realApi.get('/admin/trips')).trips, onOpen() {} })));
  assert.match(list, /06:30 .*Route 1 - Kikuyu Town .*Morning pickup .*KDA 101A .*Driver Kikuyu Town .*On the road/);

  const report = text(renderToStaticMarkup(React.createElement(Office.ReportsView, { data: await realApi.get('/admin/reports') })));
  assert.match(report, /No finished trips in this period|ran on time/);
  assert.match(report, /Heavy traffic/);
});
