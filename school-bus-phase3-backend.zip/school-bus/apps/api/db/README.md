# Database (Phase 2)

PostgreSQL **15 or newer** (tested on 16). There are no extensions in production. `pgcrypto` is used only by the dev seed.

## Commands
```bash
export DATABASE_URL=postgres://postgres:postgres@localhost:5432/schoolbus_dev
npm run db:migrate   # apply pending migrations
npm run db:status    # list applied / pending
npm run db:seed      # dev data: 6 buses, 12 schedules, 180 students, 150 households
npm run db:test      # 15 constraint tests, rolled back afterwards
npm run db:reset     # drop + migrate + seed + test (refuses URLs containing "prod")
```

## Migrations
| File | Contents |
|---|---|
| 0001_foundation | Enums, `ke_phone` / `latitude` / `longitude` domains, `set_updated_at()`, `app_settings` with tunable thresholds |
| 0002_people | users, devices, refresh_tokens, otp_codes, guardians (incl. notification prefs), drivers, students, student_guardians |
| 0003_fleet_routes | buses, routes, schedules, stops, student_stops |
| 0004_trips_tracking | trips (+ transition trigger), trip_stop_events, student_trip_events, absences, location_points, bus_positions, segment times/stats, `refresh_segment_stats()`, `purge_old_location_points()` |
| 0005_notifications_ops | notifications, sms_delivery_reports, incidents, audit_logs, ussd_sessions |
| 0006_views | trip_stop_recipients, trip_stop_manifest, schedule_load, active_fleet |
| 0007_trip_events_and_login_lockout | `trip_events` outbox (alerts written in the same transaction as the trip change; each event once per trip), login lockout counters, `trips.last_point_at` |

Rules: migrations are forward-only. Never edit an applied file, because the runner checks a checksum and will refuse. Add `0007_...` instead. pg-boss creates its own `pgboss` schema when the worker starts.

## Integrity rules enforced by the database
Integrity rules are enforced by the database, not just the API, so a bug in the app can't corrupt data:
- **Roles:** a `guardians` row can only point at a user with role `guardian`, and the same applies to drivers. This uses composite FK `(user_id, role)`.
- **Stops belong to schedules:** a student can't be assigned, and a trip can't record, a stop from a different schedule. This uses composite FKs on `(stop_id, schedule_id)`.
- **No duplicate trips:** there is one trip per schedule per day, and a bus or driver can be on only one active trip at a time.
- **Legal trip transitions only:** `scheduled → active|cancelled`, `active → completed|cancelled`.
- **No duplicate alerts:** `UNIQUE (dedupe_key, channel)`. Push + fallback SMS is allowed, but a second identical SMS is not.
- **One SMS segment:** SMS body ≤ 160 characters.
- **Kenyan phone format:** `+2547XXXXXXXX` / `+2541XXXXXXXX` only. The API normalises `07…`, `01…` and `2547…` inputs.
- **Idempotent GPS:** `UNIQUE (trip_id, recorded_at)`. Insert with `ON CONFLICT DO NOTHING` so live and backlog uploads can overlap safely.

## Views the next phases rely on
- `trip_stop_recipients`: who to alert for each stop of a trip, with absences removed. Siblings at one stop produce two rows, and the dedupe key collapses them to one alert.
- `trip_stop_manifest`: the driver's stop list with expected/absent counts and `can_skip`.
- `schedule_load`: students assigned vs bus capacity.
- `active_fleet`: live map feed for the admin dashboard.

## Scale notes
About 12k GPS rows/day, ~1M rows over the 90-day retention window. A BRIN index on `recorded_at` keeps purges cheap. Partitioning isn't needed at this size and can be added later in a migration if the school grows past ~50 buses.
