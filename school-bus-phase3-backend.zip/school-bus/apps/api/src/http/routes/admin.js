'use strict';
const express = require('express');
const { validate, auditCtx } = require('../middleware');
const { writeAudit, diff } = require('../../services/audit');
const S = require('../schemas').admin;

/** Standard list/get/create/update/delete endpoints for a generic CRUD resource. */
function mountCrud(r, path, svc, { create, update, query }, overrides = {}) {
  r.get(path, validate({ query }), async (req, res) => res.json(await svc.list(req.valid.query)));
  r.get(`${path}/:id`, validate({ params: S.idParam }),
    async (req, res) => res.json(await (overrides.get ?? svc.get)(req.valid.params.id)));
  r.post(path, validate({ body: create }),
    async (req, res) => res.status(201).json(await (overrides.create ?? svc.create)(req.valid.body, auditCtx(req))));
  r.patch(`${path}/:id`, validate({ params: S.idParam, body: update }),
    async (req, res) => res.json(await svc.update(req.valid.params.id, req.valid.body, auditCtx(req))));
  r.delete(`${path}/:id`, validate({ params: S.idParam }),
    async (req, res) => res.json(await svc.remove(req.valid.params.id, auditCtx(req))));
}

module.exports = function adminRoutes({ db, adminService: A, tripService, settings, importStudents }) {
  const r = express.Router();
  const { crud } = A;

  // ---------- fleet & routes ----------
  mountCrud(r, '/buses', crud.buses, { create: S.bus, update: S.busUpdate, query: S.listQuery });
  mountCrud(r, '/routes', crud.routes, { create: S.route, update: S.routeUpdate, query: S.listQuery });
  mountCrud(r, '/schedules', crud.schedules, { create: S.schedule, update: S.scheduleUpdate, query: S.schedulesQuery });
  mountCrud(r, '/stops', crud.stops, { create: S.stop, update: S.stopUpdate, query: S.stopsQuery }, { create: A.createStop });
  r.put('/schedules/:id/stop-order', validate({ params: S.idParam, body: S.reorderStops }),
    async (req, res) => res.json(await A.reorderStops(req.valid.params.id, req.valid.body.stopIds, auditCtx(req))));

  // ---------- students ----------
  mountCrud(r, '/students', crud.students, { create: S.student, update: S.studentUpdate, query: S.studentsQuery }, { get: A.getStudentDetail });
  r.put('/students/:id/guardians', validate({ params: S.idParam, body: S.linkGuardian }), async (req, res) => {
    const { guardianId, ...opts } = req.valid.body;
    res.json(await A.linkGuardian(req.valid.params.id, guardianId, opts, auditCtx(req)));
  });
  r.delete('/students/:id/guardians/:guardianId', validate({ params: S.studentGuardianParam }),
    async (req, res) => res.json(await A.unlinkGuardian(req.valid.params.id, req.valid.params.guardianId, auditCtx(req))));
  r.put('/students/:id/stops', validate({ params: S.idParam, body: S.assignStop }), async (req, res) => {
    res.json(await A.assignStudentStop(req.valid.params.id, req.valid.body.scheduleId, req.valid.body.stopId, auditCtx(req)));
  });
  r.delete('/students/:id/stops/:scheduleId', validate({ params: S.studentScheduleParam }),
    async (req, res) => res.json(await A.removeStudentStop(req.valid.params.id, req.valid.params.scheduleId, auditCtx(req))));

  // CSV import: send the file as text/csv (or JSON {"csv": "..."}). ?dryRun=true validates only.
  r.post('/import/students', express.text({ type: ['text/csv', 'text/plain'], limit: '2mb' }),
    validate({ query: S.importQuery }), async (req, res) => {
      const csv = typeof req.body === 'string' ? req.body : req.body?.csv;
      if (!csv) return res.status(400).json({ error: { code: 'csv_required', message: 'Send the CSV file as the request body' } });
      const out = await importStudents(csv, { dryRun: req.valid.query.dryRun, ctx: auditCtx(req) });
      return res.status(out.ok ? 200 : 422).json(out);
    });

  // ---------- people ----------
  r.get('/guardians', validate({ query: S.listQuery }), async (req, res) => res.json(await A.listGuardians(req.valid.query)));
  r.post('/guardians', validate({ body: S.guardianCreate }),
    async (req, res) => res.status(201).json(await A.createGuardian(req.valid.body, auditCtx(req))));
  r.patch('/guardians/:id', validate({ params: S.idParam, body: S.guardianUpdate }),
    async (req, res) => res.json(await A.updateGuardian(req.valid.params.id, req.valid.body, auditCtx(req))));

  r.get('/drivers', async (req, res) => res.json({ items: await A.listDrivers() }));
  r.post('/drivers', validate({ body: S.driverCreate }),
    async (req, res) => res.status(201).json(await A.createDriver(req.valid.body, auditCtx(req))));
  r.patch('/drivers/:id', validate({ params: S.idParam, body: S.driverUpdate }),
    async (req, res) => res.json(await A.updateDriver(req.valid.params.id, req.valid.body, auditCtx(req))));
  r.post('/drivers/:id/reset-pin', validate({ params: S.idParam, body: S.pinReset }),
    async (req, res) => res.json(await A.resetDriverPin(req.valid.params.id, req.valid.body.pin, auditCtx(req))));
  r.post('/drivers/:id/reset-device', validate({ params: S.idParam }),
    async (req, res) => res.json(await A.resetDriverDevice(req.valid.params.id, auditCtx(req))));

  r.post('/admins', validate({ body: S.adminCreate }),
    async (req, res) => res.status(201).json(await A.createAdmin(req.valid.body, auditCtx(req))));

  // ---------- operations ----------
  r.get('/trips', validate({ query: S.tripsQuery }), async (req, res) => res.json({ trips: await A.listTrips(req.valid.query) }));
  r.post('/trips', validate({ body: S.tripCreate }),
    async (req, res) => res.status(201).json(await tripService.createScheduledTrip({ ...req.valid.body, actorId: req.user.id })));
  r.get('/trips/:id', validate({ params: S.idParam }), async (req, res) => res.json(await tripService.getTripDetail(req.valid.params.id)));
  r.post('/trips/:id/cancel', validate({ params: S.idParam, body: S.cancel }),
    async (req, res) => res.json(await tripService.cancelTrip({ tripId: req.valid.params.id, actor: req.user, reason: req.valid.body.reason })));

  r.get('/fleet', async (req, res) => res.json({ buses: await A.fleet() }));
  r.get('/schedule-load', async (req, res) => res.json({ schedules: await A.scheduleLoad() }));
  r.get('/notifications', validate({ query: S.notificationsQuery }), async (req, res) => res.json({ notifications: await A.listNotifications(req.valid.query) }));
  r.get('/incidents', validate({ query: S.incidentsQuery }), async (req, res) => res.json({ incidents: await A.listIncidents(req.valid.query) }));
  r.post('/incidents/:id/resolve', validate({ params: S.idParam }),
    async (req, res) => res.json(await A.resolveIncident(req.valid.params.id, auditCtx(req))));
  r.get('/audit-logs', validate({ query: S.auditQuery }), async (req, res) => res.json({ entries: await A.listAudit(req.valid.query) }));

  // ---------- settings ----------
  r.get('/settings', async (req, res) => res.json(await settings.all()));
  r.patch('/settings', validate({ body: S.settingsPatch }), async (req, res) => {
    const before = await settings.all();
    const after = await settings.update(req.valid.body);
    await writeAudit(db, { ...auditCtx(req), action: 'settings.update', entity: 'app_settings', changes: diff(before, Object.fromEntries(Object.keys(req.valid.body).map((k) => [k, after[k]]))) });
    res.json(after);
  });

  return r;
};
