'use strict';
/**
 * TEST-ONLY stand-ins for express (+ helmet, cors, express-rate-limit) and socket.io, used
 * when those packages are not installed. They implement just enough routing semantics
 * (Express 5: path params, nested routers, middleware chains, async errors -> next(err),
 * 4-arg error handlers) to drive the real route modules, validation, auth middleware and
 * error handler end-to-end against the real services and database.
 */
const Module = require('module');
const path = require('path');

// ---------- express ----------
function compile(pattern, exact) {
  const keys = [];
  const src = pattern.replace(/\/$/, '').replace(/:([A-Za-z_]\w*)/g, (_, k) => { keys.push(k); return '([^/]+)'; });
  const re = new RegExp(`^${src}${exact ? '/?$' : '(?=/|$)'}`);
  return (p) => {
    const m = re.exec(p);
    if (!m) return null;
    const params = {};
    keys.forEach((k, i) => { params[k] = decodeURIComponent(m[i + 1]); });
    return { params, rest: p.slice(m[0].length) || '/' };
  };
}

function Router() {
  const router = (req, res, next) => router.handle(req, res, next, req.path);
  router.stack = [];
  for (const method of ['get', 'post', 'put', 'patch', 'delete']) {
    router[method] = (p, ...handlers) => { router.stack.push({ method: method.toUpperCase(), match: compile(p, true), handlers: handlers.flat() }); return router; };
  }
  router.use = (...args) => {
    const p = typeof args[0] === 'string' ? args.shift() : '/';
    router.stack.push({ method: null, match: p === '/' ? (x) => ({ params: {}, rest: x }) : compile(p, false), handlers: args.flat() });
    return router;
  };
  router.handle = (req, res, done, p) => {
    let i = 0;
    const next = (err) => {
      if (res.headersSent) return undefined;
      const layer = router.stack[i++];
      if (!layer) return done(err);
      if (layer.method && layer.method !== req.method) return next(err);
      const m = layer.match(p);
      if (!m) return next(err);
      if (layer.method) req.params = m.params;
      else req.params = { ...req.params, ...m.params };
      let j = 0;
      const run = (e) => {
        if (res.headersSent) return undefined;
        if (j >= layer.handlers.length) return next(e);
        const h = layer.handlers[j++];
        if (h.stack) return e ? run(e) : h.handle(req, res, run, m.rest); // routers never see errors
        const isErr = h.length === 4;
        if (e ? !isErr : isErr) return run(e);
        try {
          const ret = isErr ? h(e, req, res, run) : h(req, res, run);
          if (ret && typeof ret.then === 'function') ret.catch(run);
        } catch (x) { run(x); }
        return undefined;
      };
      return run(err);
    };
    next();
  };
  return router;
}

function express() {
  const app = Router();
  app.disable = () => app;
  app.set = () => app;
  return app;
}
express.Router = Router;
express.json = () => (req, res, next) => next();
express.text = () => (req, res, next) => next();

/** Dispatch a fake request through an app built with this stub. */
function request(app, { method = 'GET', url, body, headers = {}, query = {} }) {
  return new Promise((resolve) => {
    const listeners = {};
    const res = {
      statusCode: 200, headersSent: false, body: undefined,
      status(c) { this.statusCode = c; return this; },
      json(b) { this.body = b; this.headersSent = true; (listeners.finish || []).forEach((f) => f()); resolve({ status: this.statusCode, body: b }); return this; },
      on(ev, f) { (listeners[ev] = listeners[ev] || []).push(f); },
    };
    const lower = Object.fromEntries(Object.entries(headers).map(([k, v]) => [k.toLowerCase(), v]));
    const req = { method, url, path: url, body, query, headers: lower, ip: '127.0.0.1', params: {}, get: (h) => lower[h.toLowerCase()] };
    app(req, res, (err) => resolve({ status: 'unhandled', err }));
  });
}

const passthrough = () => (req, res, next) => next();

// ---------- socket.io ----------
class FakeServer {
  constructor() { this.middleware = []; this.handlers = {}; this.rooms = new Map(); this.emitted = []; }
  use(fn) { this.middleware.push(fn); }
  on(ev, fn) { this.handlers[ev] = fn; }
  to(room) { return { emit: (event, data) => this.emitted.push({ room, event, data }) }; }
  in(room) { return { socketsLeave: () => this.rooms.delete(room) }; }
  close() {}
  /** Simulate a client connecting with a token; resolves to a fake socket or rejects. */
  connect(token) {
    const socket = {
      handshake: { auth: { token } }, data: {}, joined: new Set(), handlers: {},
      on: (ev, fn) => { socket.handlers[ev] = fn; },
      join: (room) => { socket.joined.add(room); },
      leave: (room) => { socket.joined.delete(room); },
      call: (ev, payload) => new Promise((resolve) => socket.handlers[ev](payload, resolve)),
    };
    return new Promise((resolve, reject) => {
      let k = 0;
      const next = (err) => {
        if (err) return reject(err);
        const mw = this.middleware[k++];
        if (mw) return mw(socket, next);
        this.handlers.connection(socket);
        return resolve(socket);
      };
      next();
    });
  }
}
let lastServer = null;
const socketIo = { Server: function Server() { lastServer = new FakeServer(); return lastServer; } };

// ---------- install ----------
const STUBS = {
  express,
  helmet: passthrough,
  cors: passthrough,
  'express-rate-limit': { rateLimit: passthrough },
  'socket.io': socketIo,
};

function install() {
  const dir = path.join(__dirname, '__stubs__');
  const origResolve = Module._resolveFilename;
  Module._resolveFilename = function resolve(request, ...rest) {
    if (Object.prototype.hasOwnProperty.call(STUBS, request)) return path.join(dir, `${request}.js`);
    return origResolve.call(this, request, ...rest);
  };
  for (const [name, exp] of Object.entries(STUBS)) {
    const filename = path.join(dir, `${name}.js`);
    const m = new Module(filename);
    m.filename = filename;
    m.loaded = true;
    m.exports = exp;
    require.cache[filename] = m;
  }
}

module.exports = { install, request, lastSocketServer: () => lastServer };
