'use strict';
/**
 * Smoke-renders the driver screens (server-side, React 19) with React Native primitives
 * stubbed as DOM elements. Catches runtime errors in render logic and checks what the
 * driver actually sees, including with REAL trip data from the backend.
 */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');

const MODS = '/opt/npm-tools/node_modules';
const esbuild = require(path.join(MODS, 'esbuild'));
const React = require(path.join(MODS, 'react'));
const { renderToStaticMarkup } = require(path.join(MODS, 'react-dom/server'));
const { translate } = require('../src/i18n/strings');

const OUT = fs.mkdtempSync(path.join(os.tmpdir(), 'drv-render-'));
function load(file) {
  const outfile = path.join(OUT, `${path.basename(file)}.cjs`);
  esbuild.buildSync({
    entryPoints: [path.join(__dirname, '..', file)], bundle: true, outfile, platform: 'node', format: 'cjs',
    loader: { '.js': 'jsx' }, jsx: 'automatic', logLevel: 'silent',
    alias: { 'react-native': path.join(__dirname, 'support/rnStub.js') },
    external: ['react', 'react/jsx-runtime'],
  });
  const Module = require('module');
  const m = new Module(outfile);
  m.paths = [path.join(MODS)];
  m._compile(fs.readFileSync(outfile, 'utf8'), outfile);
  return m.exports;
}
const render = (el) => renderToStaticMarkup(el);
const tt = (lang) => (k, v) => translate(lang, k, v);
const text = (html) => html.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ');

const { TripView } = load('src/screens/TripView.js');
const { TodayList } = load('src/screens/TodayList.js');
const { LoginForm } = load('src/screens/LoginForm.js');
const { SetupChecklist } = load('src/screens/SetupChecklist.js');
const { IncidentSheet, SkipSheet } = load('src/screens/Sheets.js');
const noop = () => {};

const now = Date.parse('2026-11-17T04:00:00Z');
const trip = (over = {}) => ({
  id: 't1', status: 'active', direction: 'to_school', routeName: 'Route 2 - Gikambura', scheduleName: 'Morning pickup', plateNumber: 'KDA 102B',
  stops: [
    { stopId: 's1', sequence: 1, name: 'Gikambura Stage 10', status: 'departed', expected: 3, isSchool: false, riders: [] },
    { stopId: 's2', sequence: 2, name: 'Gikambura Stage 9', status: 'approaching', etaAt: new Date(now + 4 * 60000).toISOString(), expected: 2, canSkip: false, isSchool: false, lat: -1.2, lng: 36.6,
      riders: [
        { studentId: 'a', fullName: 'Amina Wairimu', className: 'Grade 3', absent: false, events: [] },
        { studentId: 'b', fullName: 'Baraka Otieno', className: 'Grade 5', absent: true, events: [] },
        { studentId: 'c', fullName: 'Chebet Kiprop', className: 'Grade 1', absent: false, events: ['boarded'] },
      ] },
    { stopId: 'sch', sequence: 3, name: 'School gate', status: 'pending', expected: 0, isSchool: true, riders: [] },
  ],
  ...over,
});

test('trip screen: next stop, ETA, check-on buttons, absent and boarded children, all-stops list', () => {
  const html = render(React.createElement(TripView, { t: tt('en'), trip: trip(), online: true, pendingPoints: 0, pendingActions: 0, nowMs: now,
    onStopAction: noop, onRiderAction: noop, onNavigate: noop, onReport: noop, onEnd: noop }));
  const s = text(html);
  assert.match(s, /Next stop .*ETA 4 min .*Gikambura Stage 9 .*2 to pick up/);
  assert.match(html, /data-testid="stop-arrived"/);
  assert.match(html, /data-testid="stop-skipped"/);
  assert.match(html, /data-testid="rider-a-boarded"/);
  assert.match(html, /data-testid="rider-a-no_show"/);
  assert.match(s, /Baraka Otieno .*Absent today/);
  assert.match(s, /Chebet Kiprop .*On bus/);
  assert.match(s, /1 of 3 stops/);
  assert.match(s, /Online/);
});

test('trip screen in Kiswahili, offline with a backlog', () => {
  const s = text(render(React.createElement(TripView, { t: tt('sw'), trip: trip(), online: false, pendingPoints: 140, pendingActions: 2, nowMs: now,
    onStopAction: noop, onRiderAction: noop, onNavigate: noop, onReport: noop, onEnd: noop })));
  assert.match(s, /Nje ya mtandao/);
  assert.match(s, /Maeneo 140 yanasubiri kutumwa/);
  assert.match(s, /Vitendo 2 vinasubiri kutumwa/);
  assert.match(s, /Kituo kijacho .*Dakika 4/);
  assert.match(s, /Amepanda/);
});

test('trip screen: all stops done -> big End trip; finished trip -> no actions', () => {
  const done = trip({ stops: trip().stops.map((st) => ({ ...st, status: 'departed' })) });
  const html = render(React.createElement(TripView, { t: tt('en'), trip: done, online: true, nowMs: now, onEnd: noop }));
  assert.match(html, /data-testid="end-trip-main"/);
  const ended = render(React.createElement(TripView, { t: tt('en'), trip: trip({ status: 'completed' }), online: true, nowMs: now }));
  assert.match(text(ended), /This trip has ended/);
  assert.doesNotMatch(ended, /data-testid="stop-arrived"|data-testid="report"/);
});

test('trip screen renders REAL trip data from the backend (field names match the API)', async () => {
  const API = path.join(__dirname, '../../api');
  const { freshDatabase, fakeBroadcaster, quietLogger } = require(path.join(API, 'test/support/context'));
  const { createSettingsService } = require(path.join(API, 'src/services/settingsService'));
  const { createTripService } = require(path.join(API, 'src/services/tripService'));
  const { pool, db } = await freshDatabase('schoolbus_test_driver_render');
  try {
    const trips = createTripService({ db, settings: createSettingsService({ db }), broadcaster: fakeBroadcaster(), logger: quietLogger });
    const driverId = (await db.one("SELECT id FROM users WHERE phone = '+254700000005'")).id;
    const sched = (await db.one("SELECT sc.id FROM schedules sc JOIN routes r ON r.id = sc.route_id WHERE r.name LIKE 'Route 5%' AND sc.direction = 'to_school'")).id;
    const { trip: real } = await trips.startTrip({ scheduleId: sched, driverId });
    const html = render(React.createElement(TripView, { t: tt('en'), trip: real, online: true, nowMs: Date.now(),
      onStopAction: noop, onRiderAction: noop, onNavigate: noop, onReport: noop, onEnd: noop }));
    const s = text(html);
    assert.match(s, /Route 5 - Thogoto/);
    assert.match(s, /Thogoto Stage 10 .*3 to pick up/);
    assert.equal((html.match(/data-testid="rider-[^"]+-boarded"/g) || []).length, 3, 'three children with check-on buttons');
    assert.match(s, /0 of 11 stops/);

    const today = await trips.listDriverToday(driverId);
    const list = text(render(React.createElement(TodayList, { t: tt('en'), schedules: today, onAction: noop, onRefresh: noop })));
    assert.match(list, /06:30 .*Morning pickup .*Resume trip/);
    assert.match(list, /16:00 .*Afternoon drop-off .*30 students .*Start trip/);
  } finally {
    await pool.end();
  }
});

test('today list: empty and finished states', () => {
  assert.match(text(render(React.createElement(TodayList, { t: tt('en'), schedules: [], onAction: noop, onRefresh: noop }))), /No trips assigned to you today/);
  const s = text(render(React.createElement(TodayList, { t: tt('en'), schedules: [{ scheduleId: 'x', startTime: '06:30:00', scheduleName: 'AM', routeName: 'R', students: 3, tripStatus: 'completed', plateNumber: 'KDA 1' }], onAction: noop, onRefresh: noop })));
  assert.match(s, /Finished/);
});

test('login, setup checklist, incident and skip sheets render', () => {
  assert.match(text(render(React.createElement(LoginForm, { t: tt('sw'), onSubmit: noop, error: 'Phone number or PIN is incorrect' }))), /Ingia kama dereva .*Phone number or PIN is incorrect/);
  const setup = render(React.createElement(SetupChecklist, { t: tt('en'), status: { services: true, foreground: true, background: false, battery: false, ready: false }, onFix: noop, onContinue: noop }));
  assert.equal((text(setup).match(/Fix/g) || []).length, 2);
  assert.match(text(setup), /Allow all the time/);
  const inc = text(render(React.createElement(IncidentSheet, { t: tt('en'), visible: true, onClose: noop, onSend: noop })));
  for (const label of ['Heavy traffic', 'Bus breakdown', 'Accident', 'Bad weather', 'Road closed', 'Other']) assert.ok(inc.includes(label), label);
  assert.equal(render(React.createElement(IncidentSheet, { t: tt('en'), visible: false, onClose: noop, onSend: noop })), '');
  assert.match(text(render(React.createElement(SkipSheet, { t: tt('sw'), visible: true, stop: { name: 'Stage 4' }, onClose: noop, onSkip: noop }))), /Stage 4 .*Barabara imefungwa/);
});
