/**
 * In-browser mock of the school-bus API for `npm run demo` and the clickable preview.
 * Same paths and response shapes as the real backend (docs/api.md), seeded like
 * apps/api/db/seeds/dev_seed.sql, with the current run in progress and buses that move.
 */
import { TZ_OFFSET, todayLocal } from '../lib/format.js';

const AREAS = ['Kikuyu Town', 'Gikambura', 'Kinoo', 'Muguga', 'Thogoto', 'Zambezi'];
const FIRST = ['Amani', 'Wanjiru', 'Achieng', 'Njeri', 'Otieno', 'Muthoni', 'Kamau', 'Wambui', 'Omondi', 'Chebet', 'Kiptoo', 'Akinyi', 'Mwangi', 'Nyambura', 'Baraka', 'Imani', 'Zawadi', 'Neema', 'Jabari', 'Faith', 'Brian', 'Mercy', 'Kevin', 'Sharon', 'Dennis', 'Joy', 'Ian', 'Tracy', 'Victor', 'Wairimu'];
const LAST = ['Kamau', 'Otieno', 'Mwangi', 'Wanjiku', 'Kiprono', 'Achieng', 'Njoroge', 'Ochieng', 'Wafula', 'Mutua', 'Kariuki', 'Chepkoech', 'Onyango', 'Gitau', 'Kimani', 'Muriuki', 'Odhiambo', 'Waweru', 'Koech', 'Nyaga'];
const ADULT = ['Grace', 'Joseph', 'Mary', 'Peter', 'Jane', 'John', 'Esther', 'David', 'Lucy', 'James', 'Ruth', 'Samuel', 'Beatrice', 'Daniel', 'Agnes', 'Paul'];
const DRIVER = ['Josphat Mburu', 'Kennedy Ouma', 'Francis Kiplagat', 'Stephen Njuguna', 'Moses Wekesa', 'Patrick Kilonzo'];
const SCHOOL = { lat: -1.2463, lng: 36.6629 };

let seq = 0;
const uid = (p) => `${p}-${(seq += 1).toString(36)}-${Math.random().toString(36).slice(2, 6)}`;
const iso = (ms) => new Date(ms).toISOString();
const err = (status, code, message, details) => Object.assign(new Error(message), { status, code, details, retryable: status >= 500 });
const clone = (x) => JSON.parse(JSON.stringify(x));
const at = (n, km) => ({
  lat: +(SCHOOL.lat + (km / 111) * Math.cos((n * 60 * Math.PI) / 180)).toFixed(6),
  lng: +(SCHOOL.lng + (km / 111) * Math.sin((n * 60 * Math.PI) / 180)).toFixed(6),
});
const localTime = (ms) => new Intl.DateTimeFormat('en-GB', { timeZone: 'Africa/Nairobi', hour: '2-digit', minute: '2-digit', hour12: false }).format(ms);

export function createMockServer({ now = () => Date.now() } = {}) {
  const t0 = now();
  const today = todayLocal(t0);
  const hour = Number(localTime(t0).slice(0, 2));
  const morningNow = hour < 12;
  const db = { buses: [], drivers: [], routes: [], schedules: [], stops: [], students: [], guardians: [], links: [], assign: [], trips: [], incidents: [], notifications: [], days: [], audit: [], positions: {} };
  const settings = {
    school_name: 'Greenfield Academy', timezone: 'Africa/Nairobi', sms_sender_id: 'GREENFIELD', default_approach_minutes: 5, default_stop_radius_m: 120,
    delay_threshold_minutes: 10, delay_escalation_minutes: [10, 20, 30], stalled_minutes: 8, stalled_radius_m: 50, not_started_grace_minutes: 10,
    stale_point_max_age_s: 120, location_retention_days: 90, critical_events_force_sms: true,
  };
  const admin = { id: 'admin-1', role: 'admin', fullName: 'Lucy Wairimu' };
  const audit = (action, entity, entityId, changes = null) => db.audit.unshift({ id: uid('a'), actorId: admin.id, actorName: admin.fullName, action, entity, entityId, changes, createdAt: iso(now()) });

  // ---------- seed ----------
  AREAS.forEach((area, i) => {
    const n = i + 1;
    const bus = { id: uid('bus'), plateNumber: `KD${'ABCDEF'[i]} ${100 + n * 37}${'XYZQRS'[i]}`, capacity: 33, isActive: true };
    const drv = { id: uid('drv'), fullName: DRIVER[i], phone: `+2547${String(10000000 + n * 1234567).slice(0, 8)}`, isActive: true, lastLoginAt: iso(t0 - (i + 1) * 3600e3), licenceNumber: null, deviceRegistered: i !== 5 };
    const route = { id: uid('route'), name: `Route ${n} - ${area}`, description: `Serves ${area}`, defaultBusId: bus.id, defaultDriverId: drv.id, isActive: true };
    db.buses.push(bus); db.drivers.push(drv); db.routes.push(route);
    for (const dir of ['to_school', 'from_school']) {
      const am = dir === 'to_school';
      const sc = { id: uid('sch'), routeId: route.id, name: am ? 'Morning pickup' : 'Afternoon drop-off', direction: dir, daysOfWeek: [1, 2, 3, 4, 5], startTime: am ? '06:30:00' : '16:00:00', isActive: true };
      db.schedules.push(sc);
      for (let seqNo = 1; seqNo <= 11; seqNo += 1) {
        const k = am ? 11 - seqNo : seqNo - 1; // physical stage (0 = school)
        const isSchool = k === 0;
        const mins = am ? (seqNo - 1) * 6 : (seqNo - 1) * 6;
        const [hh, mm] = am ? [6, 30 + mins] : [16, mins];
        db.stops.push({
          id: uid('stop'), scheduleId: sc.id, sequence: seqNo, name: isSchool ? 'School gate' : `${area} Stage ${k}`, landmark: null,
          ...(isSchool ? SCHOOL : at(n, k * 0.6)), radiusM: 120, approachMinutes: 5,
          scheduledTime: `${String(hh + Math.floor(mm / 60)).padStart(2, '0')}:${String(mm % 60).padStart(2, '0')}:00`, isSchool, isActive: true,
        });
      }
    }
  });
  for (let i = 1; i <= 180; i += 1) {
    const routeIdx = Math.floor((i - 1) / 30);
    const stage = Math.floor(((i - 1) % 30) / 3) + 1;
    const household = i % 6 === 0 ? i - 1 : i;
    const last = LAST[(household * 7) % LAST.length];
    const s = { id: uid('stu'), admissionNo: `ADM${String(i).padStart(4, '0')}`, fullName: `${FIRST[(i * 11) % FIRST.length]} ${last}`, className: `Grade ${(i % 6) + 1}`, isActive: true, notes: null };
    db.students.push(s);
    let g = db.guardians.find((x) => x.household === household);
    if (!g) {
      g = { id: uid('gdn'), household, fullName: `${ADULT[household % ADULT.length]} ${last}`, phone: `+254711${String(household).padStart(6, '0')}`, isActive: true, channelMode: household % 5 === 0 ? 'sms' : 'push_then_sms', preferredLanguage: household % 4 === 0 ? 'sw' : 'en', consentAt: iso(t0 - 20 * 86400e3), hasApp: household % 5 !== 0 };
      db.guardians.push(g);
    }
    db.links.push({ studentId: s.id, guardianId: g.id, relationship: household % 2 ? 'mother' : 'father', isPrimary: true, receivesAlerts: true });
    const route = db.routes[routeIdx];
    for (const sc of db.schedules.filter((x) => x.routeId === route.id)) {
      const stop = db.stops.find((x) => x.scheduleId === sc.id && x.name === `${AREAS[routeIdx]} Stage ${stage}`);
      db.assign.push({ studentId: s.id, scheduleId: sc.id, stopId: stop.id });
    }
  }

  // ---------- today's trips: the current run in progress ----------
  // progress = stops done; lateMin shifts the schedule so the trip runs behind.
  const scenario = [
    { progress: 6, lateMin: 2 }, { progress: 9, lateMin: 0 }, { progress: 4, lateMin: 14 },
    { progress: 2, lateMin: 1 }, { progress: 5, lateMin: 3, gpsStaleMin: 6 }, { progress: 11, lateMin: 0 },
  ];
  const tripStops = new Map();
  db.routes.forEach((route, i) => {
    for (const sc of db.schedules.filter((x) => x.routeId === route.id)) {
      const current = (sc.direction === 'to_school') === morningNow;
      const sStops = db.stops.filter((x) => x.scheduleId === sc.id).sort((a, b) => a.sequence - b.sequence);
      const sc0 = scenario[i];
      let status = 'scheduled';
      let startMs;
      if (current) {
        // Planned start P; the bus left lateMin after P and has now done `progress` stops.
        // Stop k is due at P + 6k min, so the next stop is due lateMin before the bus gets there.
        startMs = t0 - (sc0.progress * 6 + sc0.lateMin) * 60000;
        status = sc0.progress >= 11 ? 'completed' : 'active';
        sStops.forEach((st, k) => { st.scheduledTime = `${localTime(startMs + k * 6 * 60000)}:00`; });
        sc.startTime = sStops[0].scheduledTime;
      } else if (!morningNow) {
        status = 'completed';
        startMs = new Date(`${today}T06:31:00${TZ_OFFSET}`).getTime();
      } else {
        startMs = new Date(`${today}T16:00:00${TZ_OFFSET}`).getTime();
      }
      const trip = {
        id: uid('trip'), scheduleId: sc.id, serviceDate: today, busId: route.defaultBusId, driverId: route.defaultDriverId, status,
        scheduledStartAt: iso(startMs), startedAt: status === 'scheduled' ? null : iso(current ? startMs + sc0.lateMin * 60000 : startMs),
        endedAt: status === 'completed' ? iso(startMs + 66 * 60000) : null, distanceM: status === 'completed' ? 7200 + i * 340 : null, cancelledReason: null,
      };
      db.trips.push(trip);
      const states = sStops.map((st, k) => {
        const done = status === 'completed' || (status === 'active' && k < sc0.progress);
        const arrived = status === 'active' && k === sc0.progress && k % 2 === 0;
        return {
          stopId: st.id, status: done ? 'departed' : arrived ? 'arrived' : status === 'active' && k === sc0.progress ? 'approaching' : 'pending',
          etaAt: status === 'active' && !done ? iso(t0 + ((k - sc0.progress) * 6 + 1 + i) * 60000) : null,
          arrivedAt: done || arrived ? iso(startMs + (sc0.lateMin + k * 6) * 60000) : null, departedAt: done ? iso(startMs + (sc0.lateMin + k * 6 + 1) * 60000) : null, skippedReason: null,
        };
      });
      if (status === 'active' && i === 0) { states[3].status = 'skipped'; states[3].skippedReason = 'No children waiting'; }
      tripStops.set(trip.id, states);
      if (status === 'active') {
        const prev = sStops[Math.max(0, sc0.progress - 1)];
        const next = sStops[Math.min(10, sc0.progress)];
        db.positions[trip.id] = { lat: (prev.lat + next.lat) / 2, lng: (prev.lng + next.lng) / 2, speedMps: 7.5, headingDeg: 300, positionAt: iso(t0 - (sc0.gpsStaleMin || 0) * 60000 - 4000), frac: 0.5 };
      }
    }
  });
  const activeTrips = () => db.trips.filter((t) => t.status === 'active');
  const tripByRoute = (n) => db.trips.find((t) => t.status === 'active' && db.schedules.find((s) => s.id === t.scheduleId).routeId === db.routes[n].id);
  if (tripByRoute(4)) db.incidents.push({ id: uid('inc'), tripId: tripByRoute(4).id, type: 'gps_lost', severity: 'medium', note: `No GPS from ${db.buses[4].plateNumber} (${db.routes[4].name}) for 6 min. Driver app may be closed or phone offline.`, lat: null, lng: null, notifyParents: false, createdAt: iso(t0 - 60000), resolvedAt: null, autoDetected: true, reportedBy: null });
  if (tripByRoute(2)) db.incidents.push({ id: uid('inc'), tripId: tripByRoute(2).id, type: 'traffic', severity: 'medium', note: 'Jam at the Kinoo footbridge', lat: null, lng: null, notifyParents: true, createdAt: iso(t0 - 9 * 60000), resolvedAt: null, autoDetected: false, reportedBy: db.drivers[2].id });
  db.days.push({ serviceDate: (() => { const d = new Date(t0 + 9 * 86400e3); return todayLocal(d.getTime()); })(), reason: 'Mid-term break', createdAt: iso(t0 - 5 * 86400e3) });

  const EVENTS = ['approaching', 'arrived', 'boarded', 'approaching', 'delay', 'dropped_off'];
  for (let i = 0; i < 64; i += 1) {
    const g = db.guardians[(i * 13) % db.guardians.length];
    const ev = EVENTS[i % EVENTS.length];
    const channel = g.channelMode === 'sms' || i % 3 === 0 ? 'sms' : 'push';
    const status = i % 23 === 7 ? 'failed' : i % 31 === 5 ? 'skipped' : channel === 'sms' && i % 2 ? 'delivered' : 'sent';
    db.notifications.push({
      id: uid('n'), eventType: ev, channel, status, toAddress: channel === 'sms' ? g.phone : 'fcm-token', guardianId: g.id, guardianName: g.fullName,
      body: ev === 'delay' ? 'Bus KDC 211Z is running about 14 min late. We\'ll keep you updated. -Greenfield Academy' : ev === 'boarded' ? `${g.fullName.split(' ')[1]} boarded bus KDA 137X at Kikuyu Town Stage 4. -Greenfield Academy` : 'Bus KDA 137X is about 5 min from Kikuyu Town Stage 6. -Greenfield Academy',
      error: status === 'failed' ? '403 InvalidPhoneNumber' : status === 'skipped' ? 'quiet_hours' : null, costKes: channel === 'sms' && status !== 'skipped' && status !== 'failed' ? 0.8 : null,
      createdAt: iso(t0 - i * 97000), sentAt: iso(t0 - i * 97000 + 3000), deliveredAt: status === 'delivered' ? iso(t0 - i * 97000 + 9000) : null,
    });
  }
  audit('student.import_csv', 'students', null, { summary: [null, { studentsCreated: 180 }] });
  audit('driver.device_bound', 'drivers', db.drivers[0].id);

  // ---------- read models ----------
  const scheduleOf = (t) => db.schedules.find((s) => s.id === t.scheduleId);
  const routeOf = (t) => db.routes.find((r) => r.id === scheduleOf(t).routeId);
  const busOf = (t) => db.buses.find((b) => b.id === t.busId);
  const driverOf = (t) => db.drivers.find((d) => d.id === t.driverId);
  function tripSummary(t) {
    const st = tripStops.get(t.id) || [];
    return {
      id: t.id, status: t.status, serviceDate: t.serviceDate, scheduledStartAt: t.scheduledStartAt, startedAt: t.startedAt, endedAt: t.endedAt, distanceM: t.distanceM,
      cancelledReason: t.cancelledReason, scheduleName: scheduleOf(t).name, direction: scheduleOf(t).direction, routeName: routeOf(t).name,
      plateNumber: busOf(t).plateNumber, driverName: driverOf(t).fullName,
      stopsDone: st.filter((s) => s.status === 'arrived' || s.status === 'departed').length, stopsTotal: st.length,
    };
  }
  function tripDetail(t) {
    const states = tripStops.get(t.id);
    const stops = db.stops.filter((s) => s.scheduleId === t.scheduleId).sort((a, b) => a.sequence - b.sequence).map((s) => {
      const state = states.find((x) => x.stopId === s.id);
      const riders = db.assign.filter((a) => a.stopId === s.id).map((a) => db.students.find((x) => x.id === a.studentId))
        .map((x, j) => ({ studentId: x.id, fullName: x.fullName, className: x.className, absent: j === 2 && s.sequence === 4, events: state.status === 'departed' ? ['boarded'] : [] }));
      return {
        stopId: s.id, sequence: s.sequence, name: s.name, lat: s.lat, lng: s.lng, scheduledTime: s.scheduledTime, isSchool: s.isSchool,
        assigned: riders.length, absent: riders.filter((r) => r.absent).length, expected: riders.filter((r) => !r.absent).length, canSkip: false, ...state, riders,
      };
    });
    const { stopsDone, stopsTotal, ...sum } = tripSummary(t); // the real detail has no counters
    return { ...sum, scheduleId: t.scheduleId, driverId: t.driverId, busId: t.busId, stops };
  }

  // ---------- live simulation ----------
  const listeners = new Set();
  function tick() {
    for (const t of activeTrips()) {
      const pos = db.positions[t.id];
      const states = tripStops.get(t.id);
      if (!pos || states.every((s) => s.status === 'departed' || s.status === 'skipped')) continue;
      const routeIdx = db.routes.indexOf(routeOf(t));
      if (scenario[routeIdx].gpsStaleMin) continue; // this bus has "lost GPS"
      const stops = db.stops.filter((s) => s.scheduleId === t.scheduleId).sort((a, b) => a.sequence - b.sequence);
      const i = states.findIndex((s) => s.status !== 'departed' && s.status !== 'skipped');
      const changed = [];
      if (states[i].status === 'arrived') {
        states[i].status = 'departed'; states[i].departedAt = iso(now()); changed.push(states[i]);
        if (i + 1 < states.length) { states[i + 1].status = 'approaching'; changed.push(states[i + 1]); }
        pos.frac = 0;
      } else {
        pos.frac = Math.min(1, (pos.frac || 0) + 0.34);
        if (pos.frac >= 1) { states[i].status = 'arrived'; states[i].arrivedAt = iso(now()); changed.push(states[i]); }
      }
      const prev = stops[Math.max(0, i - 1)]; const next = stops[i];
      Object.assign(pos, { lat: prev.lat + (next.lat - prev.lat) * pos.frac, lng: prev.lng + (next.lng - prev.lng) * pos.frac, positionAt: iso(now()) });
      if (states.every((s) => s.status === 'departed' || s.status === 'skipped' || s.status === 'arrived') && i === states.length - 1 && states[i].status === 'arrived') {
        t.status = 'completed'; t.endedAt = iso(now()); delete db.positions[t.id];
        listeners.forEach((h) => h.ended?.({ tripId: t.id, status: 'completed' }));
        continue;
      }
      listeners.forEach((h) => {
        h.location?.({ tripId: t.id, busId: t.busId, lat: pos.lat, lng: pos.lng, speedMps: 7.5, headingDeg: 300, recordedAt: pos.positionAt });
        if (changed.length) h.stops?.({ tripId: t.id, stops: changed.map((c) => ({ ...c })) });
      });
    }
  }
  function connectRealtime(handlers) {
    listeners.add(handlers);
    handlers.status?.(true);
    const timer = setInterval(tick, 4000);
    return () => { clearInterval(timer); listeners.delete(handlers); };
  }

  // ---------- request routing ----------
  const page = (items, q) => { const limit = Number(q.limit || 50); const offset = Number(q.offset || 0); return { total: items.length, limit, offset, items: items.slice(offset, offset + limit) }; };
  const like = (s, q) => !q || String(s).toLowerCase().includes(String(q).toLowerCase());
  const byId = (arr, id, what) => { const x = arr.find((y) => y.id === id); if (!x) throw err(404, 'not_found', `${what} not found`); return x; };

  const routes = [
    ['POST', '/auth/admin/login', (_, b) => { if (b.password !== 'demo' && b.password !== 'ChangeMe!2026') throw err(401, 'invalid_credentials', 'Email or password is incorrect'); return { accessToken: 'demo', refreshToken: 'demo-refresh', user: admin }; }],
    ['POST', '/auth/logout', () => ({ ok: true })],
    ['GET', '/admin/trips', (q) => ({ trips: db.trips.filter((t) => t.serviceDate === (q.date || today)).map(tripSummary).sort((a, b) => a.scheduledStartAt.localeCompare(b.scheduledStartAt)) })],
    ['GET', '/admin/trips/:id', (q, b, p) => tripDetail(byId(db.trips, p.id, 'Trip'))],
    ['PATCH', '/admin/trips/:id', (q, b, p) => { const t = byId(db.trips, p.id, 'Trip'); if (t.status !== 'scheduled') throw err(409, 'trip_not_scheduled', 'Only trips that have not started can be reassigned'); Object.assign(t, b.busId ? { busId: b.busId } : {}, b.driverId ? { driverId: b.driverId } : {}); audit('trip.reassign', 'trips', t.id); return t; }],
    ['POST', '/admin/trips/:id/cancel', (q, b, p) => { const t = byId(db.trips, p.id, 'Trip'); if (!['scheduled', 'active'].includes(t.status)) throw err(409, 'trip_not_cancellable', `This trip is already ${t.status}`); t.status = 'cancelled'; t.cancelledReason = b.reason; delete db.positions[t.id]; audit('trip.cancel', 'trips', t.id, { reason: [null, b.reason] }); listeners.forEach((h) => h.ended?.({ tripId: t.id, status: 'cancelled' })); return { id: t.id, status: t.status }; }],
    ['GET', '/admin/fleet', () => ({ buses: activeTrips().filter((t) => db.positions[t.id]).map((t) => ({ tripId: t.id, routeName: routeOf(t).name, plateNumber: busOf(t).plateNumber, driverName: driverOf(t).fullName, ...db.positions[t.id] })) })],
    ['GET', '/admin/incidents', (q) => ({ incidents: db.incidents.filter((i) => (q.open === true || q.open === 'true' ? !i.resolvedAt : true)).map((i) => { const t = db.trips.find((x) => x.id === i.tripId); return { ...i, routeName: routeOf(t).name, plateNumber: busOf(t).plateNumber, reportedByName: i.reportedBy ? db.drivers.find((d) => d.id === i.reportedBy)?.fullName : null }; }) })],
    ['POST', '/admin/incidents/:id/resolve', (q, b, p) => { const i = byId(db.incidents, p.id, 'Issue'); if (i.resolvedAt) throw err(404, 'not_found', 'Open incident not found'); i.resolvedAt = iso(now()); audit('incident.resolve', 'incidents', i.id); return i; }],
    ['GET', '/admin/notifications/summary', (q) => {
      const rows = db.notifications.filter((n) => !q.date || todayLocal(new Date(n.createdAt).getTime()) === q.date);
      const map = new Map();
      for (const n of rows) { const k = `${n.channel}|${n.status}`; const r = map.get(k) || { channel: n.channel, status: n.status, count: 0, costKes: 0 }; r.count += 1; r.costKes += n.costKes || 0; map.set(k, r); }
      return { date: q.date || null, total: rows.length, smsCostKes: +rows.reduce((a, n) => a + (n.channel === 'sms' ? n.costKes || 0 : 0), 0).toFixed(2), breakdown: [...map.values()] };
    }],
    ['GET', '/admin/notifications', (q) => ({ notifications: db.notifications.filter((n) => !q.status || n.status === q.status).slice(0, Number(q.limit || 100)).map(({ guardianId, ...n }) => n) })],
    ['POST', '/admin/notifications/:id/retry', (q, b, p) => { const n = byId(db.notifications, p.id, 'Notification'); if (n.status !== 'failed') throw err(409, 'not_retryable', 'Only failed notifications can be retried'); n.status = 'queued'; n.error = null; return n; }],
    ['GET', '/admin/students', (q) => page(db.students.filter((s) => like(s.fullName, q.search) || like(s.admissionNo, q.search)).sort((a, b) => a.fullName.localeCompare(b.fullName)), q)],
    ['GET', '/admin/students/:id', (q, b, p) => {
      const s = byId(db.students, p.id, 'Student');
      const guardians = db.links.filter((l) => l.studentId === s.id).map((l) => { const g = db.guardians.find((x) => x.id === l.guardianId); return { id: g.id, fullName: g.fullName, phone: g.phone, relationship: l.relationship, isPrimary: l.isPrimary, receivesAlerts: l.receivesAlerts }; });
      const stops = db.assign.filter((a) => a.studentId === s.id).map((a) => { const sc = db.schedules.find((x) => x.id === a.scheduleId); return { scheduleId: sc.id, scheduleName: sc.name, direction: sc.direction, routeName: db.routes.find((r) => r.id === sc.routeId).name, stopId: a.stopId, stopName: db.stops.find((x) => x.id === a.stopId).name }; });
      return { ...s, guardians, stops };
    }],
    ['POST', '/admin/students', (q, b) => { if (db.students.some((s) => s.admissionNo === b.admissionNo)) throw err(409, 'already_exists', 'A record with these details already exists'); const s = { id: uid('stu'), isActive: true, notes: null, ...b }; db.students.push(s); audit('student.create', 'students', s.id); return s; }],
    ['PATCH', '/admin/students/:id', (q, b, p) => { const s = byId(db.students, p.id, 'Student'); Object.assign(s, b); audit('student.update', 'students', s.id); return s; }],
    ['PUT', '/admin/students/:id/guardians', (q, b, p) => { db.links = db.links.filter((l) => !(l.studentId === p.id && l.guardianId === b.guardianId)); db.links.push({ studentId: p.id, ...b }); audit('student.link_guardian', 'students', p.id); return b; }],
    ['DELETE', '/admin/students/:id/guardians/:gid', (q, b, p) => { db.links = db.links.filter((l) => !(l.studentId === p.id && l.guardianId === p.gid)); audit('student.unlink_guardian', 'students', p.id); return { deleted: true }; }],
    ['PUT', '/admin/students/:id/stops', (q, b, p) => { db.assign = db.assign.filter((a) => !(a.studentId === p.id && a.scheduleId === b.scheduleId)); db.assign.push({ studentId: p.id, ...b }); audit('student.assign_stop', 'students', p.id); return b; }],
    ['DELETE', '/admin/students/:id/stops/:sid', (q, b, p) => { db.assign = db.assign.filter((a) => !(a.studentId === p.id && a.scheduleId === p.sid)); audit('student.unassign_stop', 'students', p.id); return { deleted: true }; }],
    ['POST', '/admin/import/students', (q, csv) => {
      const lines = String(csv).trim().split(/\r?\n/);
      const errors = [];
      lines.slice(1).forEach((l, i) => { const c = l.split(','); if (!c[0] || !c[1]) errors.push({ line: i + 2, field: 'admission_no', message: 'Required' }); if (c[4] && !/^(\+?254|0)?[17]\d{8}$/.test(c[4].replace(/\s/g, ''))) errors.push({ line: i + 2, field: 'guardian_phone', message: `"${c[4]}" is not a valid Kenyan mobile number` }); });
      if (errors.length) throw err(422, 'import_failed', 'Import has errors', errors);
      return q.dryRun === true || q.dryRun === 'true' ? { ok: true, dryRun: true, rows: lines.length - 1, errors: [], warnings: [] } : { ok: true, dryRun: false, rows: lines.length - 1, errors: [], warnings: [], summary: { studentsCreated: lines.length - 1, studentsUpdated: 0, guardiansCreated: lines.length - 1, links: lines.length - 1, assignments: 0 } };
    }],
    ['GET', '/admin/guardians', (q) => page(db.guardians.filter((g) => like(g.fullName, q.search) || like(g.phone, q.search)).map((g) => ({ ...g, children: db.links.filter((l) => l.guardianId === g.id).map((l) => ({ studentId: l.studentId, fullName: db.students.find((s) => s.id === l.studentId).fullName, relationship: l.relationship })) })).sort((a, b) => a.fullName.localeCompare(b.fullName)), q)],
    ['POST', '/admin/guardians', (q, b) => { const g = { id: uid('gdn'), isActive: true, hasApp: false, consentAt: null, channelMode: 'push_then_sms', preferredLanguage: 'en', ...b }; db.guardians.push(g); audit('guardian.create', 'users', g.id); return g; }],
    ['PATCH', '/admin/guardians/:id', (q, b, p) => { const g = byId(db.guardians, p.id, 'Guardian'); Object.assign(g, b); audit('guardian.update', 'users', g.id); return g; }],
    ['GET', '/admin/drivers', () => ({ items: db.drivers.map((d) => ({ ...d, routes: db.routes.filter((r) => r.defaultDriverId === d.id).map((r) => r.name).join(', ') || null })) })],
    ['POST', '/admin/drivers', (q, b) => { const d = { id: uid('drv'), fullName: b.fullName, phone: b.phone, isActive: true, lastLoginAt: null, deviceRegistered: false }; db.drivers.push(d); audit('driver.create', 'users', d.id); return d; }],
    ['POST', '/admin/drivers/:id/reset-pin', (q, b, p) => { byId(db.drivers, p.id, 'Driver'); audit('driver.reset_pin', 'users', p.id); return { ok: true }; }],
    ['POST', '/admin/drivers/:id/reset-device', (q, b, p) => { byId(db.drivers, p.id, 'Driver').deviceRegistered = false; audit('driver.reset_device', 'drivers', p.id); return { ok: true }; }],
    ['GET', '/admin/routes', (q) => page(db.routes, q)],
    ['POST', '/admin/routes', (q, b) => { const r = { id: uid('route'), description: null, defaultBusId: null, defaultDriverId: null, isActive: true, ...b }; db.routes.push(r); return r; }],
    ['PATCH', '/admin/routes/:id', (q, b, p) => Object.assign(byId(db.routes, p.id, 'Route'), b)],
    ['GET', '/admin/schedules', (q) => page(db.schedules.filter((s) => !q.routeId || s.routeId === q.routeId), q)],
    ['POST', '/admin/schedules', (q, b) => { const s = { id: uid('sch'), isActive: true, ...b, startTime: `${b.startTime}:00` }; db.schedules.push(s); return s; }],
    ['GET', '/admin/stops', (q) => page(db.stops.filter((s) => !q.scheduleId || s.scheduleId === q.scheduleId).sort((a, b) => a.sequence - b.sequence), q)],
    ['POST', '/admin/stops', (q, b) => { const s = { id: uid('stop'), isSchool: false, isActive: true, sequence: db.stops.filter((x) => x.scheduleId === b.scheduleId).length + 1, ...b }; db.stops.push(s); return s; }],
    ['PATCH', '/admin/stops/:id', (q, b, p) => Object.assign(byId(db.stops, p.id, 'Stop'), b)],
    ['DELETE', '/admin/stops/:id', (q, b, p) => { if (db.trips.some((t) => (tripStops.get(t.id) || []).some((s) => s.stopId === p.id))) throw err(409, 'reference_error', 'This record references (or is referenced by) another record'); db.stops = db.stops.filter((s) => s.id !== p.id); return { id: p.id, deleted: true }; }],
    ['PUT', '/admin/schedules/:id/stop-order', (q, b, p) => { b.stopIds.forEach((id, i) => { byId(db.stops, id, 'Stop').sequence = i + 1; }); audit('route.reorder_stops', 'schedules', p.id); return db.stops.filter((s) => s.scheduleId === p.id).sort((a, c) => a.sequence - c.sequence); }],
    ['GET', '/admin/schedule-load', () => ({ schedules: db.schedules.map((s) => { const r = db.routes.find((x) => x.id === s.routeId); const bus = db.buses.find((x) => x.id === r.defaultBusId); const n = db.assign.filter((a) => a.scheduleId === s.id).length; return { scheduleId: s.id, routeName: r.name, scheduleName: s.name, plateNumber: bus?.plateNumber, capacity: bus?.capacity ?? null, assignedStudents: n, overCapacity: n > (bus?.capacity ?? 0) }; }) })],
    ['GET', '/admin/buses', (q) => page(db.buses.filter((b) => q.isActive === undefined || String(b.isActive) === String(q.isActive)), q)],
    ['POST', '/admin/buses', (q, b) => { const x = { id: uid('bus'), isActive: true, capacity: 33, ...b }; db.buses.push(x); return x; }],
    ['PATCH', '/admin/buses/:id', (q, b, p) => Object.assign(byId(db.buses, p.id, 'Bus'), b)],
    ['GET', '/admin/no-service-days', () => ({ days: [...db.days].sort((a, b) => a.serviceDate.localeCompare(b.serviceDate)) })],
    ['POST', '/admin/no-service-days', (q, b) => { if (db.days.some((d) => d.serviceDate === b.date)) throw err(409, 'already_exists', 'That day is already marked as no service'); db.days.push({ serviceDate: b.date, reason: b.reason, createdAt: iso(now()) }); audit('calendar.no_service', 'no_service_days', b.date); return { date: b.date, reason: b.reason, cancelledTrips: 0, parentsNotified: false }; }],
    ['DELETE', '/admin/no-service-days/:date', (q, b, p) => { db.days = db.days.filter((d) => d.serviceDate !== p.date); return { deleted: true }; }],
    ['GET', '/admin/reports', (q) => {
      const days = []; let d = q.from || todayLocal(t0 - 29 * 86400e3); const to = q.to || today;
      let k = 0;
      while (d <= to && k < 400) { const dow = new Date(`${d}T12:00:00${TZ_OFFSET}`).getUTCDay(); if (dow !== 0 && dow !== 6) days.push(d); d = todayLocal(new Date(`${d}T12:00:00${TZ_OFFSET}`).getTime() + 86400e3); k += 1; }
      const byDay = days.map((date, i) => { const cancelled = i % 11 === 4 ? 1 : 0; const completed = 12 - cancelled; const late = (i * 7) % 3; return { date, trips: 12, completed, cancelled, onTime: completed - late, delayed: late, onTimePct: Math.round(((completed - late) / completed) * 100), avgStartLateMin: 3, distanceM: 90000 }; });
      const sum = (key) => byDay.reduce((a, x) => a + x[key], 0);
      const totals = { trips: sum('trips'), completed: sum('completed'), cancelled: sum('cancelled'), onTime: sum('onTime'), delayed: sum('delayed'), avgStartLateMin: 3, distanceM: sum('distanceM') };
      totals.onTimePct = totals.completed ? Math.round((totals.onTime / totals.completed) * 100) : null;
      const byRoute = db.routes.map((r, i) => { const trips = days.length * 2; const delayed = Math.round(trips * [0.04, 0.06, 0.21, 0.05, 0.09, 0.02][i]); const cancelled = i === 2 ? 2 : 0; const completed = trips - cancelled; return { routeId: r.id, routeName: r.name, trips, completed, cancelled, delayed, onTime: completed - delayed, onTimePct: Math.round(((completed - delayed) / completed) * 100), avgStartLateMin: [2, 3, 8, 2, 4, 1][i], distanceM: trips * (7200 + i * 340) }; });
      return { from: q.from || days[0], to, totals, byRoute, byDay, incidents: [{ type: 'traffic', count: 14 }, { type: 'gps_lost', count: 5 }, { type: 'not_started', count: 2 }, { type: 'breakdown', count: 1 }], notifications: { smsSent: 2280, pushSent: 6110, failed: 37, smsCostKes: 1824 } };
    }],
    ['GET', '/admin/settings', () => clone(settings)],
    ['PATCH', '/admin/settings', (q, b) => { for (const [k, v] of Object.entries(b)) { if (k === 'default_approach_minutes' && (v < 1 || v > 30)) throw err(400, 'invalid_setting', `Invalid value for "${k}"`, [{ message: 'Must be between 1 and 30' }]); settings[k] = v; } audit('settings.update', 'app_settings', null, Object.fromEntries(Object.keys(b).map((k) => [k, [null, b[k]]]))); return clone(settings); }],
    ['GET', '/admin/audit-logs', () => ({ entries: db.audit.slice(0, 200) })],
  ];

  function match(pattern, path) {
    const p = pattern.split('/').filter(Boolean); const a = path.split('/').filter(Boolean);
    if (p.length !== a.length) return null;
    const params = {};
    for (let i = 0; i < p.length; i += 1) { if (p[i].startsWith(':')) params[p[i].slice(1)] = a[i]; else if (p[i] !== a[i]) return null; }
    return params;
  }

  async function request(method, path, opts = {}) {
    await new Promise((r) => setTimeout(r, 120)); // feel like a network
    for (const [m, pattern, fn] of routes) {
      if (m !== method) continue;
      const params = match(pattern, path);
      if (params) return clone(fn(opts.query || {}, opts.body, params));
    }
    throw err(404, 'route_not_found', `No route for ${method} ${path}`);
  }

  const api = {
    request,
    get: (p, o) => request('GET', p, o),
    post: (p, body, o) => request('POST', p, { ...o, body }),
    put: (p, body, o) => request('PUT', p, { ...o, body }),
    patch: (p, body, o) => request('PATCH', p, { ...o, body }),
    del: (p, o) => request('DELETE', p, o),
    accessToken: async () => 'demo',
    refresh: async () => 'demo',
  };
  return { api, connectRealtime, db, tick };
}
