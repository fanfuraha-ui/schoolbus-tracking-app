'use strict';
/**
 * Notification worker: three loops that never overlap with themselves.
 *   outbox   every 2 s   trip_events -> per-guardian notification rows
 *   sender   every 2 s   send due push/SMS (retries, fallback, batching)
 *   monitors every 60 s  planner, delays, not-started, GPS lost, stalled, nightly maintenance
 * Safe to run more than one instance (row claims + advisory locks).
 */
const { createOutboxProcessor } = require('./notifications/outbox');
const { createSender } = require('./notifications/sender');
const { createMonitors } = require('./monitors');

function createWorker({ db, settings, sms, push, logger, intervals = {} }) {
  const outbox = createOutboxProcessor({ db, settings, logger });
  const sender = createSender({ db, sms, push, logger });
  const monitors = createMonitors({ db, settings, logger });
  const every = { outboxMs: 2000, senderMs: 2000, monitorsMs: 60000, ...intervals };

  const timers = [];
  let stopping = false;

  /** Run fn repeatedly; drain quickly while there is work, then wait `ms`. */
  function loop(name, ms, fn, hasMore = () => false) {
    let running = false;
    const tick = async () => {
      if (running || stopping) return;
      running = true;
      try {
        let result;
        do {
          result = await fn();
        } while (!stopping && hasMore(result));
      } catch (err) {
        logger.error({ err, loop: name }, 'worker loop error');
      } finally {
        running = false;
      }
    };
    timers.push(setInterval(tick, ms));
    tick();
    return tick;
  }

  function start() {
    loop('outbox', every.outboxMs, () => outbox.processBatch(20), (r) => r && r.events === 20);
    loop('sender', every.senderMs, () => sender.sendDue(50), (r) => r && r.claimed === 50);
    loop('monitors', every.monitorsMs, async () => {
      const r = await monitors.runAll();
      logger.debug({ monitors: r }, 'monitors ran');
      return r;
    });
    logger.info('Notification worker started');
  }

  function stop() {
    stopping = true;
    timers.forEach(clearInterval);
  }

  return { start, stop, outbox, sender, monitors };
}

module.exports = { createWorker };
