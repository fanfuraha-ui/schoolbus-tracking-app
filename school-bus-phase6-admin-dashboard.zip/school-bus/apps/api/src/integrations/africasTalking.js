'use strict';
/**
 * Africa's Talking SMS client (REST, no SDK).
 * POST {host}/version1/messaging  form-encoded: username, to, message, [from]
 * Header: apiKey. Sandbox host when username === 'sandbox'.
 * Response: { SMSMessageData: { Message, Recipients: [{ number, status, statusCode, messageId, cost }] } }
 * statusCode 100 (Processed), 101 (Sent), 102 (Queued) mean accepted.
 */
const { maskPhone } = require('../domain/phone');

const ACCEPTED_CODES = new Set([100, 101, 102]);

/** "KES 0.8000" -> 0.8 ; anything unparseable -> null */
function parseCost(cost) {
  const m = typeof cost === 'string' ? cost.match(/([\d.]+)/) : null;
  return m ? Number(m[1]) : null;
}

function createSmsClient({ username, apiKey, senderId, dryRun = false, logger, fetchImpl = globalThis.fetch, timeoutMs = 10000 }) {
  const host = username === 'sandbox' ? 'https://api.sandbox.africastalking.com' : 'https://api.africastalking.com';

  /**
   * Send one message to one or more numbers.
   * Returns [{ number, accepted, status, statusCode, messageId, cost }]
   */
  async function send({ to, message }) {
    const numbers = Array.isArray(to) ? to : [to];
    if (dryRun || !apiKey) {
      logger?.info({ to: numbers.map(maskPhone), chars: message.length }, 'SMS dry run (not sent)');
      return numbers.map((number) => ({
        number, accepted: true, status: 'DryRun', statusCode: 100, messageId: `dry-${Date.now()}-${number}`, cost: 0,
      }));
    }
    const body = new URLSearchParams({ username, to: numbers.join(','), message });
    if (senderId) body.set('from', senderId);

    const res = await fetchImpl(`${host}/version1/messaging`, {
      method: 'POST',
      headers: { apiKey, Accept: 'application/json', 'Content-Type': 'application/x-www-form-urlencoded' },
      body,
      signal: AbortSignal.timeout(timeoutMs),
    });
    const text = await res.text();
    if (!res.ok) throw new Error(`Africa's Talking HTTP ${res.status}: ${text.slice(0, 300)}`);
    let json;
    try { json = JSON.parse(text); } catch { throw new Error(`Africa's Talking returned non-JSON: ${text.slice(0, 200)}`); }
    const recipients = json?.SMSMessageData?.Recipients ?? [];
    return recipients.map((r) => ({
      number: r.number,
      accepted: ACCEPTED_CODES.has(Number(r.statusCode)),
      status: r.status,
      statusCode: Number(r.statusCode),
      messageId: r.messageId && r.messageId !== 'None' ? r.messageId : null,
      cost: parseCost(r.cost),
    }));
  }

  return { send };
}

module.exports = { createSmsClient, parseCost };
