'use strict';
const { z } = require('zod');

const bool = z.enum(['true', 'false', '1', '0']).transform((v) => v === 'true' || v === '1');

const schema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  PORT: z.coerce.number().int().min(1).max(65535).default(4000),
  LOG_LEVEL: z.enum(['fatal', 'error', 'warn', 'info', 'debug', 'trace']).default('info'),
  DATABASE_URL: z.string().min(1),
  DB_POOL_MAX: z.coerce.number().int().min(1).max(100).default(10),
  JWT_ACCESS_SECRET: z.string().min(32, 'JWT_ACCESS_SECRET must be at least 32 characters'),
  JWT_ACCESS_TTL: z.string().default('15m'),
  REFRESH_TTL_DAYS: z.coerce.number().int().min(1).max(365).default(30),
  OTP_PEPPER: z.string().min(16, 'OTP_PEPPER must be at least 16 characters'),
  CORS_ORIGINS: z.string().default('http://localhost:5173'),
  TRUST_PROXY: bool.default('false'),
  AT_USERNAME: z.string().default('sandbox'),
  AT_API_KEY: z.string().optional(),
  AT_SENDER_ID: z.string().max(11).optional(),
  SMS_DRY_RUN: bool.default('true'),
  // Africa's Talking delivery-report callback is accepted at /webhooks/africastalking/delivery/<secret>
  AT_WEBHOOK_SECRET: z.string().min(16).optional(),
  // Firebase service account JSON (raw or base64). Without it push runs in dry-run mode.
  FCM_SERVICE_ACCOUNT: z.string().optional(),
  PUSH_DRY_RUN: bool.default('false'),
});

function loadConfig(env = process.env) {
  const parsed = schema.safeParse(env);
  if (!parsed.success) {
    const lines = parsed.error.issues.map((i) => `  - ${i.path.join('.')}: ${i.message}`).join('\n');
    throw new Error(`Invalid environment configuration:\n${lines}`);
  }
  const e = parsed.data;
  if (e.NODE_ENV === 'production' && !e.SMS_DRY_RUN && !e.AT_API_KEY) {
    throw new Error('AT_API_KEY is required in production unless SMS_DRY_RUN=true');
  }
  return {
    env: e.NODE_ENV,
    port: e.PORT,
    logLevel: e.LOG_LEVEL,
    databaseUrl: e.DATABASE_URL,
    dbPoolMax: e.DB_POOL_MAX,
    jwtSecret: e.JWT_ACCESS_SECRET,
    accessTtl: e.JWT_ACCESS_TTL,
    refreshTtlDays: e.REFRESH_TTL_DAYS,
    otpPepper: e.OTP_PEPPER,
    corsOrigins: e.CORS_ORIGINS.split(',').map((s) => s.trim()).filter(Boolean),
    trustProxy: e.TRUST_PROXY,
    sms: { username: e.AT_USERNAME, apiKey: e.AT_API_KEY, senderId: e.AT_SENDER_ID, dryRun: e.SMS_DRY_RUN },
    atWebhookSecret: e.AT_WEBHOOK_SECRET ?? null,
    push: { serviceAccount: e.FCM_SERVICE_ACCOUNT ?? null, dryRun: e.PUSH_DRY_RUN },
  };
}

module.exports = { loadConfig };
