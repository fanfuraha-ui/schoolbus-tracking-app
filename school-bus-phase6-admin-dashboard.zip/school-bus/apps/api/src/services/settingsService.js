'use strict';
const { z } = require('zod');
const { badRequest } = require('../lib/errors');

const int = (min, max) => z.number().int().min(min).max(max);

/** Settings an admin may change from the dashboard, with validation per key. */
const EDITABLE = {
  school_name: z.string().trim().min(1).max(40),
  sms_sender_id: z.string().trim().min(1).max(11),
  default_approach_minutes: int(1, 30),
  default_stop_radius_m: int(20, 1000),
  delay_threshold_minutes: int(1, 120),
  delay_escalation_minutes: z.array(int(1, 240)).min(1).max(5)
    .refine((a) => a.every((v, i) => i === 0 || v > a[i - 1]), 'Must be strictly increasing'),
  stalled_minutes: int(2, 60),
  stalled_radius_m: int(10, 500),
  not_started_grace_minutes: int(1, 120),
  stale_point_max_age_s: int(30, 900),
  location_retention_days: int(7, 365),
  critical_events_force_sms: z.boolean(),
};

function createSettingsService({ db, ttlMs = 30000, clock = Date.now }) {
  let cache = null;
  let loadedAt = 0;

  async function all() {
    if (cache && clock() - loadedAt < ttlMs) return cache;
    const rows = await db.many('SELECT key, value FROM app_settings');
    cache = Object.fromEntries(rows.map((r) => [r.key, r.value]));
    loadedAt = clock();
    return cache;
  }

  async function get(key) {
    const s = await all();
    return s[key];
  }

  async function update(changes) {
    const parsed = {};
    for (const [key, value] of Object.entries(changes)) {
      const schema = EDITABLE[key];
      if (!schema) throw badRequest('setting_not_editable', `Setting "${key}" cannot be changed`);
      const result = schema.safeParse(value);
      if (!result.success) {
        throw badRequest('invalid_setting', `Invalid value for "${key}"`, result.error.issues);
      }
      parsed[key] = result.data;
    }
    await db.tx(async (t) => {
      for (const [key, value] of Object.entries(parsed)) {
        await t.query('UPDATE app_settings SET value = $2::jsonb WHERE key = $1', [key, JSON.stringify(value)]);
      }
    });
    cache = null;
    return all();
  }

  /** Values the trip engine/service need, with typed defaults. */
  async function tracking() {
    const s = await all();
    return {
      timezone: s.timezone || 'Africa/Nairobi',
      staleMaxAgeS: Number(s.stale_point_max_age_s ?? 120),
      schoolName: s.school_name || 'School',
    };
  }

  return { all, get, update, tracking, EDITABLE_KEYS: Object.keys(EDITABLE) };
}

module.exports = { createSettingsService };
