'use strict';
/**
 * Authentication for the three user types.
 *   Admin:  email + password (bcrypt)
 *   Driver: phone + 4-digit PIN, bound to one registered phone (first login binds it;
 *           an admin can reset the binding)
 *   Parent: phone + 6-digit SMS OTP
 * All return a short-lived JWT access token + a rotating refresh token.
 *
 * Dependencies are injected so this module has no hard dependency on bcrypt/jsonwebtoken:
 *   hasher:  { compare(plain, hash) -> Promise<boolean> }
 *   tokens:  { signAccess({id, role}) -> string }
 *   sms:     { send({to, message}) -> Promise<[...]> }
 */
const { sha256, hmacSha256, randomDigits, randomToken, safeEqual } = require('../lib/crypto');
const { normalizeKenyanPhone } = require('../domain/phone');
const { badRequest, unauthorized, forbidden, tooMany } = require('../lib/errors');
const { writeAudit } = require('./audit');

// bcrypt hash of a random string: compared against when the user doesn't exist, so a wrong
// email takes as long as a wrong password (no account enumeration by timing).
const DUMMY_HASH = '$2a$10$p443YAVQSm7rCqVp4loZoeu3tpvFelhu6C6RMFSkcBYyu15Y6S3sK';

const OTP_LENGTH = 6;
const OTP_TTL_MINUTES = 5;
const OTP_MAX_ATTEMPTS = 5;
const OTP_MAX_PER_WINDOW = 3;
const OTP_WINDOW_MINUTES = 15;
const LOGIN_MAX_FAILURES = 5;
const LOCK_MINUTES = 15;

function createAuthService({ db, hasher, tokens, sms, settings, otpPepper, refreshTtlDays = 30, logger }) {
  if (!otpPepper) throw new Error('otpPepper is required');

  const publicUser = (u) => ({ id: u.id, role: u.role, fullName: u.fullName });

  async function issueSession(user, deviceId) {
    const refreshToken = randomToken();
    await db.query(
      `INSERT INTO refresh_tokens (user_id, device_id, token_hash, expires_at)
       VALUES ($1, $2, $3, now() + make_interval(days => $4::int))`,
      [user.id, deviceId, sha256(refreshToken), refreshTtlDays],
    );
    await db.query(
      'UPDATE users SET last_login_at = now(), failed_login_count = 0, locked_until = NULL WHERE id = $1',
      [user.id],
    );
    return { accessToken: tokens.signAccess({ id: user.id, role: user.role }), refreshToken, user: publicUser(user) };
  }

  async function upsertDevice(userId, app, device = {}) {
    const { deviceUid, platform, fcmToken = null, appVersion = null } = device;
    if (!deviceUid) throw badRequest('device_required', 'deviceUid is required');
    if (fcmToken) {
      // An FCM token identifies one app install; detach it from any other user/device.
      await db.query(
        `UPDATE devices SET fcm_token = NULL
         WHERE fcm_token = $1 AND NOT (user_id = $2 AND device_uid = $3 AND app = $4)`,
        [fcmToken, userId, deviceUid, app],
      );
    }
    const row = await db.one(
      `INSERT INTO devices (user_id, device_uid, app, platform, fcm_token, app_version)
       VALUES ($1, $2, $3, $4, $5, $6)
       ON CONFLICT (user_id, device_uid, app) DO UPDATE
         SET platform = EXCLUDED.platform,
             fcm_token = COALESCE(EXCLUDED.fcm_token, devices.fcm_token),
             app_version = COALESCE(EXCLUDED.app_version, devices.app_version),
             last_seen_at = now()
       RETURNING id, device_uid`,
      [userId, deviceUid, app, platform, fcmToken, appVersion],
    );
    return row;
  }

  function assertNotLocked(user) {
    if (user.lockedUntil && new Date(user.lockedUntil) > new Date()) {
      throw tooMany('account_locked', 'Too many failed attempts. Try again in a few minutes or contact the school.');
    }
  }

  async function recordFailure(userId) {
    await db.query(
      `UPDATE users
         SET failed_login_count = failed_login_count + 1,
             locked_until = CASE WHEN failed_login_count + 1 >= $2
                                 THEN now() + make_interval(mins => $3::int) ELSE locked_until END
       WHERE id = $1`,
      [userId, LOGIN_MAX_FAILURES, LOCK_MINUTES],
    );
  }

  // ---------- Admin ----------
  async function adminLogin({ email, password, device }) {
    const user = await db.one(
      `SELECT id, role, full_name, password_hash, locked_until FROM users
       WHERE lower(email) = lower($1) AND role = 'admin' AND is_active`,
      [email],
    );
    if (!user) {
      await hasher.compare(password, DUMMY_HASH);
      throw unauthorized('invalid_credentials', 'Email or password is incorrect');
    }
    assertNotLocked(user);
    if (!(await hasher.compare(password, user.passwordHash))) {
      await recordFailure(user.id);
      throw unauthorized('invalid_credentials', 'Email or password is incorrect');
    }
    const dev = await upsertDevice(user.id, 'admin', { platform: 'web', ...device });
    return issueSession(user, dev.id);
  }

  // ---------- Driver ----------
  async function driverLogin({ phone, pin, device }) {
    const normalized = normalizeKenyanPhone(phone);
    if (!normalized) throw badRequest('invalid_phone', 'Enter a valid Kenyan mobile number');
    const user = await db.one(
      `SELECT u.id, u.role, u.full_name, u.pin_hash, u.locked_until,
              d.registered_device_id, rd.device_uid AS registered_device_uid
       FROM users u
       JOIN drivers d ON d.user_id = u.id
       LEFT JOIN devices rd ON rd.id = d.registered_device_id
       WHERE u.phone = $1 AND u.role = 'driver' AND u.is_active`,
      [normalized],
    );
    if (!user) {
      await hasher.compare(pin, DUMMY_HASH);
      throw unauthorized('invalid_credentials', 'Phone number or PIN is incorrect');
    }
    assertNotLocked(user);
    if (!(await hasher.compare(pin, user.pinHash))) {
      await recordFailure(user.id);
      throw unauthorized('invalid_credentials', 'Phone number or PIN is incorrect');
    }
    if (user.registeredDeviceId && user.registeredDeviceUid !== device?.deviceUid) {
      throw forbidden('device_not_registered', 'This phone is not registered for your account. Ask the transport office to reset it.');
    }
    const dev = await upsertDevice(user.id, 'driver', device);
    if (!user.registeredDeviceId) {
      await db.query('UPDATE drivers SET registered_device_id = $2 WHERE user_id = $1 AND registered_device_id IS NULL', [user.id, dev.id]);
      await writeAudit(db, { actorId: user.id, action: 'driver.device_bound', entity: 'drivers', entityId: user.id, changes: { deviceUid: [null, dev.deviceUid] } });
    }
    return issueSession(user, dev.id);
  }

  // ---------- Parent (OTP) ----------
  const otpHash = (phone, code) => hmacSha256(otpPepper, `${phone}:${code}`);

  async function requestOtp({ phone }) {
    const normalized = normalizeKenyanPhone(phone);
    if (!normalized) throw badRequest('invalid_phone', 'Enter a valid Kenyan mobile number');

    const recent = await db.one(
      `SELECT count(*)::int AS n FROM otp_codes
       WHERE phone = $1 AND created_at > now() - make_interval(mins => $2::int)`,
      [normalized, OTP_WINDOW_MINUTES],
    );
    if (recent.n >= OTP_MAX_PER_WINDOW) {
      throw tooMany('otp_rate_limited', 'Too many codes requested. Wait 15 minutes and try again.');
    }

    const guardian = await db.one(
      `SELECT u.id FROM users u JOIN guardians g ON g.user_id = u.id
       WHERE u.phone = $1 AND u.is_active`,
      [normalized],
    );
    const code = randomDigits(OTP_LENGTH);
    // A row is stored even for unknown numbers so rate limiting behaves identically and the
    // response can't be used to discover which numbers are registered.
    await db.query(
      `INSERT INTO otp_codes (phone, purpose, code_hash, expires_at)
       VALUES ($1, 'login', $2, now() + make_interval(mins => $3::int))`,
      [normalized, otpHash(normalized, code), OTP_TTL_MINUTES],
    );
    if (guardian) {
      const { schoolName } = await settings.tracking();
      await sms.send({
        to: normalized,
        message: `${code} is your ${schoolName} bus app code. It expires in ${OTP_TTL_MINUTES} minutes. Do not share it.`,
      });
    } else {
      logger?.info({ reason: 'unknown_phone' }, 'OTP requested for unregistered number (not sent)');
    }
    return { sent: true, expiresInSeconds: OTP_TTL_MINUTES * 60 };
  }

  async function verifyOtp({ phone, code, device }) {
    const normalized = normalizeKenyanPhone(phone);
    if (!normalized) throw badRequest('invalid_phone', 'Enter a valid Kenyan mobile number');
    const otp = await db.one(
      `SELECT id, code_hash, attempts FROM otp_codes
       WHERE phone = $1 AND purpose = 'login' AND consumed_at IS NULL AND expires_at > now()
       ORDER BY created_at DESC LIMIT 1`,
      [normalized],
    );
    if (!otp) throw unauthorized('otp_invalid', 'The code is wrong or has expired');
    if (otp.attempts >= OTP_MAX_ATTEMPTS) {
      throw tooMany('otp_attempts_exceeded', 'Too many wrong codes. Request a new one.');
    }
    if (!safeEqual(otp.codeHash, otpHash(normalized, String(code)))) {
      await db.query('UPDATE otp_codes SET attempts = attempts + 1 WHERE id = $1', [otp.id]);
      throw unauthorized('otp_invalid', 'The code is wrong or has expired');
    }
    const consumed = await db.one(
      'UPDATE otp_codes SET consumed_at = now() WHERE id = $1 AND consumed_at IS NULL RETURNING id',
      [otp.id],
    );
    if (!consumed) throw unauthorized('otp_invalid', 'The code is wrong or has expired');

    const user = await db.one(
      `SELECT u.id, u.role, u.full_name, g.consent_at FROM users u
       JOIN guardians g ON g.user_id = u.id WHERE u.phone = $1 AND u.is_active`,
      [normalized],
    );
    if (!user) throw unauthorized('otp_invalid', 'The code is wrong or has expired');
    const dev = await upsertDevice(user.id, 'parent', device);
    const session = await issueSession(user, dev.id);
    return { ...session, consentRequired: !user.consentAt };
  }

  // ---------- Refresh / logout ----------
  async function refresh({ refreshToken }) {
    const row = await db.one(
      `SELECT rt.id, rt.user_id, rt.device_id, rt.expires_at, rt.revoked_at,
              u.role, u.full_name, u.is_active
       FROM refresh_tokens rt JOIN users u ON u.id = rt.user_id
       WHERE rt.token_hash = $1`,
      [sha256(String(refreshToken))],
    );
    if (!row) throw unauthorized('refresh_invalid', 'Session expired. Please sign in again.');
    if (row.revokedAt) {
      // A revoked token was replayed: assume theft and end every session for this user.
      await db.query('UPDATE refresh_tokens SET revoked_at = now() WHERE user_id = $1 AND revoked_at IS NULL', [row.userId]);
      logger?.warn({ userId: row.userId }, 'Refresh token reuse detected; all sessions revoked');
      throw unauthorized('refresh_reused', 'Session expired. Please sign in again.');
    }
    if (new Date(row.expiresAt) <= new Date() || !row.isActive) {
      throw unauthorized('refresh_invalid', 'Session expired. Please sign in again.');
    }
    const revoked = await db.one(
      'UPDATE refresh_tokens SET revoked_at = now() WHERE id = $1 AND revoked_at IS NULL RETURNING id',
      [row.id],
    );
    if (!revoked) throw unauthorized('refresh_reused', 'Session expired. Please sign in again.');
    return issueSession({ id: row.userId, role: row.role, fullName: row.fullName }, row.deviceId);
  }

  async function logout({ refreshToken }) {
    await db.query(
      'UPDATE refresh_tokens SET revoked_at = now() WHERE token_hash = $1 AND revoked_at IS NULL',
      [sha256(String(refreshToken))],
    );
    return { ok: true };
  }

  async function registerPushToken(userId, app, device) {
    const dev = await upsertDevice(userId, app, device);
    return { deviceId: dev.id };
  }

  return { adminLogin, driverLogin, requestOtp, verifyOtp, refresh, logout, registerPushToken };
}

module.exports = { createAuthService, OTP_MAX_ATTEMPTS, LOGIN_MAX_FAILURES };
