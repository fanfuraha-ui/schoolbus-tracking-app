'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { freshDatabase, fakeSms, fakeTokens, pgHasher, quietLogger } = require('../support/context');
const { createSettingsService } = require('../../src/services/settingsService');
const { createAuthService } = require('../../src/services/authService');

let pool;
let db;
let auth;
let sms;

const device = (uid, platform = 'android') => ({ deviceUid: uid, platform });

test.before(async () => {
  ({ pool, db } = await freshDatabase('schoolbus_test_auth'));
  sms = fakeSms();
  auth = createAuthService({
    db, hasher: pgHasher(db), tokens: fakeTokens, sms,
    settings: createSettingsService({ db }), otpPepper: 'test-pepper-0123456789', logger: quietLogger,
  });
});
test.after(() => pool.end());

test('admin: correct password logs in; wrong password is rejected', async () => {
  const s = await auth.adminLogin({ email: 'ADMIN@school.test', password: 'ChangeMe!2026', device: device('web-1', 'web') });
  assert.match(s.accessToken, /^access:.+:admin$/);
  assert.ok(s.refreshToken.length > 30);
  await assert.rejects(auth.adminLogin({ email: 'admin@school.test', password: 'nope', device: device('web-1', 'web') }), { code: 'invalid_credentials' });
  await assert.rejects(auth.adminLogin({ email: 'ghost@school.test', password: 'x', device: device('web-1', 'web') }), { code: 'invalid_credentials' });
});

test('admin: account locks after 5 failures', async () => {
  for (let i = 0; i < 5; i += 1) {
    await assert.rejects(auth.adminLogin({ email: 'admin@school.test', password: `bad${i}`, device: device('web-1', 'web') }));
  }
  await assert.rejects(
    auth.adminLogin({ email: 'admin@school.test', password: 'ChangeMe!2026', device: device('web-1', 'web') }),
    { code: 'account_locked', status: 429 },
  );
  await db.query("UPDATE users SET locked_until = NULL, failed_login_count = 0 WHERE email = 'admin@school.test'");
});

test('driver: first login binds the phone; other phones are refused', async () => {
  const s = await auth.driverLogin({ phone: '0700000002', pin: '1234', device: device('driver-phone-A') });
  assert.equal(s.user.role, 'driver');
  await assert.rejects(
    auth.driverLogin({ phone: '+254700000002', pin: '1234', device: device('someone-elses-phone') }),
    { code: 'device_not_registered', status: 403 },
  );
  const again = await auth.driverLogin({ phone: '254700000002', pin: '1234', device: device('driver-phone-A') });
  assert.equal(again.user.id, s.user.id);
  const audit = await db.one("SELECT count(*)::int AS n FROM audit_logs WHERE action = 'driver.device_bound'");
  assert.equal(audit.n, 1);
  await assert.rejects(auth.driverLogin({ phone: '0700000002', pin: '9999', device: device('driver-phone-A') }), { code: 'invalid_credentials' });
});

test('parent OTP: wrong code counts attempts, right code signs in once', async () => {
  const r = await auth.requestOtp({ phone: '0711000001' });
  assert.equal(r.sent, true);
  const msg = sms.sent.at(-1);
  assert.equal(msg.to, '+254711000001');
  const code = msg.message.match(/^(\d{6})/)[1];
  assert.ok(msg.message.includes('Greenfield Academy'));

  const wrong = code === '000000' ? '111111' : '000000';
  await assert.rejects(auth.verifyOtp({ phone: '0711000001', code: wrong, device: device('parent-1') }), { code: 'otp_invalid' });
  const s = await auth.verifyOtp({ phone: '0711000001', code, device: device('parent-1') });
  assert.equal(s.user.role, 'guardian');
  assert.equal(s.consentRequired, false);
  await assert.rejects(auth.verifyOtp({ phone: '0711000001', code, device: device('parent-1') }), { code: 'otp_invalid' }, 'code cannot be reused');
});

test('parent OTP: unknown numbers get the same response but no SMS; requests are rate limited', async () => {
  const before = sms.sent.length;
  const r = await auth.requestOtp({ phone: '0799999999' });
  assert.equal(r.sent, true);
  assert.equal(sms.sent.length, before, 'no SMS to unregistered numbers');
  await auth.requestOtp({ phone: '0799999999' });
  await auth.requestOtp({ phone: '0799999999' });
  await assert.rejects(auth.requestOtp({ phone: '0799999999' }), { code: 'otp_rate_limited', status: 429 });
  await assert.rejects(auth.requestOtp({ phone: '12345' }), { code: 'invalid_phone' });
});

test('parent OTP: locks after 5 wrong attempts', async () => {
  await auth.requestOtp({ phone: '0711000002' });
  const code = sms.sent.at(-1).message.slice(0, 6);
  const wrong = code === '000000' ? '111111' : '000000';
  for (let i = 0; i < 5; i += 1) {
    await assert.rejects(auth.verifyOtp({ phone: '0711000002', code: wrong, device: device('p2') }));
  }
  await assert.rejects(auth.verifyOtp({ phone: '0711000002', code, device: device('p2') }), { code: 'otp_attempts_exceeded' });
});

test('refresh tokens rotate; replaying an old one revokes every session', async () => {
  const s1 = await auth.adminLogin({ email: 'admin@school.test', password: 'ChangeMe!2026', device: device('web-2', 'web') });
  const s2 = await auth.refresh({ refreshToken: s1.refreshToken });
  assert.notEqual(s2.refreshToken, s1.refreshToken);
  await assert.rejects(auth.refresh({ refreshToken: s1.refreshToken }), { code: 'refresh_reused' });
  await assert.rejects(auth.refresh({ refreshToken: s2.refreshToken }), { code: 'refresh_reused' }, 'stolen-token defence revoked the new one too');
  const s3 = await auth.adminLogin({ email: 'admin@school.test', password: 'ChangeMe!2026', device: device('web-2', 'web') });
  await auth.logout({ refreshToken: s3.refreshToken });
  await assert.rejects(auth.refresh({ refreshToken: s3.refreshToken }));
});

test('push token moves with the device install', async () => {
  const s = await auth.verifyOtp(await (async () => {
    await auth.requestOtp({ phone: '0711000003' });
    return { phone: '0711000003', code: sms.sent.at(-1).message.slice(0, 6), device: device('shared-tablet') };
  })());
  await auth.registerPushToken(s.user.id, 'parent', { deviceUid: 'shared-tablet', platform: 'android', fcmToken: 'fcm-token-xyz-123' });
  const row = await db.one("SELECT user_id FROM devices WHERE fcm_token = 'fcm-token-xyz-123'");
  assert.equal(row.userId, s.user.id);
});
