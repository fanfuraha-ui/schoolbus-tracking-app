'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { freshDatabase, fakeBroadcaster, quietLogger } = require('../support/context');
const { createSettingsService } = require('../../src/services/settingsService');
const { createTripService } = require('../../src/services/tripService');
const { createWorker } = require('../../src/worker');
const { PushError } = require('../../src/integrations/fcm');

let pool;
let db;
let trips;
let worker;
const sms = {
  calls: [], behaviour: 'ok',
  async send({ to, message }) {
    const numbers = Array.isArray(to) ? to : [to];
    this.calls.push({ numbers, message });
    if (this.behaviour === 'throw') throw new Error('network down');
    return numbers.map((number) => (this.behaviour === 'invalid'
      ? { number, accepted: false, statusCode: 403, status: 'InvalidPhoneNumber' }
      : { number, accepted: true, statusCode: 101, status: 'Success', messageId: `ATX-${this.calls.length}-${number}`, cost: 0.8 }));
  },
};
const push = {
  calls: [], failFor: new Map(),
  async send(msg) {
    this.calls.push(msg);
    const f = this.failFor.get(msg.token);
    if (f) throw new PushError('fail', f);
    return { messageId: `projects/x/messages/${this.calls.length}` };
  },
};

const SCHOOL = { lat: -1.2463, lng: 36.6629 };
const onRoute = (n, km) => ({
  lat: SCHOOL.lat + (km / 111) * Math.cos((n * 60 * Math.PI) / 180),
  lng: SCHOOL.lng + (km / 111) * Math.sin((n * 60 * Math.PI) / 180),
});
const guardianOf = async (household) => (await db.one('SELECT id FROM users WHERE phone = $1', [`+254711${String(household).padStart(6, '0')}`])).id;
const drain = async () => { await worker.outbox.processBatch(200); return worker.sender.sendDue(1000); };

let route2Trip;
let g58; let g59; let g60x;

test.before(async () => {
  ({ pool, db } = await freshDatabase('schoolbus_test_worker'));
  const settings = createSettingsService({ db });
  trips = createTripService({ db, settings, broadcaster: fakeBroadcaster(), logger: quietLogger });
  worker = createWorker({ db, settings, sms, push, logger: quietLogger });

  // Route 2 morning stop 1 (Stage 10) serves students 58, 59, 60. 59 and 60 are siblings (household 59).
  g58 = await guardianOf(58);
  g59 = await guardianOf(59);
  await db.query(
    `INSERT INTO devices (user_id, device_uid, app, platform, fcm_token) VALUES ($1, 'phone-58', 'parent', 'android', 'tok-58')`,
    [g58],
  );
  g60x = g59;
});
test.after(() => pool.end());

test('GPS-driven alerts: one alert per guardian (siblings merged), push when the app is installed, identical SMS batched', async () => {
  const drv = (await db.one("SELECT id FROM users WHERE phone = '+254700000002'")).id;
  const am = (await db.one("SELECT sc.id FROM schedules sc JOIN routes r ON r.id = sc.route_id WHERE r.name LIKE 'Route 2%' AND sc.direction = 'to_school'")).id;
  route2Trip = (await trips.startTrip({ scheduleId: am, driverId: drv })).trip.id;
  const now = Date.now();
  const pts = [6.8, 6.6, 6.4, 6.2, 6.05, 6.0].map((km, i, a) => ({
    ...onRoute(2, km), speedMps: 8, accuracyM: 6, recordedAt: new Date(now - (a.length - i) * 10000),
  }));
  await trips.ingestPoints({ tripId: route2Trip, driverId: drv, points: pts });

  const out = await worker.outbox.processBatch(50);
  assert.ok(out.events >= 2 && out.failed === 0, JSON.stringify(out));
  const stop1 = (await db.one('SELECT id FROM stops WHERE schedule_id = $1 AND sequence = 1', [am])).id;
  const rows = await db.many(
    "SELECT guardian_id, channel, body, event_type FROM notifications WHERE trip_id = $1 AND stop_id = $2 AND event_type = 'approaching'",
    [route2Trip, stop1],
  );
  assert.equal(rows.length, 2, 'two households at stop 1 (siblings collapsed)');
  assert.equal(rows.find((r) => r.guardianId === g58).channel, 'push');
  assert.equal(rows.find((r) => r.guardianId === g59).channel, 'sms');
  assert.match(rows[0].body, /^Bus KDA 102B is about \d+ min from Gikambura Stage 10\. -Greenfield Academy$/);

  sms.calls.length = 0;
  const sent = await worker.sender.sendDue(100);
  assert.equal(sent.failed, 0);
  assert.ok(push.calls.some((c) => c.token === 'tok-58' && c.title.startsWith('Bus is')));
  const approachSms = sms.calls.filter((c) => c.message.includes('is about'));
  assert.ok(approachSms.every((c) => c.numbers.length >= 1));
  const statuses = await db.many("SELECT status, provider_message_id, cost_kes FROM notifications WHERE trip_id = $1 AND channel = 'sms'", [route2Trip]);
  assert.ok(statuses.every((s) => s.status === 'sent' && s.providerMessageId && s.costKes === 0.8));
});

test('replaying the outbox never duplicates notifications', async () => {
  const before = (await db.one('SELECT count(*)::int AS n FROM notifications')).n;
  await db.query('UPDATE trip_events SET processed_at = NULL WHERE trip_id = $1', [route2Trip]);
  await worker.outbox.processBatch(50);
  assert.equal((await db.one('SELECT count(*)::int AS n FROM notifications')).n, before);
});

test('boarding alerts go to that child\'s guardian; dead push token falls back to SMS and is forgotten', async () => {
  const drv = (await db.one("SELECT id FROM users WHERE phone = '+254700000002'")).id;
  const s58 = (await db.one("SELECT id FROM students WHERE admission_no = 'ADM0058'")).id;
  push.failFor.set('tok-58', { unregistered: true, status: 404 });
  await trips.recordStudentEvent({ tripId: route2Trip, driverId: drv, studentId: s58, status: 'boarded' });
  sms.calls.length = 0;
  await drain();                    // push fails -> SMS fallback row created
  await worker.sender.sendDue(100); // fallback SMS sent
  const n = await db.many("SELECT channel, status, error FROM notifications WHERE event_type = 'boarded' AND guardian_id = $1 ORDER BY created_at", [g58]);
  assert.deepEqual(n.map((x) => [x.channel, x.status]), [['push', 'failed'], ['sms', 'sent']]);
  assert.ok(sms.calls.some((c) => c.message.startsWith('Student boarded bus KDA 102B')));
  assert.equal((await db.one("SELECT fcm_token FROM devices WHERE device_uid = 'phone-58'")).fcmToken, null);
  push.failFor.clear();
});

test('quiet hours suppress routine alerts but never critical ones; critical = SMS + push', async () => {
  // Quiet window covering "now" for household 59; give them the app too.
  // Household 55's child waits at stop 2 (bus not there yet); household 59's children are on the bus.
  const g55 = await guardianOf(55);
  await db.query(
    `UPDATE guardians SET quiet_hours_start = ((now() AT TIME ZONE 'Africa/Nairobi') - interval '1 hour')::time,
                          quiet_hours_end = ((now() AT TIME ZONE 'Africa/Nairobi') + interval '1 hour')::time
     WHERE user_id = ANY($1::uuid[])`, [[g55, g59]],
  );
  await db.query("INSERT INTO devices (user_id, device_uid, app, platform, fcm_token) VALUES ($1, 'phone-59', 'parent', 'ios', 'tok-59')", [g59]);
  const drv = (await db.one("SELECT id FROM users WHERE phone = '+254700000002'")).id;
  await trips.reportIncident({ tripId: route2Trip, driverId: drv, type: 'traffic', notifyParents: true });
  await trips.reportIncident({ tripId: route2Trip, driverId: drv, type: 'breakdown', note: 'Engine' });
  sms.calls.length = 0; push.calls.length = 0;
  await drain();

  const delay = await db.many("SELECT status, error FROM notifications WHERE event_type = 'delay' AND guardian_id = $1", [g55]);
  assert.deepEqual(delay.map((d) => [d.status, d.error]), [['skipped', 'quiet_hours']]);
  const onBoard = await db.many("SELECT 1 FROM notifications WHERE event_type = 'delay' AND guardian_id = $1", [g59]);
  assert.equal(onBoard.length, 0, 'delay alerts go only to parents still waiting at a stop');
  const crit = await db.many("SELECT channel, status FROM notifications WHERE event_type = 'breakdown' AND guardian_id = $1 ORDER BY channel", [g59]);
  assert.deepEqual(crit.map((c) => [c.channel, c.status]), [['push', 'sent'], ['sms', 'sent']]);
  assert.ok(sms.calls.some((c) => c.message.startsWith('IMPORTANT: Bus KDA 102B has broken down')));
  assert.ok(push.calls.some((c) => c.critical === true));
});

test('sender: network failure retries with backoff; invalid numbers fail permanently; stale alerts expire', async () => {
  const g = await guardianOf(1);
  const insert = (key, extra = '') => db.one(
    `INSERT INTO notifications (dedupe_key, channel, guardian_id, event_type, to_address, body${extra ? ', created_at' : ''})
     VALUES ($1, 'sms', $2, 'delay', '+254711000001', 'Test message'${extra ? `, ${extra}` : ''}) RETURNING id`, [key, g],
  );
  const a = await insert('t:retry');
  sms.behaviour = 'throw';
  await worker.sender.sendDue(100);
  let row = await db.one('SELECT status, attempts, next_attempt_at > now() AS later FROM notifications WHERE id = $1', [a.id]);
  assert.deepEqual([row.status, row.attempts, row.later], ['queued', 1, true]);
  sms.behaviour = 'ok';
  await db.query('UPDATE notifications SET next_attempt_at = now() WHERE id = $1', [a.id]);
  await worker.sender.sendDue(100);
  assert.equal((await db.one('SELECT status FROM notifications WHERE id = $1', [a.id])).status, 'sent');

  const b = await insert('t:invalid');
  sms.behaviour = 'invalid';
  await worker.sender.sendDue(100);
  row = await db.one('SELECT status, error FROM notifications WHERE id = $1', [b.id]);
  assert.deepEqual([row.status, row.error], ['failed', '403 InvalidPhoneNumber']);
  sms.behaviour = 'ok';

  const c = await insert('t:stale', "now() - interval '30 minutes'");
  await worker.sender.sendDue(100);
  row = await db.one('SELECT status, error FROM notifications WHERE id = $1', [c.id]);
  assert.deepEqual([row.status, row.error], ['skipped', 'expired']);
});

test('cancellation reaches every guardian on the trip', async () => {
  const admin = (await db.one("SELECT id FROM users WHERE role = 'admin'")).id;
  await trips.cancelTrip({ tripId: route2Trip, actor: { id: admin, role: 'admin' }, reason: 'Bus breakdown, parents please collect' });
  await drain();
  const n = await db.one(
    "SELECT count(DISTINCT guardian_id)::int AS g, count(*) FILTER (WHERE channel = 'sms')::int AS s FROM notifications WHERE trip_id = $1 AND event_type = 'trip_cancelled'",
    [route2Trip],
  );
  assert.equal(n.g, 25, '30 children, 25 households');
  assert.equal(n.s, 25, 'every guardian gets the SMS for critical events');
});

// ---------- monitors ----------
test('planner: skips no-service days, otherwise creates today\'s scheduled trips with stop rows', async () => {
  // Make every schedule start an hour from now so the result doesn't depend on the time of day.
  await db.query("UPDATE schedules SET start_time = ((now() AT TIME ZONE 'Africa/Nairobi') + interval '1 hour')::time");
  await db.query("INSERT INTO no_service_days (service_date, reason) VALUES ((now() AT TIME ZONE 'Africa/Nairobi')::date, 'Mid-term break')");
  assert.equal((await worker.monitors.planTrips()).created, 0);
  await db.query('DELETE FROM no_service_days');
  const r = await worker.monitors.planTrips();
  assert.equal(r.created, 10, '12 schedules minus Route 1 AM (active) and Route 2 AM (cancelled)');
  assert.equal((await worker.monitors.planTrips()).created, 0, 'idempotent');
  // A run that should already be over (started 2 h ago) is never planned.
  await db.query("DELETE FROM trips WHERE status = 'scheduled'");
  await db.query("UPDATE schedules SET start_time = ((now() AT TIME ZONE 'Africa/Nairobi') - interval '2 hours')::time");
  assert.equal((await worker.monitors.planTrips()).created, 0, 'past runs are not planned');
  await db.query("UPDATE schedules SET start_time = ((now() AT TIME ZONE 'Africa/Nairobi') + interval '1 hour')::time");
  assert.equal((await worker.monitors.planTrips()).created, 10);
  const missing = await db.one(
    `SELECT count(*)::int AS n FROM trips t WHERE t.status = 'scheduled'
       AND NOT EXISTS (SELECT 1 FROM trip_stop_events e WHERE e.trip_id = t.id)`,
  );
  assert.equal(missing.n, 0);
});

test('delays escalate once per level, even for a bus that has not started', async () => {
  const am3 = (await db.one("SELECT sc.id FROM schedules sc JOIN routes r ON r.id = sc.route_id WHERE r.name LIKE 'Route 3%' AND sc.direction = 'to_school'")).id;
  const setLate = (min) => db.query(
    `UPDATE stops SET scheduled_time = ((now() AT TIME ZONE 'Africa/Nairobi') - make_interval(mins => $2::int))::time WHERE schedule_id = $1 AND sequence = 1;
     `.trim(), [am3, min],
  );
  await db.query("UPDATE trips SET scheduled_start_at = now() - interval '40 minutes' WHERE schedule_id = $1", [am3]);
  await setLate(23);
  await worker.monitors.checkDelays();
  await worker.monitors.checkDelays();
  let ev = await db.many("SELECT escalation, payload FROM trip_events te JOIN trips t ON t.id = te.trip_id WHERE t.schedule_id = $1 AND event_type = 'delay'", [am3]);
  assert.deepEqual(ev.map((e) => e.escalation), [2], 'jumped straight to level 2 (20 min), sent once');
  await setLate(12);
  await worker.monitors.checkDelays();
  assert.equal((await db.many("SELECT 1 FROM trip_events te JOIN trips t ON t.id = te.trip_id WHERE t.schedule_id = $1 AND event_type = 'delay'", [am3])).length, 1, 'no step back down to level 1');
  await setLate(31);
  await worker.monitors.checkDelays();
  ev = await db.many("SELECT escalation FROM trip_events te JOIN trips t ON t.id = te.trip_id WHERE t.schedule_id = $1 AND event_type = 'delay' ORDER BY escalation", [am3]);
  assert.deepEqual(ev.map((e) => e.escalation), [2, 3]);

  sms.calls.length = 0;
  await drain();
  assert.ok(sms.calls.some((c) => /KDA 103C is running about 3\d min late/.test(c.message)));

  // Not started for more than 90 min: no more parent delay alerts (office handles it).
  const am4 = (await db.one("SELECT sc.id FROM schedules sc JOIN routes r ON r.id = sc.route_id WHERE r.name LIKE 'Route 4%' AND sc.direction = 'to_school'")).id;
  await db.query("UPDATE trips SET scheduled_start_at = now() - interval '3 hours' WHERE schedule_id = $1", [am4]);
  await db.query("UPDATE stops SET scheduled_time = ((now() AT TIME ZONE 'Africa/Nairobi') - interval '170 minutes')::time WHERE schedule_id = $1", [am4]);
  await worker.monitors.checkDelays();
  const r4 = await db.one("SELECT count(*)::int AS n FROM trip_events te JOIN trips t ON t.id = te.trip_id WHERE t.schedule_id = $1 AND event_type = 'delay'", [am4]);
  assert.equal(r4.n, 0);
});

test('not-started and GPS-lost incidents are raised once and resolve themselves', async () => {
  let r = await worker.monitors.checkNotStarted();
  assert.ok(r.raised >= 1);
  assert.equal((await worker.monitors.checkNotStarted()).raised, 0, 'not raised twice');
  const am3Trip = (await db.one("SELECT t.id, t.driver_id, t.schedule_id FROM trips t JOIN schedules sc ON sc.id = t.schedule_id JOIN routes r ON r.id = sc.route_id WHERE r.name LIKE 'Route 3%' AND sc.direction = 'to_school'"));
  await trips.startTrip({ scheduleId: am3Trip.scheduleId, driverId: am3Trip.driverId });
  r = await worker.monitors.checkNotStarted();
  assert.ok(r.resolved >= 1);
  const inc = await db.one("SELECT resolved_at IS NOT NULL AS closed FROM incidents WHERE trip_id = $1 AND type = 'not_started'", [am3Trip.id]);
  assert.equal(inc.closed, true);

  await db.query("UPDATE trips SET started_at = now() - interval '20 minutes', last_point_at = now() - interval '9 minutes' WHERE id = $1", [am3Trip.id]);
  await worker.monitors.checkGps();
  const lost = () => db.one("SELECT resolved_at IS NOT NULL AS closed FROM incidents WHERE trip_id = $1 AND type = 'gps_lost'", [am3Trip.id]);
  assert.equal((await lost()).closed, false);
  await worker.monitors.checkGps();
  assert.equal((await db.one("SELECT count(*)::int AS n FROM incidents WHERE trip_id = $1 AND type = 'gps_lost'", [am3Trip.id])).n, 1, 'raised once');
  await db.query('UPDATE trips SET last_point_at = now() WHERE id = $1', [am3Trip.id]);
  await worker.monitors.checkGps();
  assert.equal((await lost()).closed, true, 'resolved when GPS returns');
});

test('stalled bus (parked away from any stop) raises an admin incident only', async () => {
  const t = await db.one("SELECT t.id FROM trips t JOIN schedules sc ON sc.id = t.schedule_id JOIN routes r ON r.id = sc.route_id WHERE r.name LIKE 'Route 3%' AND sc.direction = 'to_school'");
  const spot = onRoute(3, 3.3); // between Stage 5 (3.0 km) and Stage 6 (3.6 km)
  await db.query(
    `INSERT INTO location_points (trip_id, recorded_at, lat, lng, speed_mps, accuracy_m)
     SELECT $1, now() - make_interval(secs => g * 30), $2, $3, 0, 5 FROM generate_series(0, 18) g
     ON CONFLICT DO NOTHING`,
    [t.id, spot.lat, spot.lng],
  );
  await db.query("UPDATE trips SET last_point_at = now(), started_at = now() - interval '30 minutes' WHERE id = $1", [t.id]);
  const r = await worker.monitors.checkStalled();
  assert.equal(r.raised, 1);
  const parentsTold = await db.one("SELECT count(*)::int AS n FROM trip_events WHERE trip_id = $1 AND event_type = 'stalled'", [t.id]);
  assert.equal(parentsTold.n, 0);
  assert.equal((await worker.monitors.checkStalled()).raised, 0);
});

test('nightly maintenance runs once per day', async () => {
  const hour = (await db.one("SELECT extract(hour FROM now() AT TIME ZONE 'Africa/Nairobi')::int AS h")).h;
  const yesterdayTrip = await db.one(
    `INSERT INTO trips (schedule_id, service_date, bus_id, driver_id, status, scheduled_start_at)
     SELECT schedule_id, service_date - 1, bus_id, driver_id, 'scheduled', scheduled_start_at - interval '1 day'
     FROM trips WHERE status = 'scheduled' LIMIT 1 RETURNING id`,
  );
  const first = await worker.monitors.nightly();
  if (hour >= 2) {
    assert.equal(first.ran, true);
    assert.equal(first.closedNotRun, 1);
    const closed = await db.one('SELECT status FROM trips WHERE id = $1', [yesterdayTrip.id]);
    assert.equal(closed.status, 'cancelled');
    assert.equal((await db.one("SELECT count(*)::int AS n FROM trip_events WHERE trip_id = $1", [yesterdayTrip.id])).n, 0, 'closed silently');
    assert.equal((await worker.monitors.nightly()).ran, false);
  } else {
    assert.equal(first.ran, false);
  }
});

test('runAll isolates failures and reports each monitor', async () => {
  const r = await worker.monitors.runAll();
  assert.deepEqual(Object.keys(r), ['planTrips', 'checkDelays', 'checkNotStarted', 'checkGps', 'checkStalled', 'nightly']);
  assert.ok(Object.values(r).every((x) => !x.error), JSON.stringify(r));
});
